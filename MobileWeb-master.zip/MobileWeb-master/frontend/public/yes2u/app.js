var app = angular.module('yes2uApp', ['ngRoute', 'ngDialog']);

/*Routing Yes 2 Rewards templates*/
app.config(function ($routeProvider) {
    $routeProvider
        .when('/', 
            {
                controller: 'yes2uCtrl',
                templateUrl: '/yes2u/views/mcom-rewards-landing.html',
                resolve: {
                    loyaltyData: function(yes2uRewards) {
                      return yes2uRewards.loyaltyProfileData();
                    }
                }
            })
        .when('/enrollrewards', 
            {
                controller: 'yes2uCtrl',
                templateUrl: '/yes2u/views/mcom-rewards-landing.html',
                resolve: {
                    loyaltyData: function(yes2uRewards) {
                      return yes2uRewards.loyaltyProfileData();
                    }
                }
            })
        //Define a route that has a route parameter in it (:signup store)
        .when('/signedinstore',
            {
                controller: 'rwdsJoinedStoreCtrl',
                templateUrl: '/yes2u/views/signup-store.html'
            })
        //Define a route that has a route parameter in it (:rewards activity)
        .when('/mcom-rewards-activity',
            {
                controller: 'yes2uActivityCtrl',
                templateUrl: '/yes2u/views/mcom-rewards-activity.html'
            })
         .when('/rewards-activity-details:id',
            {
                controller:'rwdsactivitydetails',
                templateUrl:'/yes2u/views/mcom-activity-details.html',
                
            })
        //Define a route that has a route parameter in it (:invite friend)
         .when('/mcom-invite-friend',
            {
                controller: 'yes2uInvitFrdCtrl',
                templateUrl: '/yes2u/views/mcom-invite-friend.html'
            })
        //Define a route that has a route parameter in it (:share or donate)
         .when('/mcom-share-rewards',
            {
                controller: 'yes2uShareCtrl',
                templateUrl: '/yes2u/views/mcom-share-rewards.html',
                resolve: {
                    loyaltyData: function(yes2uRewards) {
                      return yes2uRewards.loyaltyProfileData();
                    }
                }
            })
         .when('/mcom-share-successful',
            {
                controller: 'yes2uShareSuccessCtrl',
                templateUrl: '/yes2u/views/share-points-success.html'
            })
         .when('/mcom-donate-rewards',
            {
                controller: 'yes2uDonateCtrl',
                templateUrl: '/yes2u/views/mcom-donate-rewards.html',
                resolve: {
                    loyaltyData: function(yes2uRewards) {
                      return yes2uRewards.loyaltyProfileData();
                    }
                }
            })
         .when('/mcom-donate-successful',
            {
                controller: 'yes2uDonateSuccessCtrl',
                templateUrl: '/yes2u/views/mcom-donate-success.html'
            })
         //Define a route that has a route parameter in it (:User Info)
         .when('/mcom-rewards-info',
            {
                controller: 'yes2uInfoCtrl',
                templateUrl: '/yes2u/views/mcom-rewards-info.html',
                resolve: {
                    loyaltyData: function(yes2uRewards) {
                      return yes2uRewards.loyaltyProfileData();
                    }
                }
            })
        //.otherwise({ redirectTo: '/yes2u/views/mcom-rewards-landing.html' });
        //Define a route that has a route parameter in it (:rewards phone edit)
         .when('/mcom-rewards-phone',
            {
                controller: 'rwdsSavePhone',
                templateUrl: '/yes2u/views/mcom-rewards-phone.html',
                resolve: {
                    loyaltyData: function(yes2uRewards) {
                      return yes2uRewards.loyaltyProfileData();
                    }
                }
            })
        //Define a route that has a route parameter in it (:rewards address edit)
         .when('/mcom-rewards-address',
            {
                controller: 'rwdsSaveAddress',
                templateUrl: '/yes2u/views/mcom-rewards-address.html',
                resolve: {
                    loyaltyData: function(yes2uRewards) {
                      return yes2uRewards.loyaltyProfileData();
                    }
                }
            })
       
  });
/*end*/
