var KOHLS = KOHLS||{};
KOHLS.$ele = function(ele) {
  return document.getElementById(ele);
}
KOHLS.loylaty = {
	readCookie: function(cookieKey) {
    var cookieNameEQ = cookieKey + "=",
        ca = document.cookie.split(";"),
        c;
    for (var i = 0; i < ca.length; i++) {
        c = ca[i];
        while (c.charAt(0) == " ") {
            c = c.substring(1, c.length);
        }
        if (c.indexOf(cookieNameEQ) === 0) {
            return c.substring(cookieNameEQ.length, c.length);
        }
    }
    return null;
  },
  handleBackendReferFriendErrors: function(response, $scope){
    console.log('inside handleBackedErrors');
    var backendErrors = [];
    if (response && response.referees[0].error){
      backendErrors = response.referees[0].error.message;
      $scope.displayErrMsg=backendErrors;
    }
    else{
      KOHLS.$ele('successMsg').classList.remove('hide');
      $scope.displayErrMsg = '';
      KOHLS.$ele('invite-btn').innerHTML = "Invite more friends";
      if(kohlsData.successMsgDisplay){
        setTimeout(function(){
          KOHLS.$ele('successMsg').classList.add('hide');
          KOHLS.$ele('invite-btn').innerHTML = "Invite";
        }, kohlsData.successMsgDisplay);
      }
    }
  },
  incrementValue :function(obj){
    var pointBalance = obj.getAttribute('data-attr');
    if(parseInt(KOHLS.$ele('rwdQty').value) < parseInt(pointBalance)){
        KOHLS.$ele('rwdQty').value++;
    }
    else {
       KOHLS.$ele('qtyErrMsg').classList.remove('display-none');
    }
  },
  decrementValue : function(){
    if (KOHLS.$ele('rwdQty').value != 0){
      KOHLS.$ele('rwdQty').value--;
    }
  },
  enrollTrigger : function(){
      if(KOHLS_HYBRID.utils.isLoggedIn()){
        $(window).scrollTop($('#rewardsEnrollForm').offset().top);
      }
      else{
        KOHLS_HYBRID.utils.showLogin(kohlsData.isTcom, true,'','loyalty');
        document.body.classList.add('t-login-mask');
      }
  },
  SignInTrigger : function() {
      if(KOHLS_HYBRID.utils.isLoggedIn()){
        location.href = '/checkout/checkout.jsp#/myInfoLanding';
      }
      else{
        document.body.classList.add('t-login-mask');
        KOHLS_HYBRID.utils.showLogin(kohlsData.isTcom,false,'','loyalty');
      }
  },
  triggerOmniture: function(pageType){
	  var chnl = kohlsData.isTcom?'t':'m';
	  var LoyaltyOmniValues = {
		pageName: chnl+'>my account:rewards:'+pageType,
		events: 'event38',
		prop4:chnl+'|my account',
		prop9:'my account|rewards',
		eVar68:chnl+'>my account:rewards:'+pageType,
		prop53:chnl+'>my account:rewards:'+pageType
	  };
	  KOHLS_HYBRID.browseSiteCatalyst(LoyaltyOmniValues);
  }
};
var loyaltyId = parseInt(KOHLS.loylaty.readCookie('loyaltyId')) ? KOHLS.loylaty.readCookie('loyaltyId') : false;
var walletToken  = KOHLS.loylaty.readCookie('wallet_token');
/*Global factory*/
app.factory('yes2uRewards', ['$http', '$rootScope', function($http, $root){
  var factory = {
      loyaltyProfileData : function(){
        //if($root.loyaltyData && $root.loyaltyData.data){
          //return $root.loyaltyData;
        //} else {
          if(loyaltyId && walletToken) {
          var promise = $http({
              method : 'GET',
              url : kohlsData.walletDomain+'/wallet/v2/loyalty/profiles/'+loyaltyId,
              headers: {'Content-Type': 'application/json', 'token':walletToken}
          })
          promise.success(function(data){
              return data;
          });
          promise.error(function(data){
              console.log("Loyalty profile service is down");
              KOHLS.$ele('loader-img').classList.add('display-none');
              return data;
          });
          return promise;
        }
      },
      updateLoyaltyProfileInfo : function(userData){
        $http({
          method : 'PUT',
          url : kohlsData.walletDomain+'/loyalty/v1/profiles/'+loyaltyId,
          data: JSON.stringify(userData),
          headers: {'Content-Type': 'application/json', 'token':walletToken}
        }).then(function(response){
            if(response.data.success){
              location.hash = '/mcom-rewards-info';
            }
            else{
              console.log("There is some error in the request");
              KOHLS.$ele('loader-img').classList.add('display-none');
            }
        })
        .catch(function(data){
            console.log("There is some error in the request");
            KOHLS.$ele('loader-img').classList.add('display-none');
        })
      },
      getProfileEmail : function(){
        if ($root.isLoggedIn){
            var softAccessToken = KOHLS_HYBRID.utils.getCookieValue('softLoginToken');
            var promise = $http({
              url: '/v1/profile/email',
              contentType: 'application/json',
              headers: {'Accept': 'application/json', 'access_token': softAccessToken}
            })
            promise.success(function(data){
                return data;
            })
            promise.error(function(data){
                console.log("There is some issue with your request");
            })
          }
          return promise;
      }
  }
  return factory;
}]);
/*Show page route loader*/
app.run(['$rootScope', function($root) {
  $root.isLoggedIn = KOHLS_HYBRID.utils.isLoggedIn();
  $root.loyaltyRedirect =='';
  if($root.isLoggedIn && loyaltyId){
    $root.loyaltyRedirect = 'enrolledUser';
  }
  else if($root.isLoggedIn && !loyaltyId){
    $root.loyaltyRedirect = 'notEnrolledUser';
  }
  else{
    $root.loyaltyRedirect = 'guest';
  }
  console.log($root.loyaltyRedirect);
  $root.$on('$routeChangeStart', function(e, curr, prev) {
    if (curr.$$route && curr.$$route.resolve) {
      // Show a loading message until promises aren't resolved
        KOHLS.$ele('loader-img').classList.remove('display-none');
    }
  });
  $root.$on('$routeChangeSuccess', function(e, curr, prev) {
    // Hide loading message
        KOHLS.$ele('loader-img').classList.add('display-none');
  });
  $root.getRwdProgress = function(pointBalance, thresholdValue) {
    $root.intialPoint = (pointBalance-(pointBalance%100));
    $root.thresholdPoint = ($root.intialPoint + thresholdValue);
    $root.indicatorStrength = pointBalance%100;
  }
}]);
/*Custom directive starts*/
/*end*/
/*Rewards Landing page controller*/
app.controller('yes2uCtrl', ['$scope', '$rootScope', 'yes2uRewards', 'loyaltyData', '$http', 'ngDialog','formData', function($scope, $root, yes2uRewards, loyaltyData, $http, ngDialog,formData) {
    $scope.loyaltyId = loyaltyId;
    $scope.user = {};
    $scope.templateSrc = "/yes2u/views/mcom-loyalty-guest.html";
    $scope.loyaltyFrm = '/yes2u/views/join-loyalty-form.html';
    $scope.addressFrm = '/yes2u/views/mcom-usa-address-fields.html';
    $scope.user.termsCheck = false;
    $root.loyaltyData = loyaltyData;
    $scope.getStates = formData.getStates();
    $scope.displaySignupFrm = true;
    $scope.displaySignupSuccess = false;
    if(loyaltyId && loyaltyData){
      $scope.loyaltyData = loyaltyData.data;
      $root.getRwdProgress(loyaltyData.data.profile.pointBalance, loyaltyData.data.profile.pointThreshold);
      $scope.isToInviteFriend = kohlsData.isToInviteFriend;
      $scope.programDetailsURL = {pageType:'program details',fileName:kohlsData.programDetailsURL};
      $scope.termsConditionsURL = {pageType:'terms',fileName:kohlsData.termsConditionsURL};
    }
    KOHLS.loylaty.triggerOmniture('main');
    $scope.initializeSocialShare = function(){
          KOHLSSOCIAL.socialFollow.renderSocialFollowBtns();
    },
    $scope.handleSocialEvents=function(loyaltyId, eventType){
      $http({
          method : 'POST',
          url : kohlsData.walletDomain+'/loyalty/v1/profiles/'+loyaltyId+'/events/'+eventType,
          headers: {'Content-Type': 'application/json', 'token':walletToken}
       })
      .success(function(){
          console.log('success:social button')
      })
      .error(function(){
          console.log('Failure:social button')
      })
    },
    $scope.displayModal = function (ModalObj) {
    	KOHLS.loylaty.triggerOmniture(ModalObj.pageType);
      ngDialog.open({template: ModalObj.fileName});
    },
    closeModal = function(){
      ngDialog.close();
    },
    $scope.goToFaq = function(){
    	KOHLS.loylaty.triggerOmniture('faq');
    	window.open('https://cs.kohls.com/app/answers/detail/a_id/1119','_blank');
    },
    $scope.loadTemplate = function(tmplName){
       $scope.addressFrm = tmplName;
    },
    /*Rewards enrollment - sign up loyalty*/
    $scope.signUpLoyalty = function(){
      var birthday = $scope.user.rwdsBirthDay < 10 ? "0"+$scope.user.rwdsBirthDay : $scope.user.rwdsBirthDay,
      dob = $scope.user.rwdsBirthYear+"-"+$scope.user.rwdsBirthMonth+"-"+birthday,
      channel = kohlsData.isTcom ? 'TCOM' : 'MCOM',
      correlationId = KOHLS_HYBRID.utils.getCookieValue('Correlation-Id'),
      accessToken = KOHLS_HYBRID.utils.getCookieValue('accessToken');
      if($scope.user.termsCheck){
          KOHLS.$ele('loader-img').classList.remove('display-none');
          yes2uRewards.getProfileEmail().then(function(promise){
            if(promise){
                var userData = {
                 "email": promise.data.payload.email,
                 "phone": {
                   "phoneNumber": $scope.user.phoneNumber,
                   "phoneNumberType": $scope.user.phoneNumberType
                 },
                 "dob": dob,
                 "address": {
                   "addr1": $scope.user.addr1,
                   "addr2": $scope.user.addr2,
                   "city": $scope.user.city,
                   "state": $scope.user.state,
                   "postalCode": $scope.user.postalCode
                 }
              }
            }
            $http({
              method : 'POST',
              url : '/api/loyalty/v1/loyalty',
              data:  userData,
              headers: {
                'x-correlation-id':correlationId,
                'access_token':accessToken,
                'x-channel':channel,
                'Content-Type': 'application/json',
                'Accept':'application/json'
              }
            }).then(function(response){
                if(response.data.loyaltyId){
                    KOHLS_HYBRID.utils.setCookieValue('loyaltyId', response.data.loyaltyId, 7200);
                    $scope.displaySignupFrm = false;
                    $scope.displaySignupSuccess = true;
                    var chnl = kohlsData.isTcom?'t':'m';
                    var LoyaltyOmniValues = {
                    pageName: chnl+'>sign in or sign up:y2y account created',
                    events: 'event50',
                    prop4:chnl+'|account',
                    prop9:'account|sign in or sign up',
                    eVar68:chnl+'>sign in or sign up:y2y account created',
                    prop53:chnl+'>sign in or sign up:y2y account created',
                    eVar48:""//TBD - cartID
                    }
                    KOHLS_HYBRID.browseSiteCatalyst(LoyaltyOmniValues);
                    window.location.reload();
                }
            })
            .catch(function(data){
                console.log("There is some error in the request");
                KOHLS.$ele('loader-img').classList.add('display-none');
            })
          });
        }
    }
}]);
/*Rewards enrollment - Join store*/
app.controller('rwdsJoinedStoreCtrl', ['$scope', '$rootScope', '$http', function($scope, $root, $http) {
  $scope.user = {};
  $scope.displayErrorMsg = '';
  $scope.showLinkupEmailFrm = false;
  $scope.displayLinkingSuccess = false;
  $scope.displayLoyaltyLinking = true;
  $scope.linkLoyaltyProfile = function(){
      channel = kohlsData.isTcom ? 'TCOM' : 'MCOM',
      correlationId = KOHLS_HYBRID.utils.getCookieValue('Correlation-Id'),
      accessToken = KOHLS_HYBRID.utils.getCookieValue('accessToken');
      KOHLS.$ele('loader-img').classList.remove('display-none');
      var userData = {
         "loyaltyId": ($scope.user.rewardsId.length > 10) ? $scope.user.rewardsId : '',
         "phone" : ($scope.user.rewardsId.length == 10) ? $scope.user.rewardsId : '',
         "storeEnteredEmail" : $scope.user.rewardEmail
      }
      $http({
        method : 'POST',
        url : '/api/loyalty/v1/loyalty/profile',
        data:  userData,
        headers: {
          'x-correlation-id':correlationId,
          'access_token':accessToken,
          'x-channel':channel,
          'Content-Type': 'application/json',
          'Accept':'application/json'
        }
      }).then(function(response){
            $scope.displayLoyaltyLinking = false;
            $scope.displayLinkingSuccess = true;
            $scope.showLinkupEmailFrm = false;
            KOHLS_HYBRID.utils.setCookieValue('loyaltyId', $scope.user.rewardsId, 7200);
            KOHLS.$ele('loader-img').classList.add('display-none');
            var chnl = kohlsData.isTcom?'t':'m';
            var LoyaltyOmniValues = {
            pageName: chnl+'>sign in or sign up:y2y account linked',
            events: 'event51',
            prop4:chnl+'|account',
            prop9:'account|sign in or sign up',
            eVar68:chnl+'>sign in or sign up:y2y account linked',
            prop53:chnl+'>sign in or sign up:y2y account linked',
            eVar48:""//TBD - cartID
            }
            KOHLS_HYBRID.browseSiteCatalyst(LoyaltyOmniValues);
          })
          .catch(function(response){
            if(response.data){
              var obj = JSON.parse(response.data.message.split('response:')[1]),
              errCode = obj.error.errorCode,
              errMessage = obj.error.message;
              if(errCode == "1004"){
                $scope.showLinkupEmailFrm = true;
              }
              else{
                $scope.displayErrorMsg = errMessage;
              }
            }
            KOHLS.$ele('loader-img').classList.add('display-none');
          })
  },
  $scope.closeLinkingPopup = function(){
      $scope.showLinkupEmailFrm = false;
  }
}]);
/*Invite a friend page controller*/
app.controller('yes2uInvitFrdCtrl', function($scope, $http) {
  $scope.user = {};
  var configState = kohlsData.inviteFriendIconState;
  if(configState == 'state1'){
      $scope.templateSrc = "/yes2u/views/rewards-invite-friend-state1.html";
  }
  else {
      $scope.templateSrc = "/yes2u/views/rewards-invite-friend-state2.html";
  }
  window.scrollTo(0, 0);
  $scope.inviteFrdForm = function() {
    var userData = $scope.user;
    var errors = KOHLS_HYBRID.validationHelper.rwdValidateFields(userData);
    if(errors){
      for (fieldId in errors) {
          var errorMessage = errors[fieldId];
          $scope.displayErrMsg=errorMessage;
      }
    }
    var refererData = {
      "refererLoyaltyId":loyaltyId,
      "referees": [
        {
          "refereeEMail": $scope.user.inviteEmail
        }
      ]
    }
    if(KOHLS_HYBRID.utils.isObjectEmpty(errors)){
      $http({
          method : 'POST',
          url : kohlsData.walletDomain+'/wallet/v1/loyalty/referFriends',
          data: JSON.stringify(refererData),
          headers: {'Content-Type': 'application/json', 'token':walletToken}
        }).then(function(response){
            if(response.data && response.data.referees){
              KOHLS.loylaty.handleBackendReferFriendErrors(response.data, $scope);
            }
            else{
              response.data.message ? document.getElementsByClassName('error-msg').innerHTML = response.data.message : '';
            }
        })
        .catch(function(data){
            console.log("There is some error in the request");
        })
    }
  };
});

/*Share rewards page controller*/
app.controller('yes2uShareCtrl', ['$scope', '$rootScope', 'loyaltyData', '$http', 'ngDialog', function($scope, $root, loyaltyData, $http, ngDialog) {
  try{
    $scope.pointBalance = loyaltyData.data.profile.pointBalance;
    $scope.pointThreshold = loyaltyData.data.profile.pointThreshold;
    $root.getRwdProgress(loyaltyData.data.profile.pointBalance, loyaltyData.data.profile.pointThreshold);
    window.scrollTo(0, 0);
    KOHLS.loylaty.triggerOmniture('donate landing page');
  }
  catch(err){
      console.log("There is some with your request, please try again later")
  }
  $scope.disabledButton = 'disabledButton';
  $scope.user = {};
  $scope.rwdQty = 1;
  $scope.displayLoyaltyInfo = false;
  var userData = $scope.user;
  $scope.shareRwdsFrm = function(){
	  if(KOHLS_HYBRID.utils.isObjectEmpty(userData)){
	        $scope.globalErrorMsg = true;
	        document.body.scrollIntoView();
	    }
	    else {
	      $scope.globalErrorMsg = false;
	      $scope.backendErr = '';
	      var errors = KOHLS_HYBRID.validationHelper.rwdValidateFields(userData);
	      if(errors){
	        for (fieldId in errors) {
	            var errorMessage = errors[fieldId];
	            fieldId = fieldId+'Err';
	            KOHLS.$ele(fieldId).innerHTML = errorMessage;
	        }
	      }
	      if(KOHLS_HYBRID.utils.isObjectEmpty(errors)) {
          if($scope.user.emailId && ($scope.user.emailId.toLowerCase() == loyaltyData.data.profile.email.toLowerCase())){
            $scope.backendErr = "You can only share points with other Yes2You Rewards member, Please try again!";
            document.body.scrollIntoView();
          }else{
                ngDialog.open({
                  template: '/yes2u/views/confirm-share-points.html',
                  data: {'userEmailId' : $scope.user.emailId, 'phone':$scope.user.phoneNumber, 'qty' : KOHLS.$ele('rwdQty').value, 'message' : $scope.user.message}
                });
	         }
        }
      }
  },
  cancelShareModel = function(){
    ngDialog.close();
  },
  confirmSharePoints = function(){
      ngDialog.close();
      var reqData = {
          "sourceLoyaltyId":loyaltyId,
          "rewardPoints": KOHLS.$ele('rwdQty').value,
          "charityInd":false
      }
      reqData = Object.assign(reqData, userData);
      $http({
      method : 'POST',
      url : kohlsData.walletDomain+'/wallet/v2/loyalty/points',
      data: reqData,
      headers: {'Content-Type': 'application/json', 'token':walletToken}
      })
      .success(function(data){
          if(data.success){
            KOHLS.loylaty.triggerOmniture('share successful');
            $root.newPointBalance = data.sourcePointBalance;
            $root.receiversEmailId = $scope.user.emailId;
            location.hash = '#mcom-share-successful';
            $root.getRwdProgress($scope.newPointBalance, $scope.pointThreshold);
          }
          else {
            for (var prop in data.errors){
              if (data.errors[prop]) {
                data.errors[prop].errorCode == '46' ? $scope.displayLoyaltyInfo = true :'';
                var errorMessage = data.errors[prop].message;
              }
            }
            $scope.backendErr = errorMessage;
            document.body.scrollIntoView();
          }
      })
      .error(function(data){
          console.log("there is some issue with the request");
      });
  },
  $scope.toggleButtonStatus = function(){
      var errors = KOHLS_HYBRID.validationHelper.rwdValidateFields(userData);
      if(KOHLS_HYBRID.utils.isObjectEmpty(errors)){
        $scope.disabledButton = '';
      }
      else{
        $scope.disabledButton = 'disabledButton';
      }
  },
  $scope.allowNumbersOnly = function() {
    $scope.keydownkeycode = event.keyCode
    if ($scope.keydownkeycode < 48 || $scope.keydownkeycode > 57) {
      event.preventDefault();
    }
  }

}]);
/**/
/*share Rewards - Confirmation*/
app.controller('yes2uShareSuccessCtrl', ['$scope', '$rootScope', function($scope, $root) {
}]);
/*Donate rewards page controller*/
app.controller('yes2uDonateCtrl', ['$scope', '$rootScope', 'loyaltyData', '$http', 'ngDialog', function($scope, $root, loyaltyData, $http, ngDialog) {
  try{
      $root.pointBalance = loyaltyData.data.profile.pointBalance;
      $root.pointThreshold = loyaltyData.data.profile.pointThreshold;
      $root.getRwdProgress(loyaltyData.data.profile.pointBalance, loyaltyData.data.profile.pointThreshold);
      window.scrollTo(0, 0);
  }
  catch(err){
      console.log("There is some with your request, please try again later")
  }
/*Charities Landing page*/
    $http({
      method : 'GET',
      url : kohlsData.walletDomain+'/loyalty/v1/'+loyaltyId+'/charities?accountType=charity&detail=true',
      headers: {'Content-Type': 'application/json', 'token':walletToken}
    })
    .success(function(data){
        console.log("charities request success");
        $scope.charitiesData = data;
    })
      .error(function(data, status){
          console.log("charities request failed" + data.status);
    });
/*end*/
    KOHLS.loylaty.triggerOmniture('donate landing page');
    $scope.displayCharityLanding = function(event){

      document.getElementById('showCharitiesInfo').classList.add('hide');
      $scope.missionLoyaltyid = angular.element(event.currentTarget).attr('data-loyaltyid');
      $scope.indexid = angular.element(event.currentTarget).attr('data-role');
      $root.missionLogo = $scope.charitiesData.charities[$scope.indexid].charity.accountImageURL;
      $root.accountTitle = $scope.charitiesData.charities[$scope.indexid].charity.accountTitle;
      $scope.missionStatement = $scope.charitiesData.charities[$scope.indexid].charity.accountMissionStmt;
      var htmltempl = `<div class="rwdsInvitefrdCont"><h1 class="rwdsTitle">Donate Points</h1><div class="indicatorWrap"><span class="fLeft">`+$root.intialPoint+`</span><span class="rwdsSubTitle">`+$root.pointBalance+` POINTS</span><span class="fRight">`+$root.thresholdPoint+`</span><div class="indicator"><div value="0" max="100" class="progressColor" id="id_tcom_rwdsPointBal" style="width:`+$root.indicatorStrength+`%"></div></div></div><img src=`+$scope.missionLogo+` alt="charitylogo" /><div class="rwdsSmallTxt rwdsBoldFont m10">`+$scope.accountTitle+`</div> <div class="rwdsInvitefrdTxt">`+ $scope.missionStatement +`</div> <div class="rwdsInvitefrdTxt bTop p5"> Choose how many points you want to share, then tap Donate. </div> <div class="qtyCont p5"><a class="qtySymbols qtySymbolMinus" href="javascript:void(0);" onclick="KOHLS.loylaty.decrementValue()">-</a><input type="tel" id="rwdQty" name="rewardpoints" maxlength="3" value="1" onChange="validateDonatePoints();"/><a class="qtySymbols qtySymbolPlus" href="javascript:void(0);" data-attr=`+$scope.pointBalance+` onclick="KOHLS.loylaty.incrementValue(this);">+</a></div><div class="error-msg" id="qtyErrMsg"></div><div class="rwdsSmallTxt m10"> You can donate up to 500 points per day. </div> <button id="donate-btn" class="rwdsActionButton m10" onclick="submitDonatePointsFrm(`+$scope.missionLoyaltyid+`);">Donate</button></div>`
      angular.element(document.getElementById('showMissionDetails')).append(htmltempl);
    },
    validateDonatePoints = function(){
      if(KOHLS.$ele('rwdQty').value == 0) {
        KOHLS.$ele('qtyErrMsg').innerHTML = "You must donate at least one point. Please try again.";
        KOHLS.$ele('donate-btn').classList.add('disabledButton');
        return false;
      }
      else if (KOHLS.$ele('rwdQty').value > 500){
        KOHLS.$ele('qtyErrMsg').innerHTML = "You can donate only upto 500 points per day. Please try again.";
        KOHLS.$ele('donate-btn').classList.add('disabledButton');
        return false;
      }
      else if (KOHLS.$ele('rwdQty').value > $scope.pointBalance){
        KOHLS.$ele('qtyErrMsg').innerHTML = "Sorry, you don't have that many points available. Double-check your available points balance and try again.";
        KOHLS.$ele('donate-btn').classList.add('disabledButton');
        return false;
      }
      else {
        KOHLS.$ele('qtyErrMsg').innerHTML = '';
        KOHLS.$ele('donate-btn').classList.contains('disabledButton') ? KOHLS.$ele('donate-btn').classList.remove('disabledButton') : '';
        return true;
      }
    },
    submitDonatePointsFrm = function(){
      if(validateDonatePoints()){
            ngDialog.open({
              template: '/yes2u/views/confirm-donate-points.html',
              data: {'qty' : KOHLS.$ele('rwdQty').value, 'charityName':$root.accountTitle}
            });
      }
    },
    cancelDonateModel = function(){
      ngDialog.close();
    },
    confirmDonatePonts = function(){
      ngDialog.close();
      var reqData = {
        "sourceLoyaltyId":loyaltyId,
        "destinationLoyaltyId": $scope.missionLoyaltyid,
        "rewardPoints": KOHLS.$ele('rwdQty').value,
        "charityInd":true
      }
      $http({
      method : 'POST',
      url : kohlsData.walletDomain+'/wallet/v2/loyalty/points',
      data: reqData,
      headers: {'Content-Type': 'application/json', 'token':walletToken}
      })
      .success(function(data){
          if(data.success){
        	KOHLS.loylaty.triggerOmniture('donate successful');
            location.hash = '#mcom-donate-successful';  // set the target
            $root.newPointBalance = data.sourcePointBalance;
          }
          else{
            console.log("There is some issue with your request");
          }
      })
      .error(function(data){
          console.log("There is some issue with your request");
      });
    }
}]);

/*Donate Rewards - Confirmation*/
app.controller('yes2uDonateSuccessCtrl', ['$scope', '$rootScope', function($scope, $root) {
    $scope.newPointBalance = $root.newPointBalance;
    $scope.pointThreshold = $root.pointThreshold;
    $scope.missionLogo = $root.missionLogo;
    $scope.accountTitle = $root.accountTitle;
    $root.getRwdProgress($scope.newPointBalance, $scope.pointThreshold);
}]);


/*Reward Activity page controller*/
app.controller('yes2uActivityCtrl', ['$scope', 'yes2uRewards', '$http', function($scope, yes2uRewards, $http) {
	KOHLS.$ele('header-container').classList.remove('hide');
	KOHLS.$ele('mobile-footer').classList.remove('hide');
  KOHLS.loylaty.triggerOmniture('activity');
  $scope.activityPeriodArray = [
    {'id':0,'label' : 'Last 30 days', 'period' : 1},
    {'id':1,'label' : 'Last 6 months', 'period' : 6},
    {'id':2,'label' : 'This Year', 'period' : 12},
    {'id':3,'label' : 'All', 'period' : 12},
  ];
  $scope.activityTypeArray = [
    {'id':0, 'activityLabel' : 'Purchase', 'activityType' : 'purchase'},
    {'id':1, 'activityLabel' : 'Rewards', 'activityType' : 'rewards'},
    {'id':2, 'activityLabel' : 'Others', 'activityType' : 'others'},
    {'id':3, 'activityLabel' : 'All Activity', 'activityType' : 'all'},
  ];
  $scope.setDefaultProps = function(id){
    $scope.applyBtnDisabled = true;
    $scope.selectedPeriod = 0;
    $scope.selectedType= 3;
    $scope.selectedPeriodPrevious = 0;
    $scope.selectedTypePrevious = 3;
  };
  $scope.setDefaultProps();

  $scope.setActivityPeriod = function(id){
      $scope.applyBtnDisabled = false; //enable apply button
      $scope.selectedPeriod = id;
      if($scope.selectedPeriodPrevious == id){
          $scope.applyBtnDisabled = true;
      }
  };

  $scope.setActivityType = function(id){
    $scope.applyBtnDisabled = false; //enable apply button
    $scope.selectedType = id;
    if($scope.selectedTypePrevious == id){
        $scope.applyBtnDisabled = true;
    }
  };

  window.scrollTo(0, 0);
  $scope.applyFilters = function() {
      var period = $scope.activityPeriodArray[$scope.selectedPeriod].period;
      var type = $scope.activityTypeArray[$scope.selectedType].activityType;
      $scope.displayEmptyActitivty = true;
      KOHLS.$ele('loader-img').classList.remove('display-none');
      $http({
      method : 'GET',
      url : kohlsData.walletDomain+'/loyalty/v1/profiles/'+loyaltyId+'/activities?period='+period+'&type='+type,
      headers: {'Content-Type': 'application/json', 'token':walletToken}
      }).then(function(response){
    	  KOHLS.$ele('loader-img').classList.add('display-none');
        if(response.data && response.data.success && (!KOHLS_HYBRID.utils.isObjectEmpty(response.data.transactions) || !KOHLS_HYBRID.utils.isObjectEmpty(response.data.rewards))){
          $scope.activitydata = response.data;
          $scope.displayEmptyActitivty = true;
        }
        else{
          $scope.displayEmptyActitivty = false;
        }
        /* reset values for filter */
        $scope.selectedPeriodPrevious = $scope.activityPeriodArray[$scope.selectedPeriod].id;
        $scope.selectedTypePrevious = $scope.activityTypeArray[$scope.selectedType].id;
        $scope.applyBtnDisabled = true;
      })
      .catch(function(data){
    	  KOHLS.$ele('loader-img').classList.add('display-none');
          console.log("There is some error in the request");
          $scope.displayEmptyActitivty = false;
      })
    $scope.custom = false;
    $scope.filtergroup = true;
    $scope.activityFiltergroup = true;
  },
  $scope.clearFilters = function(){
    $scope.setDefaultProps();
  },
  $scope.toggleCustom = function() {
    $scope.custom = $scope.custom === false ? true: false;
    $scope.filtergroup = true;
    $scope.activityFiltergroup = true;

    /*reset filters on click of cancel button */
    $scope.applyBtnDisabled = true;
    $scope.selectedPeriod = $scope.selectedPeriodPrevious;
    $scope.selectedType= $scope.selectedTypePrevious;
  };
  $scope.applyFilters();
}]);


/*Rewards Activity Details*/
app.controller('rwdsactivitydetails',['$scope','$http', '$routeParams', function($scope, $http, $routeParams){
  KOHLS.$ele('header-container').classList.add('hide');
  KOHLS.$ele('mobile-footer').classList.add('hide');
  var transId = $routeParams.id,
  transId = transId.split(':')[1];
  $http({
    method : 'GET',
    url : kohlsData.walletDomain+'/loyalty/v1/profiles/'+loyaltyId+'/transactions/'+transId,
    headers: {'Content-Type': 'application/json', 'token':walletToken}
  }).then(function(response){
    $scope.transDetails = response.data;
  })
  .catch(function(data){
    console.log("There is some error in the request");
  })
}]);
/*end*/

/*User info page controller*/
app.controller('yes2uInfoCtrl', ['$scope', 'loyaltyData', '$http', function($scope, loyaltyData, $http) {
  KOHLS.loylaty.triggerOmniture('info');
  $scope.loyaltyId = loyaltyId;
  KOHLS.$ele('header-container').classList.contains('hide')?KOHLS.$ele('header-container').classList.remove('hide'):'';
  KOHLS.$ele('mobile-footer').classList.contains('hide')?KOHLS.$ele('mobile-footer').classList.remove('hide'):'';
  $scope.getBirthday = function(dob) {
    var d = dob.split('-');
    var month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var getMonth = month[d[1]-1];
    var getDay = parseInt(d[2]);
    return getMonth+' '+getDay;
  }
  $scope.formatPhone = function(phone){
    return phone.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
  if(loyaltyData){
    $scope.loyaltyData = loyaltyData.data;
    window.scrollTo(0, 0);
    $scope.addressExists = KOHLS_HYBRID.utils.isObjectEmpty(loyaltyData.data.profile.address) ? false : true;
    $scope.getBirthday = loyaltyData.data.profile.birthday ? $scope.getBirthday(loyaltyData.data.profile.birthday) : loyaltyData.data.profile.birthday;
    $scope.phoneNumber = loyaltyData.data.profile.phoneNumber ? $scope.formatPhone(loyaltyData.data.profile.phoneNumber) : loyaltyData.data.profile.phoneNumber;
  }
}]);

/*Update profile*/
app.controller('rwdsSavePhone', ['$scope', 'loyaltyData', 'yes2uRewards', '$http', 'ngDialog', function($scope, loyaltyData, yes2uRewards, $http, ngDialog) {
 KOHLS.$ele('header-container').classList.add('hide');
 KOHLS.$ele('mobile-footer').classList.add('hide');
 $scope.user = {};
   try{
      $scope.user.phoneNumber = loyaltyData.data.profile.phoneNumber;
      $scope.phoneNumberType = loyaltyData.data.profile.phoneNumberType;
   }
   catch(err){
      console.log("there is some issue with loyalty profile call");
   }
 $scope.user.phoneNumber ? $scope.disabledButton = 'rwdsActionButton m25' : $scope.disabledButton = 'rwdsActionButton disabledButton m25';
 var userData = $scope.user;
 $scope.validatePhoneNumber = function(){
    var errors = KOHLS_HYBRID.validationHelper.rwdValidateFields(userData);
    KOHLS_HYBRID.utils.isObjectEmpty(errors) ? $scope.disabledButton = 'rwdsActionButton m25' : $scope.disabledButton = 'rwdsActionButton disabledButton m25' ;
 }
 $scope.savePhoneNumber = function(){
    var errors = KOHLS_HYBRID.validationHelper.rwdValidateFields(userData);
    if(errors){
      for (fieldId in errors) {
        var errorMessage = errors[fieldId];
        $scope.errorMsg = errorMessage;
      }
    }
    if(KOHLS_HYBRID.utils.isObjectEmpty(errors)) {
      userData = Object.assign(userData, {
        'phoneNumberType' : $scope.phoneNumberType
      })
      yes2uRewards.updateLoyaltyProfileInfo(userData);
    }
 }
 $scope.displayTooltip = function() {
    ngDialog.open({
        template: '<div class="ngModelContainer"><div class="tooltip-header" onclick="closeMobileTooltip();"></div><div class="tooltip-content m25">If you forget your card we can use your phone number to look up your Rewards </div></div>',
        plain : true
    });
 }
 closeMobileTooltip = function(){
      ngDialog.close();
  }
}]);

app.controller('rwdsSaveAddress', ['$scope', 'loyaltyData', 'yes2uRewards', '$http', 'formData', function($scope, loyaltyData, yes2uRewards, $http, formData) {
 KOHLS.$ele('header-container').classList.add('hide');
 KOHLS.$ele('mobile-footer').classList.add('hide');
 $scope.templateSrc = '/yes2u/views/mcom-usa-address.html';
 $scope.addressExists = KOHLS_HYBRID.utils.isObjectEmpty(loyaltyData.data.profile.address) ? false : true;
 if(loyaltyData){
    $scope.submitted=true;
    $scope.user = {
      'addr1' : loyaltyData.data.profile.address.addr1,
      'addr2': loyaltyData.data.profile.address.addr2,
      'city'  :loyaltyData.data.profile.address.city,
      'state' : loyaltyData.data.profile.address.state,
      'postalCode' : loyaltyData.data.profile.address.postalCode
    }
 }
 $scope.getStates =  formData.getStates();
 $scope.geoLocationError = false;
 $scope.getCurrentLocation = function(){
      KOHLS.$ele('loader-img').classList.remove('display-none');
      var successCallback = function(position) {
         var locDetail = KOHLS_HYBRID.setLocation(position, onSuccess);
       };
       var failureCallback = function(error) {
         console.log('Error occurred. Error code: ' + error.code +', Error msg: '+ error.message);
         KOHLS.$ele('loader-img').classList.add('display-none');
          $scope.$apply(function(){
            $scope.geoLocationError = true;
          });
       };

       var onSuccess = function(data){
         KOHLS.$ele('loader-img').classList.add('display-none');
         $scope.$apply(function(){
           $scope.geoLocationError = false;
           $scope.user.city = data.locality;
           $scope.user.postalCode = data.postal_code;
           $scope.user.state = data.state_short_name;
         });
       };

       KOHLS_HYBRID.askLocation(successCallback, failureCallback);
 },
 $scope.loadTemplate = function(tmplName){
	 $scope.submitted = false;
    $scope.templateSrc = tmplName;
 },
 $scope.numbersOnly = function() {
    $scope.keydownkeycode = event.keyCode
    if ($scope.keydownkeycode < 48 || $scope.keydownkeycode > 57) {
      event.preventDefault();
    }
 },
 $scope.saveProfileAddess = function(){
	$scope.submitted = true;
    var userData = $scope.user;
    userData = {'address' : userData, 'postalCode':$scope.user.postalCode};
    console.log(userData);
    yes2uRewards.updateLoyaltyProfileInfo(userData);
  }
}]);
/*end*/
app.factory('formData', function() {
    var states =  {
           "states": [{
           "name": "Alabama",
           "abbreviation": "AL"
       },
       {
           "name": "Alaska",
           "abbreviation": "AK"
       },
       {
           "name": "American Samoa",
           "abbreviation": "AS"
       },
       {
           "name": "Arizona",
           "abbreviation": "AZ"
       },
       {
           "name": "Arkansas",
           "abbreviation": "AR"
       },
       {
           "name": "California",
           "abbreviation": "CA"
       },
       {
           "name": "Colorado",
           "abbreviation": "CO"
       },
       {
           "name": "Connecticut",
           "abbreviation": "CT"
       },
       {
           "name": "Delaware",
           "abbreviation": "DE"
       },
       {
           "name": "District Of Columbia",
           "abbreviation": "DC"
       },
       {
           "name": "Federated States Of Micronesia",
           "abbreviation": "FM"
       },
       {
           "name": "Florida",
           "abbreviation": "FL"
       },
       {
           "name": "Georgia",
           "abbreviation": "GA"
       },
       {
           "name": "Guam",
           "abbreviation": "GU"
       },
       {
           "name": "Hawaii",
           "abbreviation": "HI"
       },
       {
           "name": "Idaho",
           "abbreviation": "ID"
       },
       {
           "name": "Illinois",
           "abbreviation": "IL"
       },
       {
           "name": "Indiana",
           "abbreviation": "IN"
       },
       {
           "name": "Iowa",
           "abbreviation": "IA"
       },
       {
           "name": "Kansas",
           "abbreviation": "KS"
       },
       {
           "name": "Kentucky",
           "abbreviation": "KY"
       },
       {
           "name": "Louisiana",
           "abbreviation": "LA"
       },
       {
           "name": "Maine",
           "abbreviation": "ME"
       },
       {
           "name": "Marshall Islands",
           "abbreviation": "MH"
       },
       {
           "name": "Maryland",
           "abbreviation": "MD"
       },
       {
           "name": "Massachusetts",
           "abbreviation": "MA"
       },
       {
           "name": "Michigan",
           "abbreviation": "MI"
       },
       {
           "name": "Minnesota",
           "abbreviation": "MN"
       },
       {
           "name": "Mississippi",
           "abbreviation": "MS"
       },
       {
           "name": "Missouri",
           "abbreviation": "MO"
       },
       {
           "name": "Montana",
           "abbreviation": "MT"
       },
       {
           "name": "Nebraska",
           "abbreviation": "NE"
       },
       {
           "name": "Nevada",
           "abbreviation": "NV"
       },
       {
           "name": "New Hampshire",
           "abbreviation": "NH"
       },
       {
           "name": "New Jersey",
           "abbreviation": "NJ"
       },
       {
           "name": "New Mexico",
           "abbreviation": "NM"
       },
       {
           "name": "New York",
           "abbreviation": "NY"
       },
       {
           "name": "North Carolina",
           "abbreviation": "NC"
       },
       {
           "name": "North Dakota",
           "abbreviation": "ND"
       },
       {
           "name": "Northern Mariana Islands",
           "abbreviation": "MP"
       },
       {
           "name": "Ohio",
           "abbreviation": "OH"
       },
       {
           "name": "Oklahoma",
           "abbreviation": "OK"
       },
       {
           "name": "Oregon",
           "abbreviation": "OR"
       },
       {
           "name": "Palau",
           "abbreviation": "PW"
       },
       {
           "name": "Pennsylvania",
           "abbreviation": "PA"
       },
       {
           "name": "Puerto Rico",
           "abbreviation": "PR"
       },
       {
           "name": "Rhode Island",
           "abbreviation": "RI"
       },
       {
           "name": "South Carolina",
           "abbreviation": "SC"
       },
       {
           "name": "South Dakota",
           "abbreviation": "SD"
       },
       {
           "name": "Tennessee",
           "abbreviation": "TN"
       },
       {
           "name": "Texas",
           "abbreviation": "TX"
       },
       {
           "name": "Utah",
           "abbreviation": "UT"
       },
       {
           "name": "Vermont",
           "abbreviation": "VT"
       },
       {
           "name": "Virgin Islands",
           "abbreviation": "VI"
       },
       {
           "name": "Virginia",
           "abbreviation": "VA"
       },
       {
           "name": "Washington",
           "abbreviation": "WA"
       },
       {
           "name": "West Virginia",
           "abbreviation": "WV"
       },
       {
           "name": "Wisconsin",
           "abbreviation": "WI"
       },
       {
           "name": "Wyoming",
           "abbreviation": "WY"
       }]
    };
    var getStates = function(){
        return states;
    }
    return {
      "getStates": getStates
    }
});
/*custom directive for phone number format*/
app.filter('tel', function () {
    return function (tel) {
        if (!tel) { return ''; }

        var value = tel.toString().trim().replace(/^\+/, '');

        if (value.match(/[^0-9]/)) {
            return tel;
        }

        var country, city, number;

        switch (value.length) {
            case 1:
            case 2:
            case 3:
                city = value;
                break;

            default:
                city = value.slice(0, 3);
                number = value.slice(3);
        }

        if(number){
            if(number.length>3){
                number = number.slice(0, 3)+'-'+number.slice(3,7);
            }
            else{
                number = number;
            }

            return (city+"-"+number).trim();
        }
        else{
            return city;
        }

    };
});
app.directive('phoneInput', function($filter, $browser) {
    return {
        require: 'ngModel',
        link: function($scope, $element, $attrs, ngModelCtrl) {
            var listener = function() {
                var value = $element.val().replace(/[^0-9]/g, '');
                $element.val($filter('tel')(value, false));
            };
            ngModelCtrl.$parsers.push(function(viewValue) {
                return viewValue.replace(/[^0-9]/g, '').slice(0,10);
            });
            ngModelCtrl.$render = function() {
                $element.val($filter('tel')(ngModelCtrl.$viewValue, false));
            };

            $element.bind('change', listener);
            $element.bind('keydown', function(event) {
                var key = event.keyCode;
                if (key == 91 || (15 < key && key < 19) || (37 <= key && key <= 40)){
                    return;
                }
                $browser.defer(listener);
            });

            $element.bind('paste cut', function() {
                $browser.defer(listener);
            });
        }

    };
});
/*end*/
