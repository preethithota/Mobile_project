const gulp = require('gulp')
const shell = require('gulp-shell')
//Test Sree - remove if this creates issues
gulp.task('default', shell.task([
	"echo Gulp should no longer be used. Run npm run build instead",
	"npm run build"
]));
