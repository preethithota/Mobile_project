import * as utils from '../global/utils';
export default React.createClass({	
		
	render: function(){
		const props = this.props;
		const historyData = props && props.historyData;
		const data = historyData && historyData.payload && historyData.payload;
		var closeOrderAvail = false;
		var openOrderAvail = false;
    	return (
			<div>
				{data && data.orders ? 						
					(<div id="PH_container">
						<div className="m-PH-header">YOUR ORDERS</div>
						<div className="m-PH-OrderHead">OPEN ORDERS</div>
						{data.orders.map((order, index) => {
							const OR_date = order && order.dateTime && new Date(order.dateTime);		
							var OR_day = OR_date && OR_date.getDate();
							OR_day = OR_day < 10 ? '0'+OR_day : OR_day; 
							var OR_month = OR_date && OR_date.getMonth();
							OR_month = OR_month < 10 ? '0'+OR_month : OR_month; 
							const OR_year = OR_date && OR_date.getFullYear();
							const OR_dateFormated = OR_date && OR_month + "/" + OR_day + "/" + OR_year;
							openOrderAvail = openOrderAvail ? openOrderAvail : (order.status=="In Fulfillment" || order.status=="Submitted");
							return (<div key={index}>
							{order.status=="In Fulfillment" || order.status=="Submitted" ? 
								<div className="m-orderDetail">
									<div className="m-orderDet">										
										<div className="m-PH-orderDate">{OR_dateFormated}</div>
										<div className="m-PH-orderTotal">${order.orderTotal}</div>
									</div>
									<div className="m-manage" onClick={evt => {utils.setCookieValue('cookie_orderNumber', order.orderNumber);window.location.href=window.location.origin + "/upgrade/myaccount/manageorder.jsp";}}>
										Manage <span className="right_arrow"></span>
									</div>
								</div> : ""}
							</div>)
							})}
							{!openOrderAvail ? <div className="m-PH-noOrder">You have no open orders.</div> : ""}
						<div className="m-PH-OrderHead">CLOSED ORDERS</div>	
						{data.orders.map((order, index) => {
							closeOrderAvail = closeOrderAvail ? closeOrderAvail : (order.status=="Cancelled" || order.status=="Fulfillment");
							return (<div key={index}>
							{order.status=="Cancelled" || order.status=="Fulfillment" ? 
								<div className="m-orderDetail">
									<div className="m-orderDet">										
										<div className="m-PH-orderDate">{order.dateTime}</div>
										<div className="m-PH-orderTotal">{order.orderTotal}</div>
									</div>
								</div> : ""}
							</div>)
							})}
						{!closeOrderAvail ? <div className="m-PH-noOrder">You have no close orders.</div> : ""}
					</div>) : ""}
			</div>
		)
	}
});