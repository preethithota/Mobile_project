import PurchaseHistoryContainer from './purchaseHistory-container';

ReactDOM.render(
	<PurchaseHistoryContainer/>,
	document.getElementById('Purchase_History')
);
