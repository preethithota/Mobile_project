import PurchaseHistoryView from './purchaseHistory-view';
import * as utils from '../global/utils';

export default React.createClass({
	// React Lifecycle function
	getInitialState: function(){
		var historyData;
		 return {
			  historyData: historyData
		}
	},
	componentDidMount: function(){
		var url = location.origin + '/api/v1/orders';
		var userStatus = utils.isLoggedIn() ? true : false;
		var access_token = utils.getCookieValue("accessToken"); 
		var header =  {'Accept': 'application/json'};
		if(access_token){
			header.access_token = access_token;
		}
		var historyData;
		var self = this;
		  $.ajax({
			url: url,
			method: 'GET',
			headers: header,
			cache: true,
			success: function(data){
				self.setState({
                  historyData: data
                });
			},
			error: function(){
				
			}
		  }); 
	},
	render: function(){
		return (<PurchaseHistoryView {...this.state} {...this.props}/>)
	}
});
