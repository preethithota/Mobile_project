import * as utils from '../global/utils';

var KOHLS = KOHLS || {};
KOHLS.wallet = {};
KOHLS.wallet.redirect = function(openedAccordian) {
    window.location.hash = openedAccordian;
    window.location.reload();
};
KOHLS.wallet.checkLogin = function() {
    var userLogStatus = utils.isLoggedIn();
    if (userLogStatus) {
        return userLogStatus;
    } else {
        return false;
    }
};
KOHLS.wallet.displaySignIn = function(openedAccordian) {
    if (openedAccordian) {        
		utils.showLogin(kohlsData.isTcom, false, function(){
            KOHLS.wallet.redirect(openedAccordian);
        },"wallet");
    } else {
        utils.showLogin(kohlsData.isTcom, false, function(){
            window.location.reload(); 
        },"wallet");
        /*var config = {};
        config.redirectUrl = window.location.href;
        utils.displayLoginModal(null, config);
        var viewWalletInterval = setInterval(function() {
            if ($(".cls_viewWalletBtn").length) {
                $(".cls_viewWalletBtn").unbind("click").bind("click", function(e) {
                    window.location = location.href;
                });
                clearInterval(viewWalletInterval);
            }
        }, 200);*/
    }
    setTimeout(function() {
	    document.body.classList.add("t-login-mask");
	},100);
};
KOHLS.wallet.displayCreateAccount = function(openedAccordian) {
    if (openedAccordian) {       
       	utils.showLogin(kohlsData.isTcom, true, function(){
            KOHLS.wallet.redirect(openedAccordian);
        },"wallet");
    } else {
        utils.showLogin(kohlsData.isTcom, true, function(){
            window.location.reload();
        },"wallet");
    }
    setTimeout(function() {
	    document.body.classList.add("t-login-mask");
	},100);
};
KOHLS.wallet.loyalty = function(buttonName, openedAccordian) {
    /*var config = {};
	    if (buttonName == "loyaltyEnroll") {
        config.joinme = true;
        SK.MR.helper.displayRewardsModal(function() {
            KOHLS.wallet.redirect(openedAccordian);
        }, config);		
    } else {
        if (buttonName == "loyaltySignUp") {
            config.signmeup = true;
            SK.MR.helper.displayRewardsModal(function() {
                KOHLS.wallet.redirect(openedAccordian);
            }, config);			
        }
    }*/
	var redirectLink = (buttonName == "loyaltyEnroll" ? window.location.origin + "/feature/rewards.jsp#enrollrewards" : (buttonName == "loyaltySignUp" ? window.location.origin + "/feature/rewards.jsp#signedinstore" : ''))
	window.location.href = redirectLink;
};
KOHLS.wallet.logoutUser = function() {
    document.cookie = "STREAMSESSIONID=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "STREAM_AUTH_REFRESH_TOKEN=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "STREAM_AUTH_ID=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "STREAM_LOYALTY_AUTH_ID=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "skBagTotalsNew=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "skBag=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "loyaltyId=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "profileId=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "skVisitorFullName=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "wallet_hash=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "wallet_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "wallet_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    document.cookie = "wallet_timestamp=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
};
/*Wallet Configuration changes - start*
KOHLS.wallet.setWalletEndPoint = function(){
    var domainurl = "http://wallet.kohls.com";
    return domainurl;
};
KOHLS.wallet.setFBAppID = function(){
    var fbAppID = "207826302581986";
    return fbAppID;
};
KOHLS.wallet.setFBShareUrl = function(){
    var fbShareUrl = "https://www.facebook.com/dialog/feed?";
    return fbShareUrl;
};
KOHLS.wallet.setBarcodeShareUrl = function(){
    var barcodeUrl = "http://m.kohls.com/wifi/email.html";
    return barcodeUrl;
};
/*Wallet Configuration changes - end*/

if(utils.isSoftedLoggedIn()){
   utils.showLogin(kohlsData.isTcom, false, function(){
           window.location.reload();
    });
    setTimeout(function() {
	    document.body.classList.add("t-login-mask");
	},100);
}
if(kohlsData.isTcom) {
	myWallet.init(KOHLS.wallet.checkLogin, KOHLS.wallet.displaySignIn, KOHLS.wallet.displayCreateAccount, KOHLS.wallet.loyalty, '', KOHLS.wallet.logoutUser, KOHLS.wallet.setWalletEndPoint, KOHLS.wallet.setFBAppID, KOHLS.wallet.setFBShareUrl, KOHLS.wallet.setBarcodeShareUrl);
}
else {
	myWallet.init(KOHLS.wallet.checkLogin, KOHLS.wallet.displaySignIn, KOHLS.wallet.displayCreateAccount, KOHLS.wallet.loyalty, KOHLS.wallet.logoutUser, KOHLS.wallet.setWalletEndPoint, KOHLS.wallet.setFBAppID, KOHLS.wallet.setFBShareUrl, KOHLS.wallet.setBarcodeShareUrl);
}