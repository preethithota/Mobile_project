if (kohlsData.isMCOMSiteLevelEnabled){
  require(['./monetization', './googleAd'], (monetization, googleAd) => {
    
    monetization.initMonetization();
    googleAd.initGOOGLE_ADSENSE();
  });
}
