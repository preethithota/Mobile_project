import React from 'react';

var KOHLS = KOHLS || {};
KOHLS.GOOGLE_ADSENSE = KOHLS.GOOGLE_ADSENSE || {};
KOHLS.G_ADSENSE = KOHLS.G_ADSENSE || {};
KOHLS.G_ADSENSE.CONFIG = {
    "mcom": {
        adtestSwitch: "off",
        killSwitch: false
    },
    "tcom": {
        adtestSwitch: "off",
        killSwitch: false
    }
};
var kohlsData = window.kohlsData || {};
KOHLS.GOOGLE_ADSENSE = {
    pubId: "",
    query: "",
    priceMin: "",
    priceMax: "",
    addTestParam: ((kohlsData.isTcom) ? KOHLS.G_ADSENSE.CONFIG['tcom'].adtestSwitch : KOHLS.G_ADSENSE.CONFIG["mcom"].adtestSwitch),
    _dynMonetizationElm: '<div id="googleAdSense"><div class="gAdsenseTitle" style="font-size:12px;font-family:gothambold;margin:5px;text-align:center;">SPONSORED LINKS</div><div id="afshcontainer" style="margin:10px auto 10px;"></div></div>',
    hideAdsenseTitle: function() {
        if ($("#googleAdSense iframe, .googleAdSense iframe") && $("#googleAdSense iframe,.googleAdSense iframe").height() > 0) {
            $(".gAdsenseTitle").css('display', 'block');
			$("#googleAdSense").css('display', 'block');
        } else {
            $(".gAdsenseTitle").css('display', 'none');
			$("#googleAdSense").css('display', 'none');			
        }
    },
	getQueryParam: function(e) {
		var t = {};
		if (e == null) {
			e = location.search.substring(1, location.search.length)
		}
		if (e.length == 0) {
			return null
		}
		e = e.replace(/\+/g, " ");
		var i = e.split("&");
		for (var s = 0; s < i.length; s++) {
			var l = i[s].split("=");
			var a = decodeURIComponent(l[0]);
			var n = l.length == 2 ? decodeURIComponent(l[1]) : a;
			t[a] = n
		}
		return t;
	  },
    setMinMaxPriceAdsense: function(priceVal, priceBooster) {
        /*
        if (priceVal) {
            priceVal = priceVal.replace('to', '-');
            if (priceVal.indexOf("-") > 0) {
                priceVal = priceVal.split("-");
                if (priceVal.length > 1) {
                    this.priceMax = parseFloat(priceVal[1].split("$")[1]) * priceBooster;
                    this.priceMin = parseFloat(priceVal[1].replace("$", "")) + 1;
                }
            } else {
                if (priceVal.indexOf("$") > -1) {
                    this.priceMax = parseFloat(priceVal.split("$")[1]) * priceBooster;
                    this.priceMin = parseFloat(priceVal.split("$")[1]) + 1;
                }
            }
        } else {
            this.priceMin = '10';
            this.priceMax = '2000';
        }
        console.log("FN setMinMaxPriceAdsense :: Here is the price min :: " + this.priceMin + " and price max :: " + this.priceMax);
        */
    },
    displayAdsense: function(tId) {
        if (typeof (this.setAdsenseQueryStr) === "function") {
            this.setAdsenseQueryStr();
        }
        (function(G, o, O, g, L, e) {
            G[g] = G[g] || function() {
                (G[g]["q"] = G[g]["q"] || []).push(arguments);
            }
            ,
            G[g]["t"] = 1 * new Date;
            L = o.createElement(O),
            e = o.getElementsByTagName(O)[0];
            L.async = 1;
            L.src = kohlsData.googleAdLibURL;
            L.onload = function() {
                setTimeout(function() {
                    KOHLS.GOOGLE_ADSENSE.hideAdsenseTitle();
                }, 2000);
            }
            ;
            e.parentNode.insertBefore(L, e);
        })(window, document, "script", "_googCsa");
		var googleAdPDPFlag = kohlsData.isTcom ? kohlsData.googleAdTCOMPDPFlag : kohlsData.googleAdMCOMPDPFlag;
		var googleAdPMPFlag = kohlsData.isTcom ? kohlsData.googleAdTCOMPMPFlag : kohlsData.googleAdMCOMPMPFlag;
        if ($('#product-content').length && googleAdPDPFlag=="true") {
            $('#googleAdSense').remove();
            this._dynMonetizationElm = '<div id="googleAdSense"><div class="gAdsenseTitle" style="font-size:12px;font-family:gothambold;margin:5px;text-align:center;">SPONSORED LINKS</div><div id="afshcontainer" style="margin:10px auto 10px;"></div></div>';
            if(!kohlsData.isTcom){
				$(this._dynMonetizationElm).insertBefore('#recommendationsMcom');
			}else{
				$(this._dynMonetizationElm).insertAfter('#product-content');
			}
            if ($("#googleAdSense").length && typeof adsenseQueryStr == 'object' && adsenseQueryStr.pdpTitle != undefined) {
                console.log("PDP page");
                this.pubId = "vert-pla-kohls-pdp";
                this.query = adsenseQueryStr.pdpTitle || $('.prdName h1').html();
                this.setMinMaxPriceAdsense('', 5);
            } else {
                this.pubId = "vert-pla-kohls-pdp";
                this.query = $('#product-desc h1').html() || '';
                console.log("PDP page with title" + this.query);
                var priceObj = catalogData & catalogData.payload && catalogData.payload.products && catalogData.payload.products[0].price.regularPrice || '';
                this.setMinMaxPriceAdsense(priceObj, 10);
            }
        }else if($(".product-results").length && googleAdPMPFlag=="true"){	
				$(".product-results").after($(this._dynMonetizationElm));	
				var priceObj = 0;
				if(catalogData && catalogData.products && catalogData.products.length >= 0){
					$.each(catalogData.products, function(i, product) {
						if(priceObj > 0 && product.prices[0] && product.prices[0].regularPrice.minPrice < priceObj){
							priceObj = product.prices[0].regularPrice.minPrice;
						}else if(priceObj == 0 && product.prices[0] && product.prices[0].regularPrice.minPrice){
							priceObj = product.prices[0].regularPrice.minPrice;
						}
						//console.log(priceObj);
					});
				}else{
					priceObj='';
				}
				this.setMinMaxPriceAdsense(priceObj, 10);
                var params = this.getQueryParam();
                if(params && params.search!=""){

					this.pubId = "vert-pla-kohls-srp",
					this.query = this.getQueryParam().search;
				}
		}
        var pageOptions = {
            pubId: this.pubId,
            query: this.query,
            adsafe: "high",
            adtest: this.addTestParam,
            hl: "en",
            priceCurrency: "USD",
            priceMin: this.priceMin,
            priceMax: this.priceMax
        };
        var afshBlock = {
            container: (tId) ? "googleAdsense" + tId : "afshcontainer",
            width: 320,
            height: 200,
            promoted: false,
            linkTarget: "_blank"
        };
        if (this.query != undefined && this.query != "") {
            try {
                _googCsa("plas", pageOptions, afshBlock);
            } catch (e) {
                console.log("Exception::" + e);
            }
        } else {
            console.log("Adsense - query must have some value ->");
        }
    },
    init: function(tId) {
		var siteKillSwitch = kohlsData.isTcom ? kohlsData.googleAdTCOMSiteFlag : kohlsData.googleAdMCOMSiteFlag;
        var killSwitch = (siteKillSwitch=="true") ? true : false;
        if (killSwitch) {
            this.displayAdsense(tId);
        }
    }
};
export function initGOOGLE_ADSENSE(){
	KOHLS.GOOGLE_ADSENSE.init();
}