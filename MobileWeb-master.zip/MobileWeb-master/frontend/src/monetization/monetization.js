import React from 'react';

var KOHLS = KOHLS || {};
KOHLS.MONETIZATION = KOHLS.MONETIZATION || {};
var kohlsData = window.kohlsData || {};
var dfpAd = null;
var showMoreClickArray = [];
var showMoreRandomCount = 100;
var customKeyMap = {
    brand: "brd",
    ageAppropriate: "age",
    occasion: "occ",
    gender: "gen",
    sportsLeague: "spl",
    sportsTeam: "spt",
    personaCategory: "pcat",
    personaTheme: "pthm",
    personaSubject: "psub",
    personaGroupCode: "pgrp",
    silhouette: "sil",
    ageAppropriateRange: "arng",
    childAgeRange: "crng",
    sizeRange: "srng",
    fit: "fit",
    legOpening: "leg",
    trend: "trnd",
    feature: "featr",
    activity: "act",
    bodyType: "bod",
    roastsFlavors: "flav"
};
KOHLS.MONETIZATION = {
	dfpPageConfigs: {
		channel: (kohlsData.isTcom) ? "tablet" : "mobile",
		debugLog: false,
		networkId: "17763952",
		homepage: {
			adUnit: "/homepage",
			showAd: (kohlsData.monetizationHomeFlag=="true"),
			dfpIds: (kohlsData.isTcom) ? ["#main-content", "#main-content"] : ["#homeDfp"],
			adSlots: (kohlsData.isTcom) ? [(kohlsData.monetizationHomeTopSlotFlag=="true"), (kohlsData.monetizationHomeBottomSlotFlag=="true")] : [(kohlsData.monetizationHomeTopSlotFlag=="true")],
			dimensions: (kohlsData.isTcom) ? [[728, 90], [728, 90]] : [[320, 50]],
			insert: (kohlsData.isTcom) ? ["before", "after"] : ["before"],
			pos: (kohlsData.isTcom) ? ["top", "bottom"] : ["middle"],
			setTargets: [{
				name: "pgtype",
				value: "home"
			}]
		},
		pdp: {
			showAd: (kohlsData.monetizationPDPFlag=="true"),
			dfpIds: (kohlsData.isTcom) ? ["#main-content", "#id_tcomPdpRecommend", "#main-content"] : ["#recommendationsMcom"],
			adSlots: (kohlsData.isTcom) ? [(kohlsData.monetizationPDPTopSlotFlag=="true"), (kohlsData.monetizationPDPRightSlotFlag=="true"), (kohlsData.monetizationPDPBottomSlotFlag=="true")] : [(kohlsData.monetizationPDPBottomSlotFlag=="true")],
			dimensions: (kohlsData.isTcom) ? [[728, 90], [300, 250], [300, 250]] : [[320, 50]],
			insert: (kohlsData.isTcom) ? ["before", "last", "after"] : ["before"],
			pos: (kohlsData.isTcom) ? ["top", "top", "bottom"] : ["bottom"],
			setTargets: [{
				name: "pgtype",
				value: "pdp"
			}]
		},
		pmp: {
			adUnit: "/ROS",
			showAd: (kohlsData.monetizationPMPFlag=="true"),
			dfpIds: (kohlsData.isTcom) ? ["#active-dimensions", ".pmp-footer", ".ZeroSearchRecommendationsTcom"] : [".pmp-footer", ".ZeroSearchRecommendationsMcom"],
			adSlots: (kohlsData.isTcom) ? [(kohlsData.monetizationPMPTopSlotFlag=="true"), (kohlsData.monetizationPMPBottomSlotFlag=="true"), (kohlsData.monetizationZeroSearchFlag=="true")] : [(kohlsData.monetizationPMPBottomSlotFlag=="true"), (kohlsData.monetizationZeroSearchFlag=="true")],
			dimensions: (kohlsData.isTcom) ? [[728, 90], [300, 250], [728, 90]] : [[320, 50], [320, 50]],
			insert: (kohlsData.isTcom) ? ["after", "after", "after"] : ["before", "after"],
			pos: (kohlsData.isTcom) ? ["top", "bottom", "middle"] : ["middle", "middle"],
			setTargets: [{
				name: "pgtype",
				value: "pmp"
			}]
		},
		orderConfirm: {
			adUnit: "/ROS",
			showAd: (kohlsData.monetizationOrderConfirmFlag=="true"),
			dfpIds: (kohlsData.isTcom) ? ["#tcom-results-header", "#main-content"] : [".contentWrapper"],
			adSlots: (kohlsData.isTcom) ? [(kohlsData.monetizationOrderConfirmTopSlotFlag=="true"), (kohlsData.monetizationOrderConfirmBottomSlotFlag=="true")] : [(kohlsData.monetizationOrderConfirmBottomSlotFlag=="true")],
			dimensions: (kohlsData.isTcom) ? [[728, 90], [300, 250]] : [[320, 50]],
			insert: (kohlsData.isTcom) ? ["after", "after"] : ["after"],
			pos: (kohlsData.isTcom) ? ["top", "bottom"] : ["middle"],
			setTargets: [{
				name: "pgtype",
				value: "orderConfirm"
			}]
		},
		deals: {
			adUnit: "/ROS",
			showAd: (kohlsData.monetizationDealsFlag=="true"),
			dfpIds: (kohlsData.isTcom) ? ["#main-content", "#main-content"] : ["#dealsDfp"],
			adSlots: (kohlsData.isTcom) ? [(kohlsData.monetizationDealsTopSlotFlag=="true"), (kohlsData.monetizationDealsBottomSlotFlag=="true")] : [(kohlsData.monetizationDealsTopSlotFlag=="true")],
			dimensions: (kohlsData.isTcom) ? [[728, 90], [728, 90]] : [[320, 50]],
			insert: (kohlsData.isTcom) ? ["before", "after"] : ["before"],
			pos: (kohlsData.isTcom) ? ["top", "bottom"] : ["middle"],
			setTargets: [{
				name: "pgtype",
				value: "sevent"
			}, {
				name: "pgname",
				value: "coupons-deals.jsp"
			}]
		}
	},
	RenderAds: function(currentPage, adParams) {
		try {
			if (kohlsData.monetizationFlag=="true") {
				dfpAd = new KOHLS.MONETIZATION.Dfp(currentPage, adParams);
				dfpAd.showAds();
			}
		} catch (e) {
			console.log("exception in RenderAds constructor" + e);
		}
	},
	Dfp: function(page, adParams){
		this.currentPage = page;
		this.dfp_config = KOHLS.MONETIZATION.dfpPageConfigs[page];
		this.adParams = adParams;
		this.includeDfpJs = function() {
			var gads = document.createElement("script");
			gads.async = true;
			gads.type = "text/javascript";
			var useSSL = "https:" == document.location.protocol;
			gads.src = (useSSL ? "https:" : "http:") + "//www.googletagservices.com/tag/js/gpt.js";
			var node = document.getElementsByTagName("script")[0];
			node.parentNode.insertBefore(gads, node);
		},
		this.trailingZero = function() {
			$(".salePriceCss").each(function() {
				$(this).html(function() {
					return $(this).html().replace(/\$((\d+(,\d+)*)|(\d+))(\.\d{1,2})*/g, function(match, p1, p2, p3, p4, p5, off, st) {
						console.log(match + "," + p5);
						if (!p5) {
							return match + ".00"
						} else if (p5.match(/\.\d$/)) {
							return match + "0"
						} else return match;
					});
				})
			});
			$(".pdtPrice").each(function() {
				$(this).html(function() {
					return $(this).html().replace(/\$((\d+(,\d+)*)|(\d+))(\.\d{1,2})*/g, function(match, p1, p2, p3, p4, p5, off, st) {
						console.log(match + "," + p5);
						if (!p5) {
							return match + ".00"
						} else if (p5.match(/\.\d$/)) {
							return match + "0"
						} else return match;
					});
				})
			});
		},
		this.removeSpecialCharacters = function(value, isAdunit) {
			var targetVal = value.toLowerCase();
			if (isAdunit) {
				targetVal = targetVal.replace(/[^a-z0-9&_//\s]/g, "").replace(/[&]/g, "and").replace(/[ ]/g, "_");
			} else {
				targetVal = targetVal.replace(/[#"*()=+<>\[\]]/g, "").split(",");
				if (targetVal.length > 1) {
					targetVal = $.map(targetVal, $.trim);
				} else {
					targetVal = targetVal.join();
				}
			}
			return targetVal;
		},
		this.settingTargets = function() {
			var setTargets = this.dfp_config.setTargets;
			var adUnit = this.dfp_config.adUnit;
			if (this.adParams) {
				setTargets = setTargets.concat(this.adParams);
			}
			googletag.cmd.push(function() {
				for (var index = 0; setTargets.length > index; index++) {
					if (setTargets[index].value != null) {
						var targetName = customKeyMap[setTargets[index].name] || setTargets[index].name;
						if (targetName != "adUnit") {
							var targetValue = dfpAd.removeSpecialCharacters(setTargets[index].value, false);
							googletag.pubads().setTargeting(targetName, targetValue);
						} else {
							adUnit = setTargets[index].value;
						}
						if (adUnit && adUnit != "/ROS") {
							adUnit = dfpAd.removeSpecialCharacters(adUnit, true);
						}
					}
				}
				dfpAd.defineAdSlots(adUnit);
				//console.log(adUnit);
			});
		},
		this.defineAdSlots = function(adUnit) {
			googletag.pubads().collapseEmptyDivs(true);
			googletag.pubads().enableSingleRequest();
			googletag.pubads().disableInitialLoad();
			googletag.enableServices();
			try{
				for (var index = 0; dfpAd.dfp_config.dfpIds.length > index; index++) {
					if (dfpAd.dfp_config.adSlots[index]) {
						var adId = "dfpAdId" + index;
						if (dfpAd.currentPage == "pmp") {
							if(kohlsData.isTcom){
								adId = "dfpAdId" + index;
							}else{
								adId = "dfpAdId" + showMoreRandomCount++;
								showMoreClickArray.push(adId);
								if (adId != "dfpAdId100") {
									dfpAd.dfp_config.pos[index] = "morebottom";
								}
							}
						}
						var slot = googletag.defineSlot("/" + KOHLS.MONETIZATION.dfpPageConfigs.networkId + adUnit, dfpAd.dfp_config.dimensions[index], adId);
						slot.addService(googletag.pubads());
						slot.setTargeting("pos", dfpAd.dfp_config.pos[index]);
						/* kohlsData.monetizationEnv="test";
	 					if(location.host == "m.kohls.com" || location.host == "mobile.kohls.com") {
	 						kohlsData.monetizationEnv="prod";
	 					} */
						slot.setTargeting("env", kohlsData.monetizationEnv);
						slot.setTargeting("channel", KOHLS.MONETIZATION.dfpPageConfigs.channel);
					}
					//console.log(adId);
					dfpAd.displayAdUnits(slot, index);
				}
			} catch(e){console.log(e)}
			googletag.pubads().addEventListener("slotRenderEnded", function(event) {
				if (!event.isEmpty && event.slot.l.m) {
					$("#" + event.slot.l.m).hide();
					$("#" + event.slot.l.m).slideDown("slow");
				}
			});
		},
		this.displayAdUnits = function(slot, index) {
			var $targetDiv = $(dfpAd.dfp_config.dfpIds[index]);
			var className = "dfp_class";
			var dfpId = "dfpAdId" + index;
			if (dfpAd.currentPage == "pmp" && !kohlsData.isTcom) {
				if ($targetDiv.length) {
					$targetDiv = $targetDiv.prev();
					dfpAd.dfp_config.insert[index] = "after";
				} else {
					dfpAd.dfp_config.insert[index] = "before";
				}
				dfpId = showMoreClickArray[showMoreClickArray.length - (index + 1)];
			}
			//console.log(dfpId);
			if (dfpAd.dfp_config.insert[index] == "before") {
				if (dfpAd.currentPage == "deals" && !kohlsData.isTcom) {
					$targetDiv.append($("<div class='dealsDfp' style='width:320px;'><div style='text-align:right;'>Advertisement</div><div id=" + dfpId + "></div></div>"));
				} else {
					$targetDiv.before($("<div id=" + dfpId + " class=" + className + "></div>"));
				}
			} else {
				$targetDiv.after($("<div id=" + dfpId + " class=" + className + "></div>"));
			}
			if (typeof KOHLS.GOOGLE_ADSENSE != "undefined" && typeof KOHLS.GOOGLE_ADSENSE.init == "function" && (dfpAd.currentPage == "pmp" || dfpAd.currentPage == "search")) {
				KOHLS.GOOGLE_ADSENSE.init(dfpId);
			}
			googletag.display(dfpId);
			googletag.pubads().refresh([slot]);
		},
		this.showAds = function() {
			this.trailingZero();
			if (this.dfp_config.showAd) {
				this.settingTargets();
			}
		},
		this.init = function() {
			if (!googletag.apiReady) this.includeDfpJs();
		};
		this.init();
	}

};
export function initMonetization(){
	try{
	$.getScript(kohlsData.monetizationgptURL, function () {
		$.getScript(kohlsData.monetizationpubads_impl_108URL, function () {
			googletag = googletag || {};
			googletag.cmd = googletag.cmd || [];
			var pathName = window.location.pathname;
			var currentPage = kohlsData.page || "homepage";
			if (currentPage) {
				if(currentPage=="pdp"){
					var adParamArr=[];
					var monetization = catalogData && catalogData.payload && catalogData.payload.products[0] && catalogData.payload.products[0].monetization;
					for(var x in monetization){
					  var obj = {};
					  obj.name= x;
					  obj.value = monetization[x] ? monetization[x].value : null;
					  adParamArr.push(obj);
					}
					var renderAds = new KOHLS.MONETIZATION.RenderAds(currentPage,adParamArr);
				}else{
					if (pathName.indexOf("/sale-event/coupons-deals") != -1 || pathName.indexOf("/sale-event/m-coupons-deals") != -1 || pathName.indexOf("nativedeals") != -1) {
						currentPage = "deals";
					}
					else if (pathName.indexOf("/checkout/checkout.jsp") != -1 && window.location.hash=="#/orderConfirmation") {
    					currentPage = "orderConfirm";
					}
					var renderAds = new KOHLS.MONETIZATION.RenderAds(currentPage);
				}
			}
		 });
	});
	}catch(e){
		console.log(e.message);
	}
}
