import {setRegistryLandingOmniture, setRegistryLandingFAQOmniture} from '../../public/lib/omniture-util';
window.KOHLSRegistry = {};
KOHLSRegistry.setRegistryLandingOmniture = setRegistryLandingOmniture;
KOHLSRegistry.setRegistryLandingFAQOmniture = setRegistryLandingFAQOmniture;

//for dynamic portions of registry landing page
require('./registryLanding-helper');
