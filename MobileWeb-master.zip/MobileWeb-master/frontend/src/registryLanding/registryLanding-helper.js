import * as utils from '../global/utils.js'; //Import utils to check login status etc..,
import $ from 'jquery'; // Import jquery to avoid compiler errors.
import * as registryHelper from '../pdp/registry/registry-helper';

//create registry page redirection
let createNewRegistry = ()=> {
   document.location.href = document.location.origin + "/upgrade/gift_registry/kohlsgrw_home.jsp?section=mylists&action=createregistry";
};

//show or hide my registy dropdown based on user login status
let toggleMyRegistryButton = ()=> {
  if (utils.isLoggedIn()) {
      let RegistryDataCb = (data) => {
          showMyRegistries(data)
      }
      registryHelper.getListData('REGISTRY', RegistryDataCb);
  } else {
      $("#topReg_Login, #botReg_Login").show();
      $("#topReg_myRegistries, #botReg_myRegistries").hide();
  }
}

//construct my registries dropdown menu
let showMyRegistries = (listOfMyRegis) => {
    let
    url, registryName = "",
    data = listOfMyRegis.lists || {},
    myRegistryList = "",
    registryLink = window.location.origin + "/kohlsopenapi/registrymobile.html?section=list&amp;viewtype=dashboard&amp;listid=";
    data.sort(function (a, b) {
        b = new Date(b.listEventDate);
        a = new Date(a.listEventDate);
        return a > b ? 1 : a < b ? -1 : 0;
    });
    if (data.length > 0) {
        var numOfRegShown = 1;
        for (var i = 0; i < data.length; i++) {
            numOfRegShown++;
            if (numOfRegShown > 4)
                break;
            url = registryLink + data[i].listId;
            ownerFirstName = data[i].registryProperties.properties.ownerFirstName;
            partnerFirstName = data[i].registryProperties.properties.partnerFirstName;
            regtype = data[i].registryProperties.properties.regtype;
            customEventType = data[i].registryProperties.properties.customEventType;
            if ((ownerFirstName !== "") && (partnerFirstName !== "")) {
                registryName = ownerFirstName + " &amp; " + partnerFirstName + "\'s";
            }
            if (ownerFirstName !== "" && partnerFirstName === "") {
                registryName = ownerFirstName + "\'s";
            }
            if (ownerFirstName === "" && partnerFirstName !== "") {
                registryName = partnerFirstName + "\'s";
            }
            if (regtype == "registry.wedding") {
                myRegistryList += '<li class="myregistry_wedding" onclick="window.location=\'' + url + '\'">' + registryName + ' Wedding Registry' + '</li>';
            }
            if (regtype == "registry.baby") {
                myRegistryList += '<li class="myregistry_baby" onclick="window.location=\'' + url + '\'">' + registryName + ' Baby Registry' + '</li>';
            }
            if (regtype == "registry.splday") {
                myRegistryList += '<li class="myregistry_celebration" onclick="window.location=\'' + url + '\'">' + registryName + ' ' + customEventType + ' Registry' + '</li>';
            }
        }
        if (data.length > 4) {
            url = window.location.origin + "/kohlsopenapi/registrymobile.html?section=mylists&view=all";
            myRegistryList += '<li class="myregistry_viewall" onclick="window.location=\'' + url + '\'">VIEW ALL REGISTRIES</li>';
        }
        myRegistryList += '<li class="myregistry_createnew" onclick="invokeCreateRegistry();">CREATE A NEW REGISTRY</li>';
        $("#topReg_listdown, #botReg_listdown").html('').append(myRegistryList);
        $("#topReg_Login, #botReg_Login").hide();
        $("#topReg_myRegistries, #botReg_myRegistries").show();
    } else {
        $("#topReg_Login, #botReg_Login, #topReg_myRegistries, #botReg_myRegistries").hide();
    }
};

//validate search form fields
let validateField=(isAdvSearch, inputID, errorMsg) =>{
    var characterReg = /^\s*[a-zA-Z0-9,\s]+\s*$/;
    var inputVal = $("#" + inputID).val();
    $("#" + inputID).css("outline", "");
    if (inputVal.length === 0 || inputVal.length === 1) {
        $("#searchMsgBar").html("Some information is missing or invalid below. <br> Please enter at least the first two letters of the " + errorMsg).show();
        $("#" + inputID).css("outline", "1px solid red");
        $("body").scrollTop();
        return false;
    }
    if (!characterReg.test(inputVal)) {
        $("#searchMsgBar").html("Some information is missing or invalid below. <br> Special Charcter are not allowed in " + errorMsg).show();
        $("#" + inputID).css("outline", "1px solid red");
        return false;
    }
    return true;
};

//for navigation
let SKOuterFrame = (id, host)=> {
    this.id = id;
    this.host = host;
};

//configure registry search
let doRegistrySearch = (params) =>{
  var _self = this, qp, _tempQp = [], regType = (params.regType && params.regType == "all" || !params.regType ? "registry.wedding,registry.baby,registry.splday" : "registry." + params.regType);
  let isMobile = /Android|webOS|iPhone|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  if (params.regNo) {
      qp = "?section=search&regno=" + params.regNo + "&regtype=" + regType
  } else {
      _tempQp.push("section=search");
      if (params.fName) {
          _tempQp.push("fname=" + params.fName);
      }
      if (params.lName) {
          _tempQp.push("lname=" + params.lName);
      }
      if (params.state) {
          _tempQp.push("state=" + params.state);
      }
      _tempQp.push("regtype=" + regType);
      qp = "?" + _tempQp.join("&");
  }
  if (isMobile) {
          var registryURL = "/upgrade/gift_registry/kohlsgrw_home.jsp" + qp;
          document.location.href = document.location.origin + registryURL;
  } else {
      skOuterFrame.call("doRegistrySearch", {
          "qParam": qp
      });
  }
}

//click events
$(document).ready(function () {
    //show or hide My Registry Button based on user login status
    toggleMyRegistryButton();

    //show find a registry modal
    $("#topReg_Find").on("click", function () {
        $(".overlayShadow, #findregistryDialog").detach().appendTo("body").show();
        $('#regFirstName').focus();
    });

    //close find a registry modal
    $("span.close_button").on("click", function () {
        $("#form_SearchModal")[0].reset();
        $("#advanced_search, .overlayShadow, #findregistryDialog").hide();
        $("#adv_searchLink").show();
        $("#searchMsgBar").text("").hide();
        $("#regFirstName, #regLastName").css("outline", "0px");
    });

    //advance serch button click
    $("#adv_searchLink > a").on("click", function() {
        $("#advanced_search").slideDown();
        $("#adv_searchLink").hide();
    });

    //create new registry button click
    $("#topReg_Create, #botReg_Create").on("click", function () {
        if (utils.isLoggedIn()) {
            createNewRegistry();
        } else {
            utils.showLogin(kohlsData.isTcom, false, function () {
                toggleMyRegistryButton();
                createNewRegistry();
            }, 'login-modal');
        }
    });

    //login modal
    $("#topReg_Login, #botReg_Login").on("click", function () {
      utils.showLogin(kohlsData.isTcom, false, function () {
          toggleMyRegistryButton();
      }, 'login-modal');
    });

    //serach registry form submit
    $("#form_SearchModal").on("submit", function(e) {
        e.preventDefault();
        let fName, lName, ifValidRegNumber, state, regType, regNo,ifValidFname,ifValidLname;
        if ($("#advanced_search").is(":hidden")) {
            fName = $("#regFirstName").val();
            lName = $("#regLastName").val();
            ifValidFname = validateField(false, "regFirstName", "First Name");
            ifValidLname = validateField(false, "regLastName", "Last Name");
            if (ifValidFname && ifValidLname) {
                $("#searchMsgBar").html("").hide();
                doRegistrySearch({
                    "fName": fName,
                    "lName": lName
                });
            }
            if (!ifValidFname && !ifValidLname) {
                $("#searchMsgBar").html("Some information is missing or invalid below. <br> Please enter at least the first two letters of the First and Last Name without special character").show();
            }
        }
        if ($("#advanced_search").is(":visible")) {
            fName = $("#regFirstName").val();
            lName = $("#regLastName").val();
            state = $("#regState").val();
            regType = $("#regType").val();
            regNo = $("#regNumber").val();
            if (!regNo) {
                ifValidFname = validateField(false, "regFirstName", "First Name");
                ifValidLname = validateField(false, "regLastName", "Last Name");
                if (state == "0") {
                    state = "";
                }
                if (ifValidFname && ifValidLname) {
                    $("#searchMsgBar").html("").hide();
                    doRegistrySearch({
                        "fName": fName,
                        "lName": lName,
                        "state": state,
                        "regType": regType
                    });
                }
                if (!ifValidFname && !ifValidLname) {
                    $("#searchMsgBar").html("Some information is missing or invalid below. <br> Please enter at least the first two letters of the First and Last Name without special character or the Registry Number").show();
                }
            }
            if (regNo) {
                var regEx = /^\d+$/;
                if (regEx.test(regNo)) {
                    $("#searchMsgBar").html("").hide();
                    $("#regFirstName, #regLastName").css("outline", "");
                    doRegistrySearch({
                        "regNo": regNo
                    });
                } else {
                    $("#regNumber").css("outline", "1px solid red");
                    $("#searchMsgBar").html("Some information is missing or invalid below. <br> Please enter at least the first two letters of the First and Last Name without special character or the Registry Number").show();
                }
            }
        }
    });

});
