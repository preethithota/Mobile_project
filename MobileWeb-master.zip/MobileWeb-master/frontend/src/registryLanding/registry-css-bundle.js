const headerCss = require('./css/registry-global-styles.css');
//required css files for registry landing page
require('./css/mobile-gift-registry.css');
require('./css/registry-widget.css');
require('./css/registry-styles.css');
