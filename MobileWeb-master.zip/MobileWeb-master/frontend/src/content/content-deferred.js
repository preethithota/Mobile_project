import '../misc/z1Loyalty-v2';
import { setDealsOmniture, setSaleEventOmniture, setFeatureOmniture } from '../../public/lib/omniture-util';
if(location.href.indexOf("coupons-deals") != -1){
	setDealsOmniture();
}else if(location.href.indexOf("/sale-event/") != -1){
	setSaleEventOmniture()
}else if(location.href.indexOf("/feature/") != -1){
	setFeatureOmniture();
}	
