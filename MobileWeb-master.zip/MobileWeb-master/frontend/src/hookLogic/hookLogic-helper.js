import React from 'react';
import * as utils from '../global/utils';

var KOHLS = KOHLS || {};
const hooklogicUrl = (location.host=="m.kohls.com" || location.host=="mobile.kohls.com") ? 'www.hlserve.com/delivery/api/' : 'uat1.hlserve.com/delivery/api/';
//const hooklogicUrl = kohlsData.hlURL; 

KOHLS.hookLogic = {
	urlParams : function(catalogData) {
		var params = {
			pcount : "pcount=24",
			pgn : catalogData.offset && "pgn="+parseInt((catalogData.offset+24)/24) || "pgn=1",
			pgsize: catalogData.products.length ? "pgsize="+catalogData.products.length : "",
			view: document.getElementsByClassName("m-grid-view").length ? "view=grid" : "view=list",
			platform: kohlsData.isTcom ? "platform=tablet" :"platform=mobile",
			minmes: "minmes=1",
			maxmes: "maxmes=8",
			minorganic: "minorganic=3",
			creative: "creative=182x2464_T-R-IG_TI_1-8_RightColumnAjax",
			beacon: "beacon=individual",
			apiKey: "apiKey=9C7B840B-E021-43BF-A29B-87E4D166C38E",
			puserid: utils.getCookieValue('m_deviceID') ? "puserid="+utils.getCookieValue('m_deviceID') : "",
			cUserid: utils.getCookieValue('profileId') ? "cuserid="+utils.getCookieValue('profileId') : ""
		};
		return params;
	},
	getTaxonomyData : function(catalogData) {
		var activeDimentions = {
			filters : {},
			product : [],
			department : [],
			category : [],
			brand : [],
			ratings : [],
			price : [],
			taxonomy : []
		};

		for(var activeIndx=0; catalogData.activeDimensions.length > activeIndx; activeIndx++) {
			var activeDim = catalogData.activeDimensions[activeIndx];
			var activeDimValues = catalogData.activeDimensions[activeIndx].activeDimensionValues;

			for (var valueIndx=0; activeDimValues.length>valueIndx; valueIndx++) {
				if(activeDim.name == "Product") {
					activeDimentions.product.push(activeDimValues[valueIndx].name);
				} else if (activeDim.name == "Department") {
					activeDimentions.department.push(activeDimValues[valueIndx].name);
				} else if (activeDim.name == "Category") {
					activeDimentions.category.push(activeDimValues[valueIndx].name);
				} else if (activeDim.name == "Brand") {
					activeDimentions.brand.push(activeDimValues[valueIndx].name);
				} else if(activeDim.name == "TopRated") {
					activeDimentions.ratings.push(activeDimValues[valueIndx].name);
				} else if(activeDim.name == "Price") {
					var price = activeDimValues[valueIndx].name.split("to");
					activeDimentions.price.push(price[0].replace(/\D/g,'')) && (price[1] && activeDimentions.price.push(price[1].replace(/\D/g,'')));
				} else {
					if(!activeDimentions.filters[activeDim.name]) {
						activeDimentions.filters[activeDim.name] = [];
					}
					activeDimentions.filters[activeDim.name].push(activeDimValues[valueIndx].name);
				}
			}
		
			activeDimentions.department.length && activeDimentions.taxonomy.push(activeDimentions.department.join(",")),activeDimentions.department = [];
			activeDimentions.category.length && activeDimentions.taxonomy.push(activeDimentions.category.join(",")),activeDimentions.category = [];
			activeDimentions.product.length && activeDimentions.taxonomy.push(activeDimentions.product.join(",")),activeDimentions.product = [];
		}
		return activeDimentions;
	},
	hl_callback : function(hlResponse) {
    	console.log(hlResponse);
    	KOHLS.hookLogic.actionCallBck(hlResponse);
    },
	prepareHooklogicUrl : function(catalogData) {
		var taxonomyObj = this.getTaxonomyData(catalogData);
		var taxonomy = taxonomyObj.taxonomy.length &&  taxonomyObj.taxonomy.join('>');
		var hlpt = "B";
		var taxonomyUrl = "";
        var searchTerm = utils.getUrlParam("search",location.href);
        var sort = "Featured";

        for(var sortInd=0; catalogData.sorts.length>sortInd ; sortInd++) {
        	if(catalogData.sorts[sortInd].active) {
        		sort = catalogData.sorts[sortInd].name;
        		break;
        	}
        }
        var priceArr = taxonomyObj.price.length && taxonomyObj.price.sort(function(a, b){return a-b});
        if (searchTerm) {
            taxonomyUrl = "search?keyword=" + searchTerm + (taxonomy ? ("&taxonomy=" + encodeURIComponent(taxonomy)) : "");
            hlpt = "S";
        } else {
            taxonomyUrl = "taxonomy?taxonomy=" + (taxonomy ? encodeURIComponent(taxonomy) : '');
        }
        var hookLogicAPIDuration = 2000;
        var hlUrlAry = [];
        var hlUrl = "http://" + hooklogicUrl + taxonomyUrl;
        var hl_params = this.urlParams(catalogData);
        hlUrlAry.push(hlUrl);
        hlUrlAry.push("sort="+encodeURIComponent(sort));
        taxonomyObj.ratings.length && hlUrlAry.push("minRating="+encodeURIComponent(taxonomyObj.ratings.join("|")));
        taxonomyObj.brand.length && hlUrlAry.push("brand="+encodeURIComponent(taxonomyObj.brand.join("|")));
        priceArr[0] && hlUrlAry.push("minPrice="+priceArr[0]);
        priceArr[priceArr.length-1] && hlUrlAry.push("maxPrice="+priceArr[priceArr.length-1]);
        taxonomyObj.filters && hlUrlAry.push("filters="+encodeURIComponent(JSON.stringify(taxonomyObj.filters)));
        for(var param in hl_params) {
        	hl_params[param] && hlUrlAry.push(hl_params[param]);
    	}
    	window.callBack = function(res) {
    		KOHLS.hookLogic.hl_callback(res);
    	}
    	hlUrlAry.push("json=callBack");
    	return hlUrlAry.join("&");
	}
}

export function initHookLogic(callBack,catalogData){
	try{
		KOHLS.hookLogic.actionCallBck = callBack;
		var hl_url = KOHLS.hookLogic.prepareHooklogicUrl(catalogData);
        $.getScript(hl_url);
	}catch(e){
		console.log(e.message);
	}
}