import createLoginModal from './containers/login-container';
import * as utils from '../global/utils';
import * as lbls from '../global/label-utils';
import * as doLogin from './login-util.js';
import * as mergeCartHelper from '../global/merge-cart-helper';
import * as cartHelper from '../global/cart-helper';
export {login, logout, setLoginCookies, getExpirationDate} from './login-util.js';

const reactContainerElementId = 'login-modal-container';
const myInfo = '/myaccount/v2/myinfo.jsp';

export function createProfile(firstName, lastName, email, password, salesAlert, errorCallback, loginCallBack){

  const profileData = {
  	"payload": {
  		"profile": {
  			"customerName": {
  				"firstName": firstName,
  				"lastName": lastName
  			},
  			"password": password,
  			"email": email,
        "preferences" :{
          "saleAlerts" : salesAlert
        }
  		}
  	}
  };
 console.log(profileData);
  $.ajax({
    url: '/api/v1/profile',
    method: 'POST',
    data: JSON.stringify(profileData),
    contentType: 'application/json',
    headers: {'Accept': 'application/json'}
  }).then(function(loginResponseObj){
    if (loginResponseObj && loginResponseObj.payload){
      //setLoginCookies(loginResponseObj);
      console.log('successful login: ' + loginResponseObj.payload.message);
      doLogin.login(email, password, errorCallback, loginCallBack);
      unmountLogin();
    }else{
      utils.hideLoader();
      console.log('error: ' + JSON.stringify(loginResponseObj));
      errorCallback(loginResponseObj);
    }
  }).fail((error) =>{
    utils.hideLoader();
    errorCallback('An Error has occurred.  Please try again:');
  });
}

export function init(LoginModalView, SignInView, SignUpView, showCreateAccount, loginCallBack, ResetView){
  const LoginModal = createLoginModal(LoginModalView, SignInView, SignUpView, ResetView);
  ReactDOM.render((
      <LoginModal showCreateAccount={showCreateAccount} loginCallBack={loginCallBack}/>
  ), document.getElementById(reactContainerElementId));

  if(kohlsData.nuDataFlag && ndsapi) {
      ndsapi.bindNewFields();

  }
}

export function unmountLogin(){
  ReactDOM.unmountComponentAtNode(document.getElementById(reactContainerElementId));
  document.body.classList.remove('t-login-mask');
}

export function resetPassword(email, errorCallback, callback){
  const data = `email=${email}`;
  email && $.ajax({
    url: '/api/v1/profile/forgotPassword',
    method: 'GET',
    data: data,
    contentType: 'application/json',
    headers: {'Accept': 'application/json'}
  }).then(function(responseObj){
    if (responseObj && responseObj.payload){
      callback && callback(responseObj);
      utils.hideLoader();
    }else{
      utils.hideLoader();
      errorCallback(loginResponseObj);
    }
  }).fail(() =>{
    utils.hideLoader();
    errorCallback({errors:[{message:lbls.labels.serverError}]});
  });
}

export function updateResetPassword(info, errorCallback, callback){
const data = {"payload": {"password":window.btoa(info.password), "token":info.token}};

$.ajax({
    //url: '/oapi/v1/profile/password',
    url: '/v1/profile/password',
    method: 'PUT',
    data: JSON.stringify(data),
    contentType: 'application/json',
    headers: {'Accept': 'application/json'}
  }).then(function(responseObj){
    if (responseObj && responseObj.payload){
      callback && callback(responseObj);
      doLogin.login(responseObj.payload.email, info.password, errorCallback, function(){});
      utils.hideLoader();
    }else{
      utils.hideLoader();
      errorCallback(loginResponseObj);
    }
  }).fail(() =>{
    utils.hideLoader();
    errorCallback({errors:[{message:lbls.labels.serverError}]});
  });

}

export function validateToken(token, errorCallback, callback){
  const data = `token=${token}`;
  token && $.ajax({
    //url: '/oapi/v1/profile/password/validate',
    url: '/v1/profile/password/validate',
    method: 'GET',
    data: data,
    contentType: 'application/json',
    headers: {'Accept': 'application/json'}
  }).then(function(responseObj){
    if (responseObj && responseObj.payload){
      callback && callback(responseObj);
      utils.hideLoader();
    }else{
      utils.hideLoader();
      errorCallback(false);
    }
  }).fail((responseObj) =>{
    utils.hideLoader();
    responseObj.responseJSON && responseObj.responseJSON.errors && responseObj.responseJSON.errors[0].code == "PROF9991" ? errorCallback(false): errorCallback(true);
  });

}
