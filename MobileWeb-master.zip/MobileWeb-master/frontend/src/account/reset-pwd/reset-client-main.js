import ResetContainer from './containers/reset-container';
ReactDOM.render(<ResetContainer />, document.getElementById('reset-container'));