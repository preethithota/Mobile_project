import * as loginHelper from '../../login-helper';
import * as validationHelper from '../../../global/validation/validation-helper';
import ResetView from '../views/reset-view';
import * as utils from '../../../global/utils';
var containerRef = null;
export default class extends React.Component{    
    constructor(props){
        super(props);
        var _this = this;
        var resetData = {resetPwd:false, updatePwd:false, expireLink:false, updateSuccess:false};
        this.state = {
          fields: {},
          errors: {},
          isSubmitButtonEnabled: false,
          backendErrors:[],
          resetView:resetData,
          shareLink:false,
          SrvErr:false
        };       
        containerRef= this.eventHandlers();
        this.token = utils.getUrlParam("token",location.href);
        this.token && loginHelper.validateToken(this.token, function(isSrvErr){
          isSrvErr?_this.setState({SrvErr:true}):_this.setState({resetView:{expireLink:true}})
        }, function(){
       _this.setState({resetView:{updatePwd:true}})})

     }

     handleBackedErrors(response){      
        let backendErrors = [];
          if (response && response.errors){
            response.errors.map((error) => {
              backendErrors.push(error.message);
            });
          }
        return backendErrors;    
     }
     
     eventHandlers(){
      return {

        handleInputChange:function(e) {
           const target = e.target, fieldId = target.id;
            const fields = this.state.fields, errors = this.state.errors;
            delete errors[fieldId];
            let fieldValue;
            try{
              fieldValue = decodeURIComponent(target.value);
            }catch(err){
              fieldValue = target.value;
            }
            fields[fieldId].value = fieldValue;
            const isSubmitButtonEnabled = validationHelper.validateRequiredFields(fields); 
            const pwValidIfPreset = validationHelper.validatePasswordInFields(fields);                   
            this.setState({fields, errors, isSubmitButtonEnabled: isSubmitButtonEnabled && pwValidIfPreset});
        }.bind(this),

        registerField: function(field){
            const fields = this.state.fields;
            fields[field.id] = field;
            this.setState({fields});           
        }.bind(this),

        resetCancelClick:function(e) {         
            this.setState({resetView:{resetPwd:false, updatePwd:false, expireLink:true, updateSuccess:false}});  
        }.bind(this),   
            
        showSignIn:function(e) {
          if(window._header){
            var bdyCls = document.body.classList;
            bdyCls.add("sign-in-page");
            bdyCls.remove("update");
            this.setState({resetView:{resetPwd:false, updatePwd:false, expireLink:false, updateSuccess:false}});
            window._header.eventHandlers().showLogin(e);
          }
        }.bind(this),

        resetYourPwd:function(e){
          this.setState({resetView:{resetPwd:true,expireLink:(kohlsData.isTcom?true:false)}});          
        }.bind(this),

        continueShop:function(e){
          location.href = '/';         
        }.bind(this),

        frmSubmit:function(event){
            if(event.charCode == 13) {
              containerRef.handleSubmit();
            }
          }.bind(this),

        handleSubmit: function(){
            var _this = this;
            if (!this.state.isSubmitButtonEnabled) return;
            const fields = this.state.fields;
            let errors = validationHelper.validate(this.state.fields);
            this.setState({errors});
            for(let key in errors) {
              if(errors.hasOwnProperty(key)){
                return false;
              }
            }
            this.state.resetView.resetPwd ? loginHelper.resetPassword(fields.resetEmail.getValue(), this.handleBackedErrors, function(){_this.setState({resetView:{resetPwd:true, expireLink:(kohlsData.isTcom?true:false)},shareLink:true})}) : loginHelper.updateResetPassword({password:fields.updatePassword.getValue(),token:_this.token}, this.handleBackedErrors, function(){_this.setState({resetView:{updatePwd:false, updateSuccess:true}});document.body.classList.remove("update")});
            this.handleBackedErrors.length && this.setState({backendErrors:this.handleBackedErrors()});
        }.bind(this)
      }
    }
    render(){
      return (<ResetView {...this.state} eventHandlers={this.eventHandlers()}/>)
    }
};
