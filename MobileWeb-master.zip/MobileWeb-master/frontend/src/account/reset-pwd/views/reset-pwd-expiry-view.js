import * as lbls from '../../../global/label-utils';
import {setResetExpiryOmniture} from '../../../../public/lib/omniture-util';

export default React.createClass({
	render: function(){
		const eventHandlers = this.props.eventHandlers;
    	 return (<div id="expire-link" className={"forget-pwd"+(kohlsData.isTcom?" t-com":"")}>
    	 	{setResetExpiryOmniture()}
			<div className="forget-pwd-title">{lbls.labels.forgetPwdTitle}</div>       
	        <div>{lbls.labels.expireLinkDesc}</div>
	        <div id='expire-link-sugn'>{lbls.labels.expireLinkSugn}</div>
	        <div>{lbls.labels.expireLinkWrn}</div>
	        <div className="reset-pwd"><button className="reset-signin-btn" onClick={eventHandlers.resetYourPwd}>{lbls.labels.expiryResetPwd}</button></div>
        </div>)
	}
}
 );


          