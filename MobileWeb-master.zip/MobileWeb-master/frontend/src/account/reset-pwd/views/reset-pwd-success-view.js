import * as lbls from '../../../global/label-utils';
import {setResetConfirmOmniture} from '../../../../public/lib/omniture-util';

export default React.createClass({
	render: function(){
		const eventHandlers = this.props.eventHandlers;
    	return (<div id="success-link" className={"forget-pwd"+(kohlsData.isTcom?" t-com":" m-com")}>
			{setResetConfirmOmniture()}
			<div className="forget-pwd-title">{lbls.labels.successResetTtl}</div>  
			<div className="reset-title-sec">{lbls.labels.successResetDesc}</div>      
	        <div>{lbls.labels.resetStatusa}{kohlsData.isTcom? "":<br/>}{lbls.labels.resetStatusb}{kohlsData.isTcom? '.' : ""} </div>        
	        <div className="continue-shop"><button className="reset-signin-btn" onClick={eventHandlers.continueShop}>{lbls.labels.resetCntShoping}</button></div>
        </div>)
	}
});

