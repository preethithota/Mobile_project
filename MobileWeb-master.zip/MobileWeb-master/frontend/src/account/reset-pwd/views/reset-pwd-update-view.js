import InputField from '../../components/input-field-component';
import * as lbls from '../../../global/label-utils';

export default React.createClass({
	render: function(){
    const props = this.props;
		const eventHandlers = props.eventHandlers;
      document.body.classList.add('update');
      document.body.classList.remove('search-visible');
      
    	return (<div id="update-password" className={"forget-pwd"+(kohlsData.isTcom?" t-com":" m-com")} onKeyPress={eventHandlers.frmSubmit}>
        {!kohlsData.isTcom?(<div className={"login-modal-header"+(props.resetView !== undefined && props.resetView.resetPwd?" display-none":"")}>
          <div id="cancel-btn" className='cancel-btn' onClick={eventHandlers.showSignIn}>{lbls.labels.forgotPwdCancel}</div>
          <div className="modal-title"><b>{lbls.labels.sentMailTtl}</b></div>
        </div>):(<div><div className='update-title'><b>{lbls.labels.sentMailTtl}</b></div>
        <div className='update-desc'>{lbls.labels.updateDesc}</div></div>)}
        
		  <InputField type="newPassword" id="updatePassword" label={lbls.labels.updatePwd} required={true} placeholder={lbls.labels.updatePwdPlsHldr}
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} showPasswordLink={true} registerField={eventHandlers.registerField}/>
          {props.backendErrors.map((error, index) => { return <div className="error-msg" key={index}>{error}</div>})}
          <button id="send-btn" className={"send-btn"+(props.isSubmitButtonEnabled ? '' : ' disabled')} onClick={eventHandlers.handleSubmit}>{lbls.labels.updateSave}</button>          
        </div>);
	}
});
