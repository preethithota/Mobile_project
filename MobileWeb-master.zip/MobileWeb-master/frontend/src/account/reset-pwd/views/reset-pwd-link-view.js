import InputField from '../../components/input-field-component';
import * as lbls from '../../../global/label-utils';
import {setResetPwdOmniture} from '../../../../public/lib/omniture-util'
import {setForgotPwdOmniture} from '../../../../public/lib/omniture-util'

class ResetView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;

    return (<div id={kohlsData.isTcom?"tcom-login-modal":"mcom-login-modal"} className="reset-password-panel">
  <div className="resetPwdWnd">
		    {!kohlsData.isTcom?(<div className={"login-modal-header"+(props.resetView !== undefined && props.resetView.resetPwd?" display-none":"")}>
          <div id="cancel-btn" onClick={eventHandlers.resetCancelClick}>{lbls.labels.forgotPwdCancel}</div>
          <div className="modal-title">{lbls.labels.forgotPwdSignIn}</div>
        </div>):
        (<div className="header-bar">
          <div className="login-title">{!props.shareLink ? lbls.labels.forgotResetYrPwd : <b>{lbls.labels.forgotPwdSent}</b>}</div>
          <div id="cancel-btn" onClick={eventHandlers.resetCancelClick}>X</div>
        </div>)}

      {!props.shareLink?(<div className="forget-pwd" onKeyPress={eventHandlers.frmSubmit}>
      {setForgotPwdOmniture()}{!kohlsData.isTcom && <div id="m-account-title">{lbls.labels.forgotPwdTtl}</div>}
      <div className="forget-pwd-desc">{lbls.labels.forgotPwdDesca}{kohlsData.isTcom?<br/>:""}{lbls.labels.forgotPwdDescb}</div>
        <InputField type="email" id="resetEmail" placeholder={lbls.labels.forgotPwdPlcHldr} label={lbls.labels.forgotPwdEml} autoCapitalize="none" autoCorrect="off" required={true}
        handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField} />        
        <button id="send-btn" className={props.isSubmitButtonEnabled ? '' : 'disabled'} onClick={eventHandlers.handleSubmit}>{lbls.labels.forgotPwdSend}</button>
        <button id="reset-cancel" onClick={eventHandlers.resetCancelClick}>{lbls.labels.forgotPwdCancel}</button>
      </div>):(<div className="share-lnk"> 
        {setResetPwdOmniture()}{!kohlsData.isTcom && <div className="forget-pwd-title">{lbls.labels.sentMailTtl}</div>}    
        <div className="share-lnk-desc" dangerouslySetInnerHTML={{__html: lbls.labels.sentLinkDesc(props.fields.resetEmail.value)}} ></div>
        <div id="share-lnk-note" className="share-lnk-note" dangerouslySetInnerHTML={{__html: lbls.labels.sentMailNote}}></div>
        <div className="forget-lnk-sign-in"><button className="reset-signin-btn" onClick={props.resetView !== undefined && props.resetView.resetPwd?eventHandlers.showSignIn:eventHandlers.resetCancelClick}>{!kohlsData.isTcom?lbls.labels.forgotPwdSignIn:lbls.labels.backtoSignIn}</button></div>
        </div>)}
      </div>
      {kohlsData.isTcom && (<div className="mask"></div>)}
    </div>) 
    
  }

}

export default ResetView;
