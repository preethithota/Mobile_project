import ResetLinkView from './reset-pwd-link-view'; 
import ResetExpiryView from './reset-pwd-expiry-view'; 
import ResetUpdateView from './reset-pwd-update-view'; 
import ResetSuccessView from './reset-pwd-success-view'; 
import * as lbls from '../../../global/label-utils';

export default React.createClass({

	render: function(){
		const props = this.props;		
    	return (    		
    	<div id="reset-modal-panel">
			{props.resetView.resetPwd && <ResetLinkView {...props} /> }
			{props.resetView.updatePwd && <ResetUpdateView {...props} /> }
			{props.resetView.expireLink && <ResetExpiryView {...props} /> }
			{props.resetView.updateSuccess && <ResetSuccessView {...props} /> }
			{props.SrvErr && (<div id='resetPwdSrvErr'>{lbls.labels.serverError}</div>)}
         </div>
		)
	}
});
