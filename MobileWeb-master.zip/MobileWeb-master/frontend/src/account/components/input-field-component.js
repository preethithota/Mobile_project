import Field from '../../global/field';
import validators from '../../global/validation/validators';

export default class InputField extends React.Component{

  constructor(props){
    super(props);
    const defaultValue = (props.defaultValue) ? props.defaultValue : '';
    this.state = {
      pwLengthValid: false,
      pwNumbersLetters: false,
      pwUpperLower: false,
      showClearPw: false,
      showPasswordHints: false,
      showPasswordGood: false,
      inputValue: defaultValue
    }
    this.isNewPassword = this.isNewPassword.bind(this);
    this.handleInputChange = this.handleInputChange.bind(this);
    this.toggleClearPw = this.toggleClearPw.bind(this);
    this.handleFocus = this.handleFocus.bind(this);
  }

  componentDidMount(){
    const props = this.props;
    const field = new Field(props.id, props.type, props.defaultValue, props.required, props.validatorType);
    props.registerField(field);
  }

  handleInputChange(e){

    this.setState({inputValue: e.target.value})

    if (this.isNewPassword()){
      const password = e.target.value;
      const pwLengthValid = validators.checkLength(8, password);
      const pwNumbersLetters = validators.containsNumbersAndLetters(password);
      const pwUpperLower = validators.containsUpperAndLowerCaseLetters(password);
      const showPasswordGood = pwLengthValid && pwNumbersLetters && pwUpperLower;

      this.setState({
        pwLengthValid,
        pwNumbersLetters,
        pwUpperLower,
        showPasswordGood
      })
    }
    if (e.target.name == "emailOptIn") {
      var inputValue = e.target.checked ? true : false;
    }
    this.props.handleInputChange(e);
  }

  isNewPassword(){
    return this.props.type === 'newPassword';
  }

  handleFocus(){
    if (this.isNewPassword()){
      this.setState({showPasswordHints: true});
    }
  }

  toggleClearPw(){
    this.setState({
      showClearPw: !this.state.showClearPw
    })
  }

  render(){
    const props = this.props;
    const htmlType = (props.type === 'checkbox' ? 'checkbox' : (!this.state.showClearPw && (props.type === 'password' || this.isNewPassword())) ? 'password' : ((props.type === 'email') ? 'email' :'text'));
    const isError = props.errors && props.errors[props.id];
    const defaultChecked = (props.defaultChecked) ? true : '';
    const defaultValue = (props.defaultValue) ? true : '';


    return(
      <div className="input-field-container">
        <div className="input-header">
          {props.label && <label htmlFor={props.id}>{props.label}</label>}
          {props.showPasswordLink && <div className="show-pw"><a onClick={this.toggleClearPw} tabIndex="99">
            {this.state.showClearPw ? 'Hide' : 'Show'} Password
          </a></div>}
        </div>
        <input id={props.id} name={props.id} type={htmlType} className={isError ? 'invalid-field' : ''}
          onChange={this.handleInputChange} defaultChecked={defaultChecked} defaultValue={defaultValue} placeholder={props.placeholder} autoCapitalize={props.autoCapitalize} autoCorrect={props.autoCorrect} onFocus={this.handleFocus} ></input>
        {props.checkAttr && <label htmlFor={props.id}></label>}
        {isError && <div className="error-msg">{props.errors[props.id]}</div>}
        {this.state.showPasswordHints && <div className="password-validity">
          {!this.state.showPasswordGood && <div>
            <div className={'password-check' + (this.state.pwLengthValid ? ' satisfied' : '')}>
              <span className="message">At least 8 characters long</span>{!this.state.pwLengthValid && <span className="dots">&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;</span>}
            </div>
            <div className={'password-check' + (this.state.pwNumbersLetters ? ' satisfied' : '')}>
              <span className="message">Numbers and letters</span>{!this.state.pwNumbersLetters && <span className="example">ABC123</span>}
            </div>
            <div className={'password-check' + (this.state.pwUpperLower ? ' satisfied' : '')}>
              <span className="message">Upper and lower case letters</span>{!this.state.pwUpperLower && <span className="example">Aa</span>}
            </div>
          </div>/*end password warnings*/}
          {this.state.showPasswordGood && <div>
            <div className="password-check success">
              <span className="message">A strong password helps protect your account. Remember to update it regularly.</span>
            </div>
          </div>/*end showPasswordGood*/}
        </div>/*end password-validity*/}
      </div>
    )
  }

}
