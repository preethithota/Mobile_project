import * as loginHelper from '../login-helper';


describe('getLoginExpiration', () => {
  //const testDate = new Date(2019, 11, 25, 8, 9, 10, 0);

  it('should return the correct date based on expires_in', () => {
    const expiresIn = "86400"; //24 hours
    const testDate = new Date(1486845624976);//Sat, 11 Feb 2017 20:40:24 GMT
    const updatedDate = loginHelper.getExpirationDate(testDate, expiresIn);
    expect(updatedDate.getDate()).toEqual(12);
    expect(updatedDate.getSeconds()).toEqual(testDate.getSeconds());
    expect(updatedDate.getMonth()).toEqual(testDate.getMonth());
    expect(updatedDate.getYear()).toEqual(testDate.getYear());
  });

  it('should return the correct date based on ttl', () => {
    const ttl = "15769999"; //24 hours
    const testDate = new Date(1486845624976);//Sat, 11 Feb 2017 20:40:24 GMT
    const updatedDate = loginHelper.getExpirationDate(testDate, ttl);
    expect(updatedDate.getMonth()).toEqual(testDate.getMonth() + 6);
    expect(updatedDate.getYear()).toEqual(testDate.getYear());
  });

});
