import Field from '../../global/field';
import * as validationHelper from '../../global/validation/validation-helper';
import * as utils from '../../global/utils';

  export default function createAccountForm(AccountView, submitCallback){

    return class extends React.Component{

      constructor(props){
        super(props);
        this.submitCallback = submitCallback;
        //this.handleBackedErrors = this.handleBackedErrors.bind(this);
        this.handleSubmit = this.eventHandlers().handleSubmit.bind(this);
        this.showResetModel = this.eventHandlers().showResetModel.bind(this);
        this.state = {
          fields: {},
          errors: {},
          isSubmitButtonEnabled: false
        };
      }

      eventHandlers(){
        return {
          handleInputChange: function(e) {
            const target = e.target, fieldId = target.id;
            const fields = this.state.fields, errors = this.state.errors;
            delete errors[fieldId];

            let fieldValue;
            try{
              fieldValue = decodeURIComponent(target.value);
            }catch(err){
              fieldValue = target.value;
            }
            if (target.name == "emailOptIn") {
              fieldValue = target.checked ? true : false;
            }
            fields[fieldId].value = fieldValue;
            const isSubmitButtonEnabled = validationHelper.validateRequiredFields(fields);
            const pwValidIfPreset = validationHelper.validatePasswordInFields(fields);
            console.log('isSubmitButtonEnabled is ' + isSubmitButtonEnabled);
            this.setState({fields,
               errors,
              isSubmitButtonEnabled: isSubmitButtonEnabled && pwValidIfPreset});
          }.bind(this),

        showResetModel: function(){
          this.submitCallback(this.state.fields,true);
        }.bind(this),

        resetCancelClick: function(){
          this.submitCallback(this.state.fields,true);
        }.bind(this),

          registerField: function(field){
            const fields = this.state.fields;
            var rstId = 'resetEmail';
            if(field.id === rstId){
              var lgnVal = document.getElementById("loginEmail").value;
              var rstEml = document.getElementById(rstId);
               if(lgnVal != ""){
                 field.value = rstEml.value = lgnVal;
                 this.setState({isSubmitButtonEnabled: true});
               }
            }

            fields[field.id] = field;
            this.setState({fields});

            if (this.props.isSoftedLoggedIn && field.id === 'loginEmail'){
              const softAccessToken = utils.getCookieValue('softLoginToken');
              $.ajax({
                //url: '/oapi/v1/profile/email',
                url: '/v1/profile/email',
                contentType: 'application/json',
                headers: {'Accept': 'application/json', 'access_token': softAccessToken}
              }).then(response => {
                if (response && response.payload){
                  //setLoginCookies(loginResponseObj);
                  console.log('response is: ' + JSON.stringify(response));
                  const email = response.payload.email;
                  field.value = email;
                  //this.setState({email});
                  document.getElementById("loginEmail").value = email;

                }
              });
            }
          }.bind(this),

          frmSubmit:function(evt){
            if(evt.charCode == 13) {
              {this.handleSubmit(evt)};
            }
          }.bind(this),

          handleSubmit: function(evt){
            if(evt.nativeEvent && evt.nativeEvent.srcElement.tagName ==="BUTTON") {
              if (!this.state.isSubmitButtonEnabled) return;
            }
            const fields = this.state.fields;
            let errors = validationHelper.validate(this.state.fields);
            this.setState({errors});
            if (utils.isObjectEmpty(errors)){
                this.submitCallback(fields,false);
            }
          }.bind(this)
        }
      }/*End eventHandlers*/

      render(){
        return <AccountView {...this.state} {...this.props} eventHandlers={this.eventHandlers()}  />
      }
    }

}
