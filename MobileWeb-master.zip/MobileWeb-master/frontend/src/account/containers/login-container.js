
import * as loginHelper from '../login-helper';
import * as utils from '../../global/utils';
import createAccountForm from './account-form-container';
import {setSignInOmniture} from '../../../public/lib/omniture-util';

export default function createLoginModal(LoginModalView, SignInView, SignUpView, ResetView){

  return class extends React.Component{

    constructor(props){
      super(props);
      this.eventHandlers = this.eventHandlers.bind(this);
      this.signUpForm = createAccountForm(SignUpView, this.submitSignUp.bind(this));
      this.signInForm = createAccountForm(SignInView, this.submitSignIn.bind(this));
      this.resetForm = createAccountForm(ResetView, this.resetViewHandle.bind(this));

      this.handleBackedErrors = this.handleBackedErrors.bind(this);
      const isSoftedLoggedIn = utils.isSoftedLoggedIn();
      const firstName = (isSoftedLoggedIn) ? utils.getFirstName() : '';
      const showSignUp = (this.props.showCreateAccount) ? true : false;
      

      this.state = {
        showSignUp,
        backendErrors: [],
        isSoftedLoggedIn,
        firstName: utils.capitalizeFirstLetter(firstName),
        email: '',
        isHomeRedirect:false,
	      isReset:false,
        resetLink:false
      };
    }

    submitSignIn(fields,isRst){
      if(!isRst) {
      utils.showLoader();
      loginHelper.login(fields.loginEmail.getValue(), fields.loginPassword.getValue(),
        this.handleBackedErrors, this.props.loginCallBack);
      }else{
         isRst && !this.state.isReset && this.setState({isReset:isRst});
      }
    }

    submitSignUp(fields,isReset){
      console.log('submit sign up called');
      utils.showLoader();
      //this.setState({isDisplayLoyalty: true});
      loginHelper.createProfile(fields.firstName.getValue(), fields.lastName.getValue(), fields.signUpEmail.getValue(),
       fields.signUpPassword.getValue(), fields.emailOptIn.getValue(), this.handleBackedErrors, this.props.loginCallBack);
    }

    resetViewHandle(fields,isRst){ 
      var _this = this;       
      if(!isRst) {
      utils.showLoader();
      loginHelper.resetPassword(fields.resetEmail.getValue(), this.handleBackedErrors, function(){
        _this.setState({resetLink:true});
      });
      }else{
         isRst && _this.state.isReset && _this.setState({isReset:!isRst,resetLink:false});
      }      
    }

    handleBackedErrors(response){
      console.log('inside handleBackedErrors');
      let backendErrors = [], jsonObj;
      if (response && response.errors){
        response.errors.map((error) => {
          try {
            jsonObj = JSON.parse(error.message);
          }
          catch(exception) {
            jsonObj = null;
          }
          if(jsonObj) {
            for(var obj in jsonObj){
              if(obj == 'Error'){
                backendErrors.push(jsonObj[obj]);
              }
            }
          }
          else {
            backendErrors.push(error.message);
          }
        });
      }
      this.setState({backendErrors});
      if(response.errors && response.errors[0].code == "PROF9163"){
        document.getElementById('signUpEmail').classList.add("invalid-field");
      } 
      document.body.scrollIntoView();
    }

    eventHandlers(){
      return {
        setShowSignUp: function(showSignUp){
          if (showSignUp !== this.state.showSignUp){
            this.setState({
              showSignUp,
              backendErrors: []
            });
          }
        const page = location.href.indexOf('rewards') > -1 ? "loyalty" : "account";
		    setSignInOmniture(page,showSignUp);
        }.bind(this),

        handleCancelClick: function(){
          if(this.state.isHomeRedirect){
            location.href = '/';
          }
		  if(window.location.href.indexOf("write_review.jsp") !=-1)
		  {
			  history.go(-1);
		  }
          this.eventHandlers().disappearLoginModal();
        }.bind(this),

        guestCheckoutClick: function(){
          var data = {};
          this.props.loginCallBack(data, 'CHECKOUT_AS_GUEST');
          this.eventHandlers().disappearLoginModal();
        }.bind(this),
        disappearLoginModal: function() {
          loginHelper.unmountLogin();
          document.body.classList.remove('t-login-mask');
        }.bind(this),
        redirectVISACheckoutPage: function() {
          this.eventHandlers().disappearLoginModal();
          location.hash = '/visaCheckout';
        }.bind(this),
        logout: function(){
          loginHelper.logout();

          const emailElem = document.getElementById("loginEmail");
          if (emailElem) emailElem.value =  '';
          
          this.setState({
            isSoftedLoggedIn: false,
            firstName: '',
            backendErrors: [],
            isHomeRedirect:true
          });
        }.bind(this)
      }
    }

    render(){
      return <LoginModalView {...this.state}
        signInForm={this.signInForm}
        signUpForm={this.signUpForm}
        resetForm={this.resetForm}
        eventHandlers={this.eventHandlers()}
        />
    }
  }

}
