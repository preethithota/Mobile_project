import Field from '../../global/field';
import * as validationHelper from '../../global/validation/validation-helper';
import * as utils from '../../global/utils';

  export default function loyaltyForm(LoyaltyEnrollView, submitCallback){

    return class extends React.Component{

      constructor(props){
        super(props);
        this.submitCallback = submitCallback;
        //this.handleBackedErrors = this.handleBackedErrors.bind(this);
        this.handleSubmit = this.eventHandlers().handleSubmit.bind(this);
        this.state = {
          fields: {},
          errors: {},
          isDisplayLoyalty : false
        };
      }

      eventHandlers(){
        return {
            handleSubmit: function(){
            if (!this.state.isSubmitButtonEnabled) return;
            const fields = this.state.fields;
            let errors = validationHelper.validate(this.state.fields);
            this.setState({errors});
            if (utils.isObjectEmpty(errors)){
              this.submitCallback(fields,false);
            }
          }.bind(this)
        }
      }/*End eventHandlers*/

      render(){
        return <LoyaltyEnrollView {...this.state} {...this.props} eventHandlers={this.eventHandlers()}  />
      }
    }

}
