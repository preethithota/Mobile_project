import InputField from '../components/input-field-component';

class SignInView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;

    return <div id="sign-in-form" onKeyPress={eventHandlers.frmSubmit} className="left-pane">
      

          {props.backendErrors.map((error, index) => {
            return <div className="error-msg" key={index}>{error}</div>
          })}
		  {!props.isSoftedLoggedIn && <div>
          <h3>Sign In</h3>
          <p>Sign in to your Kohl&#39;s Shopping Account and take advantage of Express Checkout.</p>
		  </div>}
		  {props.isSoftedLoggedIn && <div>
          <p>Since you haven&#39;t been active in a while, please sign in to confirm it&#39;s you.</p>
		  </div>}
          <InputField type="email" id="loginEmail" label="E-Mail address" required={true}
            handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField} />
          <InputField type="password" id="loginPassword" label="Password" required={true}
            handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField} />
          <button id="sign-in-btn" className={props.isSubmitButtonEnabled ? '' : 'disabled'} onClick={(e)=>eventHandlers.handleSubmit(e)}>
            SIGN IN
          </button>
          <div className="forgot-pw">
            <a href="#" id="forgot-pw-link" onClick={eventHandlers.showResetModel}>Forgot your password?</a>
          </div>

       
    </div>
  }
}

export default SignInView;
