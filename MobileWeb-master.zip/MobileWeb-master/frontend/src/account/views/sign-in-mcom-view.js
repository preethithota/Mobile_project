import InputField from '../components/input-field-component';

class SignInView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;

    return <div id="sign-in-form" onKeyPress={eventHandlers.frmSubmit}>
      <InputField type="email" id="loginEmail" placeholder="name@email.com" label="Email Address" autoCapitalize="none" autoCorrect="off" required={true}
        handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField} />
      <InputField type="password" id="loginPassword" placeholder="Password" label="Password" required={true} showPasswordLink={true}
        handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField} />
      {props.backendErrors.map((error, index) => {
        return <div className="error-msg" key={index}>{error}</div>
      })}
      <div className="forgot-pw">
        <a href="javascript:void(0);" id="forgot-pw-link" onClick={eventHandlers.showResetModel}>Forgot your password?</a>
      </div>

      <button type="submit" id="sign-in-btn" className={props.isSubmitButtonEnabled ? '' : 'disabled'} onClick={(e)=>eventHandlers.handleSubmit(e)}>
        SIGN IN
      </button>
    </div>
  }
}

export default SignInView;
