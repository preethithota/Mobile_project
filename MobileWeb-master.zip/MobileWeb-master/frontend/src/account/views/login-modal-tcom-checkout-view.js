import InputField from '../components/input-field-component';

export default class LoginModalView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;
    const SignUpForm = props.signUpForm;
    const SignInForm = props.signInForm;
    const ResetForm = props.resetForm;

    return <div id="login-modal">
	  <div id="tcom-login-modal" className={props.isReset?"display-none":""}>
        <div className="header-bar">
          <div className="login-title">{props.showSignUp ? 'Create Account' : 'SIGN IN'}</div>
          <div id="cancel-btn" onClick={eventHandlers.handleCancelClick}>X</div>
        </div>
        <div id="form-container">
		<div className="main-content">
          {!props.showSignUp && <SignInForm setShowSignUp={eventHandlers.setShowSignUp} backendErrors={props.backendErrors}
		  isSoftedLoggedIn={props.isSoftedLoggedIn} firstName={props.firstName} logout={eventHandlers.logout} isSoftedLoggedIn={props.isSoftedLoggedIn}/>}
			
		 {!props.isSoftedLoggedIn && <div className="right-pane">
			<div className="guest-checkout">
			  <h2>Guest Checkout</h2>				 
				<p> There is no sign-in required to checkout as a guest. You&#39;ll have the opportunity to create an account during checkout. </p>
			  <p>Member Benefits:</p>
			  <ul>
				<li>-Express Checkout</li>
				<li>-Save and share your favorite products in My Lists</li>
			  </ul>
			  <div><button onClick={eventHandlers.guestCheckoutClick} className="guest-checkout-btn" >GUEST CHECKOUT</button></div>
			  <div className="checkout-txt">Or checkout with</div>
			  <div><div className="t-visa-checkout-option"></div><div className="t-master-pass-option"></div></div>
			</div>
			</div>}
			
		{props.isSoftedLoggedIn && <div className="right-pane">
        <h2 onClick={props.logout}>Not you?</h2>
        <button id="soft-logout-btn" onClick={props.logout}>LOG OUT</button>
        </div>}
      </div>
      
          {props.showSignUp && <SignUpForm setShowSignUp={eventHandlers.setShowSignUp} backendErrors={props.backendErrors}/>}
        </div>
      </div>
      {props.isReset && <ResetForm backendErrors={props.backendErrors} shareLink={props.resetLink} />}
	  <div className="t-login-overlay" onClick={eventHandlers.handleCancelClick}></div>
    </div>
  }
}
