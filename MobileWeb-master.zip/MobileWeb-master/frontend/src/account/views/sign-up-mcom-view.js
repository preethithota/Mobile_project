import InputField from '../components/input-field-component';

class SignUpView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;

    return <div id="sign-up-form" onKeyPress={eventHandlers.frmSubmit}>
      <p>
        With an account you have access to express checkout, easy order tracking and purchase history. By creating an account, you agree to Kohl&#39;s <strong><a href="#">Security &amp; Privacy Policy</a></strong> and <strong><a href="#">Legal Notices.</a></strong>
      </p>

      <div className="form-container">
        <h3>ABOUT ME</h3>
         {props.backendErrors.map((error, index) => {
            return <div className="error-msg" key={index}>{error}</div>
          })}
        <InputField type="name" id="firstName" label="First Name" required={true}
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField}/>
        <InputField type="name" id="lastName" label="Last Name" required={true}
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField}/>
        <InputField type="email" id="signUpEmail" label="Email Address" autoCapitalize="none" autoCorrect="off" required={true}
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField}/>
        <InputField type="newPassword" id="signUpPassword" label="Password" required={true} placeholder="At least 8 characters, can't be email address"
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} showPasswordLink={true} registerField={eventHandlers.registerField}/>
        <div className="email-opt-in">
          <InputField type="checkbox" id="emailOptIn" defaultChecked={true} defaultValue={true} handleInputChange={eventHandlers.handleInputChange} registerField={eventHandlers.registerField} checkAttr="emailOptIn" />
          <div className="opt-in-desc">Yes, sign me up to receive Kohl&#39;s e-mail offers, updates on sales and events and more! US Residents Only. Get 15% off your next purchase. Terms apply; <a href="https://cs.kohls.com/app/answers/detail/a_id/691/kw/sales%20alerts" target="_blank">see details</a>. <a href="/common/content/securityprivacy" target="_blank">Privacy Policy</a></div>
        </div>

        <button id="sign-in-btn" className={props.isSubmitButtonEnabled ? 'active' : 'disabled'} onClick={eventHandlers.handleSubmit}>
          CONTINUE
        </button>
      </div>
    </div>
  }
}

export default SignUpView;
