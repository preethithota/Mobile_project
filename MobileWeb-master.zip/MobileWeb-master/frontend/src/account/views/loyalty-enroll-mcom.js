import InputField from '../components/input-field-component';

export default class LoyaltyEnrollView extends React.Component{

  render(){

    return <div id="loyalty-signup" className={props.isDisplayLoyalty ? 'show' : 'hide'}>
      <h3>ADD REWARDS</h3>
      <div className="rwdsSmallTxt m10">One more step. You&#39;re almost done!</div>
      <div className="mcomRwdsYes2YouImg p5"></div>
      <div className="rwdsModifyDetails">
          <div className="rwdsSmallTxt m10">Enroll in Yes2You Rewards today and earn <br/> points on your purchases!</div>
          <div className="rwdsSmallTxt m10"> Not a member yet? <br/>PROGRAM DETAILS</div>
      </div> 
      <div className="rwdsBdayContainer rwdsInputWrap">
          <label>Birthday</label>
          <div className="rwdsBirthDayDiv">
            <div className="selectElemParent selectParentMonth">
              <div className="selectBirthdayCustomArrow"></div>
              <select id="idRwdsJoinBirthInputMonth" className="tcomRwdsMonth" name="nameRwdsMonth">
                <option value="">Month</option>  <option value="01">January</option>  <option value="02">February</option>  <option value="03">March</option>  <option value="04">April</option>  <option value="05">May</option>  <option value="06">June</option>  <option value="07">July</option>  <option value="08">August</option>  <option value="09">September</option>  <option value="10">October</option>  <option value="11">November</option>  <option value="12">December</option>  
              </select>
            </div>
            <div className="selectElemParent selectParentDay">
              <div className="selectBirthdayCustomArrow"></div>
              <select id="idRwdsJoinBirthInputDay" className="tcomRwdsDay" name="nameRwdsDay">
                <option value="">01</option>  
              </select>
            </div>
            <div className="selectElemParent selectParentYear">
                <div className="selectBirthdayCustomArrow"></div>
                <select id="idRwdsJoinBirthInputYear" className="tcomRwdsYear" name="nameRwdsYear" onchange="KOHLS.loylaty.init().generateBirthdaySelect(0);">
                  <option value="">2001</option>  
                 </select>
             </div>
           </div>
      </div>
      <div className="tcomRwdsInputWrap rwdsInputWrap" id="rwdIdCont">
          <InputField type="name" id="rewardsId" autocomplete="off" label="Reward ID or Phone Number" registerField={eventHandlers.registerField} required={true} errors={props.errors} placeholder="Enter 11 digit Reward ID or Phone #" />
      </div>
      <button id="create-act-btn" onClick={eventHandlers.handleSubmit}>
          Create Account
      </button>
    </div>
  }
}