import InputField from '../components/input-field-component';

export default class LoginModalView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;
    const SignUpForm = props.signUpForm;
    const SignInForm = props.signInForm;
    const ResetForm = props.resetForm;

    return <div id="login-modal">
	  <div id="tcom-login-modal" className={props.isReset?"display-none":""}>
        <div className="header-bar">
          <div className="login-title">{props.showSignUp ? 'Create Account' : 'SIGN IN'}</div>
          <div id="cancel-btn" onClick={eventHandlers.handleCancelClick}>X</div>
        </div>
        <div id="form-container">
		<div className="main-content">
          {!props.showSignUp && <SignInForm setShowSignUp={eventHandlers.setShowSignUp} backendErrors={props.backendErrors}
		  isSoftedLoggedIn={props.isSoftedLoggedIn} firstName={props.firstName} logout={eventHandlers.logout} isSoftedLoggedIn={props.isSoftedLoggedIn}/>}
			
		 {!props.showSignUp && !props.isSoftedLoggedIn && <div className="right-pane">
          <h2>CREATE AN ACCOUNT</h2>
          <p>As a registered Kohl&#39;s.com customer, enjoy exclusive benefits that make shopping faster and easier!</p>
          <p>Member Benefits:</p>
          <ul>
            <li>-Express Checkout</li>
            <li>-Save and share your favorite products in My Lists</li>
          </ul>
          <button className="white-button" id="show-sign-in-btn" onClick={() => eventHandlers.setShowSignUp(true)}>
            CREATE AN ACCOUNT
          </button>
        </div>}
        {props.isSoftedLoggedIn && <div className="right-pane">
        <h2 onClick={props.logout}>Not you?</h2>
        <button id="soft-logout-btn" onClick={props.logout}>LOG OUT</button>
        </div>}
      </div>
      {!props.showSignUp && !props.isSoftedLoggedIn && <div className="modal-footer">
        <p>Looking for your Kohl&#39;s Charge Account?</p>
        <p><a href="https://credit.kohls.com/eCustService/" target="_blank">Sign in to your Kohl&#39;s Charge Account</a> or <a href="https://apply.kohls.com/" target="_blank">Apply for a Kohl&#39;s Charge Card</a></p>
      </div>}
          {props.showSignUp && <SignUpForm setShowSignUp={eventHandlers.setShowSignUp} backendErrors={props.backendErrors}/>}
        </div>
      </div>
      {props.isReset && <ResetForm backendErrors={props.backendErrors} shareLink={props.resetLink} />}
	  <div className="t-login-overlay" onClick={eventHandlers.handleCancelClick}></div>
    </div>
  }
}
