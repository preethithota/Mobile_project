import InputField from '../components/input-field-component';

class SignUpView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;

    return <div id="sign-up-form" onKeyPress={eventHandlers.frmSubmit}>
      <p>All fields are required unless marked optional.</p>

       {props.backendErrors.map((error, index) => {
            return <div className="error-msg" key={index}>{error}</div>
          })}
       
      <div className="field-row">
        <InputField type="name" id="firstName" label="First name" required={true}
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField}/>
        <InputField type="name" id="lastName" label="Last name" required={true}
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField}/>
      </div>
      <div className="field-row">
        <InputField type="email" id="signUpEmail" label="Email" required={true} placeholder="name@mail.com"
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} registerField={eventHandlers.registerField}/>
        <InputField type="newPassword" id="signUpPassword" label="Password" required={true} placeholder="At least 8 characters, can't be email address"
          handleInputChange={eventHandlers.handleInputChange} errors={props.errors} showPasswordLink={true} registerField={eventHandlers.registerField}/>
      </div>

      <div className="preferences">
        <h2>Communication Preferences</h2>
        <div className="email-opt-in">
          <div className="opt-in-input"><input type="checkbox" id="emailOptIn" defaultChecked={true}/></div>
          <div className="opt-in-desc"><p>Yes, sign me up to receive Kohl&#39;s e-mail offers, updates on sales and events and more! US Residents Only. Get 15% off your next purchase. Terms apply; <a href="https://cs.kohls.com/app/answers/detail/a_id/691/kw/sales%20alerts" target="_blank">see details</a> <a href="/common/content/securityprivacy" target="_blank">Privacy Policy</a></p></div>
        </div>
      </div>

      <div className="btn-row">
        <button id="sign-in-btn" className={props.isSubmitButtonEnabled ? 'active' : 'disabled'} onClick={eventHandlers.handleSubmit}>
          CREATE ACCOUNT
        </button>
        <button id="cancel-btn" className="white-button cancel-btn" onClick={() => props.setShowSignUp(false)}>
          CANCEL
        </button>
      </div>
    </div>
  }
}

export default SignUpView;
