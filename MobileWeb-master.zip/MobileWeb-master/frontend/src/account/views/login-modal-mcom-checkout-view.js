import InputField from '../components/input-field-component';
import {unmountLogin} from '../login-helper.js';

export default class LoginModalView extends React.Component{

  render(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;
    const SignUpForm = props.signUpForm;
    const SignInForm = props.signInForm;
    const ResetForm = props.resetForm;
    const isSoftedLoggedIn = props.isSoftedLoggedIn;

    return <div id="login-modal" className={!isSoftedLoggedIn ? "m-login-modal login-modal-checkout" : "m-login-modal login-modal-checkout soft-login-modal"} onKeyPress={eventHandlers.frmSubmit}>
      <div id="mcom-login-modal" className={props.isReset ? "mcom-login-modal-checkout display-none" : "mcom-login-modal-checkout"}>
        {!isSoftedLoggedIn ? <div className="sign-in-header">SIGN IN</div> : (<div className="login-modal-header">
          <div id="cancel-btn" onClick={eventHandlers.handleCancelClick} >Cancel</div>
          <div className="modal-title">SIGN IN</div>
        </div>)}
        {isSoftedLoggedIn && <div className="soft-login-header">Your privacy is important! Since you haven't been active in a while, please sign in to confirm it's you.</div>}
        {/*{!isSoftedLoggedIn && <div id="form-container">
		      <div id="m-account-title">ACCOUNT</div>
          <div id="form-tabs">
            <div className={props.showSignUp ? '' : 'selected'}
              onClick={() => eventHandlers.setShowSignUp(false)}>Sign In</div>
            <div className={props.showSignUp ? 'selected' : ''}
              onClick={() => eventHandlers.setShowSignUp(true)}>Create an Account</div>
          </div>
        </div>}*/}
        {/*{!props.showSignUp && <SignInForm backendErrors={props.backendErrors}  isSoftedLoggedIn={props.isSoftedLoggedIn}/>}
        {props.showSignUp && <SignUpForm backendErrors={props.backendErrors} />}*/}
        <SignInForm backendErrors={props.backendErrors}  isSoftedLoggedIn={props.isSoftedLoggedIn}/>

        {!isSoftedLoggedIn && <div className="guest-checkout">
          <p> There is no sign-in required to checkout as a guest. You'll have the opportunity to create an account during checkout. </p>
          <div><button onClick={eventHandlers.guestCheckoutClick} className="guest-checkout-button" >GUEST CHECKOUT</button></div>
          <div className="checkout-txt">Or checkout with</div>
          <div>{window.kohlsData.isVISACheckoutEnabled && <div className="visa-checkout-option v-button" role="button" onClick={eventHandlers.redirectVISACheckoutPage}></div>}
          <div className="master-pass-option"></div></div>
        </div>}

        {/*{!isSoftedLoggedIn  && <div className="kc-section">
          <p>Looking for your  Kohl&#39;s Charge Account? </p>
          <div><a href="#">Sign in to your Kohl&#39;s Charge Account.</a></div>
          <div><a href="#">Apply for a Kohl&#39;s Charge</a></div>
        </div>}*/}

        {isSoftedLoggedIn && <div className="soft-login-logout">
          <div className="not-me" onClick={eventHandlers.logout}>Not You?</div>
          <button id="soft-logout-btn" onClick={eventHandlers.logout}>LOG OUT</button>
        </div>}

      </div>
      {props.isReset && <ResetForm backendErrors={props.backendErrors} shareLink={props.resetLink} />}
	  <div className="t-login-overlay" onClick={eventHandlers.handleCancelClick} onTouchMove={(e) => e.preventDefault()}></div>
    </div>
  }

}
