import * as utils from '../global/utils';
import {unmountLogin} from './login-helper';
import {mergeOmniChannelBag} from '../global/cart-helper';
import {setProfileData} from '../../public/lib/brightTag-util';

export function getExpirationDate(currentDate, secondsFromNow){
  const secondsFromNowNumber = new Number(secondsFromNow);
  return new Date(currentDate.getTime() + (secondsFromNowNumber * 1000));
}

export function login(userId, password, errorCallback, loginCallBack, hybridLoginCallBack){
  let nuDataNdpdData = "";
  let headerObj = {'Accept': 'application/json'};
  if(kohlsData.nuDataFlag) {
    const nds_pmd = document.getElementsByName("nds-pmd")[0] && document.getElementsByName("nds-pmd")[0].value;
    // To-DO enable this after openapi supports this
    //nuDataNdpdData = nds_pmd ? "&nuDataNdpdData="+nds_pmd : "";
    headerObj['X-APP-API_SESSIONID'] = utils.getCookieValue("nuDataSessionId");
  }
  const data = `grant_type=password&password=${password}&userId=${userId}${nuDataNdpdData}`;
  utils.showLoader();
  $.ajax({
    url: '/api/v2/auth/signInProfile',
    method: 'POST',
    data: data,
    contentType: 'application/x-www-form-urlencoded',
    headers: headerObj//Accept", "application/json"
  }).then(function(loginResponseObj){
    utils.hideLoader();
    if (loginResponseObj && loginResponseObj.payload && loginResponseObj.payload.response){
      setLoginCookies(loginResponseObj);
	  setProfileData(loginResponseObj);
      hybridLoginCallBack && hybridLoginCallBack(loginResponseObj);
      const callback = (data) => {
        loginCallBack && loginCallBack(data, true);
        unmountLogin();
      }
      mergeOmniChannelBag(callback, utils.getCartAccessToken());
    }else{
      console.log('error: ' + JSON.stringify(loginResponseObj));
      errorCallback(loginResponseObj);
    }
  }).fail(() => {
    utils.hideLoader();
  });
}

export function logout(){
  utils.deleteCookie('accessToken');
  utils.deleteCookie('hasAccessToken');
  utils.deleteCookie('refreshToken');
  utils.deleteCookie('hasRefreshToken');
  utils.deleteCookie('softLoginToken');
  utils.deleteCookie('hasSoftLoginToken');
  utils.deleteCookie('firstName');
  utils.deleteCookie('wallet_id');
  utils.deleteCookie('wallet_token');
  utils.deleteCookie('wallet_timestamp');
  utils.deleteCookie('bvusertoken');
  utils.deleteCookie('loyaltyId');
  utils.deleteCookie('nuDataSessionId');
  utils.deleteCookie('skBag');
  utils.deleteFromLocalStorage('skBag');
  utils.deleteCookie('KOHLS-OCB');
  utils.deleteFromLocalStorage('KOHLS-OCB');
  utils.deleteCookie('KOHLS-BAG');
  utils.deleteFromLocalStorage('KOHLS-BAG');

}

function setLoginCookies(loginResponseData){

//TODO: these cookies should all be set server side
  try{
    const currentDate = new Date();
    const walletData = loginResponseData.payload.response.wallet;
    const walletExp = getExpirationDate(currentDate, 7200).toUTCString();// two hours from now

    utils.setCookieValue('wallet_id', walletData.walletId, walletExp, true);
    utils.setCookieValue('wallet_token', walletData.token, walletExp, true);
    utils.setCookieValue('wallet_timestamp', walletData.timestamp, walletExp);
    utils.setCookieValue('loyaltyId', loginResponseData.payload.response.profileInfo.loyaltyId, walletExp, true);

    const signInData = loginResponseData.payload.response.signIn;
    //const loginExp = getExpirationDate(currentDate, signInData.expires_in).toUTCString();
    const loginExp = getExpirationDate(currentDate, 7200).toUTCString();
    const softLoginExp = getExpirationDate(currentDate, signInData.ttl).toUTCString();
    const refreshTokenExp = getExpirationDate(currentDate, 7200).toUTCString();

    utils.setCookieValue('accessToken', signInData.access_token, loginExp, true);
    utils.setCookieValue('hasAccessToken', 'true', loginExp);
    utils.setCookieValue('refreshToken', signInData.refresh_token, refreshTokenExp, true);
    utils.setCookieValue('hasRefreshToken', 'true', refreshTokenExp);
    utils.setCookieValue('softLoginToken', signInData.access_token, softLoginExp, true);
    utils.setCookieValue('hasSoftLoginToken', 'true', softLoginExp);
    utils.setCookieValue('firstName', loginResponseData.payload.response.profileInfo.customerName.firstName, softLoginExp);
    utils.setCookieValue('bvusertoken', loginResponseData.payload.response.profileInfo.bvusertoken, softLoginExp);
    utils.setCookieValue('profileId', loginResponseData.payload.response.profileInfo.id, softLoginExp, true);

  }catch(error){
    console.error('error setting login cookies ' + error);
  }
}

export function getProfile(success, failure){
  var tokenCache = utils.getCookieValue("accessToken");
  var headers = {'Accept': 'application/json'};
  if (tokenCache !== null &&  tokenCache !== undefined){
    headers.access_token = tokenCache;
  }
  $.ajax({
    url: '/api/v1/profile',
    method: 'GET',
    contentType: 'application/x-www-form-urlencoded',
    headers: headers//Accept", "application/json"
  }).then(function(response){
    success(response);
  }).fail(function(error){
    failure(error);
  });
}
