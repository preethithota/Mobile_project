var app = angular.module('yes2uApp', ['ngRoute']);

/*Routing Yes 2 Rewards templates*/
app.config(function ($routeProvider) {
    $routeProvider
        .when('/landing',
            {
                controller: 'yes2uCtrl',
                templateUrl: '/yes2u/views/yes2u-landing.html'
            })
        //Define a route that has a route parameter in it (:rewards activity)
        .when('/reward-activity',
            {
                controller: 'yes2uActivityCtrl',
                templateUrl: '/yes2u/views/yes2u-activity.html',
                currentTab : 'rw'
            })
        //Define a route that has a route parameter in it (:invite friend)
        .when('/invite-friend',
            {
                controller: 'yes2uInvitFrdCtrl',
                templateUrl: '/yes2u/views/yes2u-invite-friend.html'
            })
        .when('/yes2u-share',
            {
                controller: 'yes2uShareCtrl',
                templateUrl: '/yes2u/views/yes2u-share.html'
            })
         .when('/myinfo',
            {
                controller: 'yes2uInfoCtrl',
                templateUrl: '/yes2u/views/yes2u-info.html'
            })
          .otherwise({ redirectTo: '/landing' });

  });
/*end*/
