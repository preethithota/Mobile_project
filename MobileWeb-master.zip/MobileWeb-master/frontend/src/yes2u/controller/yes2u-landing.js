app.controller('yes2uCtrl', function($scope, $http) {
	$scope.loyaltyId = false;
	$scope.earningPeriod = "Feb";
	$scope.pointBalance = 25;
	$scope.firstName = "Santhosh";
	$scope.lastName = "Kumar"
});
app.controller('yes2uActivityCtrl', function($scope, $http) {
	$scope.loyaltyId = true;
	
});
app.controller('yes2uInvitFrdCtrl', function($scope, $http) {
	$scope.message = "test"
});
app.controller('yes2uShareCtrl', function($scope, $http) {
	$scope.message = "test"
});
app.controller('yes2uInfoCtrl', function($scope, $http) {
	$scope.message = "test"
});