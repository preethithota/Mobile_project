//

// this is mapping of mock data to return for the
// given ajax config (url and method)
let ajaxConfigMappings = [];

const $ = {
    // take in an obj with url, method, and returnData
  __addAjaxConfigMappings: function(ajaxConfigMapping){
    ajaxConfigMappings.push(ajaxConfigMapping);
  },

  __clearAjaxConfigMappings: function(){
    ajaxConfigMappings = [];
  },

  // return returnData data field from ajaxConfigMappings where
  // url and method match.  If shouldFail === true, invoke fail() callback
  ajax: jest.fn(function(config){
    //console.log('inside mock ajax with config ' + JSON.stringify(config));
    const returnData = getReturnData(config, ajaxConfigMappings);

    return {
      always: function(alwaysCallback){
        //console.log('inside always mock callback');
        //console.log('returning data: ' + JSON.stringify(returnData));
        alwaysCallback(returnData);
        return this;
      },
      then: function(thenCallback){
        //console.log('inside then mock callback');
        thenCallback(returnData);
        return this;
      },
      fail: function(fail){
        //console.log('inside fail mock callback');
        if (returnData.shouldFail){
          fail(returnData);
        }
        return this;
      }
    }
  })
};

function getReturnData(config, ajaxConfigMappings){
  const matchedMapping = ajaxConfigMappings.filter((mapping) => {
    return mapping.url === config.url && mapping.method === config.method;
  });

  if (matchedMapping && matchedMapping.length > 0){
    return matchedMapping[0].returnData;
  }

  return null;
}

//export {$};
export default $;
