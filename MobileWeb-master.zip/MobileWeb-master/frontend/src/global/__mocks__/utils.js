
let accessToken = null;
let isLSDisabled = false;
let mockLSData = {};
let mockCookieData = {};

// for non-mocked functions, we need to invoke the actual method
const utils = require.requireActual('../utils.js');

export function __setAccessToken(data){
  accessToken = data;
}

export function __disableLS(){
  isLSDisabled = true;
}

export function __clearData(){
  mockLSData = {};
  mockCookieData = {};
  accessToken = null;
  isLSDisabled = false;
}

export const showLoader = jest.fn();
export const hideLoader = jest.fn();
export const scrollTop = jest.fn();


export const getCookieValue = jest.fn((key) => {
  //console.log('getCookieValue called with key: ' + key + ', value returned: ' + mockCookieData[key]);
  return mockCookieData[key] ? mockCookieData[key] : '';
});

export const setCookieValue = jest.fn((key, value) => {
  mockCookieData[key] = value;
});

export const putInLocalStorage = jest.fn((key, value) => {
  if (!isLSDisabled){
    mockLSData[key] = value;
  }
});

export const getFromLocalStorage = jest.fn((key) => {
  //return mockLSData[key] : '';
  return mockLSData[key] ? mockLSData[key] : '';
});

export const getCartAccessToken = jest.fn(() => accessToken);

export const isLoggedIn = jest.fn(() => {
  return (accessToken) ? true : false;
});

//export const getUrlParam = obj => utils.isObjectEmpty(obj);

export const getImageUrl = (origUrl, size, returnOnePixelImage) => utils.getImageUrl(origUrl, size, returnOnePixelImage);

export const capitalizeFirstLetter = word => utils.capitalizeFirstLetter(word);

export const showLogin = (isTcom, showCreateAccount, loginCallBack, template) => utils.showLogin(isTcom, showCreateAccount, loginCallBack, template);

export const findInArray = (arr, findFunction) => utils.findInArray(arr, findFunction);

export const convertToDollar = num => utils.convertToDollar(num);

//export const getCartAccessToken = () => utils.getCartAccessToken();

export const generateDobValues = () => utils.generateDobValues();

export const getFirstName = () => utils.getFirstName();

export const isSoftedLoggedIn = () => utils.isSoftedLoggedIn();

export const areSortedArraysEqual = (array1, array2) => utils.areSortedArraysEqual(array1, array2);

export const getObjPropertyWithOneLength = obj => utils.getObjPropertyWithOneLength(obj);

export const checkEmptyString = text => utils.checkEmptyString(text);

export const isObjectEmpty = obj => utils.isObjectEmpty(obj);

export const getUrlParam = (query, url) => utils.getUrlParam(query, url);

export const showFindInStoreModal = (isTcom, selectedProduct, containerElementId, calledBy, successCallback) => utils.showFindInStoreModal(isTcom, selectedProduct, containerElementId, calledBy, successCallback);

export const howFindInStoreFilter = isTcom => utils.howFindInStoreFilter(isTcom);

export const updateStores = () => utils.updateStores();

export const updateStoreTypes = () => utils.updateStoreTypes();

export const modalActionPosition = utils.modalActionPosition;

export const createSessionId = () => utils.createSessionId();

export const initalizeNuDataSDK = url => utils.initalizeNuDataSDK(url);

export const goToCheckout = () => utils.goToCheckout();
