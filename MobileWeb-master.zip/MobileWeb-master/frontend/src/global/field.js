export default class Field{

  constructor(id, type, value, required, validatorType){
    this.id = id;
    this.type = type;
    this.value = value;
    this.required = required;
    this.validatorType = validatorType;
  }

  getId(){
    return this.id;
  }

  getType(){
    return this.type;
  }

  getValue(){
    return this.value;
  }

  isRequired(){
    return this.required;
  }

  getValidatorType(){
    return this.validatorType;
  }

  setValue(value){
    this.value = value;
  }
}
