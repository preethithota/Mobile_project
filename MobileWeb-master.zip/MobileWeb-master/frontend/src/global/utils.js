import {setSignInOmniture} from '../../public/lib/omniture-util';
import ReactDOM from 'react-dom';
let localStorageEnabled;


export function putInLocalStorage(key, obj){
	putInStorage(key, obj, localStorage);
}

export function putInSessionStorage(key, obj){
	putInStorage(key, obj, sessionStorage);
}

export function putInStorage(key, obj, storage){
	if (isLocalStorageEnabled()){
		storage.setItem(key, obj);
	}
}

export function capitalizeFirstLetter(word){
	if (!word || word.length === 0){
		return word
	}
	const firstLetter = word.substr(0, 1);
	const restOfWord = word.substr(1, word.length - 1);
	return firstLetter.toUpperCase() + restOfWord;
}

export function showLogin(isTcom, showCreateAccount, loginCallBack, template){
	var loginModalTemplate;
	switch(template) {
		case 'checkout':
		loginModalTemplate = isTcom ? 'login-modal-tcom-checkout-view' : 'login-modal-mcom-checkout-view';
		break;
		default:
		loginModalTemplate = isTcom ? 'login-modal-tcom-view' : 'login-modal-mcom-view';
	}

	if (typeof loginCallBack !== 'function'){
		loginCallBack = () => {
			var redirectPageAfterLogin = {
				'#/shoppingBag': {
					url: '/checkout/checkout.jsp'
				},
				'#/orderManagement': {
					url: '/checkout/myaccount.jsp'
				}
			},
			matchRedirectPage = redirectPageAfterLogin[location.hash],
			redirectUrl = '/checkout/myaccount.jsp#/myInfoLanding';
			if (matchRedirectPage) {
				redirectUrl = matchRedirectPage['url'] + location.hash;
			}
            location.href = redirectUrl;if(location.hash && location.hash !== '#/shoppingBag') location.reload();
        };
	}

	if (isTcom){
		// These async dependencies are statically analyzed by Webpack
		// so this array cannot be or contain variables
		require(['../account/login-helper.js',
			'../account/views/'+loginModalTemplate,
			'../account/views/sign-in-tcom-view',
			'../account/views/sign-up-tcom-view',
			'../account/reset-pwd/views/reset-pwd-link-view',
			],
			(loginHelper, loginModalView, signInView, signUpView, resetView) => {
			loginHelper.init(loginModalView.default, signInView.default, signUpView.default, showCreateAccount, loginCallBack, resetView.default);
		});
	}else{
		require(['../account/login-helper.js',
		 	'../account/views/'+loginModalTemplate,
	 		'../account/views/sign-in-mcom-view',
			'../account/views/sign-up-mcom-view',
			'../account/reset-pwd/views/reset-pwd-link-view',
			],
		  (loginHelper, loginModalView, signInView, signUpView, resetView) => {
			loginHelper.init(loginModalView.default, signInView.default, signUpView.default, showCreateAccount, loginCallBack, resetView.default);
		});
	}
	document.body.classList.add('t-login-mask');
	setSignInOmniture(template,showCreateAccount);
}

export function getFromLocalStorage(key){
	return getFromStorage(key, localStorage)
}

export function getFromSessionStorage(key){
	return getFromStorage(key, sessionStorage)
}

export function getFromStorage(key, storage){
	let returnValue = "";
	if (isLocalStorageEnabled()){
		returnValue = storage.getItem(key);
	}
	return returnValue;
}

export function deleteFromLocalStorage(key){
	deleteFromStorage(key, localStorage);
}

export function deleteFromSessionStorage(key){
	deleteFromStorage(key, sessionStorage);
}

export function deleteFromStorage(key, storage){
	if (isLocalStorageEnabled()){
		storage.removeItem(key);
	}
}

export function isLocalStorageEnabled(){
	if (typeof localStorageEnabled !== 'undefined'){
		return localStorageEnabled;
	}

	try {
		if (typeof localStorage === 'undefined'){
			return false;
		}
		const testLsStr = 'test-ls';
		localStorage.setItem(testLsStr, testLsStr);
		localStorage.removeItem(testLsStr);
		localStorageEnabled = true;

	} catch (exception) {
		localStorageEnabled = false;
	}
	return localStorageEnabled;

}

export function findInArray(arr, findFunction){
		for (let i = 0; i < arr.length; i++){
			const elem = arr[i];
			if (findFunction(elem)) return elem;
		}
}

/*TODO: convert this to prototype*/
export function convertToDollar(num) {
	return '$' + num.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
}

export function getCookieValue(name) {
	if (name){
		var regex = new RegExp('[; ]'+name+'=([^\;]*)');
		var match = (' ' + document.cookie).match(regex);
		if (match){
			return unescape(match[1]);
		}
	}
	return '';
}

// This will return normal access_token if available
// if not it will fallback to the soft login token
export function getCartAccessToken(){
  const fullAccessToken = getCookieValue('accessToken');
  if (fullAccessToken){
    return fullAccessToken;
  }
  return getCookieValue('softLoginToken');
}

export function generateDobValues(){
	let kcyear  = document.getElementsByName("nameRwdsYear")[0],
	  	kcmonth = document.getElementsByName("nameRwdsMonth")[0],
	  	kcday   = document.getElementsByName("nameRwdsDay")[0];

	var d = new Date();
	var n = d.getFullYear()-13;
	for (var i = n; i >= 1950; i--) {
	  var opt = new Option();
	  opt.value = opt.text = i;
	  kcyear.add(opt);
	}
	kcyear.addEventListener("change", validate_date);
	kcmonth.addEventListener("change", validate_date);

	function validate_date() {
	    var y = +kcyear.value, m = kcmonth.value, d = kcday.value;
		 if (m === "02")
		     var mlength = (28 + (!(y % 4 !=0)));
		 else var mlength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
		 kcday.length = 1;
		 for (var i = 1; i <= mlength; i++) {
		     var opt = new Option();
		     opt.value = opt.text = i;
		     if (i == d) opt.selected = true;
		     kcday.add(opt);
		 }
	}
	validate_date();
}

export function getFirstName(){
	return getCookieValue('firstName');
}

export function setCookieValue(name, value, exp, isSecure) {
	const expiration = (typeof exp === 'undefined') ? '' : exp;

	const cookieString = `${name}=${value}; path=/;expires=${expiration}`;

	if (isSecure && location.protocol === 'https:'){
		cookieString + ';secure'
	}
	document.cookie = cookieString;
}

export function deleteCookie(name){
	document.cookie = name + '=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT';
}

export function isLoggedIn(){
  return (getCookieValue('hasAccessToken') === 'true');
}

export function isSoftedLoggedIn(){
  return (!isLoggedIn() && getCookieValue('hasSoftLoginToken') === 'true');
}

export function fetch(url){
	let response = $.ajax({
		url: url,
		dataType: 'json',
		cache: true
	});

	response.fail(err => {
		hideLoader();
		console.log('Error connecting to url ' + url + ', error ' + err)
	});

	return response;
}

export function scrollTop(){
  $('body').animate({ scrollTop: '0px' }, {duration: 0});
}

export function showLoader(){
	if (typeof $ === 'undefined'){
		return;
	}
	$('#loader-img').removeClass('display-none');
	$('#mcom-filter-loader').removeClass('display-none');

};

export function hideLoader(){
	if (typeof $ === 'undefined'){
		return;
	}
	$('#loader-img').addClass('display-none');
	$('#mcom-filter-loader').addClass('display-none');
};

export function getImageUrl(origUrl, size, returnOnePixelImage){
	var origUrl = origUrl;

	if (typeof origUrl === 'undefined' || (typeof returnOnePixelImage !== 'undefined' && returnOnePixelImage)){
		return '/images/product-filler-image.png';
	}

	origUrl = origUrl
				.replace(/hei=(\d)+/, 'hei=' + size)
				.replace(/wid=(\d)+/, 'wid=' + size)
				.replace(/^http:/, '')
				.replace(/op_sharpen$/g, 'op_sharpen=1')
				.replace(/&amp;/g, '&');

	if(size > 300) {
		/* Applies for larger image */
		origUrl += "&fmt=jpeg&qlt=85,1&op_sharpen=0&resMode=sharp2&op_usm=1,0.8,6,0&fmt=jpeg&qlt=85,1&op_sharpen=0&resMode=sharp2&op_usm=1,0.8,6,0";
	}

	return origUrl;
}

// This requires the arrays to be sorted
export function areSortedArraysEqual(array1, array2){
	return array1.join() === array2.join();
}

export function isObjectEmpty(obj){
	for(let key in obj) {
		if(obj.hasOwnProperty(key)){
			return false;
		}
	}
	return true;
}

export function getObjPropertyWithOneLength(obj){
	for(let key in obj) {
		if(obj.hasOwnProperty(key)){
			return key;
		}
	}
}

/**
 * This function checks againts empty string.
 * @param {string} text
 * @returns boolean
 */
export function checkEmptyString(text){
	if (text) {
    	return true;
	} else {
		return false;
	}
}

/* query any string passed as URL */
export function getUrlParam(query, url){
	query = query.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
	var regex = new RegExp('[\\?&]' + query + '=([^&#]*)');
	var results = regex.exec(url);
	return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}

/**
 * Opens Find in Store Modal
 * @param {boolean} isTcom - Is platform is tab.
 * @param {object} selectedProduct - Selected product details.
 */
export function showFindInStoreModal(isTcom, selectedProduct, containerElementId, calledBy, successCallback){
	console.log(JSON.stringify(selectedProduct));
	if (isTcom){console.log('tcom modal');
		require(['../pdp/store/find-in-store-helper.js',
		 	'../pdp/store/find-in-store-tcom-view'],
		  (findInStoreHelper, findInStoreView) => {
			findInStoreHelper.init(findInStoreView.default, selectedProduct, containerElementId, calledBy, successCallback);
		});
	}else{
		require(['../pdp/store/find-in-store-helper.js',
		 	'../pdp/store/find-in-store-mcom-view'],
		  (findInStoreHelper, findInStoreView) => {
			findInStoreHelper.init(findInStoreView.default, selectedProduct, containerElementId, calledBy, successCallback);
		});
	}
	setTimeout(function() {
	    document.body.classList.add("find-in-store-mask");
	},100);
}

export function showFindInStoreFilter(isTcom){
	require(['../pdp/store/find-in-store-helper.js',
		'../pmp/views/filters-store-area-search'],
		(findInStoreHelper, findInStoreView) => {
		findInStoreHelper.init(findInStoreView.default, null, "selectStoreArea");
	});
}


export function updateStores() {
	var match = /storeid=[^&]+/.exec(location.search);

		window.catalogData.stores = {};
		if(match) {
			var storeList = match[0].split("=")[1];
			if(storeList) {
				storeList = storeList.split(",");
				for(var i=0; i < storeList.length; i++) {
					window.catalogData.stores[storeList[i]] = true;
				}
			}
		}
}

export function updateStoreTypes() {
	var match = /&N=[^&]+/.exec(location.search);
	window.catalogData.storeTypes = {};
	if(match) {
		var storeTypes = match[0].split("=")[1];
		if(storeTypes) {
			storeTypes = storeTypes.split("+");
			for(var i=0; i < storeTypes.length; i++) {
				window.catalogData.storeTypes[storeTypes[i]] = true;
			}
		}
	}
}

export var modalActionPosition = (function() {
	var action = {};
	return {
		setFocusPosition: function () {
			if(action.positionTop && action.target) {
				$('#main-content').css({position: 'static'});
				$(action.target).focus();
				$('body').scrollTop(action.positionTop);
			}
			this.resetData();
		},
		getFocusPosition: function (evt) {
			if (typeof $ !== 'undefined'){
				$('#main-content').css({position: ''});
				action.positionTop = document.body.scrollTop;
				action.target = evt.target;
			}
		},
		resetData: function (argument) {
			action = {
				positionTop: null,
				target: null
			};
		}
	}
})();

export function createSessionId(){
		var deviceId = 'xxxxxxxx-xxxx-2xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
			var r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
			return v.toString(16);
		});
		return deviceId + new Date().getTime();
};

export function initalizeNuDataSDK(url) {
	(function(w, d, s, u, q, js, fjs, nds) {
	    nds = w.ndsapi || (w.ndsapi = {});
	    nds.config = {
	        q: [],
	        ready: function(cb) {
	            this.q.push(cb)
	        }
	    };
	    js = d.createElement(s);
	    fjs = d.getElementsByTagName(s)[0];
	    js.src = u;
	    fjs.parentNode.insertBefore(js, fjs);
	    js.onload = function() {
	        nds.load(u);
	    }
	}(window, document, "script", url));
}

export function goToCheckout(){
	document.body.classList.remove("modal-overlay");
	ReactDOM.unmountComponentAtNode(document.getElementById('login-modal-container'));
	window.location.href = "/checkout/checkout.jsp#/directCheckout";
};
