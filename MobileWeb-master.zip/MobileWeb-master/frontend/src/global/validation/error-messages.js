const firstNameErr = 'Invalid value passed for First Name.';
const lastNameErr = 'Invalid value passed for Last Name.';
const nameError = 'Invalid value passed for Name.';
const genericError = 'Invalid Entry.';
const passwordError = 'Please enter a valid password';
const phoneNumberErr = 'Please enter a valid 10 digit phone number.';


const errorMessage = {
 email: 'Please enter your email address in this format: name@domain.com',
 password: passwordError,
 newPassword: passwordError,
 firstName: firstNameErr,
 lastName: lastNameErr,
 tel:phoneNumberErr,
 genericError
}

export default errorMessage;
