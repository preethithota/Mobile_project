const errGlobal = {
    colSizeMsg : "You\’ll need to choose a size and color before you can continue.",
    sizeMsg: "You\'ll need to choose a size before you can continue.",
    colMsg: "You\'ll need to choose a color before you can continue.",
    exceedQtyMsg: "The quantity specified exceeds the available quantity.",
    selStoreMsg: "Please select a store"
};

const errField = {
    colSizeMsg: "Please select your size / color",
    sizeMsg: "Please select a color",
    colMsg: "Please select a size",
    selStoreMsg: "Please select a store"
};

const pdpErrMsg = {
  errGlobal : errGlobal,
  errField : errField
};

export default pdpErrMsg;
