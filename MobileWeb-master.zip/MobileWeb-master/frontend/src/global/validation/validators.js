const validators = {
  email: function(email){
    if (!validators.notEmpty(email))  return true;
    return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.]+\.[a-zA-Z]{2,3}$/.test(email);
  },

  name: function(name){
    if (!validators.notEmpty(name)) return true;
    if (name.length > 1 && name.length < 100){
      return /^[a-zA-Z]+$/.test(name);
    }
    return false;
  },

  // new password should only be invoked for new password entries (i.e. change pw or sign up)
  newPassword: function(password){
    return (validators.checkLength(8, password) && validators.containsNumbersAndLetters(password)
      && validators.containsUpperAndLowerCaseLetters(password));
  },

  notEmpty: function(value){
    return (typeof value != 'undefined' && value) ? true : false;
  },

  containsNumbersAndLetters: function(input){
    return /[a-zA-Z]+/.test(input) && /[0-9]+/.test(input);
  },

  containsUpperAndLowerCaseLetters: function(input){
    return /[a-z]+/.test(input) && /[A-Z]+/.test(input);
  },

  checkLength: function(length, value){
    return (value && value.length >= length) ? true : false;
  },
  tel:function(phonenumber){
    return (!validators.notEmpty(phonenumber) || phonenumber.length < 10) ? false : true;
  }
}

export default validators;
