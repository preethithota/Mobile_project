import validators from './validators';
import errorMessages from './error-messages';

export function validate(fields){
  const errors = {};

  for (let fieldId in fields) {
    if (fields.hasOwnProperty(fieldId)) {
      let field = fields[fieldId];
      //validatorName = getValidatorName(type);
      const validatorType = (field.getValidatorType()) ? field.getValidatorType() : field.getType();
      let validationFunction = validators[validatorType];

      if (validationFunction && !validationFunction(field.getValue())){
        let errorMessage = getErrorMessage(validatorType, field.getId());
        if (typeof errorMessage === 'undefined'){
          errorMessage = errorMessages.genericError;
        }

        errors[field.getId()] = errorMessage;
      }
    }
  }
  return errors;
}

export function rwdValidateFields(fields){
  const errors = {};

  for (let fieldId in fields) {
    if (fields.hasOwnProperty(fieldId)) {
      let field = fields[fieldId];
      //validatorName = getValidatorName(type);
      const validatorType = document.getElementById(fieldId).getAttribute('type');
      let validationFunction = validators[validatorType];

      if (validationFunction && !validationFunction(document.getElementById(fieldId).value)){
        let errorMessage = getErrorMessage(validatorType, fieldId);
        if (typeof errorMessage === 'undefined'){
          errorMessage = errorMessages.genericError;
        }
        errors[fieldId] = errorMessage;
      }
      else{
        document.getElementById(fieldId).value  ? delete errors[fieldId] : errors[fieldId] = "Please enter an email address";
      }
    }
  }
  return errors;
}

export function validateRequiredFields(fields){
  for (let fieldId in fields) {
    if (fields.hasOwnProperty(fieldId)) {
      let field = fields[fieldId];
      let fieldValue = field.getValue();
      if (field.isRequired() && (!fieldValue || fieldValue.length < 1)){
        return false;
      }
    }
  }
  return true;
}

export function validatePasswordInFields(fields){
  for (let fieldId in fields) {
    if (fields.hasOwnProperty(fieldId)) {
      let field = fields[fieldId];
      if (field && field.getType() === 'newPassword'){
        let password = field.getValue();
        return (validators.checkLength(8, password) && validators.containsNumbersAndLetters(password)
          && validators.containsUpperAndLowerCaseLetters(password));
      }
    }
  }
  return true;
}

export function getErrorMessage(id, fieldVal){
  if(fieldVal=="firstName" || fieldVal=="lastName") {
      return errorMessages[fieldVal] ? errorMessages[fieldVal] : errorMessages.genericError;
  }
  else{
      return errorMessages[id] ? errorMessages[id] : errorMessages.genericError;
  }
}
