import validators from '../validators';

describe('validateEmail', () => {

  it('should return true for correct emails', () => {
    expect(validators.email('br@k.com')).toBe(true);
    expect(validators.email('Br@KoHLS.coM')).toBe(true);
    expect(validators.email('Jo@BlOw.coM')).toBe(true);
    expect(validators.email('b@k.xyz')).toBe(true);
    expect(validators.email('bk#r@k.com')).toBe(true);
    expect(validators.email('disposable.style.email.with+symbol@example.com')).toBe(true);

    //empty validation handled with isEmpty validator
    let someUndefinedVar;
    expect(validators.email(someUndefinedVar)).toBe(true);
    expect(validators.email('')).toBe(true);
  });

  it('should return false for incorrect emails', () => {
    expect(validators.email('brAtk.com')).toBe(false);
    expect(validators.email('A@b@c@k.com')).toBe(false);
  });

});

describe('validateName', () => {
  it('should return true for correct names', () => {
    expect(validators.name('joe')).toBe(true);
    expect(validators.name('cHriStoPhEr')).toBe(true);

    //empty validation handled with isEmpty validator
    expect(validators.name('')).toBe(true);
  });

  it('should return false for incorrect names', () => {
    expect(validators.name('joe@smith.com')).toBe(false);
    expect(validators.name('joe smith')).toBe(false);
    expect(validators.name('joesmith123')).toBe(false);
  });

});

describe('notEmpty', () => {
  it('should return false for empty values', () => {
    let someUndefinedVar;
    expect(validators.notEmpty(someUndefinedVar)).toBe(false);
    expect(validators.notEmpty('')).toBe(false);
  });

  it('should return true for nonempty values', () => {
    expect(validators.notEmpty('abc')).toBe(true);
  });

});

describe('containsNumbersAndLetters', () => {
  it('should return true if value contains numbers and letters', () => {
    expect(validators.containsNumbersAndLetters('abc123')).toBe(true);
    expect(validators.containsNumbersAndLetters('AbC123')).toBe(true);
    expect(validators.containsNumbersAndLetters('12AlsoValid')).toBe(true);
  });

  it('should return false if value does not contain both letters and numberss', () => {
    expect(validators.containsNumbersAndLetters('P')).toBe(false);
    expect(validators.containsNumbersAndLetters('abc')).toBe(false);
    expect(validators.containsNumbersAndLetters('ABc')).toBe(false);
    expect(validators.containsNumbersAndLetters('123')).toBe(false);
    expect(validators.containsNumbersAndLetters('12#^@3')).toBe(false);
  });
});

describe('containsUpperAndLowerCaseLetters', () => {
  it('should return true if value contains upper and lower case letters', () => {
    expect(validators.containsUpperAndLowerCaseLetters('abcXYZ')).toBe(true);
    expect(validators.containsUpperAndLowerCaseLetters('aBcXyZ')).toBe(true);
    expect(validators.containsUpperAndLowerCaseLetters('a#B@c!Xy@Z')).toBe(true);
    expect(validators.containsUpperAndLowerCaseLetters('A98AlsoValid')).toBe(true);
    expect(validators.containsUpperAndLowerCaseLetters('ABCdef')).toBe(true);
  });

  it('should return false if value does not contain both upper and lower case letters', () => {
    expect(validators.containsUpperAndLowerCaseLetters('P')).toBe(false);
    expect(validators.containsUpperAndLowerCaseLetters('abc')).toBe(false);
    expect(validators.containsUpperAndLowerCaseLetters('XYZ')).toBe(false);
  });
});

describe('validate password', () => {
  it('should return true for valid password', () => {
    expect(validators.newPassword('ValidPassword123')).toBe(true);
    expect(validators.newPassword('98AlsoValid')).toBe(true);
    expect(validators.newPassword('123456Ab')).toBe(true);
  });

  it('should return false for invalid password', () => {
    expect(validators.newPassword('')).toBe(false);
    expect(validators.newPassword('ShorT12')).toBe(false);
    expect(validators.newPassword('a123456789')).toBe(false);
    expect(validators.newPassword('nouppercase123')).toBe(false);
    expect(validators.newPassword('NOLOWERCASE123')).toBe(false);
    expect(validators.newPassword('123456789')).toBe(false);
  });
});
