import * as validationHelper from '../validation-helper';
import errorMessages from '../error-messages';
import Field from '../../field';
import * as utils from '../../utils';

const id = 'emailField', emailType = 'email', validEmail = 'joe@example.com', emailValidator = 'email';
const invalidEmail = 'invalidEmail';
const invalidEmailField = new Field(id, emailType, invalidEmail, true, emailValidator);
const validEmailField = new Field(id, emailType, validEmail, true, emailValidator);
const validNewPassword = new Field('pwField', 'newPassword', 'Password1', true, 'password');
const invalidNewPassword = new Field('pwField', 'newPassword', 'invalidpw', true, 'password');

describe('validate', () => {
  it('should return errors for invalid fields', () => {
    const fields = {'field1': invalidEmailField};
    const errors = validationHelper.validate(fields);
    expect(errors[id]).toEqual(errorMessages.email);
    expect(utils.isObjectEmpty(errors)).toBe(false);

    const fields2 = {'field1': validEmailField, 'field2': invalidEmailField};
    expect(utils.isObjectEmpty(errors)).toBe(false);
  });

  it('should use type field if no validationType present', () => {
    const validEmailFieldwithNoValidatorType = new Field(id, emailType, validEmail, true, null);
    const fields = {'field1': validEmailFieldwithNoValidatorType};
    const errors = validationHelper.validate(fields);
    expect(utils.isObjectEmpty(errors)).toBe(true);
  });

  it('if validationType present, should take precenence over type', () => {
    const invalidEmailFieldWithNameValidator = new Field(id, emailType, 'invalidEmailButValidName', true, 'name');
    const fields = {'field1': invalidEmailFieldWithNameValidator};
    const errors = validationHelper.validate(fields);
    expect(utils.isObjectEmpty(errors)).toBe(true);
  });

  it('should return empty errors for all valid fields', () => {
    const fields = {'field1': validEmailField};
    const errors = validationHelper.validate(fields);
    expect(utils.isObjectEmpty(errors)).toBe(true);
  });

});

describe('validateRequiredFields', () => {
  it('should return false if any required field are blank', () => {
    let blankField = new Field(id, emailType, '', true, emailValidator);
    let fields = {'field1': validEmailField, 'field2': blankField};
    expect(validationHelper.validateRequiredFields(fields)).toBe(false);
  });

  it('should return true if all non-required fields are blank', () => {
    let nonRequiredBlankField = new Field(id, emailType, '', false, emailValidator);
    let fields = {'field1': nonRequiredBlankField, 'field2': validEmailField};
    expect(validationHelper.validateRequiredFields(fields)).toBe(true);
  });

  it('should return true if all required fields are non-blank', () => {
    let fields = {'field1': invalidEmailField, 'field2': validEmailField};
    expect(validationHelper.validateRequiredFields(fields)).toBe(true);
  });
});

describe('validatePasswordInFields', () => {

  it('should return true if new password field is valid', () => {
    let testFields = [validEmailField, validNewPassword, invalidEmailField];
    expect(validationHelper.validatePasswordInFields(testFields)).toBe(true);
  });

  it('should return false if new password field is invalid', () => {
    let testFields = [validEmailField, invalidEmailField, invalidNewPassword];
    expect(validationHelper.validatePasswordInFields(testFields)).toBe(false);
  });

  it('should return true if fields do not contain new password', () => {
    let testFields = [validEmailField, invalidEmailField];
    expect(validationHelper.validatePasswordInFields(testFields)).toBe(true);
  });

});
