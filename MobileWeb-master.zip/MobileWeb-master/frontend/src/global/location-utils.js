
import * as utils from './utils';

const googleGeocodeApi = 'https://maps.googleapis.com/maps/api/geocode/json?';
const clientKey = 'gme-kohlsdepartmentstores';
const addressComponent = {
		street_number: 'short_name',
		route: 'long_name',
		locality: 'long_name',
		administrative_area_level_1: 'short_name',
		administrative_area_level_2: 'long_name',
		county: 'long_name',
		postal_code: 'short_name',
		state_short_name: 'short_name',
		state_long_name: 'long_name' //administrative_area_level_1: 'long_name',
};

/**
 * Parse google api response and get location data
 * 
 * @param {object} data  - response from google api
 * @returns object
 */
function parseAddressComponents(data) {
	let locationDetails = {};

	if (data.results[0].address_components) {
		for (var i = 0; i < data.results[0].address_components.length; i++) {
			var addressType = data.results[0].address_components[i].types[0];
			if (addressComponent[addressType]) {
			locationDetails[addressType] = data.results[0].address_components[i][addressComponent[addressType]];
				if (addressType  === 'administrative_area_level_1') {
					locationDetails['state_long_name'] = data.results[0].address_components[i]['long_name'];
				}
			}
		}
	}
	locationDetails.state_short_name = locationDetails.administrative_area_level_1 ? locationDetails.administrative_area_level_1 : '';
	locationDetails.county = locationDetails.administrative_area_level_2 ? locationDetails.administrative_area_level_2 : '';
	return locationDetails;
}

/**
 * Asks user location and sets lat lng in cookie.
 * Uses navigator.geolocation HTML5 API
 * On success sets geoip_lat and geoip_lng cookie for lat & lng
 * Also sets locationasked to true
 */
export function askLocation(success, failure){
	console.log('called get location');
	var userLocation = null;
	var geoLocationOptions = {
		timeout: 10 * 1000,
		enableHighAccuracy: false
	}
	var geoLocationSuccess = (typeof success === "function") ? success  : function(position) {
		setLocation(position);
	};
	var geoLocationError = (typeof failure === "function") ? failure : function(error) {
		console.log('Error occurred. Error code: ' + error.code +', Error msg: '+ error.message);
	};
	navigator.geolocation.getCurrentPosition(geoLocationSuccess, geoLocationError, geoLocationOptions);
}

export function setLocation(userLocation, successCallback) {
	var loc = {latitude: userLocation.coords.latitude, longitude: userLocation.coords.longitude};
	utils.setCookieValue('geoip_lat', loc.latitude);
	utils.setCookieValue('geoip_lng', loc.longitude);
	utils.setCookieValue('locationasked', true);
	if(typeof successCallback === 'function'){
		geoCodeLatLng(loc.latitude, loc.longitude, successCallback);	
	} else {
		geoCodeLatLng(loc.latitude, loc.longitude);
	}
	getNearByStoreList(loc.latitude, loc.longitude, 50);
}

/**
 * get geocode lat long location to zipcode
 * @param {number} lat - Latitude of users location.
 * @param {number} lng - Longitude of users location.
 * @returns TBD
 */
export function geoCodeLatLng(lat, lng, successCallback) {
	if (lat && lng) {
		var latlng = 'latlng=' + lat + ',' + lng;
		const url = googleGeocodeApi + latlng;// + '&client=' + clientKey;  // add google api key from kohls data(currenty request not working with client Id)
		$.ajax({
			url: url,
			dataType: 'json',
			cache: true,
			success: function(data){
				if(data.status === 'OK') {
					var locationDetails = parseAddressComponents(data);
					locationDetails.latitude = lat;
					locationDetails.longitude = lng;
					typeof successCallback === 'function' && successCallback(locationDetails);

					let myLocation = {};
					myLocation.zipCode = {long_name: locationDetails.postal_code};
					utils.setCookieValue('myLocation', JSON.stringify(myLocation));
				}
			}
		});
	}

}


/**
 * Get near by stores list from open api
 * @param {number} lat - Latitude of users location.
 * @param {number} lng - Longitude of users location.
 * @param {number} radius - Radius to search for.
 * @returns null // sets stores list in localStorage or cookie
 */
export function getNearByStoreList(lat, lng, radius){
	if (lat && lng && radius) {
		var latlng = 'latlng=' + lat + ',' + lng;
		const storeApi = '/api/v1/stores?latitude=' + lat + '&longitude=' + lng + '&radius=' + radius;
		$.ajax({
			url: storeApi,
			dataType: 'json',
			cache: true,
			success: setNearestStoreList
		});
	}
}

 /**
 * Get near by stores list from open api
 * @param {object} data - Reaturned object from stores API from MFP.
 * @returns null // sets stores list in localStorage or cookie
 */
export function setNearestStoreList(data){
	let maxCount = 5;
	if (data.payload.stores.length >= 1) {
		let stores = {};
		stores.id = data.payload.stores[0].storeNum;
		stores.name = data.payload.stores[0].storeName;
		stores.zipcode = data.payload.stores[0].address.postalCode;
		stores.distance = Number(data.payload.stores[0].distanceFromOrigin).toFixed(2);
		let storesList = [];
		for (let i=0 ;i <= data.payload.stores.length && i < maxCount; i++) {
			storesList.push(data.payload.stores[i].storeNum);
		}
		stores.storeNums = storesList.join();

        if (utils.isLocalStorageEnabled()){
		    utils.putInLocalStorage('closeststore', JSON.stringify(stores));
	    } else {
            utils.setCookieValue('closeststore', JSON.stringify(stores));
        }
	}
}

/**
 * This function geo codes zip codes and returns city state etc.
 * 
 * @param {function} successCallback 
 * @param {function} failureCallback 
 * @param {number} postalCode 
 */
export function geoCodeByZip(successCallback, failureCallback, postalCode) {
	var locationDetails = {};
	var data = {};
	data.results = [];

	if (typeof google != "undefined") {
		var geocoder = new google.maps.Geocoder();
		geocoder.geocode({ componentRestrictions: {
					country: "US",
					postalCode: postalCode
				}
			},
			function(results, status) {
				if (status == 'OK') {
					data.results.push(results[0]);
					var locationDetails = parseAddressComponents(data);
					typeof successCallback === 'function' && successCallback(locationDetails);
				} else {
					failureCallback();
				}
			}
		);
	}
	else {
		failureCallback();
	}
}
