import * as cartHelper from './cart-helper';

export function convertOcbToLocalEntry(ocbEntry){

  const localEntryValues = {
    skuCode: ocbEntry.skuCode,
    webID: ocbEntry.webID,
    quantity: parseInt(ocbEntry.qty),
    isGift: (ocbEntry.giftItem) ? 'true' : 'false',
    registryID: '-1',
    collId: '-1',
    isBopusItem: (ocbEntry.bopusItem) ? 'true' : 'false',
    storeNum: (ocbEntry.bopusItem) ? ocbEntry.storeNum : '-1',
    //cartItemID: ocbEntry.cartItemID,
    bagItemId: ocbEntry.cartItemID
  }

  return cartHelper.normalizeCartEntry(localEntryValues);
}

// this is called when when the SAVE_BAG plugin method is called
// with removed entries
export function getEntriesToRemove(ocbCartEntries, localEntries){
  const entriesToRemove = [];
  ocbCartEntries.map(ocbEntry => {
    if (ocbEntry.bagItemId){
      let matchingLocalEntries = localEntries.filter(localEntry => ('' + localEntry.bagItemId) === ('' + ocbEntry.bagItemId));
      if (matchingLocalEntries.length === 0){
        entriesToRemove.push(ocbEntry);
      }
    }
  });
  return entriesToRemove;
}

// this returns the local cart entries that need to be added/updated on ocb
function getEntriesToAddOrUpdate(ocbCartEntries, localEntries, mergeWithMaxQty = true){
  const entriesToAdd = [], entriesToUpdate = [];
  const entriesToAddOrUpdate = {entriesToAdd, entriesToUpdate};

  if (!ocbCartEntries){
    ocbCartEntries = [];
  }

  const ocbCartEntriesCopy = ocbCartEntries.slice(0);
  localEntries.map(localEntry => {
    let localEntryMatched = false;
    for(let i = 0; i < ocbCartEntriesCopy.length; i++){
      let currentOcbEntry = ocbCartEntriesCopy[i];
      if (currentOcbEntry == null){
        continue;
      }

      if (cartHelper.canCartEntriesBeMerged(localEntry, currentOcbEntry)){
        const localEntryQty = parseInt(localEntry.quantity);
        const ocbEntryQty = parseInt(currentOcbEntry.quantity);
        if (mergeWithMaxQty){
          if (localEntryQty > ocbEntryQty){
              entriesToAddOrUpdate.entriesToUpdate.push(localEntry);
          }
        }else{
          if (localEntryQty !== ocbEntryQty){
              entriesToAddOrUpdate.entriesToUpdate.push(localEntry);
          }
        }

        //found match, so skip this ocb entry on next iteration
        ocbCartEntriesCopy[i] = null;
        localEntryMatched = true;
        break;
      }
    }

    if (!localEntryMatched){
      entriesToAddOrUpdate.entriesToAdd.push(localEntry);
    }
  });
  return entriesToAddOrUpdate;
}

export function mergeLocalCartWithOcb(ocbCart, localCartEntries, mergeWithMaxQty){

  const localEntriesCopy = localCartEntries.slice(0);
  const normalizedLocalEntries = localEntriesCopy.map(entry => cartHelper.normalizeCartEntry(entry));

  let entries = {
    entriesToAdd: [],
    entriesToUpdate: [],
    //allEntries: localCartEntries.slice(0) //make a copy of original entries in case updated cart gets corrupted
    allEntries: normalizedLocalEntries
  }

  let mergedEntries = entries;
  try{
    let ocbCartEntries;
    if (ocbCart && ocbCart.payload && ocbCart.payload.cart){
      ocbCartEntries = ocbCart.payload.cart.cartItems;
    }else{
      ocbCartEntries = [];
      //return entries;
    }

    const convertedOcbEntries = ocbCartEntries.map((ocbEntry) => {
      return convertOcbToLocalEntry(ocbEntry);
    });

    let mergedAllEntries = mergedEntries.allEntries;
    convertedOcbEntries.map((convertedOcbEntry) => {
      mergedAllEntries = cartHelper.addOrMergeCartEntries(mergedAllEntries, convertedOcbEntry, true, mergeWithMaxQty);
    });

    mergedEntries.allEntries = mergedAllEntries;
    const entriesToAddOrUpdate = getEntriesToAddOrUpdate(convertedOcbEntries, localCartEntries, mergeWithMaxQty);
    mergedEntries.entriesToAdd = entriesToAddOrUpdate.entriesToAdd;
    mergedEntries.entriesToUpdate = entriesToAddOrUpdate.entriesToUpdate;
  }catch(err){
    console.log('Error in mergeLocalCartWithOcb ' + err);
    return entries;
  }
  return mergedEntries;
}

function getUpdateCartPayloadCartItem(cartEntry, action, localCart){

  const payloadCartItem = {
    skuCode: cartEntry.skuCode,
    qty: cartEntry.quantity,
    action
  };

  const updatingExistingItem = (action === 'update' || action === 'remove');
  if (updatingExistingItem){
    payloadCartItem.cartItemID = cartEntry.bagItemId;
  }

  if (cartEntry.isBopusItem === true || cartEntry.isBopusItem === 'true'){
    // for some reason oapi will abend if the cart item is already a bopus item
    // and we set the bopus flag to true on the update cart call
    const localEntry = cartHelper.getBagItem(localCart, cartEntry.bagItemId);
    if (!updatingExistingItem || !localEntry.bopusItem){
        payloadCartItem.bopusItem = true;
    }
    if (!updatingExistingItem || (('' + localEntry.storeNum) !== (cartEntry.storeNum))){
        payloadCartItem.storeNum = cartEntry.storeNum;
    }
  }

  if (cartEntry.isGift === true || cartEntry.isGift === 'true'){
    payloadCartItem.bopusItem = true;
  }

  if (cartEntry.registryID === true){
    payloadCartItem.bopusItem = true;
  }
  return payloadCartItem;
}

export function getUpdateCartPayload(entriesToAdd, entriesToUpdate, entriesToRemove, cartId, localCart){

  if (entriesToAdd.length == 0 && entriesToUpdate.length == 0){
    return null;
  }

  const covertedEntriesToAdd = entriesToAdd.map(entryToAdd =>
    getUpdateCartPayloadCartItem(entryToAdd, 'add', localCart)
  );
  const covertedEntriesToUpdate = entriesToUpdate.map(entryToUpdate =>
    getUpdateCartPayloadCartItem(entryToUpdate, 'update', localCart)
  );

  const covertedEntriesToRemove = entriesToRemove.map(entryToRemove =>
    getUpdateCartPayloadCartItem(entryToRemove, 'remove', localCart)
  );

  const payload = {
    payload: {
      cart: {
        cartID: cartId,
        cartItems: covertedEntriesToAdd.concat(covertedEntriesToUpdate)
      }
    }
  };
  return payload;
}
