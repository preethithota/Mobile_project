import $ from 'jquery';
import * as utils from './utils';
import * as mergeCartHelper from './merge-cart-helper';

const fieldsNames = ['skuCode', 'webID', 'quantity', 'isGift', 'registryID', 'collId', 'isBopusItem', 'storeNum', 'bagItemId'];
const legacyStoredCartKey = 'skBag';
const storedLocalBagKey = 'KOHLS-BAG';
const storedOcbKey = 'KOHLS-OCB';

// These are the default entries for the cart object which is read
// from the cookie or local storage
//const defaultCartEntryValues = {
const legacyDefaultCartEntryValues = {
  isGift: 'false',
  registryID: '-1',
  collId: '-1',
  isBopusItem: 'false',
  storeNum: '-1',
  bagItemId: 'null'
};

// These are the default entries for the cart object which will be passed
// to the hybrid shopping bag
export const defaultHybridBagEntryValues = {
  bagItemId: "0",
  isGift: false,
  isSynced: false,
  itemOffers: [],
  quantity: 0,
  registryID: "0",
  registryName: "",
  registryQty: "",
  registryShipID: "",
  registryType: "",
  registryWantedQty: "",
  storeNum: "",
  isBopusItem: false
};

// updated getHybridBag
export function getHybridBag(callback){
  let cartArr;
  const ocbCallBack = () => {
    const cartArr = getCartFromStorageInternal(utils.getFromLocalStorage, utils.getCookieValue);
    const hybridBag = cartArr.map((cartEntry, index) => {
      return getHybridBagEntry(cartEntry);
    });
    callback(hybridBag);
  };

  const accessToken = utils.getCartAccessToken();

  if (utils.getCartAccessToken()){
      mergeOmniChannelBag(ocbCallBack, accessToken);
  }else{
    ocbCallBack();
  }
}

export function updateBag(bag, updatedBagItem){
  if (!bag || !updatedBagItem){
    return bag;
  }

  for (let i = 0; i < bag.length; i++){
    let currentBagItem = bag[i];
    if (currentBagItem.bagItemId && currentBagItem.bagItemId == updatedBagItem.bagItemId){
      bag[i] = updatedBagItem;
    }
  }

  return bag;
}

export function getBagItem(bag, bagItemId){
  const matchingBagItems = bag.filter(bagItem => bagItem.bagItemId === bagItemId);

  if (!matchingBagItems || matchingBagItems.length === 0){
    console.error('Error: no matching bag items for bagItemId: ' + bagItemId);
    return null;
  }

  return matchingBagItems[0];
}

export function addToBag(callback, skuCode, webID, quantity, isGift = defaultHybridBagEntryValues.isGift, registryID = defaultHybridBagEntryValues.registryID,
    collId = defaultHybridBagEntryValues.collId, isBopusItem = defaultHybridBagEntryValues.isBopusItem, storeNum = defaultHybridBagEntryValues.storeNum, bagItemId = defaultHybridBagEntryValues.bagItemId){
    const cartEntry = getCartEntryFromFields(skuCode, webID, quantity, isGift,
      registryID, collId, isBopusItem, storeNum, bagItemId);

    // add to local bag
    utils.showLoader();

    const updateCartItems = addToBagInternal(cartEntry, utils.getCookieValue,
        utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    //merge with ocb
    mergeCartWithCallback(callback, updateCartItems);
}

function mergeCartWithCallback(callback, updateCartItems, mergeWithMaxQty = true){
  const accessToken = utils.getCartAccessToken();
  if (accessToken){
    const addToBagCallback = () => {
      utils.hideLoader();
      window._header && window._header.updateCartCount(updateCartItems);
      callback && callback();
    };
    mergeOmniChannelBag(addToBagCallback, accessToken, mergeWithMaxQty);
  }else{
    utils.hideLoader();
    window._header && window._header.updateCartCount(updateCartItems);
    callback && callback();
  }
}

export function updateHybridBag(bagItemId, isGift, quantity, callback){
  const updateCartItems = updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage, utils.getCookieValue,
    utils.putInLocalStorage, utils.setCookieValue);

  mergeCartWithCallback(callback, updateCartItems, false);
}

export function updateHybridBagFromPdpModal(callback, bagItemId, skuCode, quantity, isGift, storeNum){
  const updateCartItems = updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage, utils.getCookieValue,
    utils.putInLocalStorage, utils.setCookieValue, skuCode, storeNum);

  mergeCartWithCallback(callback, updateCartItems, false);
}

export function clearHybridBag(){
  utils.deleteFromLocalStorage(legacyStoredCartKey);
  utils.deleteCookie(legacyStoredCartKey);
  utils.deleteFromLocalStorage(storedLocalBagKey);
  utils.deleteCookie(storedLocalBagKey);
  utils.deleteFromLocalStorage(storedOcbKey);
  utils.deleteFromLocalStorage(storedOcbKey);
  window._header && window._header.updateCartCount([{quantity: 0}]);
}


export function updateHybridBagInternal(bagItemId, isGift, quantity, getFromLocalStorage, getCookieValue, putInLocalStorage,
  setCookieValue, skuCode, storeNum){
  const currentCartEntryArr = getCartFromStorageInternal(getFromLocalStorage, getCookieValue);
  //console.log('currentCartEntryArr: ' + JSON.stringify(currentCartEntryArr));
  let updatedUpdateCartEntryArr;
  if (quantity === 0 || quantity === '0'){
    //remove item
    updatedUpdateCartEntryArr = currentCartEntryArr.filter((element, index) => {
      return bagItemId != element.bagItemId;
    });
    if (typeof bagItemId === 'undefined') {
      updatedUpdateCartEntryArr = [];
    }
  }else{
      updatedUpdateCartEntryArr = currentCartEntryArr.slice(0); //copy array

      //const currentCartEntry = currentCartEntryArr[bagItemId];
      const currentCartEntry = getBagItem(currentCartEntryArr, bagItemId);
      const updatedEntries = {};
      if (isGift === true || isGift === false || isGift === 'true' || isGift === 'false' ){
        updatedEntries.isGift = isGift;
      }
      if (quantity && !isNaN(quantity)){
        updatedEntries.quantity = quantity;
      }

      if (typeof storeNum !== 'undefined' && storeNum != null){
        updatedEntries.storeNum = storeNum;
        updatedEntries.isBopusItem = (storeNum) ? (storeNum !== defaultHybridBagEntryValues.storeNum) : false;
      }

      if (typeof skuCode !== 'undefined' && skuCode != null){
        updatedEntries.skuCode = skuCode;
      }

      const newCartEntry = Object.assign(currentCartEntry, updatedEntries);

      //again check if index should be bagItemId - 1
      updateBag(updatedUpdateCartEntryArr, newCartEntry)

      //updatedUpdateCartEntryArr[bagItemId] = newCartEntry;
  }

  //write to disk
  //const updatedCartString = getCartStringFromArray(updatedUpdateCartEntryArr);
  //persistCart(updatedCartString, putInLocalStorage, getFromLocalStorage, setCookieValue);
  persistLocalCart(updatedUpdateCartEntryArr);
  if (window && window && window._header){
    window._header.updateCartCount(updatedUpdateCartEntryArr);
  }

  return updatedUpdateCartEntryArr;
}

export function getCartArrayFromString(cartString){
  const rawCartArr = (cartString) ? JSON.parse(cartString) : [];
  let cartEntryArr;
  if (rawCartArr && rawCartArr.length > 0){
    cartEntryArr = rawCartArr.map(rawEntry => getCartEntryFromString(rawEntry));
  }else{
    cartEntryArr = [];
  }

  return cartEntryArr;
}

export function getCartStringFromArray(cartEntryArr){
  const updatedRawCartArr = cartEntryArr.map(cartEntry => createCartEntryString(cartEntry));
  const updatedCartString = JSON.stringify(updatedRawCartArr);
  return updatedCartString;
}

export function generateIdsForBagItems(cart){
  let newBagItemId = 1;
  cart.map(cartEntry => {
    if (!cartEntry.bagItemId || cartEntry.bagItemId === '0'){
      newBagItemId = getNextBagItemId(newBagItemId, cart);
      cartEntry.bagItemId = '' + newBagItemId;
    }
  });

  return cart;
}

function getExistingBagItemIds(cart){
  const existingBagItemIds = [];
  cart.map(currentCartItem => {
    if (typeof currentCartItem.bagItemId !== 'undefined'){
      existingBagItemIds.push('' + currentCartItem.bagItemId);
    }

    // if (currentCartItem.bagItemId && currentCartItem.bagItemId !== '0'){
    //   existingBagItemIds.push(currentCartItem.bagItemId);
    // }
  });
  return existingBagItemIds;
}

function getNextBagItemId(currentBagItemId, cart){
  const existingBagItemIds = getExistingBagItemIds(cart);
  let newBagItemId = currentBagItemId;
  while(existingBagItemIds.indexOf('' + newBagItemId) > -1){
    newBagItemId++;
  }
  return newBagItemId;
}



// This generates a unique bagItemId for the cart entry about be added
export function getNewLocalBagItemId(cart){
  return '' + getNextBagItemId(1, cart);
  //return getNextBagItemId(1, cart);
}

export function addOrMergeCartEntries(mergedAllEntries, cartEntry, mergeLocalEntryWithOcb, mergeWithMaxQty = true){
  // make a copy of entries
  const entries = mergedAllEntries.slice(0);
  let isEntryMerged = false;
  for (let i = 0; i < entries.length; i++){
    let currentEntry = entries[i];
    if (canCartEntriesBeMerged(cartEntry, currentEntry)){
      let mergedCartEntry = mergeCartEntries(cartEntry, currentEntry, mergeLocalEntryWithOcb, mergeWithMaxQty);
      entries[i] = mergedCartEntry;
      isEntryMerged = true;
      break;
    }
  }
  if (!isEntryMerged){
    const currentBagItem = cartEntry.bagItemId;
    if (typeof currentBagItem === 'undefined' || !currentBagItem || currentBagItem === "0"){
      cartEntry.bagItemId = getNewLocalBagItemId(entries);
    }
    entries.push(cartEntry);
  }
  return entries;
}

// This allows external functions to be injected for unit testability
export function addToBagInternal(cartEntry, getCookieValue,
  setCookieValue, getFromLocalStorage, putInLocalStorage){
    let updatedCartString;
    let updatedCartEntries;
    const cartEntryArr = getCartFromStorageInternal(getFromLocalStorage, getCookieValue);
    //console.log('### cartEntryArr.length ' + cartEntryArr.length);
    try{
      const entries = {
        entriesToAdd: [],
        entriesToUpdate: [],
        allEntries: cartEntryArr
      };
      updatedCartEntries = addOrMergeCartEntries(entries.allEntries, cartEntry, false, true);
      persistLocalCart(updatedCartEntries)
    }catch(err){
      updatedCartEntries = cartEntryArr;
      console.error('Error adding to cart: ' + err);
    }
	return updatedCartEntries;
}

function persistCart(updatedCartString, putInLocalStorage, getFromLocalStorage, setCookieValue){
  putInLocalStorage(legacyStoredCartKey, updatedCartString);

  setCookieValue(legacyStoredCartKey, updatedCartString);

}

export function getCartEntryFromFields(skuCode, webID, quantity, isGift,
  registryID, collId, isBopusItem, storeNum, bagItemId){

    const entryFields = {
      skuCode,
      webID,
      quantity,
      isGift,
      registryID,
      //collId,
      isBopusItem,
      storeNum
      //bagItemId
    }
    const hybridEntry = getHybridBagEntry(entryFields, bagItemId);
    return normalizeCartEntry(hybridEntry);
}

export function canCartEntriesBeMerged(newEntry, currentEntry){
  if (typeof newEntry === 'undefined' || typeof currentEntry === 'undefined'){
    return false;
  }

  if (!newEntry.skuCode || !newEntry.webID){
    return false;
  }

  if (newEntry.skuCode !== currentEntry.skuCode || newEntry.webID !== currentEntry.webID){
    return false;
  }

  if (newEntry.skuCode === currentEntry.skuCode &&
     newEntry.webID === currentEntry.webID &&
     newEntry.registryID === currentEntry.registryID &&
     newEntry.storeNum === currentEntry.storeNum
   ){
    return true;
  }

  if (compareOptionalValues(newEntry.registryID, currentEntry.registryID) &&
    compareOptionalValues(newEntry.storeNum, currentEntry.storeNum)){
    return true;
  }

  // if (newEntry.skuCode === currentEntry.skuCode &&
  //    newEntry.webID === currentEntry.webID &&
  //    newEntry.registryID === currentEntry.registryID &&
  //    newEntry.storeNum === currentEntry.storeNum
  //  ){
  //   return true;
  // }
  return false;
}

function compareOptionalValues(valueA, valueB){
  if (isFalsy(valueA) && isFalsy(valueB)){
    return true;
  }
  return ('' + valueA) === ('' + valueB);
}

function isFalsy(value){
  return (typeof value === 'undefined' ||
    !value ||
    value === 'false' ||
    value === '0' ||
    value === '-1' ||
    value === '')
}

export function mergeCartEntries(ocbEntry, currentEntry, mergeLocalEntryWithOcb, mergeWithMaxQty = true){
  if (typeof ocbEntry === 'undefined' || typeof currentEntry === 'undefined'){
    return currentEntry;
  }

  const ocbEntryQty = parseInt(ocbEntry.quantity);
  const currentEntryQty = parseInt(currentEntry.quantity);
  if (isNaN(ocbEntryQty) || isNaN(currentEntryQty)){
    return currentEntry;
  }

  let newQuantity;
  if (mergeWithMaxQty){
      // if this is a new cart addition, add the two qtys
      // if this is a merge of local cart with OCB, use the max of the two qtys
      newQuantity = (mergeLocalEntryWithOcb) ? Math.max(ocbEntryQty, currentEntryQty) : (ocbEntryQty + currentEntryQty);
  }else{
    // set newQuantity to local cart entry (which has the updated qty)
    newQuantity = currentEntryQty;
  }

  const updatedFields = {quantity: newQuantity, isSynced: false};
  const mergedEntry = Object.assign({}, currentEntry, updatedFields);
  return mergedEntry;
}

export function getCartFromStorage(){
  return getCartFromStorageInternal(utils.getFromLocalStorage, utils.getCookieValue);
}

export function getCartFromStorageInternal(getFromLocalStorage, getCookieValue){
  let cart = [];
    let cartStr = getFromLocalStorage(storedLocalBagKey);
  if (cartStr){
    return JSON.parse(cartStr);
  }
  cartStr = getCookieValue(legacyStoredCartKey);
  // this is a legacy cart, so we need to generate bagItemIds
  if (cartStr){
    try{
      cart = generateIdsForBagItems(getCartArrayFromString(cartStr));
      utils.putInLocalStorage(storedLocalBagKey, JSON.stringify(cart));
    }catch(err){
      console.log('error adding to cart with cart');
    }
  }

  return cart;
}

// This allows external functions to be injected for unit testability
export function getHybridBagInteral(getFromLocalStorage, getCookieValue){
  let cartArr;
  //if (utils.isLoggedIn()){
  if (utils.getCartAccessToken()){
    const storedOcb = getOcbCart();
    if (storedOcb && storedOcb.cartItems){
      cartArr = storedOcb.cartItems.map(ocbCartItem => {
        return mergeCartHelper.convertOcbToLocalEntry(ocbCartItem);
      });
    }
  }

  if (!cartArr){
    cartArr = getCartFromStorageInternal(getFromLocalStorage, getCookieValue);
  }

  const hybridBag = cartArr.map((cartEntry, index) => {
    //return getHybridBagEntry(cartEntry, index);
    return getHybridBagEntry(cartEntry);
  });

  return hybridBag;
}

// This function is to return a shopping cart entry which can be consumed by
// checkout
//export function getHybridBagEntry(cartEntry, bagItemId){
export function getHybridBagEntry(cartEntry){
  const overrideValues = {
    quantity: getNumericFromString(cartEntry.quantity),
    isGift: convertBoolean(cartEntry.isGift),
    isBopusItem: convertBoolean(cartEntry.isBopusItem),
    registryID: ((cartEntry.registryID == -1) ? "0": cartEntry.registryID),
    storeNum: ((cartEntry.storeNum == -1) ? "" : cartEntry.storeNum)
    //bagItemId: bagItemId
  };

  return Object.assign({}, defaultHybridBagEntryValues, cartEntry, overrideValues);
}

export function createCartEntryString(cartEntry){

  const isGift = cartEntry.isGift ? cartEntry.isGift : legacyDefaultCartEntryValues.isGift;
  const registryID = (cartEntry.registryID && cartEntry.registryID !== 0 && cartEntry.registryID !== '0') ? cartEntry.registryID : legacyDefaultCartEntryValues.registryID;
  const collId = cartEntry.collId ? cartEntry.collId : legacyDefaultCartEntryValues.collId;
  const isBopusItem = cartEntry.isBopusItem ? cartEntry.isBopusItem : legacyDefaultCartEntryValues.isBopusItem;
  const storeNum = cartEntry.storeNum ? cartEntry.storeNum : legacyDefaultCartEntryValues.storeNum;
  const bagItemId = typeof cartEntry.bagItemId !== 'undefined' ? cartEntry.bagItemId : legacyDefaultCartEntryValues.bagItemId;

  return `${cartEntry.skuCode}|${cartEntry.webID}|${cartEntry.quantity}|${isGift}|${registryID}|${collId}|${isBopusItem}|${storeNum}`;
}

export function getCartEntryFromString(cartEntryString){
  const cartEntryFieldsArr = cartEntryString.split('|');
  if (cartEntryFieldsArr.length < 3){
    return {};
  }

  //const cartEntry = Object.assign({}, defaultCartEntryValues);
  const cartEntry = Object.assign({}, defaultHybridBagEntryValues);

  for (let i = 0; i < cartEntryFieldsArr.length && i < fieldsNames.length; i++){
    let fieldValue = cartEntryFieldsArr[i];
    let fieldName = fieldsNames[i];
    //cartEntry[fieldName] = (fieldName === 'quantity') ? getNumericFromString(fieldValue) : fieldValue;
    cartEntry[fieldName] = fieldValue;
  }

  return normalizeCartEntry(cartEntry);
}

//TODO: is the function necessary?
export function updateLocalCartItemIDs(localCart, ocb){
  try{
    const ocbEntriesCopy = ocb.cartItems.slice(0); //copy ocb
    localCart.map(localCartEntry => {
      //if (!localCartEntry.cartItemID){
      if (!localCartEntry.isSynced){
        for(let i = 0; i < ocbEntriesCopy.length; i++){
          let currentOcbEntry = ocbEntriesCopy[i];

          if (currentOcbEntry
            && canCartEntriesBeMerged(localCartEntry, currentOcbEntry)){
            //&& localCartEntry.quantity == currentOcbEntry.qty)){
              localCartEntry.cartItemID = currentOcbEntry.cartItemID;
              localCartEntry.isSynced = true;
              delete ocbEntriesCopy[i];
          }
        }
      }
    });
  }catch(err){
    console.log('Error in updateLocalCartItemIDs: ' + err);
  }

  return localCart;
}


export function persistLocalCart(updatedCartEntries){
  const normalizedEntries = updatedCartEntries.map(entry => normalizeCartEntry(entry));
  const cartStr = JSON.stringify(normalizedEntries);
  utils.putInLocalStorage(storedLocalBagKey, cartStr);

  //test write
  if (utils.getFromLocalStorage(storedLocalBagKey) !== cartStr){
    utils.setCookieValue(storedLocalBagKey, cartStr);
  }

  //set legacy value in cart
  const updatedCartString = getCartStringFromArray(normalizedEntries);
  //console.log('updatedCartString: ' + updatedCartString)
  utils.setCookieValue(legacyStoredCartKey, updatedCartString)
}

export function normalizeCartEntry(cartEntry){
  const entry = Object.assign({}, cartEntry);
  for(let key in entry) {
    if(entry.hasOwnProperty(key)){
      let currentVal = cartEntry[key];
      if(key === 'isGift' || key === 'isBopusItem'){
        entry[key] = convertBoolean(entry[key]);
      }else if (key === 'quantity'){
        entry[key] = getNumericFromString(entry[key]);
      }else if(key === 'registryID' && (currentVal === '-1' || !currentVal)){
        entry[key] = '0';
      }else if(key === 'storeNum' && (currentVal === '-1' || !currentVal)){
        entry[key] = '';
      }else if(key === 'bagItemId' && currentVal === 'null'){
        //entry[key] = null;
        entry[key] = '0';
      }else if(key === 'collId'){
        // we're not currently useing this key
        delete entry[key];
      }
    }
  }
  return entry;
}

function updateOcb(entriesToAdd, entriesToUpdate, entriesToRemove, cartId, accessToken, callback, localCart){
  const url = '/api/v1/cart';
  const updatePayload = mergeCartHelper.getUpdateCartPayload(entriesToAdd, entriesToUpdate, entriesToRemove, cartId, localCart);
  $.ajax({
    url: url,
    method: 'POST',
    contentType: 'application/json',
    headers: {'Accept': 'application/json', 'access_token': accessToken},
    data: JSON.stringify(updatePayload)
  }).fail(function(error){
    console.log('Error in POST to /api/v1/cart' + error);
  }).always(function(ocbCartData){
    saveOcb(ocbCartData);
    callback(ocbCartData);
  });
}

function getOcbCart(){
  const ocbCartFromLs = utils.getFromLocalStorage(storedOcbKey);
  if (ocbCartFromLs){
    return JSON.parse(ocbCartFromLs);
  }
  const cookieVal = utils.getCookieValue(storedOcbKey);
  if (cookieVal){
    return JSON.parse(cookieVal);
  }
  return cookieVal;
}


function saveOcb(ocbCartData){
  if (ocbCartData && ocbCartData.payload){
      const ocbCartDataStr = (ocbCartData.payload.cart) ? JSON.stringify(ocbCartData.payload.cart) : {};
      utils.putInLocalStorage(storedOcbKey, ocbCartDataStr);
      if (utils.getFromLocalStorage(storedOcbKey) !== ocbCartDataStr){
        utils.setCookieValue(storedOcbKey, ocbCartDataStr);
      }
  }
}

function synchCart(ocbCartData, callback, accessToken, mergeWithMaxQty = true, removeItemsNotInLocalBag = false){
  let shouldUpdateCart = false;
  let entriesToRemove = [];
  try{
    if (!ocbCartData || !ocbCartData.payload){
      callback(ocbCartData);
      return;
    }
    const localCart = getCartFromStorage();
    const mergedEntries = mergeCartHelper.mergeLocalCartWithOcb(ocbCartData, localCart, mergeWithMaxQty);
    saveCart(mergedEntries.allEntries);

    if (mergedEntries.entriesToAdd && mergedEntries.entriesToAdd.length > 0){
      shouldUpdateCart = true;
    }else if (mergedEntries.entriesToUpdate && mergedEntries.entriesToUpdate.length > 0){
      shouldUpdateCart = true;
    }

    if (removeItemsNotInLocalBag){
      entriesToRemove = mergeCartHelper.getEntriesToRemove(ocbCartEntries, localCart);
    }

    if (shouldUpdateCart){
      updateOcb(mergedEntries.entriesToAdd, mergedEntries.entriesToUpdate, entriesToRemove, ocbCartData.payload.cart.cartID, accessToken, callback, localCart);
    }
  }catch(error){
    console.log('Error getting OCB data: ' + error);
    callback(ocbCartData);
  }
  callback && !shouldUpdateCart && callback(ocbCartData);
}

export function mergeOmniChannelBag(callback, accessToken, mergeWithMaxQty = true){
  const url = '/api/v1/cart';
  $.ajax({
    url: url,
    method: 'GET',
    contentType: 'application/json',
    headers: {'Accept': 'application/json', 'access_token': accessToken}
  }).always(function(ocbCartData){
    if (ocbCartData && ocbCartData.payload){
      saveOcb(ocbCartData);
    }
    synchCart(ocbCartData, callback, accessToken, mergeWithMaxQty, false);
  });
}

export function saveAndUpdateCart(cartData, callback){
  saveCart(cartData);
  //const accessToken = utils.getCartAccessToken();
  //synchCart(cartData, callback, accessToken, false, true)
  mergeCartWithCallback(callback, cartData, false);
}

export function saveCart(cartData){
  persistLocalCart(cartData);
  window._header.updateCartCount(cartData);
}

function getNumericFromString(numberString){
  const defaultNumber = 0;
  if (numberString){
    const number = parseInt(numberString);
    return isNaN(number) ? defaultNumber :  number;
  }
  return defaultNumber;
}

function convertBoolean(bool){
  if (bool === true){
    return bool;
  }
  return 'true' === bool;
}
