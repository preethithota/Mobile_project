import * as mergeCartHelper from '../merge-cart-helper';
import * as cartHelper from '../cart-helper';

// ocbTestData contains the following:
// 1 sku# 92599202 - bopus store# 761
// 1 sku# 93270601 - shipped
// 3 sku# 92778446 - shipped
const ocbTestData = require('./ocb-data.json');


// ocbTestData2 contains the following:
// 1 sku# 92599202 - shipped
// 3 sku# 93270601 - shipped
const ocbTestData2 = require('./ocb-data2.json');

// localCartTestData contains the following:
// 1 sku# 92599202 - shipped
// 2 sku# 93270601 - shipped
// 1 sku# 92778451 - shipped gift
// 4 sku# 92831376 - bopus store# 761
const localCartTestData = '["92831376|1815305|4|false|-1|-1|true|761","92599202|1030732|1|false|-1|-1","93270601|1037968|2|false|-1|-1","92778451|1069102|1|true|-1|-1"]';

const localCartEntries = cartHelper.getCartArrayFromString(localCartTestData);

describe('getEntriesToAddOrUpdate', () => {
  const testLocalCartEntries = Object.assign({}, localCartEntries);
  const entries = mergeCartHelper.mergeLocalCartWithOcb(ocbTestData2, localCartEntries);

  // Test that skus 92599202 and 93270601 are not added because the local qty <= ocb qty
  it('should only include in entriesToAdd local cart skus whose qty is > ocb sku qty', () => {
    expect(entries.entriesToAdd.length).toBe(2);

    const sku92778451 = entries.entriesToAdd.filter(entry => entry.skuCode === '92778451');
    expect(sku92778451.length).toBe(1);
    expect(sku92778451[0].quantity).toBe(1);
    expect(sku92778451[0].isGift).toEqual(true);

    const sku92831376 = entries.entriesToAdd.filter(entry => entry.skuCode === '92831376');
    expect(sku92831376.length).toBe(1);
    expect(sku92831376[0].quantity).toBe(4);
    expect(sku92831376[0].storeNum).toEqual('761');
  });

  it('return the correct entriesToUpdate', () => {
    expect(entries.entriesToUpdate.length).toBe(0);
  });

});

describe('convertOcbToLocalEntry', () => {
  it('should correctly convert OCB entry from /v1/cart response to local cart entry', () => {
    const ocbCartItems = ocbTestData.payload.cart.cartItems;
    const testOcbItem = ocbCartItems[0];
    const expectedCartEntryValues = {
      skuCode: '92599202',
      webID: '1030732',
      quantity: 1,
      isGift: 'false',
      registryID: '-1',
      collId: '-1',
      isBopusItem: 'true',
      storeNum: '761',
      bagItemId: '1601003312'
    };
    const expectedCartEntry =  cartHelper.normalizeCartEntry(expectedCartEntryValues);
    const actualCartEntry = mergeCartHelper.convertOcbToLocalEntry(testOcbItem);
    expect(actualCartEntry).toEqual(expectedCartEntry);

  });
});

const entries = mergeCartHelper.mergeLocalCartWithOcb(ocbTestData, localCartEntries);
const mergedEntries = entries.allEntries;
describe('mergeLocalCartWithOcb', () => {
  it('should return array of correct length', () => {
    const expectedLength = 6;
    expect(mergedEntries.length).toBe(expectedLength);
  });

  it('should not merge a bopus and non-bopus sku', () => {
    const skus92599202 = mergedEntries.filter(entry => entry.skuCode === '92599202');
    const bopusSku = skus92599202.filter(entry => entry.storeNum === '761');

    expect(skus92599202.length).toBe(2);
    expect(bopusSku.length).toBe(1);
  });

  it('should use the max qty of local sku (qty 2) and ocb sku (qty 1)', () => {
    const sku93270601 = mergedEntries.filter(entry => entry.skuCode === '93270601');
    expect(sku93270601.length).toBe(1);
    expect(sku93270601[0].quantity).toEqual(2);
  });

  it('should include a sku that exists in ocb but not in local cart', () => {
    const sku92778446 = mergedEntries.filter(entry => entry.skuCode === '92778446');
    expect(sku92778446.length).toBe(1);
    expect(sku92778446[0].quantity).toEqual(3);
  });

  it('should include a sku that exists in local cart but not in ocb', () => {
    const sku92831376 = mergedEntries.filter(entry => entry.skuCode === '92831376');
    expect(sku92831376.length).toBe(1);
    expect(sku92831376[0].quantity).toEqual(4);
  });

  it('should preserve gift attribute', () => {
    const sku92778451 = mergedEntries.filter(entry => entry.skuCode === '92778451');
    expect(sku92778451.length).toBe(1);
    expect(sku92778451[0].quantity).toEqual(1);
    expect(sku92778451[0].isGift).toEqual(true);
  });

  it('should return ocb items only if no local cart', () => {
    const ocbOnlyMergedEntries = mergeCartHelper.mergeLocalCartWithOcb(ocbTestData, []).allEntries;
    expect(ocbOnlyMergedEntries.length).toEqual(3);
  });

  it('should return local items only if no ocb cart', () => {
    const ocbOnlyMergedEntries = mergeCartHelper.mergeLocalCartWithOcb({}, localCartEntries).allEntries;
    expect(ocbOnlyMergedEntries.length).toEqual(4);
  });

});


describe('getEntriesToAddOrUpdate', () => {

  const entriesToAdd = entries.entriesToAdd;

  it('should return the correct number entires to add', () => {
    const expectedLength = 3;
    expect(entriesToAdd.length).toBe(expectedLength);
  });

  it('should return the correct entires to add', () => {
    const sku92599202 = entriesToAdd.filter(entry => entry.skuCode === '92599202');
    expect(sku92599202.length).toBe(1);
    expect(sku92599202[0].quantity).toBe(1);

    const sku92831376 = entriesToAdd.filter(entry => entry.skuCode === '92831376');
    expect(sku92831376.length).toBe(1);
    expect(sku92831376[0].quantity).toBe(4);

    const sku92778451 = entriesToAdd.filter(entry => entry.skuCode === '92778451');
    expect(sku92778451.length).toBe(1);
    expect(sku92778451[0].quantity).toBe(1);
  });

});

describe('getEntriesToUpdate', () => {
  const entriesToUpdate = entries.entriesToUpdate;
  it('should return the correct number of entires to update', () => {
    const expectedLength = 1;
    expect(entriesToUpdate.length).toBe(expectedLength);
  });

  it('should return the correct entires to update', () => {
    const sku93270601 = entriesToUpdate.filter(entry => entry.skuCode === '93270601');
    expect(sku93270601.length).toBe(1);
    expect(sku93270601[0].quantity).toBe(2);
  });

});



describe('getUpdateCartPayload', () => {
  const cartId = ocbTestData.payload.cart.cartID;
  const cartPayload = mergeCartHelper.getUpdateCartPayload(entries.entriesToAdd, entries.entriesToUpdate, [], cartId, ocbTestData.payload.cart.cartItems);
  const expectedCartPayload = require('./update-cart-data.json');

  it('should return the correct update cart payload', () => {
    const cartItems = cartPayload.payload.cart.cartItems;
    const sku92599202 = cartItems.filter(entry => entry.skuCode === '92599202');
    expect(sku92599202.length).toBe(1);
    expect(sku92599202[0].qty).toEqual(1);
    expect(sku92599202[0].action).toEqual('add');

    const sku93270601 = cartItems.filter(entry => entry.skuCode === '93270601');
    expect(sku93270601.length).toBe(1);
    expect(sku93270601[0].qty).toEqual(2);
    expect(sku93270601[0].action).toEqual('update');

    const sku92831376 = cartItems.filter(entry => entry.skuCode === '92831376');
    expect(sku92831376.length).toBe(1);
    expect(sku92831376[0].qty).toEqual(4);
    expect(sku92831376[0].action).toEqual('add');
    expect(sku92831376[0].bopusItem).toBe(true);
    expect(sku92831376[0].storeNum).toEqual('761');

    const sku92778451 = cartItems.filter(entry => entry.skuCode === '92778451');
    expect(sku92778451.length).toBe(1);
    expect(sku92778451[0].qty).toEqual(1);
    expect(sku92778451[0].action).toEqual('add');
  });

});


describe('mergeLocalCartWithOcb2', () => {
  const ocbCart = {"payload":{"cart":{"cartID":"881157227659","cartItems":[],"error":null}}};
  const localCartEntries = [{"isGift":false,"registryID":"-1","collId":"-1","isBopusItem":false,"storeNum":"-1","skuCode":"94323044","webID":"1490282","quantity":11}];
  const entries = mergeCartHelper.mergeLocalCartWithOcb(ocbCart, localCartEntries);

  it('should properly merge with empty ocb', () => {
    expect(entries.entriesToAdd.length).toBe(1);
    const sku94323044 = entries.entriesToAdd.filter(entry => entry.skuCode === '94323044');
    expect(sku94323044.length).toBe(1);
    expect(sku94323044[0].quantity).toBe(11);
    expect(sku94323044[0].isGift).toEqual(false);
  });
});

describe('getEntriesToRemove', () => {

  it('should remove entries from OCB which are not present in the local bag', () => {
    const ocbCartEntries = [{bagItemId: '1'}, {bagItemId: '2'}, {bagItemId: '3'}];
    const localEntries = [{bagItemId: '1'}, {bagItemId: '3'}];
    const entriesToRemove = mergeCartHelper.getEntriesToRemove(ocbCartEntries, localEntries);
    expect(entriesToRemove.length).toBe(1);
    expect(entriesToRemove[0].bagItemId).toBe('2');
  });

  it('should return empty array if there are no removeable entries', () => {
    const ocbCartEntries = [{bagItemId: '3'}];
    const localEntries = [{bagItemId: '1'}, {bagItemId: '3'}];
    const entriesToRemove = mergeCartHelper.getEntriesToRemove(ocbCartEntries, localEntries);
    expect(entriesToRemove.length).toBe(0);
  });

  it('should correctly return multiple entries', () => {
    const ocbCartEntries = [{bagItemId: '3'}, {bagItemId: '4'}, {bagItemId: '5'}, {bagItemId: '1'}, {bagItemId: '6'}];
    const localEntries = [{bagItemId: '1'}, {bagItemId: '3'}];
    const entriesToRemove = mergeCartHelper.getEntriesToRemove(ocbCartEntries, localEntries);
    expect(entriesToRemove.length).toBe(3);
  });

});
