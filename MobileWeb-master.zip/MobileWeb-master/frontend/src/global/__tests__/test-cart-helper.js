import * as utils from '../utils';
import * as cartHelper from '../cart-helper';
jest.mock('../utils');

const testCartEntry = {
  "bagItemId": "null",
  "isGift": true,
  "isSynced": false,
  "itemOffers": [],
  "quantity": "3",
  "registryID": "123",
  "registryName": "",
  "registryQty": "",
  "registryShipID": "",
  "registryType": "",
  "registryWantedQty": "",
  "storeNum": "789",
  "isBopusItem": true,
  "skuCode": "18037602",
  "webID": "2539706",
  "collId": "456"
}

//const storedCartKey = 'skBag';
const legacyStoredCartKey = 'skBag';
const storedLocalBagKey = 'KOHLS-BAG';
const storedOcbKey = 'KOHLS-OCB';

describe('updateHybridBag', () => {
  const origCartStoredInLocalStorage = '["33647125|2659206|1|false|-1|-1|true|761|6016661","99292746|2150121|1|true|3135883|-1|false|-1|6016662","76358516|1529669|1|false|-1|-1|false|-1|6016663"]';

  beforeEach(() => {
    utils.__clearData();
    utils.getCookieValue.mockClear();
    utils.setCookieValue.mockClear();
    utils.putInLocalStorage.mockClear();
    utils.getFromLocalStorage.mockClear();

  });

  it('should properly update the qty', () => {
    //const bagItemId = 1, isGift = true, quantity = 14;
    const bagItemId = '6016662', isGift = true, quantity = 14;

    //updated 99292746 qty to 14
    const expectedUpdatedCart = '["33647125|2659206|1|false|-1|-1|true|761|6016661","99292746|2150121|14|true|3135883|-1|false|-1|6016662","76358516|1529669|1|false|-1|-1|false|-1|6016663"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedUpdatedCart);
    putCartInMockedLS(origCartStoredInLocalStorage);

    const actualHybridBag = cartHelper.updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage, utils.getCookieValue, utils.putInLocalStorage, utils.setCookieValue);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

  it('should properly update gift flag', () => {
    const bagItemId = '6016661', isGift = true, quantity = 1;
    //updated 33647125 isGift to true
    const expectedUpdatedCart = '["33647125|2659206|1|true|-1|-1|true|761|6016661","99292746|2150121|1|true|3135883|-1|false|-1|6016662","76358516|1529669|1|false|-1|-1|false|-1|6016663"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedUpdatedCart);
    putCartInMockedLS(origCartStoredInLocalStorage);

    const actualHybridBag = cartHelper.updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage, utils.getCookieValue, utils.putInLocalStorage, utils.setCookieValue);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

  it('should properly update the storeNum', () => {
    const bagItemId = '6016663', isGift = false, quantity = 1, skuCode = null, storeNum = '112233';
    //sku 76358516 storeNum = 112233
    const expectedUpdatedCart = '["33647125|2659206|1|false|-1|-1|true|761|6016661","99292746|2150121|1|true|3135883|-1|false|-1|6016662","76358516|1529669|1|false|-1|-1|true|112233|6016663"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedUpdatedCart);

    putCartInMockedLS(origCartStoredInLocalStorage);
    const actualHybridBag = cartHelper.updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage,
      utils.getCookieValue, utils.putInLocalStorage, utils.setCookieValue, skuCode, storeNum);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

  it('should properly update the sku', () => {
    const bagItemId = '6016662', isGift = null, quantity = 1, skuCode = '123456789', storeNum = null;

    const expectedUpdatedCart = '["33647125|2659206|1|false|-1|-1|true|761|6016661","123456789|2150121|1|true|3135883|-1|false|-1|6016662","76358516|1529669|1|false|-1|-1|false|-1|6016663"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedUpdatedCart);
    putCartInMockedLS(origCartStoredInLocalStorage);
    cartHelper.updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage,
      utils.getCookieValue, utils.putInLocalStorage, utils.setCookieValue, skuCode, storeNum);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

  it('should not update qty/isGift if invalid values passed', () => {
    const bagItemId = '6016661', isGift = null, quantity = null;
    //same as cartStoredInLocalStorage
    const expectedUpdatedCart = '["33647125|2659206|1|false|-1|-1|true|761|6016661","99292746|2150121|1|true|3135883|-1|false|-1|6016662","76358516|1529669|1|false|-1|-1|false|-1|6016663"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedUpdatedCart);
    putCartInMockedLS(origCartStoredInLocalStorage);
    cartHelper.updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage, utils.getCookieValue, utils.putInLocalStorage, utils.setCookieValue);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);

  });

  it('should remove entry if qty is 0', () => {
    const bagItemId = '6016662', isGift = true, quantity = 0;
    //updated 99292746 is remvoed
    const expectedUpdatedCart = '["33647125|2659206|1|false|-1|-1|true|761|6016661","76358516|1529669|1|false|-1|-1|false|-1|6016663"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedUpdatedCart);
    putCartInMockedLS(origCartStoredInLocalStorage);
    //exclued "99292746|2150121|1|true|3135883|-1|false|-1"
    const actualHybridBag = cartHelper.updateHybridBagInternal(bagItemId, isGift, quantity, utils.getFromLocalStorage, utils.getCookieValue, utils.putInLocalStorage, utils.setCookieValue);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
    //expect(putInLocalStorage).toBeCalledWith(legacyStoredCartKey, expectedUpdatedCart);
  });

});

describe('getCartStringFromArray', () => {
  it('should return the correct cart string', () => {
    const cartEntryArr = [{"bagItemId":'0',"skuCode":"94356030","webID":"1119487","quantity":1,"isGift":false,"registryID":"0","registryName":"","registryType":"","registryShipID":"","registryWantedQty":"","registryQty":"","storeNum":"","itemOffers":[],"lineCost":"34.99","title":"Gloria Vanderbilt Amanda Slimming Tapered Jeans - Petite","salePrice":"", "bagItemId": '6016661'}];
    const expectedResult = '["94356030|1119487|1|false|-1|-1|false|-1"]';
    const result = cartHelper.getCartStringFromArray(cartEntryArr);
    expect(result).toEqual(expectedResult);
  });
});

describe('getCartEntryFromFields', () => {

  const testCartEntry = {
    "bagItemId": "0",
    "isGift": true,
    "isSynced": false,
    "itemOffers": [],
    "quantity": 3,
    "registryID": "123",
    "registryName": "",
    "registryQty": "",
    "registryShipID": "",
    "registryType": "",
    "registryWantedQty": "",
    "storeNum": "789",
    "isBopusItem": true,
    "skuCode": "18037602",
    "webID": "2539706",
  }

  it('should return the correct cart entry', () => {
    const actualCartEntry = cartHelper.getCartEntryFromFields(testCartEntry.skuCode, testCartEntry.webID, testCartEntry.quantity, testCartEntry.isGift,
      testCartEntry.registryID, testCartEntry.collId, testCartEntry.isBopusItem, testCartEntry.storeNum, testCartEntry.bagItemId);
    expect(actualCartEntry).toEqual(testCartEntry);
  });

});

describe('getHybridBagInteral', () => {
  const cartStoredInLocalStorage = '["33647125|2659206|1|false|-1|-1|true|761","99292746|2150121|1|true|3135883|-1","76358516|1529669|1|false|-1|-1"]';
  const cartStoredInLocalStorageObj = cartHelper.getCartArrayFromString(cartStoredInLocalStorage);

  it('should return the correct cart', () => {
    putCartInMockedLS(cartStoredInLocalStorage);
    const actualHybridBag = cartHelper.getHybridBagInteral(utils.getFromLocalStorage, utils.getCookieValue);

    //value is found in localstorage, so shouldn't need to check cookie
    expect(actualHybridBag[0].skuCode).toEqual('33647125');
    expect(actualHybridBag[0].webID).toEqual('2659206');
    expect(actualHybridBag.length).toEqual(3);
    expect(actualHybridBag[2].itemOffers.length).toBe(0);
  });

});

//putCartInMockedLS(origCartStoredInLocalStorage);
describe('addToBagInternal', () => {
  //const rawCart with 1 shipped item, 1 bopus item, and 1 registry item
  const origCartStoredInLocalStorage = '["33647125|2659206|1|false|-1|-1|true|761","99292746|2150121|1|true|3135883|-1","76358516|1529669|1|false|-1|-1"]';
  const expectedCartString = '["33647125|2659206|1|false|-1|-1|true|761|null","99292746|2150121|1|true|3135883|-1|false|-1|null","76358516|1529669|1|false|-1|-1|false|-1|null","18037602|2539706|3|true|123|456|true|789|null"]';
  const expectedCartObj = cartHelper.getCartArrayFromString(expectedCartString);

  beforeEach(() => {
    utils.getCookieValue.mockClear();
    utils.setCookieValue.mockClear();
    utils.putInLocalStorage.mockClear();
    utils.getFromLocalStorage.mockClear();
    utils.__clearData();
  });

  it('should add cart to localstorage when localstorage is enabled', () => {
    putCartInMockedLS(origCartStoredInLocalStorage);
    cartHelper.addToBagInternal(testCartEntry, utils.getCookieValue,
      utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    expect(utils.getFromLocalStorage).toHaveBeenCalled();
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

  it('should try to retieve the cart from the cookie if localStorage cart is unavailable', () => {
    // This is to test the cookie with an outdated cart
    const origCartStoredInCookie = '["46388712|2680367|1|false|-1|-1"]';
    utils.setCookieValue(legacyStoredCartKey, origCartStoredInCookie);
    const expectedCartString = '["46388712|2680367|1|false|-1|-1|false|-1","18037602|2539706|3|true|123|456|true|789"]';

    cartHelper.addToBagInternal(testCartEntry, utils.getCookieValue,
      utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    const expectedCartObj = cartHelper.getCartArrayFromString(expectedCartString);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);

    expect(excludeBagItemIds(expectedCartObj)).toEqual(excludeBagItemIds(lastPutInLSCallVal));
    expect(utils.getCookieValue).toHaveBeenCalled();
  });

  it('write cart to cookie when localstorage is disabled', () => {
    const expectedCartString = '["46388712|2680367|1|false|-1|-1|false|-1","18037602|2539706|3|true|123|-1|true|789"]';
    const origCartStoredInCookie = '["46388712|2680367|1|false|-1|-1"]';
    utils.setCookieValue(legacyStoredCartKey, origCartStoredInCookie);
    utils.__disableLS();
    cartHelper.addToBagInternal(testCartEntry, utils.getCookieValue,
      utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    const setCookieCallArgs = utils.setCookieValue.mock.calls;
    const secondToLastCallArgs = setCookieCallArgs[setCookieCallArgs.length - 2];
    const lastCallArgs = setCookieCallArgs[setCookieCallArgs.length - 1];

    const expectedBagObj = cartHelper.getCartArrayFromString(expectedCartString);
    const actualBagObj = JSON.parse(secondToLastCallArgs[1]);

    //We expect two calls to setCookieValue
    //the first is KOHLS-BAG = expectedBagObj
    expect(secondToLastCallArgs[0]).toEqual(storedLocalBagKey);
    expect(excludeBagItemIds(actualBagObj)).toEqual(excludeBagItemIds(expectedBagObj));

    //the second is skBag = legacy bag string
    expect(lastCallArgs).toEqual([legacyStoredCartKey, expectedCartString]);
  });

  it("should create new cart with single cart entry if cart didn't exist previously", () => {
    //const getCookieValue = jest.fn().mockReturnValue(''); // simulate no current cart
    const singleEntryCartString = '["18037602|2539706|3|true|123|456|true|789"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(singleEntryCartString);

    cartHelper.addToBagInternal(testCartEntry, utils.getCookieValue,
      utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    expect(utils.getFromLocalStorage).toHaveBeenCalled();
    expect(utils.getCookieValue).toHaveBeenCalled(); // didn't find in ls, so should check cookie
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

    it("should create cart with properly merged bopus entry", () => {
    //qty 7 for 33647125
    const expectedCartString = '["33647125|2659206|7|false|-1|-1|true|761|null","99292746|2150121|1|true|3135883|-1|false|-1|null","76358516|1529669|1|false|-1|-1|false|-1|null"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedCartString);

    const testBopusCartEntry = {
      "bagItemId": "0",
      "isGift": false,
      "isSynced": false,
      "itemOffers": [],
      "quantity": "6",
      "registryID": "0",
      "registryName": "",
      "registryQty": "",
      "registryShipID": "",
      "registryType": "",
      "registryWantedQty": "",
      "storeNum": "761",
      "isBopusItem": true,
      "skuCode": "33647125",
      "webID": "2659206"
    }

    putCartInMockedLS(origCartStoredInLocalStorage);

    cartHelper.addToBagInternal(testBopusCartEntry, utils.getCookieValue,
      utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    //expect(utils.putInLocalStorage).toBeCalledWith(legacyStoredCartKey, expectedCartString);
    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);

    expect(lastPutInLSCallVal).toEqual(expectedCartObj);

    expect(utils.getFromLocalStorage).toHaveBeenCalled();
    expect(utils.getCookieValue).not.toHaveBeenCalled();
  });

  it("should create cart with properly merged registry entry", () => {
    //qty 4 for 99292746
    const expectedCartString = '["33647125|2659206|1|false|-1|-1|true|761","99292746|2150121|4|true|3135883|-1|false|-1","76358516|1529669|1|false|-1|-1|false|-1"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedCartString);
    //putCartInMockedLS(cartStr)

    putCartInMockedLS(origCartStoredInLocalStorage);
    const testRegistryCartEntry = cartHelper.getCartEntryFromFields('99292746', '2150121', '3', true,
      '3135883');

    cartHelper.addToBagInternal(testRegistryCartEntry, utils.getCookieValue,
      utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

  it("should create cart with properly merged shipped entry", () => {
    // qty 17 for 76358516
    const expectedCartString = '["33647125|2659206|1|false|-1|-1|true|761|null","99292746|2150121|1|true|3135883|-1|false|-1|null","76358516|1529669|17|false|-1|-1|false|-1|null"]';
    const expectedCartObj = cartHelper.getCartArrayFromString(expectedCartString);

    putCartInMockedLS(origCartStoredInLocalStorage);
    const testShippedCartEntry = cartHelper.getCartEntryFromFields('76358516', '1529669', '16');

    cartHelper.addToBagInternal(testShippedCartEntry, utils.getCookieValue,
      utils.setCookieValue, utils.getFromLocalStorage, utils.putInLocalStorage);

    const lastPutInLSCallVal = getLastCallValue(utils.putInLocalStorage, storedLocalBagKey, true);
    expect(lastPutInLSCallVal).toEqual(expectedCartObj);
  });

});

describe('createCartEntryString', () => {
  it('should return correct cart entry if all params passed in', () => {
    //const expectedValue = '18037602|2539706|3|true|123|456|true|789|null';
    const expectedValue = '18037602|2539706|3|true|123|456|true|789';
    expect(cartHelper.createCartEntryString(testCartEntry)).toEqual(expectedValue);
  });
});

describe('getCartEntryFromString', () => {
  it('should return the correct cart entry', () => {
    const cartEntryString = '18037602|2539706|3|true|123|456|true|789';
    const expectedCartEntry = {
      skuCode: '18037602',
      webID: '2539706',
      quantity: 3,
      isGift: true,
      registryID: '123',
      isBopusItem: true,
      storeNum: '789',
      bagItemId: '0',
      isSynced: false,
      itemOffers: [],
      registryName: "",
      registryQty: "",
      registryShipID: "",
      registryType: "",
      registryWantedQty: ""
    };

    //const expectedCartEntry = Object.assign({}, cartHelper.defaultHybridBagEntryValues, expectedCartValues)
    //const expectedCartEntry = getNormalizedExpectedCartEntry(expectedCartValues);
    const actualCartEntry = cartHelper.getCartEntryFromString(cartEntryString);
    expect(actualCartEntry).toEqual(expectedCartEntry);
  });

  it('should return the correct default values', () => {
    const cartEntryString = '18037602|2539706|3';

    const expectedCartValues = {
      skuCode: '18037602',
      webID: '2539706',
      bagItemId: "0",
      isGift: false,
      isSynced: false,
      itemOffers: [],
      quantity: 3,
      registryID: "0",
      registryName: "",
      registryQty: "",
      registryShipID: "",
      registryType: "",
      registryWantedQty: "",
      storeNum: "",
      isBopusItem: false
    };

    const expectedCartEntry = getNormalizedExpectedCartEntry(expectedCartValues);
    expect(cartHelper.getCartEntryFromString(cartEntryString)).toEqual(expectedCartEntry);
  });

  it('return correct bopus entry', () => {
    const cartEntryString = '39637819|2672335|2|false|-1|-1|true|761|null';
    const expectedCartValues = {
      skuCode: '39637819',
      webID: '2672335',
      quantity: 2,
      isGift: false,
      isBopusItem: true,
      storeNum: '761',
      isSynced: false,
      itemOffers: [],
      registryID: "0",
      registryName: "",
      registryQty: "",
      registryShipID: "",
      registryType: "",
      registryWantedQty: "",
    };
    const expectedCartEntry = getNormalizedExpectedCartEntry(expectedCartValues);
    expect(cartHelper.getCartEntryFromString(cartEntryString)).toEqual(expectedCartEntry);
  });

});

describe('getShoppingBagEntry', () => {
  it('should return the correct shoppingBagEntry', () => {
    const testCartEntry = {
      bagItemId: '5',
      skuCode: '18037602',
      webID: '2539706',
      quantity: 3,
      isGift: 'true',
      registryID: '123',
      collId: '456',
      isBopusItem: 'true',
      storeNum: '789'
    };

    const expectedShoppingBagEntry = {
      "bagItemId": '5',
      "isGift": true,
      "isSynced": false,
      "itemOffers": [],
      "quantity": 3,
      "registryID": "123",
      "registryName": "",
      "registryQty": "",
      "registryShipID": "",
      "registryType": "",
      "registryWantedQty": "",
      "skuCode": "18037602",
      "storeNum": "789",
      "webID": "2539706",
      "collId": '456',
      "isBopusItem": true
    };

    expect(cartHelper.getHybridBagEntry(testCartEntry, 5)).toEqual(expectedShoppingBagEntry);
  });


  it('should return properly convert default values', () => {
    const testCartEntry = {
      bagItemId: '7',
      skuCode: '18037602',
      webID: '2539706',
      quantity: 3,
      isGift: 'false',
      registryID: '-1',
      collId: '-1',
      isBopusItem: 'false',
      storeNum: '-1'
    };

    const expectedShoppingBagEntry = {
      "bagItemId": '7',
      "isGift": false,
      "isSynced": false,
      "itemOffers": [],
      "quantity": 3,
      "registryID": "0",
      "registryName": "",
      "registryQty": "",
      "registryShipID": "",
      "registryType": "",
      "registryWantedQty": "",
      "skuCode": "18037602",
      "storeNum": "",
      "webID": "2539706",
      "collId": '-1',
      "isBopusItem": false
    };

    expect(cartHelper.getHybridBagEntry(testCartEntry, 7)).toEqual(expectedShoppingBagEntry);
  });

  describe('canCartEntriesBeMerged', () => {

    const newEntry = {
      "bagItemId": "0",
      "isGift": false,
      "isSynced": false,
      "itemOffers": [],
      "quantity": 3,
      "registryID": "0",
      "registryName": "",
      "registryQty": "",
      "registryShipID": "",
      "registryType": "",
      "registryWantedQty": "",
      "skuCode": "18037602",
      "storeNum": "",
      "webID": "2539706",
      "isBopusItem": false
    };

    const currentEntry = {
      "bagItemId": "0",
      "isGift": false,
      "isSynced": false,
      "itemOffers": [],
      "quantity": 1,
      "registryID": "0",
      "registryName": "",
      "registryQty": "",
      "registryShipID": "",
      "registryType": "",
      "registryWantedQty": "",
      "skuCode": "18037602",
      "storeNum": "",
      "webID": "2539706",
      "isBopusItem": false
    };

    it('should return true if cart can be merged', () => {
      expect(cartHelper.canCartEntriesBeMerged(newEntry, currentEntry)).toBe(true);
    });

    it("should return false if registry id doesn't match", () => {
      const updatedCartEntry = Object.assign({}, newEntry, {registryID: '123'});
      expect(cartHelper.canCartEntriesBeMerged(updatedCartEntry, currentEntry)).toBe(false);
    });

    it("should return false if storeNum id doesn't match", () => {
      const updatedCartEntry = Object.assign({}, newEntry, {storeNum: '456'});
      expect(cartHelper.canCartEntriesBeMerged(updatedCartEntry, currentEntry)).toBe(false);
    });

    it("should return false if skuCode doesn't match", () => {
      const updatedCartEntry = Object.assign({}, newEntry, {skuCode: '1234567'});
      expect(cartHelper.canCartEntriesBeMerged(updatedCartEntry, currentEntry)).toBe(false);
    });

    it("should return false if webID doesn't match", () => {
      const updatedCartEntry = Object.assign({}, newEntry, {webID: '1234567'});
      expect(cartHelper.canCartEntriesBeMerged(updatedCartEntry, currentEntry)).toBe(false);
    });

  });

  describe('mergeCartEntries', () => {

    const newEntry = {
      "bagItemId": "0",
      "isGift": false,
      "isSynced": false,
      "itemOffers": [],
      "quantity": 3,
      "registryID": "0",
      "registryName": "",
      "registryQty": "",
      "registryShipID": "",
      "registryType": "",
      "registryWantedQty": "",
      "skuCode": "18037602",
      "storeNum": "",
      "webID": "2539706",
      "isBopusItem": false
    };

    const currentEntry = {
      "bagItemId": "0",
      "isGift": false,
      "isSynced": false,
      "itemOffers": [],
      "quantity": 1,
      "registryID": "0",
      "registryName": "",
      "registryQty": "",
      "registryShipID": "",
      "registryType": "",
      "registryWantedQty": "",
      "skuCode": "18037602",
      "storeNum": "",
      "webID": "2539706",
      "isBopusItem": false
    };

    it('should create a cart entry with the correct values', () => {
      const mergedEntry = cartHelper.mergeCartEntries(newEntry, currentEntry);
      expect(mergedEntry.quantity).toEqual(4);
      expect(mergedEntry.webID).toEqual('2539706');
      expect(mergedEntry.skuCode).toEqual('18037602');
    });

    it('should return original entry if invalid newEntry qty', () => {
      const invalidQtyObj = {};
      const updatedNewEntry = Object.assign({}, newEntry, {quantity: invalidQtyObj.quantity});
      const mergedEntry = cartHelper.mergeCartEntries(updatedNewEntry, currentEntry);
      expect(mergedEntry.quantity).toEqual(1); // same as currentEntry.quantity
    });

    it('merged entry should have same qty as updatedNewEntry if mergeWithMaxQty=true', () => {
      const mergeWithMaxQty = false;
      const mergedEntry = cartHelper.mergeCartEntries(currentEntry, newEntry, false, mergeWithMaxQty);
      expect(mergedEntry.quantity).toEqual(3);
      expect(mergedEntry.webID).toEqual('2539706');
      expect(mergedEntry.skuCode).toEqual('18037602');
    });

  });
});

describe('getNewLocalBagItemId', () => {
  it('should correctly generate a new unique bagItemId for the added cart entry', () => {
    const currentCartStr = '["33647125|2659206|1|false|-1|-1|true|761|711","99292746|2150121|4|true|3135883|-1|false|-1|1","76358516|1529669|1|false|-1|-1|false|-1|712"]';
    const currentCartArr = cartHelper.getCartArrayFromString(currentCartStr);
    const newBagItemId = cartHelper.getNewLocalBagItemId(currentCartArr);
    // bagItemIds are [711, 1, 712]
    expect(newBagItemId).toBe('2');
  });

  it('should correctly handle null or undefined values', () => {
    const currentCartStr = '["33647125|2659206|1|false|-1|-1|true|761","99292746|2150121|4|true|3135883|-1|false|-1|null","76358516|1529669|1|false|-1|-1|false|-1|null"]';
    const currentCartArr = cartHelper.getCartArrayFromString(currentCartStr);
    const newBagItemId = cartHelper.getNewLocalBagItemId(currentCartArr);
    // bagItemIds are [undefined, null, undefined]
    expect(newBagItemId).toBe('1');
  });

  it('should return unused id ', () => {
    const currentCartStr = '["33647125|2659206|1|false|-1|-1|true|761|null","99292746|2150121|4|true|3135883|-1|false|-1|null","76358516|1529669|1|false|-1|-1|false|-1|null"]';
    const currentCartArr = cartHelper.getCartArrayFromString(currentCartStr);
    currentCartArr[0].bagItemId = '2';
    currentCartArr[0].isSynced = false;

    currentCartArr[1].bagItemId = '1';

    currentCartArr[2].bagItemId = '123';
    currentCartArr[2].isSynced = true;

    //console.log('currentCartArr: ' + JSON.stringify(currentCartArr));
    const newBagItemId = cartHelper.getNewLocalBagItemId(currentCartArr);

    // bagItemIds are [2, 1, 123]
    expect(newBagItemId).toBe('3');
  });

});

describe('generateIdsForBagItems', () => {
  let testCart = [{
    "bagItemId": "123",
    "isGift": false,
    "isSynced": false,
    "webID": "111",
    "skuCode": "221",
    "quantity": 1
  },
  {
    "bagItemId": "8881",
    "isGift": false,
    "isSynced": true,
    "webID": "112",
    "skuCode": "222",
    "quantity": 4
  },
  {
    "isGift": false,
    "isSynced": false,
    "webID": "113",
    "skuCode": "223",
    "quantity": 2
  },{
    "bagItemId": "8882",
    "isGift": false,
    "isSynced": true,
    "webID": "114",
    "skuCode": "224",
    "quantity": 7
  },{
    "isGift": false,
    "isSynced": true,
    "webID": "115",
    "skuCode": "225",
    "quantity": 6
  }];

  it("should correctly generate bagItemIds for each entry that doesn't have one", () => {
    const updatedCart = cartHelper.generateIdsForBagItems(testCart);
    //console.log('updatedCart: ' + JSON.stringify(updatedCart));
    expect(updatedCart[2].bagItemId).toBe('1');
    expect(updatedCart[4].bagItemId).toBe('2');
  });

});

function getNormalizedExpectedCartEntry(expectedCartValues){
  return Object.assign({}, cartHelper.defaultHybridBagEntryValues, expectedCartValues);
}

function excludeBagItemIds(cart){
  const cartCopy = cart.slice(0);
  cartCopy.map(cartEntry =>{
    delete cartEntry['bagItemId'];
  });
  return cartCopy;
}

function putCartInMockedLS(cartStr){
  const cartObjectInLS = cartHelper.getCartArrayFromString(cartStr);
  const cartObjectInLSStr = JSON.stringify(cartObjectInLS);
  utils.putInLocalStorage(storedLocalBagKey, cartObjectInLSStr);
}

function getLastCallValue(mockFn, key, shouldParse){
  // filter all calls to mock function where the key (args[0]) matches key param
  const allCalls = mockFn.mock.calls.filter(args => args[0] === key);
  // return second arg of last call to mockFn with key
  const strVal = allCalls[allCalls.length - 1][1]; //return
  return (shouldParse) ? JSON.parse(strVal) : strVal;
}
