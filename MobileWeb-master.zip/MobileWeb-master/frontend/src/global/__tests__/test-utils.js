import * as utils from '../utils';

describe('findInArray', () => {
  const arr = [{"name": "a"}, {"name": "b"}, {"name": "c"}];

  it('should find "b" in array', () => {
    const shouldBeFoundElem = utils.findInArray(arr, elem => elem.name === "b");
    expect(shouldBeFoundElem.name).toBe("b");
  });

  it('should not find "z" in array', () => {
    const shouldNotBeFoundElem = utils.findInArray(arr, elem => elem.name === "z");
    expect(shouldNotBeFoundElem).toBeUndefined();
  });

});

describe('getImageUrl', () => {

  it('should return the correct image url', () => {
    const origUrl = 'http://media.kohlsimg.com/is/image/kohls/323481?wid=180&hei=180&op_sharpen=1';
    expect(utils.getImageUrl(origUrl, 28)).toBe('//media.kohlsimg.com/is/image/kohls/323481?wid=28&hei=28&op_sharpen=1');
  });

});

describe('convertToDollar', () => {

  it('should properly format dollar values', () => {
    expect(utils.convertToDollar(27.50)).toBe("$27.50");
    expect(utils.convertToDollar(32)).toBe("$32.00");
    expect(utils.convertToDollar(16.325)).toBe("$16.32");
  });

});

describe('isObjectEmpty', () => {

  let someNonEmptyObj = {'name1': 'value1', 'name2': 'value2'};

  it('should return true for empty objects', () => {
    expect(utils.isObjectEmpty({})).toBe(true);
  });

  it('should return false for non-empty objects', () => {
    expect(utils.isObjectEmpty(someNonEmptyObj)).toBe(false);
  });

  it('should properly handle deletes', () => {
    let newObj = Object.assign({}, someNonEmptyObj);
    delete newObj.name1;

    //still have name2
    expect(utils.isObjectEmpty(newObj)).toBe(false);

    delete newObj.name2;
    //newObj should now be empty
    expect(utils.isObjectEmpty(newObj)).toBe(true);
  });
});

describe('capitalizeFirstLetter', () => {

  it('should capitalize first letter of word', () => {
    const word = 'joe';
    expect(utils.capitalizeFirstLetter(word)).toEqual('Joe');

  });

  it('should handle empty strings', () => {
    expect(utils.capitalizeFirstLetter('')).toEqual('');
  });

});

 it('should chechk empty and null string', () => {
    let someString = 'aa';

    //should return true
    expect(utils.checkEmptyString(someString)).toBe(true);

    someString = '';

    //should return false bevause string is empty
    expect(utils.checkEmptyString(someString)).toBe(false);

  });
