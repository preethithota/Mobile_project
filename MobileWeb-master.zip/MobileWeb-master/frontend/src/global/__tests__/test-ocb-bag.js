import * as cartHelper from '../cart-helper';
import * as utils from '../utils';
import $ from 'jquery';

jest.mock('../utils');
jest.mock('jquery');

describe('updateHybridBagFromPdpModal', () => {
  const callback = jest.fn();

  const currentCart = require('./ocb-data2.json');
  const skuCode = '93270601';
  const bagItemId = '1601003314';
  const isGift = null;
  const storeNum = null;

  // current qty is 2
  const updatedQty = '6';

  utils.__clearData();

});

describe('addToBag', () => {
  const mockUpdateCartCount = jest.fn();
  global.window = {};
  global.window._header = {};
  global.window._header.updateCartCount = mockUpdateCartCount;

  utils.__clearData();
  const callback = jest.fn();
  const mockAccessTokenValue = 'mock-token';
  utils.__setAccessToken(mockAccessTokenValue);
  const mockOriginalStoredCart = '["92599202|1030732|1|false|-1|-1|false|-1","93270601|1037968|2|false|-1|-1|false|-1"]';
  //utils.putInLocalStorage('skBag', mockOriginalStoredCart);
  utils.setCookieValue('skBag', mockOriginalStoredCart);

  const cartUrl = '/api/v1/cart';
  const obcData = require('./ocb-data2.json');

  const getAjaxConfigMapping = {
    url: cartUrl,
    method: 'GET',
    returnData: obcData
  }
  const postAjaxConfigMapping = {
    url: cartUrl,
    method: 'POST',
    returnData: {testReturnData: true}
  }

  $.__clearAjaxConfigMappings();
  $.__addAjaxConfigMappings(getAjaxConfigMapping);
  $.__addAjaxConfigMappings(postAjaxConfigMapping);

  debugger;
  const skuCode = '93224050', webID = '1176404', quantity = 4;
  cartHelper.addToBag(callback, skuCode, webID, quantity);

  it('should invoke loader', () => {
    expect(utils.showLoader).toHaveBeenCalled();
  });

  it('should call window._header.updateCartCount with correct data', () => {
    // check the data passed to window._header.updateCartCount
    // see http://facebook.github.io/jest/docs/en/mock-functions.html#mock-property
    // for the structure of the mock.calls 2-dimensional array
    const updateCartItems = mockUpdateCartCount.mock.calls[0][0];
    // 2 items were originally in ocb-data2.json, and we added one more
    //console.log('updateCartItems: ' + JSON.stringify(updateCartItems))
    expect(updateCartItems.length).toEqual(3);
  });

  it('should make correct Get Cart call to backend', () => {
    const expectedAjaxGetConfig = {
      url: cartUrl,
      method: 'GET',
      contentType: 'application/json',
      headers: {'Accept': 'application/json', 'access_token': mockAccessTokenValue}
    }
    expect($.ajax).toBeCalledWith(expectedAjaxGetConfig);
  });


  it('should set the correct local cart value cart value in local storage ', () => {
    const putInLSCalls = utils.putInLocalStorage.mock.calls;
    //get all local storage put calls for key=skBag
    const skBagCalls = putInLSCalls.filter(args => args[0] === 'KOHLS-BAG');
    const lastSkBagCall = skBagCalls[skBagCalls.length - 1];
    // get the second param (value)
    const lastSavedSkbagVal = JSON.parse(lastSkBagCall[1]);
    expect(lastSavedSkbagVal.length).toBe(3);
    const sku93224050Items = lastSavedSkbagVal.filter(bagItem => bagItem.skuCode === skuCode);
    expect(sku93224050Items.length).toBe(1);
    expect(sku93224050Items[0].quantity).toBe(4);
  });


});
