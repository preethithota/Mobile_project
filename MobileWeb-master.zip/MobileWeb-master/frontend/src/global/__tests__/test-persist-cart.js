import * as cartHelper from '../cart-helper';
import * as utils from '../utils';

jest.mock('../utils');

// cartItemID: 1601003312, cartItemID: 1601003314
describe('updateLocalCartItemID ', () => {
  const localCartEntries = [];
  localCartEntries[0] = cartHelper.normalizeCartEntry({
    skuCode: '92599202',
    webID: '1030732',
    quantity: '1',
    isGift: false,
    registryID: '',
    collId: '',
    isBopusItem: false,
    storeNum: ''
  });
  localCartEntries[1] = cartHelper.normalizeCartEntry({
    skuCode: '93270601',
    webID: '1037968',
    quantity: '2',
    isGift: false,
    registryID: '',
    collId: '',
    isBopusItem: false,
    storeNum: ''
  });

  it('should correctly update the local cartItemIDs ', () => {
    const ocbData = require('./ocb-data2.json');
    debugger;
    const updatedLocalCart = cartHelper.updateLocalCartItemIDs(localCartEntries, ocbData.payload.cart);
    expect(updatedLocalCart.length).toBe(2);

    const sku92599202 = updatedLocalCart.filter(entry => entry.skuCode === '92599202');
    expect(sku92599202.length).toBe(1);
    expect(sku92599202[0].cartItemID).toBe('1601003312');

    const sku93270601 = updatedLocalCart.filter(entry => entry.skuCode === '93270601');
    expect(sku93270601.length).toBe(1);
    expect(sku93270601[0].cartItemID).toBe('1601003314');

    // utils.__clearData();
    // utils.__disableLS();
    // cartHelper.persistLocalCart(localCartEntries);
    //expect(utils.setCookieValue).toBeCalledWith(storedLocalBagKey, strLocalCartEntries);
  });
});


describe('persistLocalCart', () => {

  const localCartEntries = [];
  localCartEntries[0] = cartHelper.normalizeCartEntry({
    skuCode: '93270601',
    webID: '2539706',
    quantity: '2',
    isGift: false,
    registryID: '',
    //collId: '456',
    isBopusItem: true,
    storeNum: '789'
  });
  localCartEntries[1] = cartHelper.normalizeCartEntry({
    skuCode: '93270601',
    webID: '1037968',
    quantity: '20',
    isGift: false,
    registryID: '',
    //collId: '789',
    isBopusItem: false,
    storeNum: ''
  });

  const strLocalCartEntries = JSON.stringify(localCartEntries);
  const storedLocalBagKey = 'KOHLS-BAG';
  //const expectedLegacyCartString = '["93270601|2539706|2|false|-1|456|true|789","93270601|1037968|20|false|-1|789|false|-1"]';
  const expectedLegacyCartString = '["93270601|2539706|2|false|-1|-1|true|789","93270601|1037968|20|false|-1|-1|false|-1"]';

  it('should properly persist cart to local storage', () => {
    utils.__clearData();
    cartHelper.persistLocalCart(localCartEntries);
    expect(utils.putInLocalStorage).toBeCalledWith(storedLocalBagKey, strLocalCartEntries);
    expect(utils.setCookieValue).toBeCalledWith('skBag', expectedLegacyCartString);
  });

  it('should fall back to cookie if local storage is unavialble', () => {
    utils.__clearData();
    utils.__disableLS();
    cartHelper.persistLocalCart(localCartEntries);
    expect(utils.setCookieValue).toBeCalledWith(storedLocalBagKey, strLocalCartEntries);
  });

});
