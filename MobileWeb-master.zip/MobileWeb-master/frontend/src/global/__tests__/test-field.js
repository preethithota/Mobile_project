import Field from '../field';

describe('Field', () => {
  it('should be a valid class', () => {
    const id = '123', type = 'email', value = 'joe@example.com';
    const field1 = new Field(id, type, value);
    expect(field1.getId()).toEqual(id);
    expect(field1.getType()).toEqual(type);
    expect(field1.getValue()).toEqual(value);
  });

});
