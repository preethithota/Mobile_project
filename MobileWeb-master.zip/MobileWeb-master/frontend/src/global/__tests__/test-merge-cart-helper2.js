import * as mergeCartHelper from '../merge-cart-helper';

describe('mergeLocalCartWithOcb', () => {
  it('should not remove items in local cart', () => {
    const ocbCartData3 = require('./ocb-data3.json');
    const localEntries = [{"isGift":"false","registryID":"-1","collId":"-1","isBopusItem":"false","storeNum":"-1","skuCode":"94704803","webID":"1603669","quantity":1}];
    const mergedEntries = mergeCartHelper.mergeLocalCartWithOcb(ocbCartData3, localEntries).allEntries;
    expect(mergedEntries.length).toEqual(7);

    const sku94704803 = mergedEntries.filter(entry => entry.skuCode === '94704803');
    expect(sku94704803.length).toBe(1);
    expect(sku94704803[0].quantity).toBe(1);
  });
});
