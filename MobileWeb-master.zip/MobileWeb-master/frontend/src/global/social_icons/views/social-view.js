import React from 'react';

export default React.createClass({
	
	render: function(){
    	var props = this.props;
    	var eventHandlers = this.props.eventHandlers;
		let socialIcons = '';
			if (!props.isTcom) {
			socialIcons = (
				<ul id='mcom-social-items' className="mcom-social-items">
					<li id="mcom-social-fb" className="mcom-social-item" alt="facebook">
						<a href="#" id="share_FB" rel="noopener" onClick={eventHandlers.shareItem} className="mcom-social-share js-social-launch" name="Facebook" role="button" aria-label="Facebook"></a>
					</li>
					<li id="mcom-social-twitter" className="mcom-social-item"  alt="twitter">
						<a href="#" rel="noopener" id="share_Twitter" onClick={eventHandlers.shareItem} className="mcom-social-share js-footer-launch-corporate" name="Twitter" role="button" aria-label="Twitter"></a>
					</li>
					<li id="mcom-social-pinterset" className="mcom-social-item"  alt="pinterset">
						<a href="#" id="share_Pinterest" onClick={eventHandlers.shareItem} onClick={eventHandlers.shareItem} rel="noopener" className="mcom-social-share js-footer-launch-corporate" name="PinIt" role="button" aria-label="Pinterest"></a>
					</li>
					<li id="mcom-social-email" className="mcom-social-item" alt="email">
						<a href="#" rel="noopener" id="share_Email" onClick={eventHandlers.shareItem} className="mcom-social-share js-footer-launch-corporate" name="E-mail" role="button" aria-label="Email"></a>
					</li>
					<li id="mcom-social-google" className="mcom-social-item" alt="google">
						<a href="#" id="share_Google" onClick={eventHandlers.shareItem} className="mcom-social-share js-footer-launch-corporate" name="Google" role="button" aria-label="Google plus"></a>
					</li>
				</ul>
			);
		}
		else{
			socialIcons = (<div id="social-tcom-container" className={(props.isShare) ? '' : 'display-none'}>
				<ul id="pdp-share-container">
					<li id="tcom-pdp-shareFb" className="tcom-social-item">
					<a href="#" id="share_FB" rel="noopener" onClick={eventHandlers.shareItem} className="mcom-social-share js-social-launch tcom-social-share" name="Facebook" role="button" aria-label="Facebook"></a>
					</li>
					<li id="tcom-pdp-sharePin" className="tcom-social-item">
					<a href="#" id="share_Pinterest" onClick={eventHandlers.shareItem} onClick={eventHandlers.shareItem} rel="noopener" className="mcom-social-share js-footer-launch-corporate tcom-social-share" name="PinIt" role="button" aria-label="Pinterest"></a>
					</li>
				</ul>
				</div>);
		}
		
		return socialIcons;			
	}
});
