import React from 'react';
import SocialView from '../views/social-view';
import {setSocailShareOmniture} from '../../../../public/lib/omniture-util';

export default React.createClass({
	init:function()
	{
		//configurable properties.

        this.fbShareUrl = kohlsData.fbShareUrl || "";
        this.twiterShare = kohlsData.twiterShare || "";
        this.pinterestUrl = kohlsData.pinterestUrl || "";
        this.googlePlus = kohlsData.googlePlus || "";
        this.googleTinyUrl = kohlsData.googleTinyUrl + kohlsData.googleAPIKey || "";        

        this.twitterText = "I love this item I found on Kohls.com.Check it out";
        this.googleText = "I love this item I found on Kohls.com ";
        this.emailText = "I love this item I found on Kohls.com ";

	},
	getInitialState: function(){

		return {
			isShare:false
		};
	},

	eventHandlers: function(){
			return {

			//toggle share overlay
			shareProduct: function(e){
				e.preventDefault();
				this.setState({isShare: true});
			}.bind(this),

			//share product details to particular social media
			shareItem: function(e){
				e.preventDefault();
				this.productSocialShare(e.target);
			}.bind(this)

		}
	},

	componentDidMount: function(){		
		document.addEventListener('click', (e)=>e.target.id != 'tcom-share-product' && this.setState({isShare: false}), false);
		this.fbShareAction();
		this.init();
	},

	/*	
	prarams(Element:object) : element is required to process the corrsponding social media and share the product details.
	descriptionL : fetching corrasponding social media details.
	*/
	productSocialShare: function(element) {
        
        var pdtImageUrl = '', pdtTitle = '', pdtId = '', shareType = '', shareId = element.getAttribute("id"), url = "";
		var product = this.props.data.payload.products[0];             
        var domainName = location.host;          
        shareType = (element.getAttribute("name") ? element.getAttribute("name") : "");
        pdtTitle = product.productTitle;
		pdtImageUrl = product.images[0].url;
        pdtId = product.webID;        
		var currentWebUrl = product.productURL;
        var titleTxt = (escape(pdtTitle));    
		var webUrl = product.productURL;
        var shareUrl = this.fbShareUrl + "entry_label1=" + titleTxt + "&entry_itemurl1=" + encodeURIComponent(pdtImageUrl) + "&webUrl=" + encodeURIComponent(webUrl);
        var configParams = {
            shareUrl: shareUrl,
            currentWebUrl: currentWebUrl,
            pdtTitle: pdtTitle,
            pdtImageUrl: pdtImageUrl,
            pdtId: pdtId,
            webUrl: webUrl
        };
        this.shareItem(shareId, configParams);
    },

	/*	
	prarams(Element:object) : element is required to process the Facebook media and share the product details.
	prarams(data:object) : configurblbe data with respective product details.
	descriptionL : send the respective product details to Facebook media .
	*/
	fbShareAction:function (element, data) {
    var details = data || {};    
    details.appId = typeof kohlsData !== "undefined" && kohlsData.faceBookID;    
    if (!details.appId) {
        return
    }
    switch (element) {
    case 1:
        var o = details.URL
          , i = {
            method: "stream.publish",
            message: "",
            attachment: {
                name: details.title,
                description: details.description,
                href: o,
                media: [{
                    type: "image",
                    src: details.img,
                    href: o
                }]
            }
        };
        FB.ui(i, function(e) {
            //DBGLOG("shared in Facebook")
        });
        break;
    	default:
        window.fbAsyncInit = function() {
            FB.init({
                appId: details.appId,
                status: true,
                cookie: true,
                xfbml: true,
                oauth: true
            })
        };
        
        if ($("#fb-root").length == 0) {
            $('<div id="fb-root"/>').prependTo("body")
        }
        (function(e) {
            var ele, facebook = "facebook-jssdk", script = e.getElementsByTagName("script")[0];
            if (e.getElementById(facebook)) {
                return
            }
            ele = e.createElement("script");
            ele.id = facebook;
            ele.async = true;
            ele.src = "//connect.facebook.net/en_US/all.js";
            script.parentNode.insertBefore(ele, script)
        })(document)
    }
},

/*	
	descriptionL : this is to determine the version of Iphone or iPod.
*/
iOSversion:function() {
    try {
        if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i))) {
            var match = navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
            return [parseInt(match[1], 10), parseInt(match[2], 10), parseInt(match[3] || 0, 10)]
        }
    } catch (error) {
        console.log(error)
    }
},

/*	
	prarams(shareId:number) : share id is required to provide relevant id to corresponding media.
	prarams(configParams:object) : product details.
	descriptionL : send the respective product details to respective media.
*/
shareItem: function(shareId, configParams) {
		var _this = this;     
		var shared_domain; 
        var afterGetTiny = function(shareTinyUrl) {
            if (shareId == "share_FB") {
                var fbConfig = {
                    "title": "Kohl's",
                    "description": configParams.pdtTitle,
                    "img": configParams.pdtImageUrl,
                    "URL": location.href
                };
                _this.fbShareAction(1, fbConfig);
				shared_domain="Facebook";
            } else if (shareId == "share_Pinterest") {               
                configParams.shareUrl = _this.pinterestUrl + encodeURIComponent(location.href) + "&description=" + encodeURIComponent(configParams.pdtTitle) + "&media=" + encodeURIComponent(configParams.pdtImageUrl);
				shared_domain="Pinterest";
            } else if (shareId == "share_Twitter") {
                configParams.shareUrl = _this.twiterShare + encodeURIComponent(shareTinyUrl) + "&text=" + _this.twitterText;
				shared_domain="Twitter";
            } else if (shareId == "share_Google") {
                var ua = navigator.userAgent.toLowerCase();
                var url = "sms:";
                var version = _this.iOSversion();
				url += (ua.indexOf("iphone") > -1) ?( version && version[0] && version[0] > 7 ? "&" : ";" ): "?";
                url += "body=" + encodeURIComponent(_this.googleText + location.href);
                location.href = url;
				shared_domain="Google plus";
            } else if (shareId == "share_Email") {
                location.href = "mailto:?body=" + encodeURIComponent(_this.emailText + location.href);
				shared_domain="Email";
            }
            if (shareId != "share_Email" && shareId != "share_FB" && shareId != "share_Google") {
                var isPopupOpen = window.open(configParams.shareUrl, "_blank");
                if (!isPopupOpen) {
                    alert('Please turn off "Block pop up" setting to proceed further.');
                }
            }
        };
        if (shareId == "share_Twitter") {
            this.getTinyUrl(location.href, afterGetTiny);
        } else {
            afterGetTiny();
        }    
		setSocailShareOmniture(shared_domain);
    },

	/*	
		prarams(url:URL) : url is required to get shorten.
		prarams(cbk:Function) : callback function to be triggered after receiving result.
		descriptionL : send the respective product details to respective media.
	*/
    getTinyUrl: function(url, cbk) {
        $.ajax({
            url: this.googleTinyUrl,
            contentType: "application/json",
            type: 'POST',
            data: JSON.stringify({
                "longUrl": url
            }),
            success: function(response) {
                if (response && response.id && cbk) {
                    cbk(response.id);
                } else {
                    console.log("Fn getTinyUrl: error in getting tiny URL");
                }
            },
            error: function(response) {
                if (cbk) {
                    console.warn("Fn getTinyUrl call failed");
                }
            }
        });
    },

  render(){
		return <SocialView {...this.props} {...this.state} eventHandlers={this.eventHandlers()}/>;
  }
});
