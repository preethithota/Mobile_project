import React from 'react';
import AddToRegistryView from './add-to-registry-view';
import * as registryHelper from './registry-helper';

export default class AddToRegistryContainer extends React.Component{

  constructor(props){
    super(props);
    this.state = {
      registryData: null,
      selectedList: null,
      showSelectionModal: true,
      showCreateListModal: ( this.props.showCreateListModal ) ? true :false,
      defaultListNameValue:'My Kohl\'s List',
      listNameValue: 'My Kohl\'s List',
      showSuccess:false,
      isPublicChecked: true,
      errorMessage: null,
      isCreateListSuccess: false
  }
    this.closeModal = this.closeModal.bind(this);
    this.setRegistryData = this.setRegistryData.bind(this);
    this.success = this.success.bind(this);
    this.displayError = this.displayError.bind(this);
    this.addToList = this.addToList.bind(this);
    this.createNewList = this.createNewList.bind(this);
    this.eventHandlers = this.eventHandlers.bind(this);
    this.hamburgerCreateListSuccess = this.hamburgerCreateListSuccess.bind(this);
    this.hamburgerCreateListCloseModal = this.hamburgerCreateListCloseModal.bind(this);
  }
  closeModal(){
    if(this.state.isAdding)
        return false;
    registryHelper.unMountRegistryModal();
    document.body.classList.remove("modal-overlay");
  }
  setRegistryData(Data){
    this.setState({registryData: Data});
  }

  success(){
    document.body.classList.remove("modal-overlay");
    this.setState({
      showSelectionModal:false,
      isAdding: false,
      showSuccess:true
    })
  }

  displayError(data){
    console.info(data);
    this.setState({
      errorMessage: data.responseMessage
    });
  }

  hamburgerCreateListSuccess() {
    this.setState({
      isCreateListSuccess: true,
      showCreateListModal: false
    });
  }

  hamburgerCreateListCloseModal() {
    this.setState({
      isCreateListSuccess: false
    });
    registryHelper.unMountRegistryModal();
  }

  addToList(listName, listId, registryType){
    let _this = this;
    this.setState({
      selectedList: listId,
      isAdding: true
    });
    var productInfo = this.props.selectedProductInfo;
    //Item color and size added. TODO: Add if more configurable options are available.
    const ListPayLoad = {
      "itemType":"SKU",
      "itemId":productInfo.selectedSkus[0].skuCode,
      "itemProductId":productInfo.webID,
      "productCode":productInfo.webID,
      "upcCode":productInfo.selectedSkus[0].UPC.ID,
      "itemSize":(productInfo.selectedSkus[0].size) ? productInfo.selectedSkus[0].size: null,
      "itemColor": (productInfo.selectedSkus[0].color) ? productInfo.selectedSkus[0].color : null,
      "priceWhenCreated":1,
      "wantedQty":this.props.inputQuantity.inpQuantity,
      "priority":"1",
      "collectionsProdId":productInfo.webID,
      "collectionsProdCode":productInfo.webID,
      "listId":listId,
      "listType": this.props.listType,
      "listName" : listName,
      "registryType" : registryType
    };
    registryHelper.addToList(ListPayLoad, _this.success, _this.displayError);
  }
  createNewList(){
    let _this = this;
    let productInfo = this.props.selectedProductInfo;
    const payLoad ={
      'listName': this.state.listNameValue,
      'listType': 'wishlist',
      'budget':'',
      'listEventDate':'',
      'isPublic':this.state.isPublicChecked,
      'emailOptIn': false,
    }
    //createNewList From PDP
    if(productInfo && productInfo.selectedSkus[0]) {
      registryHelper.createNewList(payLoad, _this.addToList, _this.displayError);
    } else {
      //createNewList From Menu
      registryHelper.createNewList(payLoad, _this.hamburgerCreateListSuccess, _this.displayError);
    }
  }
  componentDidMount(){
    var _this = this;
    document.body.classList.add("modal-overlay");
    registryHelper.getListData(_this.props.listType, _this.setRegistryData);
  }
  eventHandlers() {
    var _this = this;
    return {
      selectList: function(_list){
        try{
          let _registryType = _list.type == "registry" ? _list.registryProperties.properties.regtype : '';
          _this.addToList(_list.listName, _list.listId, _registryType);
        }
        catch(e){
          console.log('exception in add product to list/registry-'+ e);
        }
      }.bind(this),
      createNewRegistry: function(e,listType){
        switch(listType){
          case "LIST":
            this.setState({
              showCreateListModal:true
            });
            break;
          case "REGISTRY":
          var currentLocation = window.location.href;
          window.location = '/upgrade/gift_registry/kohlsgrw_home.jsp?section=mylists&action=createregistry&redirecturl='+currentLocation;
            break;
        }
      }.bind(this),
      handleClose: function(e){
        _this.closeModal();
      }.bind(this),
      handleCreateListKeypress:function(event){
        this.setState({listNameValue: event.target.value });
      }.bind(this),
      handleCreateListInputBlur:function(event){
        this.setState((prevState)=>{
          return { listNameValue: prevState.listNameValue.trim() === '' ? prevState.defaultListNameValue: prevState.listNameValue }
        })
      }.bind(this),
      hideSuccess:function(){
        setTimeout(()=>{
          registryHelper.unMountRegistryModal();
        }, 5000);
      }.bind(this),
      handleCheckBox: function(){
        this.setState((prevState)=>{
          return {isPublicChecked: !prevState.isPublicChecked }
        });
      }.bind(this),
      handleFocus:function(e){
        this.setState((prevState)=>{
          return { listNameValue: event.target.value === prevState.defaultListNameValue ? '': event.target.value }
        });
      }.bind(this),
      createList: function(){
        this.setState({
          errorMessage: null,
        });
        _this.createNewList();
      }.bind(this),

      handleCloseSuccessModal: function() {
        _this.hamburgerCreateListCloseModal();
      }.bind(this),

      handleCloseBtnNavigation: function(e) {
        var btnName = e.target.id;
        if(btnName =='seeList') {
          window.location.href="/upgrade/giftinglisting/wishlist.jsp?section=mylists";
        } else if(btnName =='keepSharing'){
          _this.hamburgerCreateListCloseModal();
        }
      }
    }
  }
  render(){
    return <AddToRegistryView {...this.props} {...this.state} eventHandlers={this.eventHandlers()}/>
  }
}
