import React from 'react';
import {labels} from '../../global/label-utils.js';

export default class AddToRegistryModalView extends React.Component{

  render(){
    const props = this.props;
    const registryData = props.registryData;
    const eventHandlers = props.eventHandlers;
    var modalContent;
    if( !(props.isAdding || props.showCreateListModal  || props.isCreateListSuccess) ){
      modalContent = (<div className="content-wrapper">
         <div className="label">My { (props.listType === "LIST") ? 'List':'Registry' }</div>
         <div className="registryData">
         <div className="item" onClick={(e) => eventHandlers.createNewRegistry(e, props.listType) }>Create a new { (props.listType === "LIST") ? 'List':'Registry' }</div>
          {registryData && registryData.lists.map(list => {
            return (
              <div className="item" key={list.listId} onClick={(e) => eventHandlers.selectList(list)}>
                {list.listName} {(list.isNew) ? <span className="new-label">New</span>:'' }
              </div>)
            })
      }
          </div>
        </div>
      )
    }else if(props.showCreateListModal){
      modalContent = (
        <div className="create-list-container">
          <div className="close-button" onClick={(e) => eventHandlers.handleClose(e)}><img src="/images/close_g_btn.png" title="" alt="Loading..." action="1" /></div>
          <div className="create-name-label">{labels.createListName}</div>
          <div className="info-message create-name">{labels.requiredLabel}</div>
          { ( props.errorMessage ) ? <div className="error-msg"><span className="error-image"><input type="image" src="/images/transparent.png"/></span><span>{ props.errorMessage}</span></div> : ''}
          <div className="list-name-wrapper">
            <label><input type="text" className="list-name" maxLength="40" value={props.listNameValue} onFocus={(e)=> eventHandlers.handleFocus(e)} onBlur={(e)=>eventHandlers.handleCreateListInputBlur(e)} onChange={(e)=>eventHandlers.handleCreateListKeypress(e)}/><font>*</font></label>
              <div className="info-message">{labels.listNameLikeMessage}</div>
          </div>
          <div className="make-list-public-wrapper">
            <label onClick={(e)=>eventHandlers.handleCheckBox(e)}><input type="image" className={props.isPublicChecked ? 'checkbox selected':'checkbox'} src="/images/transparent.png"/>{labels.makeThisPublic}</label>
            <div className="info-message">{labels.makeThisPublicMessage}</div>
          </div>
          <div className="btn-wrapper"><input onClick={(e)=> eventHandlers.createList(e)} src="/images/m_done_btn.png" type="image" title="" className="btn done_btn" alt="Create New List" value="Create New List" /></div>
        </div>
        )
    }else if(props.isAdding ){
      modalContent = (
        <div className="adding-to-list">
        <span className="loader"><img src="/images/loader.gif" alt="Loading.."/></span>
        <span className="label">{labels.addingItemToList}</span>
        </div>
      )
    }else if(props.isCreateListSuccess){
      modalContent = (
        <div className="create-succeess-container">
          <div className="close-button" onClick={(e) => eventHandlers.handleCloseSuccessModal(e)}><img src="/images/close_g_btn.png" title="" alt="Close" /></div>
          <div className="create-name-label">{labels.success}</div>
          <div className="create-succeess-msg">{labels.listSuccessMsg(props.listNameValue)}</div>
          <div className="btn-wrapper">
            <button className="btn-see-list" id="seeList" onClick={(e) => eventHandlers.handleCloseBtnNavigation(e)}>{labels.seeList}</button>
            <button className="btn-keep-sharing" id="keepSharing"onClick={(e) => eventHandlers.handleCloseBtnNavigation(e)}>{labels.keepShop}</button>
            <div className="clear"></div>
          </div>
        </div>
        )
    }
    return (
      <div id="add-to-registry">
      <div className="registry-modal-wrapper " onClick={(e) => eventHandlers.handleClose(e)} >
       </div>
        <div className={ props.showCreateListModal ? 'create-list-modal registy-modal':'registy-modal'}>
        { modalContent }
        </div>
     </div>
    )
  }
}
