import React from 'react';
import AddToRegistryModalView from './add-to-registry-modal-view.js';
require('../css/add-to-registry.css'); //css styles include for registry&list 

class Successview extends React.Component{
	render(){
	return (
			<div className="successWrapper">
				<div>Item added to your List successfully</div>
			</div>
		)
	};
}

export default class AddToRegistryView extends React.Component{
  render(){
    const props = this.props;
    const registryData = props.registryData;
    const eventHandlers = props.eventHandlers;
    if(props.showSuccess){
      eventHandlers.hideSuccess();
    }
    return (<div className="add-to-registry">
    	{ props.showSelectionModal && <AddToRegistryModalView {...props} /> }
    	{ props.showSuccess && <Successview /> }
    	</div>)

  }
}
