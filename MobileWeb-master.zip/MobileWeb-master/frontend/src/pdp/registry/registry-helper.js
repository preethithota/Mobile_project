/**
*This file contains helper functions for the Add to Registry/List module.
*This does not work in the localhost:8080 environment as cross domain requests are not allowed.
*TODO: Change the Endpoints to the required endpoints when migrating to a different domain.
**/

/* TODO: Change when migrating to a diffrent envt. */
const services = {
	'getProfile':'/skavastream/xact/v5/kohls/profile/get',
	'getLists':'https://kd50.km.sl.edst.ibm.com/kohls/showListsWithItems?numLists=50&numItems=0',
	'getRegistry':'https://kd50.km.sl.edst.ibm.com/registry/showListsWithItems?listType=registry&numLists=300&numItems=3&includeFulfillments=true',
	'addToListPost':'https://kd50.km.sl.edst.ibm.com/kohls/addItemsToList',
	'addToRegistryPost':'https://kd50.km.sl.edst.ibm.com/registry/addItemsToList',
	'createListPost':'https://kd50.km.sl.edst.ibm.com/kohls/createList'
}
import * as utils from '../../global/utils.js';//Import utils to check login status etc..,
import $ from 'jquery';// Import jquery to avoid compiler errors.
import {setAddtoRegistryOmniturePDP, setAddtoListOmniturePDP} from '../../../public/lib/omniture-util';

const  addToRegistryContainerId = 'add-to-registry-container';
let profilePayload;
export function showRegistryModal(listType, _props){
	require(['./add-to-registry-container.js'], (containerImport) => {
    	const AddToRegistryContainer = containerImport.default;
    	ReactDOM.render((
        	<AddToRegistryContainer listType={listType} {..._props} />
    		), document.getElementById(addToRegistryContainerId));
	});
}

export function unMountRegistryModal(){
	  ReactDOM.unmountComponentAtNode(document.getElementById(addToRegistryContainerId));
}

export function getListData(listType, setRegistryCallback){
	getProfileWithChecksum(listType, getListAsync, setRegistryCallback);
}

//Gets the profile details along with the checksum needed for the list/registry services.
/**
*Gets the profile details from the skavastream API if its already not available and calls the next fn with payLoad, listDetails and callbacks as arguments.
**/
export function getProfileWithChecksum( listDetails, next, successcallback, failureCallback){
	if(profilePayload){
		next(profilePayload, listDetails, successcallback, failureCallback);
	}else{
		var tokenCache = utils.getCookieValue("accessToken");
		var headers = {'Accept': 'application/json'};
		if (tokenCache !== null &&  tokenCache !== undefined){
			headers.access_token = tokenCache
		}
		$.ajax({
			url: services.getProfile,
			method: 'GET',
			contentType: 'application/x-www-form-urlencoded',
			headers: headers
		})
		.then((profileData)=>{
			profilePayload = {
				"retailerUserId": getProfileId(),
				"firstName": profileData.properties.userinfo[0].firstname,
				"lastName":profileData.properties.userinfo[0].lastname,
				"email":profileData.properties.userinfo[0].email,
				"checkSum": JSON.parse(profileData.properties.userinfo[0].hash).hash
			}
			next(profilePayload, listDetails, successcallback, failureCallback);
		})
		.fail((error)=>{
				console.error("Error getting list details",error);
		});
}

}
//Get the user profile ID.
export function getProfileId(){
	return utils.getCookieValue("profileId");
}
/**
*Gets the List/Registry Data from the skavaone services.
**/
export function getListAsync(profileData, listType, setRegistryCallback, failureCallback){
	$.ajax({
	type: "POST",
	url: (listType === "LIST" )? services.getLists : services.getRegistry,
	data: {
		'loggedInUser': JSON.stringify(profileData)
	},
	dataType: 'json',
	headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
	})
	.then((response)=>{
		setRegistryCallback(response);
	})
	.fail((error)=>{
		console.error("Error getting list details",error);
	});
}

export function addToList(listPayLoad, successCallback, failureCallback){
	getProfileWithChecksum(listPayLoad, addToListPost, successCallback, failureCallback);
}

export function createNewList(listPayLoad, successCallback, failureCallback){
	getProfileWithChecksum(listPayLoad, createNewListPost, successCallback, failureCallback );
}

export function addToListPost(profilePayload, listPayLoad, successCallback, failureCallback){
	const _listType = listPayLoad.listType;
	const _listName = listPayLoad.listName;
	const _registryType = listPayLoad.registryType;
	const _listId = listPayLoad.listId;
	const url = listPayLoad.listType === "LIST" ? services.addToListPost : services.addToRegistryPost;
	delete listPayLoad.listType;//Delete listType as its not required for the request body.
	delete listPayLoad.listName;//Delete listName as its not required for the request body.
	delete listPayLoad.registryType;//Delete registryType as its not required for the request body.
	$.ajax({
	type: "POST",
  	url: url,
  	data: {
		loggedInUser: JSON.stringify(profilePayload),
		listItem: JSON.stringify(listPayLoad)
	},
	dataType: 'json',
  	headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
	})
	.then((response)=>{
		if(response.responseCode === 0){
				//trigger omniture for List/Registry (refer:-MRP-1275 & MRP-1273)
				if(_listType == "REGISTRY"){
					setAddtoRegistryOmniturePDP(_registryType, _listId);
				}
				if(_listType == "LIST"){
					setAddtoListOmniturePDP(_listName);
				}
	  		successCallback();
	  	} else {
	  		failureCallback(response);
			}
	})
	.fail((error)=>{
		console.error("Error getting list details",error);
		failureCallback(error);
	});
}
/**
*Posts the new list Data to the skavaone create list API..
**/

export function createNewListPost(profileData, listPayLoad, successCallback, failureCallback){
	var query = $.param(listPayLoad);
	$.ajax({
	type: "POST",
  	url: services.createListPost+'?'+query,
  	data: {
  		'loggedInUser': JSON.stringify(profileData)
  	},
	dataType: 'json',
  	headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
	})
	.then((response)=>{
	  		if(response.responseCode === 0)
	  		successCallback(response.wishList.listId);
	  	else
	  		failureCallback(response);
	})
	.fail((error)=>{
		console.error("Error getting list details",error);
		failureCallback(error);
	});
}
