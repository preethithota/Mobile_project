import React from 'react';
import * as pdpHelper from './pdp-helper';

export default React.createClass({
	getInitialState: function(){
		return {
			offer: {}
		}
	},
	componentDidMount: function(nextProps){
		var _this = this;

		var successCallback = function(data){
			_this.setState({offer:data});

			var offerAddtoBagInfo = {};

			try{
				const productOffer = data.payload && data.payload.products[0].productOffers[0];

				offerAddtoBagInfo['offerWebID'] = productOffer.offerProducts[0].id;
				offerAddtoBagInfo['offerType'] = productOffer.offerGroups[0].groupType;
				offerAddtoBagInfo['offerEligibility'] = productOffer.offerGroups[0].offerPriceEligible;

				// Checking Offers SKUS
				productOffer.offerProducts && productOffer.offerProducts.length == 1 && productOffer.offerProducts[0].skus.length == 1 && (
					offerAddtoBagInfo['isSingleSku'] = true,
					offerAddtoBagInfo['skuCode'] = productOffer.offerProducts[0].skus[0].skuCode
				);
			} catch(e) {
				console.log('Exception in Offers Data' +e);
			}

			_this.props.callbackOffers(offerAddtoBagInfo);
		};

		var errorCallback = function(err){
			console.log('err')
		};

		pdpHelper.getOffers(true, this.props.prdId, errorCallback, successCallback);
	},
	render: function(){
		var offersMsg='', offerPrc='', offers=[];
		const productOffer = this.state.offer.payload && this.state.offer.payload.products[0].productOffers[0];
		offers = productOffer && productOffer.offerProducts || [] ;

		if(productOffer){
			for (var msg in productOffer.conditionalMessages){
				if(productOffer.conditionalMessages[msg].key == 'OfferMessage'){
					offersMsg = productOffer.conditionalMessages[msg].value;
					if(productOffer.thresholdAmt !== undefined){
						offersMsg = offersMsg.replace("%amount", productOffer.thresholdAmt);						
					}
					else if(productOffer.thresholdQty !== undefined){
						offersMsg = offersMsg.replace("%amount", productOffer.thresholdQty);						
					}
					break;
				}
			}
		}

		return (
			<div className="pdp-offer">
				<div className="pdp-offer-GWP">
					<div className="pdp-GWP-Desc">{offersMsg}</div>

					<div id="pdp-offer-products" className="offer-products">{
						Array.apply(null, offers).map((item, index) => {
							return (
								<div className="product-offer" key={index}>
									<img className="offer-PDP-Image" src={item.images[0].URL} />

									<div className="product-info">
										<div className="product-title">{item.productTitle}</div>

										<p className="offer-price">{ parseInt(item.price.offerPrice.min) ? (
											kohlsData.isTcom ? (
												<span id="#tcom-pdp-offer" className="your-price">YOUR PRICE: ${item.price.offerPrice.min}</span>
											) : (
												<span id="#mcom-pdp-offer" className="your-price"><b>YOUR PRICE: ${item.price.offerPrice.min}</b></span>
											)
										) : (
											kohlsData.isTcom ? <span>Your Price: FREE</span> : <span>Your Price:<b id="pdp-price-free"> FREE</b></span>
										)}</p>

										{item.price.regularPrice && (
											<p className="original-price">
												{(item.price.regularPrice.indexOf("Original") != -1) ?
													<span className='original-amount'>value{item.price.regularPrice.split("Original")[1]}</span> :
													<span>Regular{item.price.regularPrice}</span>
												}
											</p>)}
									</div>
								</div>
							)
						})
					}</div>
				</div>
			</div>


		)
	}
});
