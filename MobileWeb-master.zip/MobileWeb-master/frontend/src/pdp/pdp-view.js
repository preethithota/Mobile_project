import React from 'react';
import * as utils from '../global/utils';
import {labels} from '../global/label-utils';
import Accordion from './accordion';
import SocialView from '../global/social_icons/container/social-container';
import ShopModel from './pdp-shop-model-view';
import QuantityView from './quantity/quantity-view';
import * as OffersHelper from './offers/offers-helper';
import OffersView from './offers/offers-view';
import AddtobagView from './addtobag/pdp-addtobag-view';
import {displayPrice} from './pdp-helper';

export default React.createClass({
	render: function(){
    	const props = this.props;
		const product = props.data.payload.products[0];
    	const eventHandlers = props.eventHandlers;
		const prodImgWidth = product.images[0].width;
		const stdCarouselItems = 7;

		let price = props.isConfigDone && props.selectedSkus && props.selectedSkus.length && props.selectedSkus[0].price ? props.selectedSkus[0].price : product.price;

		let priceObj = displayPrice(price);
 		const clsName = priceObj.isRedLabel ? "sale-price" : "blackLabel";
		const regPrice = priceObj.combainWithReg ? "or "+priceObj.regPrice+" each" : priceObj.regPrice;

		//let priceObj = displayPrice(pdpprice);
		//const clsName = priceObj.isRedLabel ? "sale-price" : "blackLabel";

		const salePriceMarkup = (priceObj.specialPrice) && (<div id="product-sale-price" className={clsName}>{priceObj.specialPrice}</div>);
		const salesPrice = product.price.salePrice && product.price.salePrice.match(/\//);
		//const origPriceMarkup = (product.price.regularPrice) ? (<div className={"orig-price "+(salesPrice && "group-price")}>{salesPrice?("or "+product.price.regularPrice+" each"):product.price.regularPrice}</div>) : '';
		const origPriceMarkup = (price.regularPrice) ? (<div className={"orig-price "+ (!salesPrice && price.promotion ? " group-price" : "")}>{regPrice}</div>) : '';
		let productImages = props.productImages;

		if(props.selectedSwatchImgUrl){
			productImages[0].url = props.selectedSwatchImgUrl;
		}


		{/* Product Image Counter Checking
			- Product Images = Main + Alternate images
			- Null Checking AND only for length > 1 */}

		const imageCounterMarkupMcom = productImages.length && (
			(productImages.length > 1) && (
				(productImages.length > stdCarouselItems) ? (
					<div className="img-count">{props.selectedImageIndex +1} OF {productImages.length}</div>
				) : (<ul className="carousel-dots">
						{productImages.map((image, index) => {
							return (

								<li key={index.toString()}
									data-key={"dot-" +index}
								 	className={(props.selectedImageIndex == index) ? "active-img" : ""}
									onClick = {props.eventHandlers.swipeImage}></li>
							)
						})}
					</ul>
				)
			)
		);

		let imageCounterMarkupTcom = productImages.length && (
			(!productImages.length < 1) && (
				(productImages.length > stdCarouselItems) ? (
					<div className="img-count">{props.selectedImageIndex +1} OF {productImages.length}</div>
				) : (<ul className="carousel-tiles">
						{productImages.map((image, index) => {
							return (
								<li key={index.toString()}><img src={image.url}
											data-key={"tile-" +index}
											className={(props.selectedImageIndex == index) ? "active-img" : ""}
											onClick = {props.eventHandlers.swipeImage} /></li>
							)
						})}
					</ul>
				)
			)
		);

		var showFisButton = true;
		let mainImageMarkup;
		var gwpMarkup;
		var gwpAccordionId;
		var gwpContentMarkup;
		var onlineImgMarkup;
		var pwpGetItemMarkup;

		const accordionMetaData = [{attributeKey: 'productDetails', title: 'Product Details'},
               {attributeKey: 'shippingAndReturn', title: 'Shipping & Returns'},
               {attributeKey: 'relatedInformation', title: 'Related Information'},
               {attributeKey: 'ingredients', title: 'Ingredients'},
               {attributeKey: 'careInstructions', title: 'Care Instructions'},
               {attributeKey: 'rebate', title: 'Rebates'},
			   {attributeKey: 'pricingDetails', title: 'Pricing Details'}];

		mainImageMarkup = (
			<div id="image-carousel" onClick={!props.isTcom && props.eventHandlers.productCarouselZoom}>
				{productImages.map((image, index) => {
					return (
						<div className="product-img" key={index}>
							<img id={"zoom-img-" +index} src={utils.getImageUrl(image.url, props.mainImgWidth, !image.rendered)}  onLoad={!index && props.handleImageLoaded} alt={image.altText}/>

						</div>
					)
				})}
			</div>
		);

		if(product.valueAddedIcons && product.valueAddedIcons.length > 0) {
			//value added icons to display
			let icons = product.valueAddedIcons.map(function(icon){
				var icon_id = icon.substr(icon.lastIndexOf('/')+1)
				icon_id = icon_id.replace('.gif','').trim();
				return icon_id;
			});

			//Priority order of badges
			let sortingOrder = ['bogo', 'warning', 'rebate', 'Online_Exclusive', 'morecolors', 'kohls-exclusive', 'buy', 'closeout','closeout-deal','final-call'];

			//sort value added icons based on priority
			icons.sort(function(icon1, icon2){
				icon1 = icon1 && icon1.split('_')[0].toLowerCase();
				icon2 = icon2 && icon2.split('_')[0].toLowerCase();
				return sortingOrder.indexOf(icon1) < sortingOrder.indexOf(icon2) ? -1 : 1;
			});

			//generate markup for valu added icons  <span onClick={props.eventHandlers.handleInfoSectionClick('acc-rebate')}>Learn more</span>
			if (icons[0] && icons[0].indexOf("rebate") > -1) {
				let icon = "url(" + icons[0] + ")";
				let rebateDes = product.rebate && product.rebate.shortDescription;
				onlineImgMarkup = (<div id="valueAddBlock" className="marginTop10">
					<div className="marginBtm10">{rebateDes}</div>
					<div className="valueAddedIcon1 rebate-icon">
						{/*<div className={'pdp-onlineOnlyCont'} id={icons[0]} style={{backgroundImage:icon}}></div>*/}
						<div className={'pdp-onlineOnlyCont'} id={icons[0]}></div></div>
						{
							<span onClick={() => props.eventHandlers.openAndFocusAccordion('acc-rebate')} className="learnMore mcom-only">Learn more</span>
						}

						{ icons[1] && <div className="valueAddedIcon2"><div className="pdp-onlineOnlyCont" id={icons[1]}></div></div>}

					</div>);
			} else if (icons[1] && icons[1].indexOf("rebate") > -1) {
				onlineImgMarkup = (<div id="valueAddBlock" className="marginTop10">
					<div className="valueAddedIcon1 rebate-icon">
						<div className={'pdp-onlineOnlyCont'} id={icons[0]}></div>
					</div>
					<div className="valueAddedIcon2">
						{ icons[1] && <div className="pdp-onlineOnlyCont" id={icons[1]}></div>}
						{<span onClick={() => props.eventHandlers.openAndFocusAccordion('acc-rebate')} className="learnMore mcom-only">Learn more</span>}
					</div>
					</div>);
			} else {
				onlineImgMarkup = (<div id="valueAddBlock" className="marginTop10">
					<div className="valueAddedIcon1">
						<div className={'pdp-onlineOnlyCont'} id={icons[0]}></div>
					</div>
					<div className="valueAddedIcon2">
						{ icons[1] && <div className="pdp-onlineOnlyCont" id={icons[1]}></div>}
					</div>
					</div>);
			}


			// if there is online only badge available then FIS button will not show
			for (var j=0; j<product.valueAddedIcons.length; j++) {
				if (product.valueAddedIcons[j].toLowerCase().indexOf('online') !== -1){
					showFisButton = showFisButton && false;
				}
			}
		}

		let pdp_reviews_view = (<div id="BVRRContainer"></div>);
		let pdp_qa_view = (<div id="BVQAContainer"></div>);

        let pdpTabItems = props.isTcom ? (<div id="pdp-tab-selection">
			<a id="pdp_reviews" href="#" onClick={props.eventHandlers.getPdpTabContent} className="pdp-tab selected">RATINGS & REVIEWS<span id="RRreview_count">(0)</span></a>
			<a id="pdp_qa" href="#" onClick={props.eventHandlers.getPdpTabContent} className="pdp-tab">Q&A</a>
		</div>) : "";
		let tabview = {"pdp_reviews":pdp_reviews_view,"pdp_qa":pdp_qa_view};
		var swatchMarkup;
		if(product.swatchImages && product.swatchImages.length > 0){
			var defaultSwatchLimit = 20;
			var toggleAllColorsMessage = (props.showAllColors) ? labels.hideMoreColors : labels.showMoreColors;
			var showToggleAllColors = (product.swatchImages.length > defaultSwatchLimit);
			swatchMarkup = (
				<div id="swatch-section">
					<h3>COLOR: <span>{props.selectedColor}</span></h3>
					<div id="swatches" className={(!props.showAllColors) ? 'limited-swatch-height' : ''}>
					{product.swatchImages.map((swatchImage, index) => {
						var swatchImgUrl = utils.getImageUrl(swatchImage.URL, 75, (index > (defaultSwatchLimit - 1) && !props.showAllColors));
						var available = (props.collection["productSizeCln-0"] === '' || (props.collection["colorAvl-productSizeCln-0"] ? props.collection["colorAvl-productSizeCln-0"][swatchImage.color] : swatchImage.color));
						var availablityImage = (available) ? '' : (<div className="swatch-unavailable"><img src="/images/swatch_unavailable.png" /></div>);
						return(
							<div className="swatch" key={index}>
								<a href="#" title={swatchImage.color +' color'} className={props.selectedColor == swatchImage.color ? "colr-selected" : ""} onClick={eventHandlers.handleSwatchClick}>
									<img className="swatch-img" data-color={swatchImage.color} data-url={swatchImgUrl} src={swatchImgUrl} />
								</a>
								{availablityImage}
							</div>
						)
					})}
					</div>

					<div id="show-all-swatches" className={(showToggleAllColors ? (props.showAllColors ? '' : 'showMore') : 'display-none')}>
						<a href="#" onClick={eventHandlers.toggleAllColors}>{toggleAllColorsMessage}</a>
					</div>
				</div>
			);
		}else{
			swatchMarkup = '';
		}

		var sizeInfoArr = props.sizes.map((size) => {
			var available = !!props.sizeAvailability[size];
			return {size: size, avail: available};
		});

		//var addToBagBtnEnabled = (props.selectedSwatchImgUrl && props.collection["productSizeCln-0"]) ? 'enabled': '';

		let addToBagBtnEnabled = (function(){
			let isColor = "",
				isSize = "";

			if(product.productStatus !=='Out of Stock') {
				isColor = (product.swatchImages.length > 1) && (props.selectedSwatchImgUrl ? "true" : "false")
				isSize = (sizeInfoArr.length > 1) && (props.collection["productSizeCln-0"] ? "true" : "false")

				if((isColor == "" || isColor == 'true') && (isSize == "" || isSize == 'true')){
					return "enabled";
				}
			}
		})();

		var styleGuideMarkup = '';
		if (product.styleGuide && product.styleGuide.sizeChartText){
			styleGuideMarkup = (
				<div id="style-guide-section">
					<h4 className="mcom-only">Not sure about the size ?</h4>
					<div id="style-guide-content">
						<span className="mcom-only">Check out our </span><a href={product.styleGuide.sizeChartURL} target="_blank"><span dangerouslySetInnerHTML={{__html: product.styleGuide.sizeChartText}} /></a>
					</div>
				</div>
			);
		}


		var prodOffers = product.productOffers;
		var availOfferData = this.props.availOfferData;
		var isAvailOfferEligible = false;
		var pwpGetItemPrice;

		if(prodOffers && prodOffers.length && availOfferData) {
			let grpType = prodOffers[0].groupType;
			let itemType = prodOffers[0].itemType;

			if(itemType && itemType.toUpperCase() == "BUY") {
				grpType && (grpType.toUpperCase() == "GWP") ? (
					gwpMarkup = labels.GWPTxt,
					gwpContentMarkup = labels.GWPTxtContent,
					gwpAccordionId = 'acc-gwpProduct'
				) : (
					grpType.toUpperCase() == "PWP" ? (
						gwpMarkup = labels.PWPTxt,
						gwpContentMarkup = labels.PWPTxtContent,
						gwpAccordionId = 'acc-pwpProduct'
					) : ''
				)
			}

			if(availOfferData.offerGroups){
			 	if(availOfferData.offerGroups[0].itemType == "GET" && availOfferData.offerGroups[0].groupType == "PWP") {
					pwpGetItemMarkup = labels.PWPgetTxt;
					pwpGetItemPrice = "Your price $"+availOfferData.pricePointAmount.toFixed(2);
				}

				if(availOfferData.offerGroups[0].offerPriceEligible){
					isAvailOfferEligible = true;
				}
			}
		}

		var selectBoxMarkup = '';
		var error = props.tryAddtoBag && !props.selectedSize?"hasError":"";
		if(props.isTcom){
			selectBoxMarkup = (
				<div className='t-selectBox'>
					{(sizeInfoArr && sizeInfoArr.length) && (
						(sizeInfoArr.length > 1) ? (
							<div data-item="1" className={`product-size ${error}`} onClick={eventHandlers.showSizeList}>
								{props.collection["productSizeCln-0"] || props.selectedSize ? ('SIZE:' +(props.collection["productSizeCln-0"] || props.selectedSize)) : 'Select a size'}
							</div>) : (<div className='product-size'>{'SIZE:' +sizeInfoArr[0].size}</div>))}
					{props.showSizeListBox ? (<div className='sel-list'>
						<div className='size-dropdown' onTouchMove={(e) => e.preventDefault()}><ul>
							{sizeInfoArr.map((sizeInfo, index) => {
								return (
									<li className={(props.collection["productSizeCln-0"]==sizeInfo.size ? 'active ' : '') + (!sizeInfo.avail ? 'sel-disabled' : '')} key={index}>
										<span id="productSizeCln-0" data-item="0" onClick={eventHandlers.handleSizeSelection} value={sizeInfo.size}>{sizeInfo.size}</span>
									</li>
								)
							})}
						</ul></div>
					</div>) : ''}

					{props.tryAddtoBag && !props.selectedSize ? <div className="req-size-txt">{labels[props.reqSize]}</div> : ''}
				</div>
			);
		} else {
			selectBoxMarkup = (
				<div className='m-selectBox'> {
					/* checks Size Length */
					(sizeInfoArr && sizeInfoArr.length) && (
						(sizeInfoArr.length > 1) ? (
							<div data-item="1" className={'product-size' + (props.tryAddtoBag && !props.selectedSize ? ' req-size' : '')} onClick={eventHandlers.showSizeList}>
								{props.collection["productSizeCln-0"] || props.selectedSize ? ('SIZE:' +(props.collection["productSizeCln-0"] || props.selectedSize)) : 'Select a size'}
								{props.isCartModal && <span></span>}
							</div>
						) : (
							<div className='product-size'>{'SIZE:' +sizeInfoArr[0].size}</div>
						)
					)
				}

				{/* only required for Multi-Size options */
					props.showSizeListBox ? (<div className='sel-list'>
						<div className="m-size-backdrop" onClick={eventHandlers.showSizeList} onTouchMove={(e) => e.preventDefault()}></div>

						<div className='size-dropdown'><ul>
							<li className='sizelist-title'>SIZE</li>
							{sizeInfoArr.map((sizeInfo, index) => {
								return (
									<li className={(props.collection["productSizeCln-0"]==sizeInfo.size ? 'active ' : '') + (!sizeInfo.avail ? 'sel-disabled' : '')} key={index}>
										<div id="productSizeCln-0" data-item="0" onClick={eventHandlers.handleSizeSelection} value={sizeInfo.size}>{sizeInfo.size}</div>
									</li>
								)
							})}
						</ul></div>
					</div>) : ''
				}

				{props.tryAddtoBag && !props.selectedSize ? <div className="req-size-txt">{labels[props.reqSize]}</div> : ''}
				</div>
			);
		}

		return(<div id="product-content"><div itemScope="" itemType="http://schema.org/Product"><div>
			{!props.isCartModal && props.continueShopModel && <ShopModel {...props} />}
			{props.isTcom && props.errGlobal && <div className="gblErrMsg-container"><p className="globalErrorMsg">{labels[props.errGlobal]}</p></div>}

			{props.isCartModal && <div className="pdp-modal-header">
				<div id="cancel-link" onClick={props.unmountModal}>Cancel</div><div className="title">Edit Bag Item</div>
			</div>}
			<div className="pdp-title tcom-only-block"><span><a href="javascript:history.go(-1)" className="t-arrow_back"></a></span><span dangerouslySetInnerHTML={{__html: product.productTitle}} /></div>
				<div id="section-1">
					{!props.isTcom && props.errGlobal && <div className="globalErrorMsg">{labels[props.errGlobal]}</div>}

					<div id="main-img">
						<div id="product-img-section">
							{mainImageMarkup}
						</div>
						<a href="#" className={"tap-to-zoom "+(!props.isTcom?"display-none":"")} onClick={props.eventHandlers.productCarouselZoom}>TAP TO ZOOM</a>
						{props.isTcom ? imageCounterMarkupTcom : imageCounterMarkupMcom}
					</div>
					<div id="main-product-content">
						<div id="product-desc">
							<h1 dangerouslySetInnerHTML={{__html: product.productTitle}} />
						</div>
						<div id="price-section">
							<div className="pdpPriceContent" itemProp="offers" itemScope="" itemType="http://schema.org/Offer">
								{salePriceMarkup}
								{origPriceMarkup}
								<meta itemProp="priceCurrency" content="USD"/>
							</div>
							{props.cartSkuCode && <div className="selected-sku">SKU# {props.cartSkuCode}</div>}
							{/*props.selectedColor && <div className="selected-color">COLOR<span className="selected-color-value">{props.selectedColor}</span></div>*/}

							<div className ="mcom-only">{onlineImgMarkup}</div>
						</div>
						{!utils.isObjectEmpty(product.exclusions.shortDescription) && (
							 <div className = "exclusions-pdp">
							 	{product.exclusions.shortDescription}
							 </div>
						)}
						{this.props.isTcom ? <div id="rating-review-section"> <div id="BVRRSummaryContainer"></div><div id="BVQASummaryContainer"></div></div> : ""}
						{this.props.isTcom && !utils.isObjectEmpty(product.rebate.shortDescription) && (
							 <div className = "rebate-product-pdp">
								 <span className = "rebate-product-text-pdp">{product.rebate.shortDescription}&nbsp;</span>
								 <span className="rebate-product-link-pdp" onClick={() => props.eventHandlers.openAndFocusAccordion('acc-rebate')} >Learn More</span>
							 </div>
						)}

						{!this.props.isTcom && product.productOffers && availOfferData && !pwpGetItemMarkup && (
							<div className="gift-purchase-pdp">
								<span className="offerTitle">{gwpMarkup}</span>
								<div className="mcom-only gwp-msg">{OffersHelper.getConditionalMessage('Terms', availOfferData)}</div>
								{this.props.isTcom && prodOffers ? <span className="gwpLearnMore" onClick={() => props.eventHandlers.openAndFocusAccordion(gwpAccordionId)}>Learn More</span> : ''}
							</div>
						)}

						{!this.props.isTcom && product.productOffers && availOfferData && pwpGetItemMarkup && isAvailOfferEligible && (
							<div className="gift-purchase-pdp">
								<span className="offerTitle">{pwpGetItemMarkup}</span>
								<div className="yourprice">{pwpGetItemPrice}</div>
							</div>
						)}



						<div className="pdpValueAddContainer mcom-only"></div>
						{swatchMarkup}
						{/* checks Size availability */
						 typeof(props.sizeAvailability) && !utils.isObjectEmpty(props.sizeAvailability) && !props.sizeAvailability[null] && (
							<div id="size-section" className={props.isTcom ? "t-com":""}>
								{!props.isTcom && (<h3>SIZE</h3>)}
								{selectBoxMarkup}
								{styleGuideMarkup}
							</div>
						)}
					</div>

					<div id="product-zoom-cntr" className={props.productCarousel.productZoom?"zoom":""}>
						<div id="product-zoom-overlay" className={"product-zoom-overlay "+(props.isTcom?"t-com":"")}>
							<div id="product-zoom-carousel" className="product-zoom-carousel" >
								<div role="button" className="close" id="product-overly-close" onClick={eventHandlers.productCarouselZoom}></div>

								{props.productImages.length > 1 ?
								(<button id="zoomedSliderPrevBtn" className={"nav-prev "+(!props.isTcom?"display-none ":"")+(props.productCarousel.nav===0?"disabled":"")}
								                                 onClick={()=>eventHandlers.navCarousel(false,1)}></button>) : ""}

								{(<div id="img-container" className={"img-container "+ (!props.productCarousel.productZoom ? "display-none":"")}>
									<ul className="carousel-slides" style={{left:props.productCarousel.value,width:(productImages.length*(props.isTcom?props.mainZoomImgWidth:props.mainImgWidth))}}>
									{productImages && productImages.map((image, index) => {
										return (
											<li className="product-img panZoom-img" key={index}>
												<img id={"zoom-overlay-img-"+index} src={utils.getImageUrl(image.url, (props.isTcom?props.mainZoomImgWidth:props.mainImgWidth), false)} style={{transform: 'matrix('+props.productZoom.prodZoomVal+', 0, 0, '+props.productZoom.prodZoomVal+', 0, 0)'}}  alt={image.altText}/>
											</li>
										)
									})}
									</ul>
								</div>)}

								{props.productImages.length > 1 ?
								(<button id="zoomedSliderNextBtn" className={"nav-next "+(!props.isTcom? "display-none ":"")+(props.productCarousel.nav+1===productImages.length?"disabled":"")}
								                                 onClick={()=>eventHandlers.navCarousel(true,1)}></button>) : ""}

								<div className="zoom-nav-titles">
									<button id="nav-zoome-prev" className={"nav-prev "+(!props.isTcom || (productImages.length <= props.productZoom.carouselLimit)?"display-none ":"")+(props.productZoom.currSlide===0?"disabled":"")} onClick={()=>eventHandlers.navMinCarousel(false)}></button>

									{props.productCarousel.productZoom && (<div id="nav-img-container" className={"nav-img-container "+(!props.productCarousel.productZoom || (props.productImages.length < 1)?"display-none":"")}>

										<ul className="carousel-slides" style={{left:-props.productZoom.slideVal}} >
											{!(props.productImages.length <1) && productImages.map((image, index) => {
												return (
													<li className={"product-img "+(("product-img-"+index) === "product-img-"+props.productCarousel.nav ? "nav-active" : "")} key={index} id={"product-img-"+index} onClick={()=>eventHandlers.navCarousel(null,index)}>
														<img src={utils.getImageUrl(image.url, props.mainImgWidth, false)}  alt={image.altText}/>
													</li>
												)
											})}
										</ul>
									</div>)}

									<button id="nav-zoome-next" className={"nav-next "+(!props.isTcom || (productImages.length <= props.productZoom.carouselLimit)?"display-none ":"")+(props.productZoom.slideEnd?"disabled":"")} onClick={()=>eventHandlers.navMinCarousel(true)}></button>

									<div id="tcomPdpZoomContainer" className="tcomPdpZoomContainer" className={!props.isTcom?"display-none":""}>
										<button id="tcomzoomMinus" className="zoom-button" onClick={()=>eventHandlers.productZoom(false)}>-</button>
										<div className="zoomTxt" id="zoomTxt"> zoom </div>
										<button id="zoomPlus" className="zoom-button" onClick={()=>eventHandlers.productZoom(true)}>+</button>
									</div>
								</div>
							</div>
						</div>

						<div id="product-zoom-mask" className="product-zoom-mask" onClick={eventHandlers.productCarouselZoom}></div>
					</div>
				</div>

				<div id="section-2">
					<QuantityView {...props} callbackQuantity={props.eventHandlers.onQuantityChange} />
					<AddtobagView {...props} callbackAddtoBag={props.eventHandlers.callbackAddtoBag} callbackStorePickup={props.eventHandlers.callbackStorePickup} />

					{!props.isCartModal && <div>
						{props.data.payload.products[0].productStatus == "In Stock" ? (
							<div id="findin-store-section">
								<div className="mcom-only">
						    {showFisButton && window.kohlsData && window.kohlsData.isFindInStoreEnabled ? <div className={"m-find-stores" + (props.isConfigDone ? " enabled" : "")} onClick={() => eventHandlers.validatePdpForFIS(false, props.selectedProductInfo)}>FIND IN STORE</div> : ''}
							<div className={"m-add-registry"}  >ADD TO REGISTRY</div>
							<div className={"m-add-list"}  >ADD TO LIST</div>
								</div>

								<div className="tcom-only-block">
								    <div>{onlineImgMarkup}</div>
									{showFisButton && window.kohlsData && window.kohlsData.isFindInStoreEnabled ? <div className="t-find-stores" onClick={() => props.eventHandlers.validatePdpForFIS(true, props.selectedProductInfo)}>FIND IN STORES</div> : ''}
									<div className="t-add-list" onClick={e => props.eventHandlers.showAddToRegistry(e, 'LIST')}>ADD TO LIST</div>
									<div className="t-add-registry" onClick={e => props.eventHandlers.showAddToRegistry(e, 'REGISTRY')}>ADD TO REGISTRY</div>
									<div className="t-add-share"><a href="#" id="tcom-share-product" onClick={eventHandlers.shareProduct}>SHARE</a></div>
								</div>
							</div>
						) : (
							<div id="findin-store-section">
								<div className="mcom-only">
								    {showFisButton && window.kohlsData && window.kohlsData.isFindInStoreEnabled ? <div className={"m-find-stores" + (addToBagBtnEnabled ? " enabled" : "")}>FIND IN STORE</div> : ''}
									<div className={"m-add-registry" + (addToBagBtnEnabled ? " enabled" : "")}>ADD TO REGISTRY</div>
									<div className={"m-add-list" + (addToBagBtnEnabled ? " enabled" : "")}>ADD TO LIST</div>
								</div>

								<div className="tcom-only-block">
								    <div>{onlineImgMarkup}</div>
									{showFisButton && window.kohlsData && window.kohlsData.isFindInStoreEnabled ? <div className="t-find-stores">FIND IN STORES</div> : ''}
									<div className="t-add-list">ADD TO LIST</div>
									<div className="t-add-registry">ADD TO REGISTRY</div>
									<div className="t-add-share"><a href="#" id="tcom-share-product">SHARE</a></div>
								</div>
							</div>
						)}


						<div id="social-icon-section"><SocialView {...props} /></div>

						{!this.props.isTcom ? <div id="rating-review-section"> <div id="BVRRSummaryContainer"></div><div id="BVQASummaryContainer"></div></div> : ""}
					</div>
					}

					{(product.productOffers && product.productOffers.length && !pwpGetItemMarkup) ? (
					<OffersView {...props} prdId={product.webID} />
					) : ""}
				</div>
				{!props.isCartModal && <div id="section-3">
					<Accordion {...props}/>
				</div>}
				{!props.isCartModal && <div id="section-4">
					<div id="recommendationsMcom" className="mcom-only"></div>
					<div id="id_tcomPdpRecommend" className="tcomPdpRecommend tcom-only-block"></div>
				</div>}
				{this.props.isTcom ? <div id="pdp-collection-tabs">
						{pdpTabItems}
						<div id="BVRRContainer" className={props.collectionPdpContent ==="pdp_qa"?'display-none':''}></div>
						<div id="BVQAContainer" className={props.collectionPdpContent ==="pdp_qa"?'display-block':'display-none'}></div>
				</div> : "" }
				<div id="add-to-registry-container"></div>
				<script src="/lib/jquery.cookie.js"></script>
				   <meta itemProp="productID" content={product.webID}/>
				   <meta itemProp="itemCondition" content="http://schema.org/NewCondition"/>
				   <meta itemProp="brand" content={product.brand}/>
				   <meta itemProp="URL" content={product.seoURL}/>
				   {product && product.SKUS.map((skus, index) => {
					   return (
					   <div className="pdpSchemaPriceContainer display-none" key={index}>
						  <div itemProp="offers" itemScope="" itemType="schema.org/Offer">
							 <span itemProp="sku">{skus.skuCode}</span>
							 <link itemProp="availability" href="http://schema.org/InStock"/>
							 <meta itemProp="itemCondition" content="http://schema.org/NewCondition"/>
							 <span itemProp="price">
								<div className="cls_pdtPrice"> {skus.price.salePrice ? "$"+skus.price.salePrice : "$"+skus.price.regularPrice} </div>
							 </span>
							 <meta itemProp="priceCurrency" content="USD"/>
						  </div>
					   </div>
					   )
				   })}
			</div>
			</div>
			</div>
		);
	}
});
