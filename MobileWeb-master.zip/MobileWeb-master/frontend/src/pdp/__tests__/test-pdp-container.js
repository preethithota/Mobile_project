import React from 'react';
import {mount} from 'enzyme';
import PdpContainer from '../pdp-container';
import * as utils from '../../global/utils';
jest.mock('../../global/utils');
//const utils = jest.genMockFromModule('../../global/utils');


//const productData = require('./dress-shirt-product-data.json');
const productData = require('./sweater-data.json');
const unmountModal = jest.fn();
const callback = jest.fn();

let currentLSMock = {};
const putInLocalStorage = jest.fn((key, value) => {
  currentLSMock[key] = value;
});

const getFromLocalStorage = jest.fn((key) => {
  let value = currentLSMock[key];
  return value;
});

const deleteFromLocalStorage = jest.fn((key) => {
  delete currentLSMock[key];
});


global.localStorage = {}
localStorage.setItem = putInLocalStorage;
localStorage.getItem = getFromLocalStorage;
localStorage.removeItem = function(){};

global.location.href = 'https://some.host/product/prd-2127363/new-balance-510-mens-trail-running-shoes.jsp';

// beforeEach(() => {
//   currentLSMock = {};
//   putInLocalStorage.mockClear();
// });

function addDataToMockEvent(currentEventMock, name, value){
  const newEventObj = {
    target:{
      dataset:{}
    }
  };
  newEventObj.target.dataset[name] = value;
  return Object.assign(currentEventMock, newEventObj);
}

describe('Edit bag item modal', () => {

  const testQty = '15';
  //const skuCode = '93230011';
  //const webId = '1170625';
  const skuCode = '92778445';
  const webId = '1069102';
  const bagItemId = '1';
  // const expectedColor = 'French Blue';
  // const expectedSize = 'SIZE:16-32/33';
  const expectedColor = 'Wild Lime';
  const expectedSize = 'SIZE:S';

  let pdpModal = mount(
    <PdpContainer data={productData} isTcom={false} isCartModal={true} cartSkuCode={skuCode}
      modalCallback={callback} cartQuantity={testQty} unmountModal={unmountModal} bagItemId={bagItemId}/>
    );

  it('should show the correct quantity', () => {
    const expectedQty = testQty;
    const actualQty = pdpModal.find('#inpQuantity').props().value;
    expect(expectedQty).toEqual(actualQty);
  });

  it('should have the correct color selected', () => {
    const actualColor = pdpModal.find('#swatches .colr-selected .swatch-img').prop('data-color');
    expect(expectedColor).toEqual(actualColor);
  });

  it('should have the correct size selected', () => {
    const actualSize = pdpModal.find('#size-section .m-selectBox .product-size').text();
    expect(expectedSize).toEqual(actualSize);
  });

  it('should update the quantity ', () => {
    const plusButton = pdpModal.find('.plus-btn');
    const refid = plusButton.prop('data-refid');

    // Unfortunately Enzyme doesn't automatically pass the event object of
    // a click event, so we have to mock it here.
    const mockEvent = addDataToMockEvent({}, 'refid', refid);

    plusButton.simulate('click', mockEvent);
    const updatedQty = pdpModal.find('#inpQuantity').props().value;
    expect(updatedQty).toEqual(16);
  });

  it('should have the update button disabled by default', () => {
    const expectedClass = 'enabled';
    const updateBtn = pdpModal.find('#add-to-bag-btn');
    expect(updateBtn.hasClass(expectedClass)).toBe(true);
  });

  it('should show the size selector modal when size is pressed', () => {
    const sizeSelectionElem = pdpModal.find('.product-size').first();
    let mockEvent = addDataToMockEvent({}, 'item', '1');

    //drop down should not be visible before we click on size
    expect(pdpModal.find('.size-dropdown').exists()).toBe(false);
    sizeSelectionElem.simulate('click', mockEvent);
    //drop down should not be visible before we click on size
    expect(pdpModal.find('.size-dropdown').exists()).toBe(true);
  });

/*
  it('should show the size selector modal when size is pressed', () => {
    const dropDownOptions = pdpModal.find('.size-dropdown li div');
    const largeSizeSelection = dropDownOptions.findWhere(e => e.prop('value') === 'L');
    let mockEvent = addDataToMockEvent({}, 'item', '0');
    mockEvent.target.classList = {
      add: function(){},
      remove: function(){}
    }
    largeSizeSelection.simulate('click', mockEvent);
    //dropdown should close
    expect(pdpModal.find('.size-dropdown').exists()).toBe(false);

  });
  */

  it('should update item and close modal when update button pressed', () => {
    utils.setCookieValue('skBag', `["${skuCode}|${webId}|15|false|-1|-1|false|-1"]`);
    const updateBtn = pdpModal.find('#add-to-bag-btn');
    let mockEvent = addDataToMockEvent({}, 'index', 0);
    mockEvent.target.classList = {
      contains: function(className){
        return className === 'enabled';
      }
    }

    updateBtn.simulate('click', mockEvent);
    expect(callback).toBeCalled();
    expect(unmountModal).toBeCalled();
  });

});
