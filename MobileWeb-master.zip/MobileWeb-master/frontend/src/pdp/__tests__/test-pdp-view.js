import React from 'react';
import {render} from 'enzyme';
import PdpContainer from '../pdp-container';

//samsonite luggage
const productDataLuggage = require('./catalog-data-luggage.json');
//shirts
const productDataShirts = require('./catalog-data-shirts.json')


describe('ProductDetailView(samsonite luggage)', () => {
  let wrapper = render(
    <PdpContainer data={productDataLuggage} isTcom={false} />
  );

  it('has value added icons', () => {
    let expectedSize = 2;
    let actualSize = wrapper.find('#valueAddBlock').length;
     expect(actualSize).toEqual(expectedSize);
  });

  it('has 0 swatches', () => {
    let expectedSize = 0;
    let actualSize = wrapper.find('.swatch').length;
     expect(actualSize).toEqual(expectedSize);
  });

});

describe('ProductDetailView(shirts)', () => {
  let wrapper = render(
    <PdpContainer data={productDataShirts} isTcom={false} />
  );

  it('has 4 swatch icons', () => {
    let expectedSize = 4;
    let actualSize = wrapper.find('.swatch').length;
     expect(actualSize).toEqual(expectedSize);
  });

});
