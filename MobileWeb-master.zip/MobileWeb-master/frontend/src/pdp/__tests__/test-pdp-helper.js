import * as pdpHelper from '../pdp-helper'

const testSkuData = require('./sku-data.json');

describe('getSku', () => {
  it('return the correct sku', () => {
    const sku = pdpHelper.getSku(testSkuData, "94416690");
    expect(sku.color).toEqual('French Press');
    expect(sku.size).toEqual('8 T/L');
  });
});

describe('getSelectedSkus', () => {

  it('should return the correct skus based on size selelection', () => {
    const expectedResult = testSkuData;
    const actualResult = pdpHelper.getSelectedSkus(testSkuData, "14 AVG/REG");
    expect(actualResult.length).toEqual(1);
    expect(actualResult[0].skuCode).toEqual("92701842");
  });

  it('should return the correct skus based on size selelection', () => {
    const expectedResult = testSkuData;
    const actualResult = pdpHelper.getSelectedSkus(testSkuData, "14 AVG/REG");
    expect(actualResult.length).toEqual(1);
    expect(actualResult[0].skuCode).toEqual("92701842");
  });

  it('should return the correct skus based on color selelection', () => {
    const expectedResult = testSkuData;
    const actualResult = pdpHelper.getSelectedSkus(testSkuData, "2 AVG/REG", "Black");
    expect(actualResult.length).toEqual(1);
    expect(actualResult[0].skuCode).toEqual("94087756");
  });

  it('should return an empty array if no skus available', () => {
    const expectedResult = testSkuData;
    const actualResult = pdpHelper.getSelectedSkus(testSkuData, "2 AVG/REG", "Blue");
    expect(actualResult).toEqual([]);
  });

  it('should return all skus if not size/color passed', () => {
    const expectedResult = testSkuData;
    const actualResult = pdpHelper.getSelectedSkus(testSkuData);
    expect(actualResult).toEqual(expectedResult);
  });

});
