import React from 'react';
import {render} from 'enzyme';
import createFindInStoreModal from '../../store/find-in-store-container';
import FindInStoreView from '../../store/find-in-store-mcom-view'

const data = require('./find-in-store-data.json');
const FindInStoreModal = createFindInStoreModal(FindInStoreView);

describe('Find In Store Modal - mcom', () => {
    let wrapper = render(
      <FindInStoreModal selectedProduct={data} />  
    );

    it('It has auto complete search box', () => {
        let searchBox = wrapper.find('#autocomplete');
        expect(searchBox.length).toBe(1);
    })
});