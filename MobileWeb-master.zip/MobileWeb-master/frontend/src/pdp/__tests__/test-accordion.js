import React from 'react';
import {shallow} from 'enzyme';
import Accordion from '../accordion';

const productData = require('./catalog-data-luggage.json');
const props = {data: productData};


describe('ProductDetailView', () => {
  let wrapper = shallow(
    <Accordion {...props} />
  );

  it('should have one product details accordion', () => {
    let expectedSize = 1;
    let actualSize = wrapper.find('#acc-productDetails').length;
    expect(actualSize).toEqual(expectedSize);
    expect(wrapper.find('.pdp-accordion-short-desc').length).toEqual(1);
  });

  it('should have one shipping And Return accordion', () => {
    let expectedSize = 1;
    let actualSize = wrapper.find('#acc-shippingAndReturn').length;
    expect(actualSize).toEqual(expectedSize);
  });

  it('should have one related information accordion', () => {
    let expectedSize = 1;
    let actualSize = wrapper.find('#acc-relatedInformation').length;
    expect(actualSize).toEqual(expectedSize);
  });

  it('should have one rebate accordion', () => {
    let expectedSize = 1;
    let actualSize = wrapper.find('#acc-rebate').length;
    expect(actualSize).toEqual(expectedSize);
  });

});