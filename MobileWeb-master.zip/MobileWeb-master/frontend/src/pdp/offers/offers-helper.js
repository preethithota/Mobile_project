import * as utils from '../../global/utils';
import * as CartHelper from '../../global/cart-helper';

export function getSkipOfferMessage(){
	var ofrAddedMsg = utils.getFromLocalStorage('ofrAddedMsg') || "";

	if(ofrAddedMsg){
		utils.deleteFromLocalStorage('ofrAddedMsg');
	}

	return ofrAddedMsg;
}

export function errCallback(err){
	console.log('err')
}

/*
export function getCartStringForOffers(){
	var cartEntries = CartHelper.getCartFromStorage() //utils.getCookieValue('skBag') //CartHelper.getStoredCartString(utils.getFromLocalStorage, utils.getCookieValue);
	var cartStringForOffer = cartEntries && cartEntries.length && JSON.parse(cartEntries).map((item, index) => {
		return(item.split('|')[0] +'|'+ item.split('|')[2])
	});

	return cartStringForOffer;
}
*/

export function getCartStringForOffers(){
	var cartEntries = CartHelper.getCartFromStorage();
	var cartStringForOffer = cartEntries && cartEntries.length && cartEntries.map((item, index) => {
		let cartEntry = item.skuCode+ '|' +item.quantity;
		return cartEntry;
	});

	console.log('CartEntry SKBAG - ' + $.cookie('skBag'))
	console.log('CartEntry latest - ' + cartStringForOffer);
	return cartStringForOffer;
}

export function getOffers(allInfo, productId, errorCallback, callback) {
	const cartStringForOffer = getCartStringForOffers();

	let data = 'productId=' +productId;
	data += cartStringForOffer ? ('&cart=' +cartStringForOffer) : '';
	data += allInfo ? '&offerProducts=true' : "";

	data = encodeURI(data);

	productId && $.ajax({
		url: '/api/v1/offers/product',
		method: 'GET',
		data: data,
		contentType: 'application/json',
		headers: {
			'Accept': 'application/json'
		}
	}).done(function(responseObj) {
		if (responseObj && responseObj.payload) {
			callback && callback(responseObj);
		}
		 else {
			errorCallback(responseObj);
		}
	}).fail((xhr) => {
		errorCallback({
			errors: {
				xhr: xhr,
				message: 'error'
			}
		});
	});
}

export function getOffersData(data){
	var productOffers

	/* Deep Null checking because sometimes, API returns empty offers data */
	if(productOffers = data.payload && data.payload.products && data.payload.products.length && data.payload.products[0].productOffers && data.payload.products[0].productOffers.length && data.payload.products[0].productOffers[0]){
		if(productOffers.offerProducts && productOffers.offerProducts.length && productOffers.offerProducts[0].availability == "In Stock"){
			return data.payload.products[0].productOffers[0];
		}

		if(productOffers.offerGroups && productOffers.offerGroups.length && productOffers.offerGroups[0].itemType=="GET" && productOffers.offerGroups[0].groupType=="PWP"){
			return data.payload.products[0].productOffers[0];
		}
	}
}

export function getAddtoBagInfo(offersData){
	var offerAddtoBagInfo = {};

	offerAddtoBagInfo['offerWebID'] = offersData.offerProducts[0].id;
	offerAddtoBagInfo['offerType'] = offersData.offerGroups[0].groupType;
	offerAddtoBagInfo['offerEligibility'] = offersData.offerGroups[0].offerPriceEligible;

	// Checking Offers SKUS
	offersData.offerProducts && offersData.offerProducts.length == 1 && offersData.offerProducts[0].skus.length == 1 && (
		offerAddtoBagInfo['isSingleSku'] = true,
		offerAddtoBagInfo['skuCode'] = offersData.offerProducts[0].skus[0].skuCode
	);

	return offerAddtoBagInfo;
}

export function actionAddtoBag(offerAddtoBagInfo, pdpData, isRedirect){
	if(isRedirect){
		setOffersInfoFromPDP(pdpData);
		location.href = '/SelectOffers.jsp';
	}
	else {
		const addToBagCallback = () => {};
		let cartEntries = CartHelper.addToBag(addToBagCallback, offerAddtoBagInfo.skuCode, offerAddtoBagInfo.offerWebID, 1);
	}
}

export function getConditionalMessage(msgKey, offersData){
	var message = "";

	for (let msg of offersData.conditionalMessages){
		if(msgKey == msg.key){
			message = msg.value;
			break;
		}
	}

	return message;
}

export function getMessageDecrypted(message, thresholdLimit, offValue, brand){
	if(message.indexOf("Special Savings with Purchase") !== -1){
		if(message.indexOf('%discountPercent') != -1){
			return message
					.replace("%count", thresholdLimit)
					.replace("%discountPercent", offValue)
					.replace("%amount", thresholdLimit)
					.replace("[brand]", brand);
		} else {
			return message
					.replace("%count", thresholdLimit)
					.replace("%amount", offValue)
					.replace("%amount", thresholdLimit)
					.replace("[brand]", brand);
		}
	} else {
		return message
				.replace("%count", thresholdLimit)
				.replace("%amount", thresholdLimit)
	}
}

export function offersMessageFactory(offersData, inputQuantity, buyPrice, trigger){
	var offerMessage = "";
	console.log(offersData.offerGroups[0]);

	buyPrice = buyPrice && inputQuantity && inputQuantity.inpQuantity && (buyPrice * inputQuantity.inpQuantity);

	var thresholdQty = offersData.thresholdQty && parseInt(offersData.thresholdQty);
	var thresholdAmt = offersData.thresholdAmt && parseInt(offersData.thresholdAmt);
	var quantityNeed = offersData.offerGroups[0].qtyNeeded;
	var dollarAmtNeeded = offersData.offerGroups[0].dollarAmtNeeded;
	var pricePointAmount = offersData.pricePointAmount && parseInt(offersData.pricePointAmount);

	if(thresholdQty){
		if(trigger == "qtyTrigger"){
			var quantityDiff = quantityNeed ? (quantityNeed - inputQuantity.inpQuantity) : thresholdQty && (thresholdQty - inputQuantity.inpQuantity);

			if(quantityDiff <= 0){
				offerMessage = getConditionalMessage('OfferConfiguredFinal', offersData);
			}
			if(quantityDiff == 1){
				offerMessage = getConditionalMessage('OfferConfiguredSingular', offersData);
			}
			if(quantityDiff > 1){
				offerMessage = getMessageDecrypted(getConditionalMessage('OfferConfigured', offersData), quantityDiff)
			}
		}
		if(trigger == "a2bTrigger"){
			if(quantityNeed <= 0){
				offerMessage = getConditionalMessage('OfferConfirmation', offersData);
			}
			if(quantityNeed > 0){
				offerMessage = getMessageDecrypted(getConditionalMessage('AddToBagMessage', offersData), quantityNeed)
			}
		}
	}
	else if(thresholdAmt){
		if(trigger == "qtyTrigger"){
			var pricevalDiff = thresholdAmt && buyPrice && (thresholdAmt - buyPrice);

			if(pricevalDiff <= 0){
				offerMessage = getConditionalMessage('OfferConfiguredFinal', offersData)
			}
			if(pricevalDiff > 0){
				offerMessage = getMessageDecrypted(getConditionalMessage('OfferConfigured', offersData), pricevalDiff.toFixed(2))
			}
		}
		if(trigger == "a2bTrigger"){
			if(dollarAmtNeeded <= 0){
				offerMessage = getConditionalMessage('OfferConfirmation', offersData)
			}
			if(dollarAmtNeeded > 0){
				offerMessage = getMessageDecrypted(getConditionalMessage('AddToBagMessage', offersData), dollarAmtNeeded)
			}
		}
	}
	else if(pricePointAmount >= 0){
		if(trigger == "qtyTrigger"){
			var pricevalDiff = (pricePointAmount >=0) && buyPrice && (pricePointAmount - buyPrice);

			if(pricevalDiff <= 0){
				offerMessage = getConditionalMessage('OfferConfiguredFinal', offersData)
			}
			if(pricevalDiff > 0){
				offerMessage = getMessageDecrypted(getConditionalMessage('OfferConfigured', offersData), pricevalDiff.toFixed(2))
			}
		}
		if(trigger == "a2bTrigger"){
			if(dollarAmtNeeded <= 0){
				offerMessage = getConditionalMessage('OfferConfirmation', offersData)
			}
			if(dollarAmtNeeded > 0){
				offerMessage = getMessageDecrypted(getConditionalMessage('AddToBagMessage', offersData), dollarAmtNeeded)
			}
		}
	}
	else {
		offerMessage = getConditionalMessage('OfferConfirmation', offersData);
	}

	return offerMessage;
}

export function setOffersInfoFromPDP(buyProduct){
	const product = buyProduct;
	var cookieString = '';
	var cookieObj = {};

	cookieObj['buyProdID'] = product.webID || "";
	//cookieObj['cartTotalPrice'] = (product.SKUS && product.SKUS.length && product.SKUS[0].price && product.SKUS[0].price.regularPrice) || ""
	cookieObj['cartQty'] = (window._header && window._header.state && window._header.state.bagTotal) || ""
	cookieObj['buyItmColor'] = (product.SKUS && product.SKUS.length && product.SKUS[0].color) || ""
	cookieObj['buyITmSize'] = (product.SKUS && product.SKUS.length && product.SKUS[0].size) || ""
	cookieObj['buyImage'] = (product.SKUS && product.SKUS.length && product.SKUS[0].images && product.SKUS[0].images.length && product.SKUS[0].images[0].url) || ""
	cookieObj["priceObj"] = (product.SKUS && product.SKUS.length && product.SKUS[0].price) || "";
	cookieObj["buyTitle"] = product.productTitle && "<p>" +product.productTitle+ "</p>" || "";

	cookieObj = JSON.stringify(cookieObj);

	utils.deleteFromLocalStorage("ofr_buyItemFromPDP");
	utils.putInLocalStorage("ofr_buyItemFromPDP", cookieObj);
}
