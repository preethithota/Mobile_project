import React from 'react';
import {labels} from '../../global/label-utils';
import * as OffersHelper from './offers-helper';
import * as CartHelper from '../../global/cart-helper';

export default React.createClass({
	getInitialState: function(){
		return {
			offersData: '',
			offersType: '',
			offersDefaultMsg: '',
			offerConditionalMsg: ''
		}
	},
	componentDidMount: function(){
		const product = this.props.data.payload.products[0];
		let _this = this;

		// Skip Offers
		let skipOfferMessage = OffersHelper.getSkipOfferMessage();

		// Ajax for Initial Page Loading
		OffersHelper.getOffers(true, this.props.prdId,
			function(err){
				console.log(err.error.message);
			},
			function(data){
				let offersDefaultMsg;
				let offersData = OffersHelper.getOffersData(data);
				let offersType = offersData && offersData.offerGroups && offersData.offerGroups[0].groupType || "";
				_this.setState({offersData, offersType});

				if(offersData){
					// Passing Offer Data Availability to Parent container
					(offersData && _this.props.eventHandlers.offerDataAvail(offersData));

					offersDefaultMsg = OffersHelper.getMessageDecrypted(
						OffersHelper.getConditionalMessage('OfferMessage', offersData),
							(offersData.thresholdQty || offersData.thresholdAmt || ""),
							(offersData.percentOff || offersData.pricePointAmount || ""),
							product.brand
					);
					offersDefaultMsg = offersDefaultMsg.replace("Special Savings with Purchase: ",'').replace("Gift with Purchase: ", '');
					offersDefaultMsg = offersDefaultMsg+ " " +OffersHelper.getConditionalMessage('Terms', offersData);
				}

				_this.setState({offersDefaultMsg});

				if(skipOfferMessage == 'Not Added'){
					let offerConditionalMsg = OffersHelper.getConditionalMessage("OfferGiftNotAdded", offersData);
					_this.setState({offerConditionalMsg});
				}
				if(skipOfferMessage == 'Added'){
					let offerConditionalMsg = OffersHelper.getConditionalMessage("OfferConfirmation", offersData);
					_this.setState({offerConditionalMsg});
				}
			});
	},
	eventHandlers: function() {
		var _this = this;
		let offerCycleCompleted = false;

		return {
			handleofferConditionalMsg: function(offersData, inputQuantity, buyPrice, trigger){
				var offerConditionalMsg = OffersHelper.offersMessageFactory(offersData, inputQuantity, buyPrice, trigger);
				this.setState({offerConditionalMsg});
			}.bind(this),
			handleAddtoBagTrigger: function(offersData, inputQuantity, buyPrice, trigger){
				const pdpData = this.props.data.payload.products[0];
				let offerAddtoBagInfo = OffersHelper.getAddtoBagInfo(offersData);
				let offersType = this.state.offersType;
				let showShopModel = true;

				if(offerAddtoBagInfo.offerEligibility && offerCycleCompleted){
					// Eligible only based on Exisitng Response itself
					if(offerAddtoBagInfo.offerType==='GWP' && !offerAddtoBagInfo.isSingleSku){
						// GWP Multi Sku and Multi Items
						OffersHelper.actionAddtoBag(offerAddtoBagInfo, pdpData, true);
						showShopModel = false;
					}
					else if(offerAddtoBagInfo.offerType==='GWP' && offerAddtoBagInfo.isSingleSku) {
						// GWP Single Sku Items
						OffersHelper.actionAddtoBag(offerAddtoBagInfo, pdpData, false);
						that.handleofferConditionalMsg(offersData, inputQuantity, buyPrice, trigger);
					}
					else {
						// PWP Items
						that.handleofferConditionalMsg(offersData, inputQuantity, buyPrice, trigger);
					}

					offerCycleCompleted = true;
					if(showShopModel){
						 _this.props.eventHandlers.showShopModel(true);
					}
				}
				else {
					OffersHelper.getOffers(true, _this.props.prdId,
						function(err){
							if(err && err.errors && err.errors.length){
								_this.props.eventHandlers.callbackAddtoBag(true, 'exceedsAllowedQtyMsg');
								_this.setState({offerConditionalMsg: ""});
								console.log(err.errors[0].message);
							}
						},
						function(data){
							var that = _this.eventHandlers();
							var offersData = OffersHelper.getOffersData(data);
							offerAddtoBagInfo = OffersHelper.getAddtoBagInfo(offersData);

							if(offerAddtoBagInfo.offerEligibility){
								// Eligible only based on New Response
								if(offerAddtoBagInfo.offerType==='GWP' && !offerAddtoBagInfo.isSingleSku){
									// GWP Multi Sku and Multi Items
									OffersHelper.actionAddtoBag(offerAddtoBagInfo, pdpData, true);
									showShopModel = false;
								}
								else if(offerAddtoBagInfo.offerType==='GWP' && offerAddtoBagInfo.isSingleSku) {
									// GWP Single Sku Items
									OffersHelper.actionAddtoBag(offerAddtoBagInfo, pdpData, false);
									that.handleofferConditionalMsg(offersData, inputQuantity, buyPrice, trigger);
								}
								else {
									// PWP Items
									that.handleofferConditionalMsg(offersData, inputQuantity, buyPrice, trigger);
								}

								offerCycleCompleted = true;
							} else{
								// Not eligible and Offer item Not added to bag
								that.handleofferConditionalMsg(offersData, inputQuantity, buyPrice, trigger)
								offerCycleCompleted = false;
							}

							_this.setState({offersData});

							if(showShopModel){
								_this.props.eventHandlers.showShopModel(true)
							}
							if(offersData){
								_this.props.eventHandlers.offerDataAvail(offersData)
							}
						}
					);
				}

				this.props.eventHandlers.triggerAddtoBag(false);
			}.bind(this)
		}
	},
	render: function(){
		const offersData = this.state.offersData;
		const offerProducts = offersData && offersData.offerProducts;
		const offersType = this.state.offersType;
		const eventHandlers = this.eventHandlers();

		/* Hiding Offers Information when response return empty or limited data */
		if(!offerProducts){
			return (null);
		}

		/* Show Offers Information */
		const inputQuantity = this.props.inputQuantity;
		const triggerQuantity = this.props.triggerQuantity;
		const triggerSizeSelction = this.props.triggerSizeSelction;
		const productPrice = this.props.data.payload.products[0].price;
		const triggerAddtoBag = this.props.triggerAddtoBag;
		const isAddtoBagEligible = this.props.errGlobal ? false : true;

		let _this = this,
			getItemPrice = "",
			priceRegex = /\d+((.|,)\d+)?/,
			offerConditionalMsg = this.state.offerConditionalMsg;

		let buyPrice = productPrice && productPrice.clearancePrice ? (
				productPrice.clearancePrice.match(priceRegex)[0]
			) : (
				productPrice.salePrice ? (
					productPrice.salePrice.match(priceRegex)[0]
				) : (
					productPrice.regularPrice && productPrice.regularPrice.match(priceRegex)[0]
				)
			);
		buyPrice = buyPrice && parseFloat(buyPrice);

		if(offerConditionalMsg){
			var offerMsgMarkup = (<div id="isofferAdded">
				<div id="offerMessageContainer">{offerConditionalMsg}</div>
			</div>)
		}

		if(triggerQuantity){
			eventHandlers.handleofferConditionalMsg(offersData, inputQuantity, buyPrice, "qtyTrigger");
			this.props.eventHandlers.stopTriggerQuantity(true);
		}

		if(triggerAddtoBag){
			eventHandlers.handleAddtoBagTrigger(offersData, inputQuantity, buyPrice, "a2bTrigger");
			//this.props.eventHandlers.triggerAddtoBag(false);
		}

		if(triggerSizeSelction){
			eventHandlers.handleofferConditionalMsg(offersData, inputQuantity, buyPrice, "qtyTrigger");
			this.props.eventHandlers.stopTriggerQuantity(true);
		}

		var offersDataMarkup = offerProducts && Array.apply(null, offerProducts).map((item, index) => {
			if(item.price.regularPrice){
				getItemPrice = item.price.regularPrice.replace(/Regular/i, '').replace(/Original/i, '');
			} else if(item.price.salePrice){
				getItemPrice = item.price.salePrice.replace(/Sale/i, '');
			}

			return (
				<div className="product-offer" key={index}>
					{getItemPrice ? <a href={item.productURL}><img className="offer-PDP-Image" src={item.images[0].URL} /></a> : <img className="offer-PDP-Image" src={item.images[0].URL} />}

					<div className="product-info">
						<div className="product-title">{item.productTitle}</div>

						<p className="offer-price">{offersType=="PWP" && parseInt(item.price.offerPrice.min) ? (
							kohlsData.isTcom ? (
								<span id="#tcom-pdp-offer" className="your-price">{labels.label_yourPrice}: ${item.price.offerPrice.min}</span>
							) : (
								<span id="#mcom-pdp-offer" className="your-price"><b>{labels.label_yourPrice}: ${item.price.offerPrice.min}</b></span>
							)
						) : (
							kohlsData.isTcom ? <span>Price: {labels.label_free}</span> : <span>Price:<b id="pdp-price-free"> {labels.label_free}</b></span>
						)}</p>

						{getItemPrice && (
							<p className="original-price">
								{(offersType == 'PWP') && <span className='original-amount'>Regular{getItemPrice}</span>}
								{(offersType == 'GWP') && <span className='value-amount'>Value{getItemPrice}</span>}
							</p>
						)}
					</div>
				</div>
			)
		});

		setTimeout(function(){$(function(){
			$("#pdp-offer-products").owlCarousel({
				items: 2,
				itemsDesktop: [250, 1],
				itemsDesktopSmall: [250, 1],
				itemsMobile: [250, 1],
				scrollPerPage: true
			});
		})}, 2000);

		return (
			<div id="mcom-pdp-offer">
				<div id="mcom-pdp-offer-title">{offersData && offersType==="PWP" ? labels.PWPTxt : labels.GWPTxt}</div>

				{offerMsgMarkup}

				<div className="pdp-GWP-Desc">{this.state.offersDefaultMsg}</div>
				<div id="mcom-pdp-offer-content">
					<div className="pdp-offer">
						<div id="pdp-offer-products" className="offer-products">{offersDataMarkup}</div>
					</div>
				</div>
			</div>
		);
	}
});
