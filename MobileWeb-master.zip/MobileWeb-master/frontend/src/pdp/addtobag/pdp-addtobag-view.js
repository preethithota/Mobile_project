import React from 'react';
import {labels} from '../../global/label-utils';
import * as utils from '../../global/utils';
import * as pdpHelper from '../pdp-helper';
import * as cartHelper from '../../global/cart-helper';
import {setAddtoCartOmniture} from '../../../public/lib/omniture-util';
export default React.createClass({
	getInitialState: function(){
		return {
			enableShipTab: '',
			storeUnselected: '',
			storeChooseUnselected: '',
			//availableSku: ''
		}
	},
	eventHandlers: function(){
		return {
			chooseStore: function(e){
				this.props.eventHandlers.resetValidationMsg();
				this.setState({storeUnselected: false});
				this.setState({storeChooseUnselected: false});

				if(this.props.isCartModal){
					var _this = this;

					var success = function(storeNum) {
						var selectedSkuItem = {
							skuCode: _this.props.cartSkuCode
						}
						var storeInfo = {
							storeFrom: 'stringHybridCart',
							storeNum: storeNum
						};

						_this.props.eventHandlers.selectStoreForHybrid(storeInfo, selectedSkuItem)
                    };

					KOHLS_HYBRID.utils.showFindInStoreModal(false, this.props.selectedProductInfo, 'login-modal-container', 'checkout', success);
				}
				else {
					let isTcom = this.props.isTcom;

					if(this.props.data.payload.products[0].collection){
						utils.showFindInStoreModal(isTcom, this.props.selectedProductInfo[this.props.collectionIndex]);
					} else {
						utils.showFindInStoreModal(isTcom, this.props.selectedProductInfo);
					}
				}
			}.bind(this),
			showAddToBagTab: function(e){
				let enableShipTab = (e.target.parentNode.id == "ship-btn" ? 'enable' : 'disable');

				this.setState({enableShipTab: enableShipTab});
			}.bind(this),
			addProductToBag: function(e){
				const storeInfo = this.props.storeInfo;

				var _this = this;
				let collectionIndex = e.target.dataset.index;
				let isStoreUnselected = e.target.dataset.store;
				let isShipButton = e.target.dataset.shipbtn;
				let product = this.props.data.payload.products[0];
				let webID = product.webID;
				let isButtonEnabled = e.target.classList.contains('enabled') ? true : false;
				let isCollection = product.collection ? true : false;
				let tryAddtoBag = this.props.tryAddtoBag || {};
				let errGlobal, reqSize;
				let storeNumberForCart = storeInfo.storeNum ? parseInt(storeInfo.storeNum) : "";

				if(isCollection){
					let selectedSku = this.props.col_selectedSkus[collectionIndex][0];
					let skuCode = selectedSku.skuCode;
					let itemMaxAvailableCount = selectedSku.itemMaxAvailableCount;
					let itemMaxAllowedCount = selectedSku.itemMaxAllowedCount;
					let chosenQuantity = this.props.inputQuantity['inpQuantity-' +collectionIndex];
					let storeNum = null, isGift = null;
					let colProductId = product.collection[collectionIndex].webID;
					tryAddtoBag[collectionIndex] = true;

					utils.modalActionPosition.getFocusPosition(e);

					if(!utils.isObjectEmpty(this.props.col_sizeAvailability[collectionIndex]) && !this.props.col_selectedSize[collectionIndex] && !utils.isObjectEmpty(this.props.col_colorAvailability[collectionIndex]) && !this.props.col_selectedColor[collectionIndex]){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'chooseBothConfigs', reqSize = 'reqSize');
						return;
					} else if(!utils.isObjectEmpty(this.props.col_sizeAvailability[collectionIndex]) && !this.props.col_selectedSize[collectionIndex]){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'chooseSizeConfigs', reqSize = 'reqSize');
						return;
					} else if(!utils.isObjectEmpty(this.props.col_colorAvailability[collectionIndex]) && !this.props.col_selectedColor[collectionIndex]){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'chooseColorConfigs');
						return;
					} else if(this.props.inputQuantity['inpQuantity-' +collectionIndex] > itemMaxAvailableCount){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'exceedsAllowedQtyMsg');
						return;
					} else if(itemMaxAllowedCount > 0 && this.props.inputQuantity['inpQuantity-' +collectionIndex] > itemMaxAllowedCount){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'exceedsAllowedQtyMsg');
						return;
					} else if(isStoreUnselected && isStoreUnselected == 'unselected'){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'storeUnselected');
						this.setState({storeUnselected: true})
						return;
					} else if(isStoreUnselected && isStoreUnselected == 'chooseUnselected'){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'storeChooseUnselected');
						this.setState({storeChooseUnselected: true})
						return;
					}

					/* Validation Success */
					if(isButtonEnabled){
						if (this.props.isCartModal){
							let addToBagCallback = () => {
								this.props.unmountModal();
								this.props.modalCallback();
							};
							cartHelper.updateHybridBagFromPdpModal(addToBagCallback, this.props.bagItemId, skuCode, chosenQuantity, isGift, storeNum);
							return;
						}
						else {
							let cartEntries = "";
							let addToBagCallback = (cart) => {
								console.log('CartEntry' +cart);
								this.props.eventHandlers.showShopModel(true);
							};
							//var cartEntries = cartHelper.addToBag(addToBagCallback, skuCode, colProductId, chosenQuantity, false, '', webID);

							if(product.collection[collectionIndex].isBopusEligible && storeInfo && isShipButton == 'false'){
								cartEntries = cartHelper.addToBag(addToBagCallback, skuCode, colProductId, chosenQuantity, false, '' , webID, true, storeNumberForCart);
							} else {
								cartEntries = cartHelper.addToBag(addToBagCallback, skuCode, colProductId, chosenQuantity, false, '' , webID);
							}
						}
					}
				}
				else {
					let selectedSku = this.props.selectedSkus[0];
					let skuCode = selectedSku.skuCode;
					let itemMaxAvailableCount = selectedSku.itemMaxAvailableCount;
					let itemMaxAllowedCount = selectedSku.itemMaxAllowedCount;
					let chosenQuantity = this.props.inputQuantity.inpQuantity;
					let storeNum = null, isGift = null;
					tryAddtoBag = true;

					utils.modalActionPosition.getFocusPosition(e);

					if(!utils.isObjectEmpty(this.props.sizeAvailability) && !this.props.selectedSize && !utils.isObjectEmpty(this.props.colorAvailability) && !this.props.selectedColor){
						this.props.eventHandlers.triggerAddtoBag(false);
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'chooseBothConfigs', reqSize = 'reqSize');
						return;
					} else if(!utils.isObjectEmpty(this.props.sizeAvailability) && !this.props.selectedSize){
						this.props.eventHandlers.triggerAddtoBag(false);
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'chooseSizeConfigs', reqSize = 'reqSize');
						return;
					} else if(!utils.isObjectEmpty(this.props.colorAvailability) && !this.props.selectedColor){
						this.props.eventHandlers.triggerAddtoBag(false);
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'chooseColorConfigs');
						return;
					} else if(this.props.inputQuantity.inpQuantity > itemMaxAvailableCount){
						this.props.eventHandlers.triggerAddtoBag(false);
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'exceedsAllowedQtyMsg');
						return;
					} else if(itemMaxAllowedCount > 0 && this.props.inputQuantity.inpQuantity > itemMaxAllowedCount){
						this.props.eventHandlers.triggerAddtoBag(false);
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'exceedsAllowedQtyMsg');
						return;
					} else if(isStoreUnselected && isStoreUnselected == 'unselected'){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'storeUnselected');
						this.setState({storeUnselected: true});
						return;
					} else if(isStoreUnselected && isStoreUnselected == 'chooseUnselected'){
						this.props.callbackAddtoBag(tryAddtoBag, errGlobal = 'storeChooseUnselected');
						this.setState({storeChooseUnselected: true});
						return;
					}

					/* Validation Success */
					if(isButtonEnabled){
						if (this.props.isCartModal){
							let addToBagCallback = () => {
								this.props.unmountModal();
								this.props.modalCallback();
							};

							let storeNum = ((isShipButton == 'true') ? '' : (this.props.storeInfo && this.props.storeInfo.storeNum));
							//updateHybridBagFromPdpModal(callback, bagItemId, skuCode, quantity, isGift, storeNum){
							cartHelper.updateHybridBagFromPdpModal(addToBagCallback, this.props.bagItemId, skuCode, chosenQuantity, isGift, storeNum);
							return;
						}
						else {
							var cartEntries = "";
							let addToBagCallback = (cart) => {
								console.log('CartEntry callback - ' +cart);
								this.props.eventHandlers.triggerAddtoBag(true);

								if(!(product.productOffers && product.productOffers.length && product.productOffers[0].groupType)){
									/* Restricting Continue Shop modal to Non-offers products only
										so that this modal can be handled inside Offers Component itself
										for Offer products */
									this.props.eventHandlers.showShopModel(true);
								}
							};

							if(product.isBopusEligible && storeInfo && isShipButton == 'false'){
								cartEntries = cartHelper.addToBag(addToBagCallback, skuCode, webID, chosenQuantity, false, '' , '', true, storeNumberForCart, null);
							} else {
								cartEntries = cartHelper.addToBag(addToBagCallback, skuCode, webID, chosenQuantity);
							}
						}
					}
				}
				setAddtoCartOmniture();
			}.bind(this),
			gen_CollectionFIS:function(product,collectionIndex){
				const propAddedToBag = {};
				propAddedToBag.productTitle = product.productTitle;
				propAddedToBag.ratingCount = product.ratingCount;
				propAddedToBag.avgRating = product.avgRating;
				propAddedToBag.webID = product.webID;
				propAddedToBag.selectedSkus = this.props.col_selectedSkus[collectionIndex];
				utils.showFindInStoreModal(false, propAddedToBag);

			}.bind(this),
			checkSkuUpdates: function(selectedSku){
				this.setState({availableSku: selectedSku})
			}.bind(this)
		}
	},
	render: function(){
		const props = this.props;
		const collectionIndex = props.collectionIndex;
		const state = this.state;
		const addToBagLabel = (props.isCartModal) ? labels.updateBag : labels.addToBag;
		const eventHandlers = this.eventHandlers();
		const product = props.data.payload.products[0];
		const colProduct = product.collection;
		const storeInfo = this.props.storeInfo;
		const enableShipTab = this.state.enableShipTab;

		let availableSku = this.state.availableSku;
		let selectedSku;

		if(product.collection){
			selectedSku = (props.col_selectedSkus && props.col_selectedSkus[collectionIndex] && props.col_selectedSkus[collectionIndex].length &&
				props.col_selectedSkus[collectionIndex][0] && props.col_selectedSkus[collectionIndex][0].skuCode) || "";
			//console.log('selectedSku = ' +selectedSku)

			let collectionAddToBagBtnEnabled = [];
			collectionAddToBagBtnEnabled[collectionIndex] = props.isCollectionConfigDone[collectionIndex];

			let col_showShipTab = (product.collection[collectionIndex].isBopusEligible && storeInfo && storeInfo.storeNum && (
				props.isCartModal || storeInfo.storeFrom=='stringURL'
			) ? false : true);

			if(enableShipTab === "enable"){ col_showShipTab = true}
			if(enableShipTab === "disable"){ col_showShipTab = false}

			//(!utils.isObjectEmpty(props.storeOutofstock)) && console.log("Checking out of stock - " +selectedSku+ " - " +props.storeOutofstock[selectedSku]);

			let pickupStoreMarkup = col_showShipTab ? (
				/* SHIP Block - Collection */
				product.collection[collectionIndex].productStatus ==='Out of Stock' ? (
					<div className='outof-stock display-block'>
						<div className="atob-labels">
							<div className='atob-primary-label'><span></span>Not available to ship</div>
						</div>
						<h1>OUT OF STOCK</h1>
					</div>
				) : (
					<div className='add-to-bag-btn'>
						{collectionAddToBagBtnEnabled[collectionIndex] && (<div className="atob-labels">
							<div className='atob-primary-label'><span></span>Available to Ship</div>
						</div>)}
						<button id="add-to-bag-btn" data-index={collectionIndex} data-shipbtn='true' onClick={eventHandlers.addProductToBag} className={collectionAddToBagBtnEnabled[collectionIndex] ? "enabled" : ""}>{addToBagLabel}</button>
					</div>
				)
			) : (
				/* PIUS Block - Collection */
				product.collection[collectionIndex].productStatus ==='Out of Stock' ? (
					<div className='outof-stock display-block'>
						<div className="atob-labels">
							<div className='atob-primary-label'><span></span>{labels.notAvailableForPickup}</div>
						</div>
						<h1>OUT OF STOCK</h1>
					</div>
				) : (
					collectionAddToBagBtnEnabled[collectionIndex] ? (
						props.aToBagPreloadImg ? (
							<div className="preloader"><span>Cheking availability</span><img src="/images/bx_loader.gif" /></div>
						) : (
							props.checkAnotherStore ? (
								props.storeOutofstock[selectedSku] ? (
									(storeInfo.storeFrom == 'stringGeoloc' || storeInfo.storeCheck[selectedSku] == 'fityMileRadius') ? (
										<div className='add-to-bag-btn'>
											<div className="atob-labels outof-stock">
												<div className='atob-primary-label'><span></span>{labels.notAvailable} <b>{labels.notAvailableAtFiftyMile} {storeInfo.storeZip}</b></div>
												<div id="selectStoreLink" className={"selectStoreLink"+ (props.tryAddtoBag && props.tryAddtoBag[collectionIndex] && props.isCollectionConfigDone[collectionIndex] && state.storeChooseUnselected ? ' req-choosestore' : '')} onClick={eventHandlers.chooseStore}><span>{labels.checkOthStore}</span></div>
											</div>
											{props.tryAddtoBag && props.tryAddtoBag[collectionIndex] && props.isCollectionConfigDone[collectionIndex] && state.storeChooseUnselected && <div className="req-choosestore-txt">{labels['storeChooseUnselected']}</div>}
											<button id="add-to-bag-btn" data-index={collectionIndex} data-store='chooseUnselected' onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
										</div>
									) : (
										<div className='add-to-bag-btn'>
											<div className="atob-labels outof-stock">
												<div className='atob-primary-label'><span></span>{labels.notAvailableAtStore} <b>{storeInfo.storeName}</b></div>
												<div id="selectStoreLink" className={"selectStoreLink"+ (props.tryAddtoBag && props.tryAddtoBag[collectionIndex] && props.isCollectionConfigDone[collectionIndex] && state.storeChooseUnselected ? ' req-choosestore' : '')} onClick={eventHandlers.chooseStore}><span>{labels.checkOthStore}</span></div>
											</div>
											{props.tryAddtoBag && props.tryAddtoBag[collectionIndex] && props.isCollectionConfigDone[collectionIndex] && state.storeChooseUnselected && <div className="req-choosestore-txt">{labels['storeChooseUnselected']}</div>}
											<button id="add-to-bag-btn" data-index={collectionIndex} data-store='chooseUnselected' onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
										</div>
									)
								) : (
									<div className='add-to-bag-btn'>
										<div className="atob-labels">
											<div className='atob-primary-label'><span></span>{labels.availableAtStore} <b>{storeInfo.storeName}</b></div>
											<div id="selectStoreLink" className="selectStoreLink" onClick={eventHandlers.chooseStore}>{labels.checkOthStore}</div>
										</div>
										<button id="add-to-bag-btn" data-index={collectionIndex} data-shipbtn='false' onClick={eventHandlers.addProductToBag} className="enabled" data-storeId={storeInfo.storeNum}>{addToBagLabel}</button>
									</div>
								)
							) : (
								<div className='add-to-bag-btn'>
									<div id="selectStoreLink" className={"selectStoreLink"+ (props.tryAddtoBag && props.tryAddtoBag[collectionIndex] && props.isCollectionConfigDone[collectionIndex] && state.storeUnselected ? ' req-choosestore' : '')} onClick={eventHandlers.chooseStore}><span>{labels.selStore}</span></div>
									{props.tryAddtoBag && props.tryAddtoBag[collectionIndex] && props.isCollectionConfigDone[collectionIndex] && state.storeUnselected && <div className="req-choosestore-txt">{labels['storeUnselected']}</div>}
									<button id="add-to-bag-btn" data-index={collectionIndex} data-store='unselected' onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
								</div>
							)
						)
					) : (
						<button id="add-to-bag-btn" data-index={collectionIndex} onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
					)
				)
			)
			return (
				<div id="add-to-bag-section">
					<div id="ship-selection">
						<div id="ship-btn" className={col_showShipTab ? "selected" : ""}><span onClick={eventHandlers.showAddToBagTab}>SHIP</span></div>
						{colProduct[collectionIndex].isBopusEligible ? (
							<div id="bopus-btn" className={col_showShipTab ? "" : "selected"}><span onClick={eventHandlers.showAddToBagTab}>PICK UP IN STORE</span></div>
						) : ""}
					</div>
					<div className="add-to-bag">
						{pickupStoreMarkup}
					</div>
				</div>
			)
		}
		else {
			const addToBagBtnEnabled = props.isConfigDone;
			selectedSku = props.selectedSkus && props.selectedSkus.length && props.selectedSkus[0].skuCode;

			let isCartUpdated = props.triggerQuantity || props.updateCart || (props.storeInfo && props.storeInfo.storeFrom == 'stringHybridCart') || (enableShipTab && enableShipTab != '');
			let showShipTab = (product.isBopusEligible && storeInfo && storeInfo.storeNum && (
				props.isCartModal || storeInfo.storeFrom=='stringURL'
			) ? false : true);

			if(enableShipTab === "enable"){ showShipTab = true}
			if(enableShipTab === "disable"){ showShipTab = false}

			let pickupStoreMarkup = showShipTab ? (
				/* SHIP Block - Regular */
				product.productStatus ==='Out of Stock' ? (
					<div className='outof-stock display-block'>
						<div className="atob-labels">
							<div className='atob-primary-label'><span></span>Not available to ship</div>
						</div>
						<h1>OUT OF STOCK</h1>
					</div>
				) : (
					<div className='add-to-bag-btn'>
						{addToBagBtnEnabled && (<div className="atob-labels">
							<div className='atob-primary-label'><span></span>Available to Ship</div>
						</div>)}

						{props.isCartModal ? (
							<button id="add-to-bag-btn" data-shipbtn='true' onClick={eventHandlers.addProductToBag} className={addToBagBtnEnabled && isCartUpdated ? "enabled" : ""}>{addToBagLabel}</button>
						) : (
							<button id="add-to-bag-btn" data-shipbtn='true' onClick={eventHandlers.addProductToBag} className={addToBagBtnEnabled ? "enabled" : ""}>{addToBagLabel}</button>
						)}
					</div>
				)
			) : (
				/* PIUS Block - Regular */
				product.productStatus ==='Out of Stock' ? (
					<div className='outof-stock display-block'>
						<div className="atob-labels">
							<div className='atob-primary-label'><span></span>{labels.notAvailableForPickup}</div>
						</div>
						<h1>OUT OF STOCK</h1>
					</div>
				) : (
					addToBagBtnEnabled ? (
						props.aToBagPreloadImg ? (
							<div className="preloader"><span>CHECKING</span><img src="/images/bx_loader.gif" /></div>
						) : (
							props.checkAnotherStore ? (
								props.storeOutofstock[selectedSku] ? (
									(storeInfo.storeFrom == 'stringGeoloc' || storeInfo.storeCheck[selectedSku] == 'fityMileRadius') ? (
										<div className='add-to-bag-btn'>
											<div className="atob-labels outof-stock">
												<div className='atob-primary-label'><span></span>{labels.notAvailable} <b>{labels.notAvailableAtFiftyMile} {storeInfo.storeZip}</b></div>
												<div id="selectStoreLink" className={"selectStoreLink"+ (props.tryAddtoBag && props.isConfigDone && state.storeChooseUnselected ? ' req-choosestore' : '')} onClick={eventHandlers.chooseStore}><span>{labels.checkOthStore}</span></div>
											</div>
											{props.tryAddtoBag && props.isConfigDone && state.storeChooseUnselected && <div className="req-choosestore-txt">{labels['storeChooseUnselected']}</div>}
											<button id="add-to-bag-btn" data-index={collectionIndex} data-store='chooseUnselected' onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
										</div>
									) : (
										<div className='add-to-bag-btn'>
											<div className="atob-labels outof-stock">
												<div className='atob-primary-label'><span></span>{labels.notAvailableAtStore} <b>{storeInfo.storeName}</b></div>
												<div id="selectStoreLink" className={"selectStoreLink"+ (props.tryAddtoBag && props.isConfigDone && state.storeChooseUnselected ? ' req-choosestore' : '')} onClick={eventHandlers.chooseStore}><span>{labels.checkOthStore}</span></div>
											</div>
											{props.tryAddtoBag && props.isConfigDone && state.storeChooseUnselected && <div className="req-choosestore-txt">{labels['storeChooseUnselected']}</div>}
											<button id="add-to-bag-btn" data-index={collectionIndex} data-store='chooseUnselected' onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
										</div>
									)
								) : (
									<div className='add-to-bag-btn'>
										<div className="atob-labels">
											<div className='atob-primary-label'><span></span>{labels.availableAtStore} <b>{storeInfo.storeName}</b></div>
											<div id="selectStoreLink" className="selectStoreLink" onClick={eventHandlers.chooseStore}>{labels.checkOthStore}</div>
										</div>
										{props.isCartModal ? (
											<button id="add-to-bag-btn" data-shipbtn='false' onClick={eventHandlers.addProductToBag} className={isCartUpdated ? "enabled" : ""} data-storeId={storeInfo.storeNum}>{addToBagLabel}</button>
										) : (
											<button id="add-to-bag-btn" data-shipbtn='false' onClick={eventHandlers.addProductToBag} className="enabled" data-storeId={storeInfo.storeNum}>{addToBagLabel}</button>
										)}
									</div>
								)
							) : (
								<div className='add-to-bag-btn'>
									<div id="selectStoreLink" className={"selectStoreLink"+ (props.tryAddtoBag && props.isConfigDone && state.storeUnselected ? ' req-choosestore' : '')} onClick={eventHandlers.chooseStore}><span>{labels.selStore}</span></div>
									{props.tryAddtoBag && props.isConfigDone && state.storeUnselected && <div className="req-choosestore-txt">{labels['storeUnselected']}</div>}
									<button id="add-to-bag-btn" data-index={collectionIndex} data-store='unselected' onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
								</div>
							)
						)
					) : (
						<button id="add-to-bag-btn" onClick={eventHandlers.addProductToBag}>{addToBagLabel}</button>
					)
				)
			)

			return (
				<div id="add-to-bag-section">
					<div id="ship-selection">
						<div id="ship-btn" className={showShipTab ? "selected" : ""}><span onClick={eventHandlers.showAddToBagTab}>{labels.addToBagShip}</span></div>
						{product.isBopusEligible ? (
							<div id="bopus-btn" className={showShipTab ? "" : "selected"}><span onClick={eventHandlers.showAddToBagTab}>{labels.pickupStore}</span></div>
						) : ""}
					</div>
					<div className="add-to-bag">
						{pickupStoreMarkup}
					</div>
				</div>
			)
		}
	}
});
