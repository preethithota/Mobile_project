import React from 'react';
import {labels} from '../../global/label-utils';
import * as utils from '../../global/utils';


export default React.createClass({
	getInitialState: function(){
		const product = this.props.data.payload.products[0];

		var inputQuantity = {};
		if(product.collection && product.collection.length){
			for(let i=0; i<product.collection.length; i++) {
				inputQuantity['inpQuantity-' +i] = 1;
			}
		} else {
			inputQuantity['inpQuantity'] = (this.props.cartQuantity) ? this.props.cartQuantity : 1;
		}

		return {
			inputQuantity: inputQuantity
		}
	},
	eventHandlers: function(){
		return {
			inputQuantityHandle: function(e){
				var valueAllowed = ""
				var value = e.target.value;
				var id = e.target.id;
				var minAllowed = parseInt(e.target.min);
				var maxAllowed = parseInt(e.target.max);

				valueAllowed = parseInt(value) > maxAllowed ?
								value.slice(0,3) :
								parseInt(value) < minAllowed ?
								minAllowed :
								value;

				const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: parseInt(valueAllowed,10)});
				let selectedProductInfo = this.props.selectedProductInfo;
				selectedProductInfo.quantity = this.state.inputQuantity.inpQuantity;
				this.setState({
					inputQuantity: newQuantity
				});
				//callback to Parent
				this.props.callbackQuantity(newQuantity);
			}.bind(this),
			increseQuantity: function(e){
				e.preventDefault();
				const product = this.props.data.payload.products[0];
				let id = e.target.dataset.refid;
				let quantity = this.state.inputQuantity[id];
				let maxAllowed = product.collection ? this.props.col_selectedSkus[index][0].itemMaxAllowedCount : this.props.selectedSkus[0].itemMaxAllowedCount
				if((parseInt(quantity) < 999) && (maxAllowed == 0 || maxAllowed > parseInt(quantity))) {
					const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: ++quantity});
					this.setState({inputQuantity: newQuantity});
					//callback to Parent
					this.props.callbackQuantity(newQuantity);
				}
			}.bind(this),
			decreseQuantiy: function(e){
				e.preventDefault();
				let id = e.target.dataset.refid;
				let quantity = this.state.inputQuantity[id];
				if (parseInt(quantity) > 1){
					const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: --quantity});
					this.setState({inputQuantity: newQuantity});
					//callback to Parent
					this.props.callbackQuantity(newQuantity);
				}
			}.bind(this),
			inputHandleBlur: function(e){
				var defaultValue = e.target.value || 1;
				var id = e.target.id;
				const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: defaultValue});
				this.setState({inputQuantity: newQuantity});
				//callback to Parent
				this.props.callbackQuantity(newQuantity);
			}.bind(this)
		}
	},
	render: function(){
		const props = this.props;
		const index = props.collectionIndex;
		const eventHandlers = this.eventHandlers();
		const product = props.data.payload.products[0];

		let quantityDisabled = "";

		if(product.collection){
			quantityDisabled = (props.isCollectionConfigDone[index] && props.col_selectedSkus[index].length && props.col_selectedSkus[index][0].itemMaxAllowedCount > 0 && props.col_selectedSkus[index][0].itemMaxAllowedCount) || '';

			return (
				<div className="quantity-section">
					<h3>Quantity</h3>

					<div className="quantity-selector">
						<div data-refid={'inpQuantity-'+index}
							 title="Quantity minus" className={"minus-btn m-black-plus-icon" + (this.state.inputQuantity['inpQuantity-'+index] == 1 ? " quantity-disabled" : "")}
						 	 onClick={eventHandlers.decreseQuantiy}>-</div>
						<div className="quantity">
							<input type='number' min="1" max="999"
									id={'inpQuantity-'+index}
									value={this.state.inputQuantity['inpQuantity-'+index]}
									onChange={eventHandlers.inputQuantityHandle}
									onBlur={eventHandlers.inputHandleBlur} />
						</div>
						<div data-refid={'inpQuantity-'+index}
							 title="Quantity plus" className={"plus-btn m-black-plus-icon" + ((this.state.inputQuantity['inpQuantity-'+index] == 999 || quantityDisabled) ? " quantity-disabled" : "")}
							 onClick={eventHandlers.increseQuantity}>+</div>
					</div>
				</div>
			);
		}
		else {
			quantityDisabled = (props.isConfigDone && props.selectedSkus.length && props.selectedSkus[0].itemMaxAllowedCount > 0 && this.state.inputQuantity['inpQuantity'] >= props.selectedSkus[0].itemMaxAllowedCount);

			return (
				<div id="quantity-section">
					<h3>Quantity</h3>

					<div className="quantity-selector">
						<div data-refid='inpQuantity'
							title="Quantity minus" className={"minus-btn m-black-plus-icon" + (this.state.inputQuantity['inpQuantity'] == 1 ? " quantity-disabled" : "")}
							 onClick={eventHandlers.decreseQuantiy}>-</div>
						<div className="quantity">
							<input type='number' min="1" max="999" id='inpQuantity'
								value={this.state.inputQuantity['inpQuantity']}
								onChange={eventHandlers.inputQuantityHandle}
								onBlur={eventHandlers.inputHandleBlur} />
						</div>
						<div data-refid='inpQuantity'
							title="Quantity plus" className={"plus-btn m-black-plus-icon" + ((this.state.inputQuantity['inpQuantity'] == 999 || quantityDisabled) ? " quantity-disabled" : "")}
							 onClick={eventHandlers.increseQuantity}>+</div>
					</div>
				</div>
			)
		}
	}
});
