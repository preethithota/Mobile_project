import React from 'react';
import * as storeUtils from '../util/store-time-helper';
import * as cart from '../../global/cart-helper';
import ContinueShopModal from '../pdp-shop-model-view';
import {displayPrice} from '../pdp-helper';

export default class FindInStoreView extends React.Component{
  getFixedNumber(ratingCount, numberDigits=1) {
      return parseFloat(ratingCount).toFixed(numberDigits);
  }

  StockAvailability(props, index) {
    const eventHandlers = props.eventHandlers;
    return (<div className="available-stock-qty-bag">
              <div className="quantity-section">
                <div className="quantity-title">Quantity</div>
                <div className="quantity-selector">
                  <div data-refid={'inpQuantity-'+index}
                     className={"m-black-plus-icon" + (props.inputQuantity['inpQuantity-'+index] === 1 ? " quantity-disabled" : "")}
                     onClick={eventHandlers.decreseQuantiy}>-</div>
                  <div className="quantity">
                    <input type='number' min="1" max="999" id={'inpQuantity-'+index}
                        value={props.inputQuantity['inpQuantity-'+index]}
                        disabled="disabled"
                        onChange={eventHandlers.inputQuantityHandle}
                        onBlur={eventHandlers.inputHandleBlur} />
                  </div>
                  <div data-refid={'inpQuantity-'+index}
                     className={"m-black-plus-icon" + (props.inputQuantity['inpQuantity-'+index] === 999 ? " quantity-disabled" : "")}
                     onClick={eventHandlers.increseQuantity}>+</div>
                </div>
              </div>
              <div className="add-to-bag-container">
                <button id="add-to-bag-btn" className="enabled" onClick={() => eventHandlers.addToBag(index)}>Add to Bag</button>
              </div>
            </div>);
  }

  StoreAvailability(props,availabilityList, index) {
    var isProductBopusEligible = props.selectedProduct.selectedSkus[0].isBopusEligible;
    var statusAndTime, stockAvailability = '';
    if (props.calledBy === 'checkout') {
      stockAvailability = <div><button className="select-store-btn enabled" onClick={() => props.eventHandlers.handleStoreSelection(index)}>SELECT STORE</button></div>;
    } else {
      const shopStatus = storeUtils.getOpenOrCloseStatus(availabilityList.storeDetail.storeHours.days);
      var currentShopStatus = <div className={"bldtxt capitalize-first-letter " + shopStatus}>{shopStatus}</div>;
      var timeToDrive = <div className="capitalize-first-letter"><span className="fis-car-icon"></span>{availabilityList.timeToDrive}</div>;
      stockAvailability =
          (availabilityList.availability === 'Low Stock' || availabilityList.availability === 'In Stock') && isProductBopusEligible && availabilityList.isBopusEligibleStore && this.StockAvailability(props, index);
    }

    return (<div className="fis-results">
              <div className="fis-results-lft">
                <h1>{availabilityList.storeDetail.storeName}</h1>
                <p>{availabilityList.storeDetail.address.addr1}</p>
                <p>{availabilityList.storeDetail.address.city}, {availabilityList.storeDetail.address.state} {availabilityList.storeDetail.address.postalCode}</p>
              </div>
              <div className="fis-results-rgt">
                  {availabilityList.availability === 'Out of Stock' && <div className="FL"><span className="red-close"></span><span className="available-stock">Not Available</span></div>}
                  {availabilityList.availability === 'Low Stock' && <div className="FL"><span className="tick-icon"></span><span className="available-stock">Limited Available</span></div>}
                  {availabilityList.availability === 'In Stock' && <div className="FL"><span className="tick-icon"></span><span className="available-stock">Available</span></div>}
                <div className="RL m-arrow"></div>
              </div>
              <div className="clearfix"></div>
              <div className="fis-results-miles">
                <div className="capitalize-first-letter">{this.getFixedNumber(availabilityList.storeDetail.distanceFromOrigin)} miles</div>
                {currentShopStatus}
                {timeToDrive}
              </div>
                {stockAvailability}
              <div className="clearfix"></div>
            </div>);
  }

  render(){
    const props = this.props;
    //const product = this.props.data.payload.products[0]
    const eventHandlers = props.eventHandlers;
    const noResult = 'Enter your current location city or code to view a list of stores near you that have this product';
    const productDetails = this.props.selectedProduct;
    const selectedSkus = productDetails.selectedSkus[this.props.selectedProduct.selectedSkus.length - 1];
	let price = selectedSkus && selectedSkus.price;

		let priceObj = displayPrice(price);
 		const clsName = (priceObj && priceObj.isRedLabel) ? "sale-price" : "blackLabel";
		const regPrice = priceObj ? (priceObj.combainWithReg ? "or "+priceObj.regPrice+" each" : priceObj.regPrice) : '';

		const salePriceMarkup = (priceObj && priceObj.specialPrice) && (<div id="product-sale-price" className={clsName}>{(priceObj) ? priceObj.specialPrice : ''}</div>);

		const origPriceMarkup = (price.regularPrice) ? (<div className="orig-price">{regPrice}</div>) : '';

    function getRatingWidth(ratings) {
      return (window.outerWidth > 680) ? (13*ratings) : (18*ratings);
    };

    function getFixedNumber(ratingCount, numberDigits=1) {
      return parseFloat(ratingCount).toFixed(numberDigits);
    };

    function ReviewRating(props) {
      const getRatingsWidth = getRatingWidth(productDetails.avgRating);
      if (props.calledBy === 'checkout') {
        return (
          <div>
            <div className="rating-container">
              <div id="BVRRSummaryContainer"></div>
            </div>
            <div className={props.haveAtleastOne && props.calledBy !== 'checkout' ? 'show-stores-availability'  : 'show-stores-availability hide'}>
                <span onClick={eventHandlers.handleSortClick}>{(props.sortResult === 'availableOnly') ? 'Show all stores' : 'Only show stores with availability'}</span>
            </div>
          </div>
        );
      } else if (!productDetails.hasOwnProperty('avgRating')) {
        return (
        <div>
            <div className={props.haveAtleastOne && props.calledBy !== 'checkout' ? 'show-stores-availability'  : 'show-stores-availability hide'}>
              <span onClick={eventHandlers.handleSortClick}>{(props.sortResult === 'availableOnly') ? 'Show all stores' : 'Only show stores with availability'}</span>
            </div>
        </div>
        );
      } else {
        return (
          productDetails.avgRating &&
          <div>
          <div className="rating-container">
              <div className="prod-image-container">
                  <div className="pmp-rate-image" style={{width:getRatingsWidth}}></div>
              </div>
              <div className="avg-count">
                  ({productDetails.ratingCount} Reviews)
              </div>
            </div>
            <div className={props.haveAtleastOne && props.calledBy !== 'checkout' ? 'show-stores-availability'  : 'show-stores-availability hide'}>
                <span onClick={eventHandlers.handleSortClick}>{(props.sortResult === 'availableOnly') ? 'Show all stores' : 'Only show stores with availability'}</span>
            </div>
          </div>
        );
      }
    };

    return <div id="fis-modal" className="m-fis-modal" onKeyPress={eventHandlers.frmSubmit}>
      <div id="mcom-fis-modal">
        <div className="fis-modal-header">
          <div id="cancel-btn" onClick={eventHandlers.handleModalCloseClick} >Cancel</div>
          <div className="modal-title">Find in Store</div>
        </div>
        <div className="modal-body">
          <div className="fis-container">
            <div className="fis-search-box">
              <div className="fis-search-box-body">
                <div className="fis-pin-image-container" onClick={eventHandlers.storesNearMe}>
                  <div className="fis-pin-image"></div>
                </div>
                <div className="fix-text-box-container">
                  <div className="fis-search-icon"></div>
                  <form action="." onSubmit={e => e.preventDefault()}><input id="autocomplete" placeholder="Enter a Location or ZIP" onFocus={window.setGeolocationBound} onKeyUp={eventHandlers.handleClearIconTextInput} type="text" className="fix-text-box" value={props.postalCode} onChange={eventHandlers.inputSearchHandle}></input></form>
				          <input type="button" className="clear-search" value="" onClick={eventHandlers.handleClearIconClick} ></input>
				        </div>
              </div>
            </div>
            <div className="fis-product-detail">
             <div className="fis-img-block">
              <img width="80px" height="80px"src={selectedSkus.images[0].url} />
			       </div>
      			 <div className="fis-details-block">
      			   <div className="productDetailsMargin">
               <div>{productDetails.productTitle}</div>
				{salePriceMarkup}
				{origPriceMarkup}
				{(selectedSkus.size !== null) ? <div><span>Size: </span><span>{selectedSkus.size}</span></div>	: ''}
      			   <div><span>SKU: </span><span>{selectedSkus.skuCode}</span></div>
               {<ReviewRating {...this.props} />}
               </div>
      			 </div>
            </div>
          </div>
				{(props.availabilityList.length < 1) ? <div className="noResult">{noResult}</div> : props.availabilityList.map((inventory, index) => this.StoreAvailability(props,inventory, inventory.storeNum))}

        </div>
        {!props.isCartModal && props.continueShopModel && <ContinueShopModal {...props} />}
      </div>
	  <div className="find-in-store-overlay" onClick={eventHandlers.handleCancelClick}></div>
    </div>
  }

}
