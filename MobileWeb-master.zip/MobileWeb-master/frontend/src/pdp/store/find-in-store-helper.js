import createFindInStoreModal from './find-in-store-container';
import * as utils from '../../global/utils';

const reactContainerElementId = 'login-modal-container';

export function init(FindInStoreView, selectedProduct, containerElementId, calledBy, successCallback){
	if(!containerElementId) {
    containerElementId = reactContainerElementId;
  }
  if(!calledBy) {
    calledBy = 'pdp';
  }
  const FindInStoreModal = createFindInStoreModal(FindInStoreView, successCallback);
  ReactDOM.render((
      <FindInStoreModal selectedProduct={selectedProduct} calledBy={calledBy}/>
  ), document.getElementById(containerElementId));
}

export function unmountModal(){
  ReactDOM.unmountComponentAtNode(document.getElementById(reactContainerElementId));
}


