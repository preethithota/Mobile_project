import React from 'react';
import ReactDOM from 'react-dom';
import * as findInStoreHelper from './find-in-store-helper';
import * as utils from '../../global/utils';
import * as cart from '../../global/cart-helper';
import * as locationUtils from '../../global/location-utils';
import {setFindInStoreSearchOmniture} from '../../../public/lib/omniture-util';

export default function createFindInStoreModal(FindInStoreView, successCallback){
  const clientKey = 'gme-kohlsdepartmentstores';
  let googleMapObj = null,
      locationInfowindow = null,
      markers = [],
      findInStoreGoogleMapOptionsObj = null;
  return class extends React.Component{

    constructor(props){
      super(props);
      this.eventHandlers = this.eventHandlers.bind(this);
      this.product = props.selectedProduct.selectedSkus[props.selectedProduct.selectedSkus.length - 1];
      this.googleApi;
      const showSignUp = (this.props.showCreateAccount) ? true : false;
      let autocomplete;
      let addressComponent = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      // map integration custom message
      this.fisCommonErrorMessage = {
          SERVICE_TURNED_OFF: 'Your location services are currently turned off. Please enable the location services and proceed',
          UNAVAILABLE: 'Location information is unavailable.',
          VALIDZIPCODE: 'Please enter valid city and state combination or zip code. City and State should be separated by a comma.',
          WITHIN50MILES: 'We couldn\'t find a store within 50 miles of your search. You can try a different search or find a store by state.',
          NOSEARCHRESULT: 'We couldn\'t find your location. Please try again or enter a city or ZIP code.',
          NOCURRENTLOCATION: 'Cannot Determine the Current Location'
      };

      //methods from google api, callback
      window.initGoogleAutocomplete = function () {
          let googleApi = new google.maps.DistanceMatrixService;
          autocomplete = new google.maps.places.Autocomplete(
              /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
              {types: ['geocode'], country: 'us'});
          autocomplete.addListener('place_changed', findAddressComponents);

          if(kohlsData.isTcom) {
            this.initializeGoogleMap();  // call only for tcom
          }
      }.bind(this);

      //Callback for geocode api, to get address components
      window.findAddressComponents = function () {

        var self = this;
        let place = autocomplete.getPlace();
        let selectedLoc = {};
        if (place.address_components) {
          for (var i = 0; i < place.address_components.length; i++) {
            var addressType = place.address_components[i].types[0];
            if (addressComponent[addressType]) {
              selectedLoc[addressType] = place.address_components[i][addressComponent[addressType]];
            }
          }
        } else if(Number(place.name) && place.name.length === 5) {
          selectedLoc.postal_code = place.name;
        }
        self.setState({postalCode: document.getElementById('autocomplete').value, isChecked: false});
          //window.fisSelectedLocation = selectedLoc;
          /**
           * make inventory call and update availability list
           */

            self.updateAvailabilityList(this.product ? this.product.skuCode : "", selectedLoc.postal_code, selectedLoc.locality, selectedLoc.administrative_area_level_1);

      }.bind(this);

      //set geolocation bound to the area
       window.setGeolocationBound = function () {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      };

      this.state = {
        availabilityList: [],
        allData: [],
        sortResult: 'all',
        inputQuantity: {},
        continueShopModel: false,
        haveAtleastOne: false,
        fisErrorMessage: this.fisCommonErrorMessage.NOSEARCHRESULT,
        isSort: false,
        postalCode: '',
        myStoreLatLng: [],
        isChecked: false
      };
    }


  componentDidMount(){
    var self = this;
    var script = document.createElement('script');
    var myLocation = utils.getCookieValue('myLocation');
    var postalCode = (utils.checkEmptyString(myLocation)) ? JSON.parse(myLocation).zipCode.long_name : '';
    var geoip_lat = utils.getCookieValue('geoip_lat');
    var geoip_lng = utils.getCookieValue('geoip_lng');
    var myStoreLatitude = utils.getCookieValue('myStoreLatitude');
    var myStoreLongitude = utils.getCookieValue('myStoreLongitude');
    var myStore = utils.getCookieValue('mystore');

    self.setState({postalCode: postalCode, myStoreLatLng: {latitude: myStoreLatitude, longitude: myStoreLongitude}});

    script.src = "https://maps.googleapis.com/maps/api/js?client="+ clientKey + "&libraries=places&callback=initGoogleAutocomplete";
    document.getElementsByTagName('head')[0].appendChild(script);

    // if(!this.product) {
    //   utils.updateStores();
    //   utils.updateStoreTypes();
    // }
    /* When user comes from other pages
     *Check for user's location and call inventory service
     */
    var locationasked = utils.getCookieValue('locationasked');
    var ratingContainer = document.getElementById("BVRRSummaryContainer");
    if(kohlsData.isTcom !== true && self.props.calledBy === 'checkout' && ratingContainer && (ratingContainer.innerHTML === '')) {
      $.getScript(kohlsData.bazarVoicemcomApiURL, function( data, textStatus, jqxhr ) {
          $BV.ui("rr", "show_reviews", {
               productId : self.props.selectedProduct.webID
          });
      });
    }
    if (!locationasked) {
      self.setState({postalCode: '', availabilityList: []});
      return false;
    }

    if(myStore && !myLocation){ 
      postalCode = JSON.parse(myStore).zipcode;
      self.setState({postalCode: postalCode});
    }
     
    if (utils.checkEmptyString(postalCode) || (utils.checkEmptyString(geoip_lat) && utils.checkEmptyString(geoip_lng))) {
        //call inventory for
        this.updateAvailabilityList(this.product ? this.product.skuCode : "", postalCode, '', '', geoip_lat, geoip_lng);
    }

  }

  searchNearBy() {
    var myLocation = utils.getCookieValue('myLocation');
    var postalCode = (utils.checkEmptyString(myLocation)) ? JSON.parse(myLocation).zipCode.long_name : '';
    var geoip_lat = utils.getCookieValue('geoip_lat');
    var geoip_lng = utils.getCookieValue('geoip_lng');
    var userLocation = null;
	  var geoLocationOptions = {
		  timeout: 10 * 1000,
		  enableHighAccuracy: false
	  };
    var locationasked = utils.getCookieValue('locationasked');
    this.setState({isSort: false});

    if (!locationasked) {
      this.setGoogleMapGeocoder();
      this.setState({availabilityList: [], fisErrorMessage: this.fisCommonErrorMessage.NOSEARCHRESULT});
      this.findInStoreGoogleMapOptions().removeFindInStoreMarker();
      return;
    } else {
      this.setState({postalCode: postalCode});
    }

    if (utils.checkEmptyString(postalCode) || (utils.checkEmptyString(geoip_lat) && utils.checkEmptyString(geoip_lng))) {
        this.updateAvailabilityList(this.product ? this.product.skuCode : "", postalCode, '', '', geoip_lat, geoip_lng);
    } else {
      var geoLocationSuccess = function(position) {
        userLocation = position;
        let loc = {latitude: userLocation.coords.latitude, longitude: userLocation.coords.longitude};
        utils.setCookieValue('geoip_lat', loc.latitude);
        utils.setCookieValue('geoip_lng', loc.longitude);
        utils.setCookieValue('locationasked', true);
        locationUtils.geoCodeLatLng(loc.latitude, loc.longitude);
        locationUtils.getNearByStoreList(loc.latitude, loc.longitude, 50);
        this.updateAvailabilityList(this.product ? this.product.skuCode : "", postalCode, '', '', loc.latitude, loc.longitude);
      }.bind(this);
      var geoLocationError = function(error) {
        this.setState({availabilityList:[]});
        if (error.code === 1 || error.code === 2) {
          (kohlsData.isTcom) ?
          this.setState({fisErrorMessage: this.fisCommonErrorMessage.SERVICE_TURNED_OFF}) :
          alert(this.fisCommonErrorMessage.SERVICE_TURNED_OFF);
        } else {
          (kohlsData.isTcom) ?
          this.setState({fisErrorMessage: this.fisCommonErrorMessage.UNAVAILABLE}) :
          alert(this.fisCommonErrorMessage.UNAVAILABLE);
        }

      }.bind(this);
      navigator.geolocation.getCurrentPosition(geoLocationSuccess, geoLocationError, geoLocationOptions);
    }
  }

/**
 * Update the list of store based on product avalability
 * @param {number} sku - SKU number of product.
 * @param {number} postalCode - Zip code of the area.
 * @param {string} city - City name of the location.
 * @param {string} state - State name of the location.
 * @param {number} lat - Latitude of current location.
 * @param {number} lng - Longitude of current location.
 * @param {number} radius - Radius to search for stores.
 * @returns sets state with list of stores
 */
  updateAvailabilityList(sku, postalCode = '', city = '', state = '', lat = '', lng ='', radius = 50 ){
    var self = this;
    var storesArray;
	setFindInStoreSearchOmniture(postalCode,city,state);
    /** Praveen's code start */

    // if(!sku) {
    //   $.ajax({
    //     url: '/api/v1/stores?&radius=' + radius + '&postalCode=' + postalCode,
    //     dataType: 'json',
    //     cache: true
    //   }).done(function(data) {
    //     let activeDimensions = 'InStoreOnline%3APick%20Up%20in%20Store';
    //     /* InStoreOnline:Online Only+InStoreOnline:Pick Up in Store */
    //     for(var i=0; i < window.catalogData.activeDimensions.length; i++) {
    //       let activeDimension = window.catalogData.activeDimensions[i];
    //       for(var j=0; j < activeDimension.activeDimensionValues.length; j++) {
    //         let activeDimensionValue = activeDimension.activeDimensionValues[j];
    //         activeDimensions += activeDimensionValue.ID + '+';
    //       }
    //     }

    //     if(activeDimensions) {
    //       activeDimensions = activeDimensions.substring(0, activeDimensions.length - 1);
    //     }

    //     let storesList = [];
    //     if(!data.payload) {
    //       self.setState({
    //         availabilityList: [],
    //       });
    //       return;
    //     }
    //     let storeListSize = 0;
    //     let topStoresInfo = "";
    //     window.catalogData.stores = {};
    //     if (data.payload.stores.length > 0) {
    //       storesArray = data.payload.stores;
    //       let stores = JSON.parse(utils.getFromLocalStorage("closeststore"))
    //       if(stores) {
    //         storeListSize = 4;
    //       } else {
    //         storeListSize = 5;
    //       }
    //       for (let i=0 ;i < data.payload.stores.length && i < storeListSize; i++) {
    //         storesList.push(data.payload.stores[i].storeNum);
    //         topStoresInfo += data.payload.stores[i].storeNum + "|" + data.payload.stores[i].storeName + ",";
    //         window.catalogData.stores[data.payload.stores[i].storeNum] = false;
    //       }
    //       topStoresInfo = topStoresInfo.substring(0, topStoresInfo.length - 1);
    //     }
    //     utils.putInLocalStorage("topStoresInfo", topStoresInfo);
    //     if (storesList.length > 0 && activeDimensions) {
    //         let stores = storesList.join();
    //         $.ajax({
    //           url: '/api/v1/catalog/productCount/' + activeDimensions + '?storeNum=' + stores + "&keyword=" + window.catalogData.searchTerm,
    //           dataType: 'json',
    //           cache: true
    //         })
    //         .done(function(data) {
    //           let availabilityList = [];
    //           for(var i=0; i < storesArray.length && i < storeListSize; i++) {
    //             for(var j=0; j < data.payload.stores.length; j++) {
    //               if(storesArray[i].storeNum == data.payload.stores[j].storeNum) {
    //                 storesArray[i].availableProductCount = data.payload.stores[j].availableProductCount;
    //               }
    //             }
    //             availabilityList.push(storesArray[i]);
    //           }
    //           self.setState({
    //             availabilityList: availabilityList,
    //           });
    //         })
    //         .fail(function(xhr){
    //           console.log('error', xhr);
    //         });
    //     } else {
    //       self.setState({
    //         availabilityList: [],
    //       });
    //     }
    //   }).fail(function(xhr) {
    //     console.log('error', xhr);
    //   });
    //   /*let topFiveStores = data.payload.stores;
    //   if(data.payload.stores.length > 5) {
    //     topFiveStores = topFiveStores.splice(0, 5);
    //   }
    //   self.setState({
    //     availabilityList: topFiveStores
    //   });*/
    //   return;
    // }

/** Praveen's code end */


    /**
     * Get store list
     */
    $.ajax({
      url: '/api/v1/stores?latitude=' + lat + '&longitude=' + lng + '&radius=' + radius + '&postalCode=' + postalCode + '&city=' + city + '&state=' + state,
      dataType: 'json',
      cache: true
    })
    .done(function(data) {
      let storesList = [];
      if (data.payload.stores.length >= 1 ) {
        for (let i=0 ;i < data.payload.stores.length; i++) {
          storesList.push(data.payload.stores[i].storeNum);
        }
        storesArray = data.payload.stores;
      }
      /**
       * Call inventory service for these stores
       */
      if (storesList.length >= 1 ) {
          let stores = storesList.join();
          $.ajax({
            url: '/api/v1/inventory/sku/' + sku + '?storeNum=' + stores + '&channel=store',
            dataType: 'json',
            cache: true
          })
          .done(function(data){
            let availabilityList = [];
            let inputQuantity = {};
            availabilityList = self.createAvailabilityList(data, storesArray);
            let haveAtleastOne = false;
            if(availabilityList && availabilityList.length) {
              for (let i = 0; i < availabilityList.length; i++) {
                if(availabilityList[i].availability === 'In Stock' || availabilityList[i].availability === 'Low Stock') {
                  inputQuantity['inpQuantity-' + availabilityList[i].storeNum] = 1;
                }
                haveAtleastOne = haveAtleastOne || availabilityList[i].availability === 'In Stock' || availabilityList[i].availability === 'Low Stock';
              }
            }
            //show only available store if called from checkout flow
            if (self.props.calledBy === 'checkout' ) {
              availabilityList = availabilityList.filter(function(obj){
                return (obj.availability === 'Out of Stock') ? false : true;
              });
            }
            self.setState({
              availabilityList: availabilityList,
              allData: availabilityList,
              sortResult: 'all',
              inputQuantity: inputQuantity,
              haveAtleastOne: haveAtleastOne,
              fisErrorMessage: null
            });
            if (kohlsData.isTcom) {
              self.addFindInStoreMarker(availabilityList);
            }

            self.createDistanceMatrix(city, state, lat, lng, availabilityList);
            })
          .fail(function(xhr){
            console.log('Error in inventory API', xhr);
            self.setState({fisErrorMessage: self.fisCommonErrorMessage.NOSEARCHRESULT});
          });
      }

    })
    .fail(function(xhr) {
      console.log('Error in Stores API', xhr);
      self.setState({fisErrorMessage: self.fisCommonErrorMessage.NOSEARCHRESULT});
    });
  }
  /**
   * Initialize Google Map
   */
  initializeGoogleMap() {
      var googleMapProp = {
          zoom: 10,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          zoomControl: false,
          mapTypeControl: false,
          panControl: false,
          streetViewControl: false,
          scrollwheel: true,
          disableDoubleClickZoom: true
      };
      googleMapObj = new google.maps.Map(document.getElementById("findInStoreGoogleMap"),googleMapProp);
      this.setGoogleMapGeocoder();
  }
  /**
   * Set the default Google Map Geocoder like "US"
   */
  setGoogleMapGeocoder() {
    var googleMapGeocoder = new google.maps.Geocoder;
        googleMapGeocoder.geocode({
            address: "US"
        }, function(googleMapGeocoderData) {
            if (googleMapGeocoderData && googleMapGeocoderData[0] && googleMapGeocoderData[0].geometry && googleMapGeocoderData[0].geometry.viewport) {
                googleMapObj.fitBounds(googleMapGeocoderData[0].geometry.viewport)
            }
        })
  }
  /**
   * Placed Google Map Marker
   * @param {object} availabilityList - list of stores.
   */
  addFindInStoreMarker(availabilityList) {
    let bounds = new google.maps.LatLngBounds(),
      iconSetting = {
        url: '../../images/googlemapmarker.png',
        // This marker is 20 pixels wide by 32 pixels high.
        scaledSize: new google.maps.Size(25,35),
        // The origin for this image is (0, 0).
        origin: new google.maps.Point(0, 0),
        // The anchor for this image is the base of the flagpole at (0, 32).
        anchor: new google.maps.Point(0, 0),
        // set label position for this image
        labelOrigin: new google.maps.Point(12, 13)
      },
      labelSettings = {
        color: "#00add0",
        fontSize: "10px",
        fontWeight: "bold"
      };
    if(!findInStoreGoogleMapOptionsObj) {
      findInStoreGoogleMapOptionsObj = this.findInStoreGoogleMapOptions();
    }    
    findInStoreGoogleMapOptionsObj.removeFindInStoreMarker();
    findInStoreGoogleMapOptionsObj.resetHighlightedStore(true);
    availabilityList.forEach(function(storeObj, key) {
      let store = storeObj.storeDetail,
        latLng = new google.maps.LatLng(storeObj.storeDetail.address.location.latitude, storeObj.storeDetail.address.location.longitude);

      labelSettings.text = '' + (key + 1);
      markers.push(new google.maps.Marker({
        map: googleMapObj,
        label: labelSettings,
        icon: iconSetting,
        title: store.storeName,
        position: latLng
      }));

      google.maps.event.addListener(markers[key],'click', this.showFindInStoreInfoWindow(markers[key], key, storeObj));
      bounds.extend(latLng);
    }.bind(this));
    googleMapObj.fitBounds(bounds);
  }
  /**
   * Get the dynamic store address
   * @param {object} storeObj - selected store details.
   * @returns store address
   */
  getInfoContent(storeObj) {
    let store = storeObj.storeDetail,
      selectedStore = (this.state.myStoreLatLng.latitude === store.address.location.latitude &&
      this.state.myStoreLatLng.longitude === store.address.location.longitude),
      myStore = (selectedStore) ? 'fis-selection-infowindow FL display-block' : 'fis-selection-infowindow FL display-none',
      makeStore = (!selectedStore) ? 'direction-make-store-cont FL display-block' : 'direction-make-store-cont FL display-none';
    return (
      `<div class="location-info-window">
        <div class="store-name">${store.storeName}</div>
        <div class="store-address1">${store.address.addr1}</div>
        <div class="store-address2">
          <span class="store-city">${store.address.city}</span>
          <span class="store-state">, ${store.address.state}</span>
          <span class="store-postalCode">, ${store.address.postalCode}</span>
        </div>
        <div class="store-phoneno">${store.address.phoneNumber}</div>
        <div class="store-distance">Approx ${store.distanceFromOrigin} mi away</div>
        <div class="statusBlock">
          ${storeObj.availability === 'Out of Stock' ? '<div class="status-image FL"><span class="red-close"></span><span class="available-stock">Not Available</span></div>' : 
            storeObj.availability === 'Limited Stock' ? '<div class="status-image FL"><span class="tick-icon"></span><span class="available-stock">Limited Available</span></div>' : 
            storeObj.availability === 'In Stock' ? '<div class="status-image FL"><span class="tick-icon"></span><span class="available-stock">Available</span></div>' : '' }
        </div>
        <div class="tcom-only-block">
          <div class="store-direction FL" id="direction">
            <div class="directionsImg"></div>
            <div class="direction-make-store-cont direction fis-direction">DIRECTIONS</div>
          </div>
          <div id="my_store" class="${myStore}">
            <div class="fis-home-icon"></div>
            <div class="direction-make-store-cont direction fis-direction">MY STORE</div>
          </div>
          <div id="make_store" class="${makeStore}">
            <div class="makeStore">MAKE THIS <br/>MY STORE</div>
          </div>
        </div>
      </div>`
    );
  }
  /**
   * Displayed information window
   * @param {array} marker - marker object.
   * @param {integer} key - selected store index.
   * @param {object} storeObj - selected store details.
   * @param {object} findInStoreGoogleMapOptionsObj - get the estential methods.
   */
  showFindInStoreInfoWindow(marker, key, storeObj) {
    return function() {
      var self = this;
      findInStoreGoogleMapOptionsObj.resetHighlightedStore();
      if(locationInfowindow) {
        locationInfowindow.close();
      }
      locationInfowindow = new google.maps.InfoWindow({
        content: this.getInfoContent(storeObj),
        maxWidth: 250,
        storeLocation: storeObj.storeDetail.address.location
      });
      google.maps.event.addListener(locationInfowindow, "domready", function() {
        findInStoreGoogleMapOptionsObj.setInfoWindowBorderColor();
        var makeStore = document.getElementById('make_store'),
          direction = document.getElementById('direction');
        if(makeStore) {
          makeStore.onclick = function() {
            self.eventHandlers().handleMakeMyStoreClick(this.storeLocation);
          }.bind(this);
        }
        if(direction) {
          direction.onclick = function() {
            self.eventHandlers().handleDirectionClick(this.storeLocation);
          }.bind(this);
        }
      });
      locationInfowindow.open(googleMapObj, marker);
      findInStoreGoogleMapOptionsObj.setHighlightedStore(key);
    }.bind(this);
  }
  /**
   * Google Map estential function
   * @returns {function} resetHighlightedStore - remove highlighted class
   * @returns {function} setHighlightedStore - add highlighted class
   * @returns {function} setInfoWindowBorderColor - set background color for info window
   * @returns {function} removeFindInStoreMarker - remove existing marker
   * @returns {function} scrollToMove - move up and down
   */
  findInStoreGoogleMapOptions() {
    var fisResults = document.getElementsByClassName('fis-results')[0],
      scrollTopFISResults = fisResults && fisResults.scrollTop,
      offsetTopFISResults = fisResults && fisResults.offsetTop + fisResults.offsetParent.offsetTop + document.body.scrollTop,
      previousSelectedDiv = 0;
    return {
      resetHighlightedStore: function(flag=false) {
        var resultCountDiv = fisResults.querySelectorAll('div.result-count.selected');
        previousSelectedDiv = resultCountDiv.length>0 ? resultCountDiv[0].offsetTop + resultCountDiv[0].offsetParent.offsetTop + document.body.scrollTop : 0;
        resultCountDiv.length > 0 && resultCountDiv[0].classList.remove('selected');
        flag && this.scrollToMove(fisResults, 0, 0);
      },
      setHighlightedStore: function(key) {
        var fisResultsFindStore = fisResults.querySelectorAll('div.result-count')[key],
          offsetTopFISResultsFindStore = (fisResultsFindStore.offsetTop + fisResults.offsetParent.offsetTop) - scrollTopFISResults,
          currentSelectedDiv = (offsetTopFISResultsFindStore + scrollTopFISResults) - offsetTopFISResults;
          fisResultsFindStore.classList.add('selected');
        this.scrollToMove(fisResults, previousSelectedDiv, currentSelectedDiv);
      },
      setInfoWindowBorderColor: function() {
        var gmStyle = document.getElementsByClassName('gm-style-iw')[0],
          previousDiv = gmStyle && gmStyle.previousSibling,
          arrowDiv = previousDiv && previousDiv.children[2];
        if(previousDiv){
          previousDiv.children[3].style.border = "4px solid #95C96F";
        }
        if(arrowDiv){
          arrowDiv.children[1].children[0].style.backgroundColor = "#95C96F";
          arrowDiv.children[0].children[0].style.backgroundColor = "#95C96F";
        }
      },
      removeFindInStoreMarker: function() {
        markers.forEach(function(marker) {
          marker.setMap(null);
        });
        markers = [];
      },
      scrollToMove: function(element, from, to, duration=500) {
        var callback = function(from, duration) {
          var difference = to - from,
            perMove = difference / duration * 10;
          setTimeout(function() {
            var scrollFrom = from + perMove;
            if (from === to) return;
            element.scrollTop = scrollFrom;
            callback(scrollFrom, duration - 10);
          }.bind(this), 10);
        };
        callback(from, duration);        
      }
    }
  }
  createDistanceMatrix(city = '', state = '', lat = '', lng ='', availabilityList) {
    var self = this;
    let origin = '';
    let destinations = [];
    if (utils.checkEmptyString(lat) && utils.checkEmptyString(lng)) {
        origin = new google.maps.LatLng(lat, lng);
    } else if ((utils.checkEmptyString(city) && utils.checkEmptyString(state))) {
        origin = city +','+state;
    } else {
        return [];
    }

    if (availabilityList.length >= 1) {
      for (let i=0; i < availabilityList.length; i++) {
          let latitude = availabilityList[i].storeDetail.address.location.latitude;
          let longitude = availabilityList[i].storeDetail.address.location.longitude;
          let dest = new google.maps.LatLng(latitude, longitude);
          destinations.push(dest);
      }
    }

    if (utils.checkEmptyString(origin) && destinations.length > 0){
        var service = new google.maps.DistanceMatrixService();
        service.getDistanceMatrix(
          {
            origins: [origin],
            destinations: destinations,
            travelMode: 'DRIVING',
            unitSystem: google.maps.UnitSystem.METRIC
          }, callback);

        function callback(response, status) {
          let size = response && response.rows[0].elements.length;
          if (size > 0) {
            for (let i=0; i < size; i++) {
              availabilityList[i].timeToDrive = response.rows[0].elements[i].duration.text;
            }
            self.setState({
              availabilityList: availabilityList
            });

          }
      }
    }
  }
  /**
   * Update the list of store based on product avalability
   * @param {object} inventory - inventory object returned from inventory api call.
   * @param {object} stores - stores array returned from get store api.
   * @returns array of store and inventory data
   */
    createAvailabilityList(inventory, stores){
      var inventoryData = inventory.payload.skus[0].stores;

      /**
       * Iterate over stores and inventory data array to create avalability list
       */
      for (let i=0; i < inventoryData.length; i++) {
        for (let j=0; j < stores.length; j++) {
          if (stores[j].storeNum === inventoryData[i].storeNum) {
            inventoryData[i].storeDetail = stores[j];
            inventoryData[i].storeDetail.storeName = "KOHL's" + ' ' + inventoryData[i].storeDetail.storeName; //prefix kohl's
            inventoryData[i].storeDetail.address.addr1 = inventoryData[i].storeDetail.address.addr1.toLowerCase();
            inventoryData[i].storeDetail.address.city = inventoryData[i].storeDetail.address.city.toLowerCase();
            inventoryData[i].visible = true;
            inventoryData[i].timeToDrive = '';
          }
        }
      }

      return this.sortListByDistance(inventoryData);
    }

    sortListByDistance(inventoryData){
      var soretdInventoryData;
      if(inventoryData.length > 1) {
        soretdInventoryData = inventoryData.sort(function(a, b){
            return a.storeDetail.distanceFromOrigin - b.storeDetail.distanceFromOrigin;
        });
        return soretdInventoryData;
      } else {
        return inventoryData;
      }
    }

    sortStoreListByAvailability(sortResult){
      var self = this;
      var data = this.state.allData.filter(function(obj){
          if (sortResult === 'availableOnly') {
              return (obj.availability === 'Out of Stock') ? false : true;
          } else {
              return true;
          }
      }.bind(self));
      self.setState({
          availabilityList: data,
          fisErrorMessage: (!data.length) ? self.fisCommonErrorMessage.WITHIN50MILES: null
      });
      self.addFindInStoreMarker(data);
    }

    eventHandlers(){
      return {
        // addToBag: function(){
        // }.bind(this)
        handleModalCloseClick: function(){
          findInStoreHelper.unmountModal();
          document.body.classList.remove('find-in-store-mask')
        }.bind(this),
        // geoLocate: function(){
        //   findInStoreHelper.unmountModal();
        //   document.body.classList.remove('find-in-store-mask')
        // }.bind(this),
        handleStoreSelection: function(e, store) {
          var storeType = "InStoreOnline:Pick%20Up%20in%20Store";
          if(e.target.classList.contains("selected")) {
            e.target.classList.remove("selected");
            window.catalogData.stores[store.storeNum] = false;
            window.catalogData.storeTypes[storeType] = false;
          } else {
            e.target.classList.add("selected");
            window.catalogData.stores[store.storeNum] = true;
            window.catalogData.storeTypes[storeType] = true;
          }
          var isStoreSelected = document.getElementById("selectStoreArea").querySelector(".selected");
          if(isStoreSelected) {
            document.getElementById("pickUpInStore").classList.add("selected");
          } else {
            document.getElementById("pickUpInStore").classList.remove("selected");
          }
        }.bind(this),
        handleStoreTypeSelection: function(e) {
          var storeType = "InStoreOnline:Online%20Only";
          if(e.target.classList.contains("selected")) {
            e.target.classList.remove("selected");
            window.catalogData.storeTypes[storeType] = false;
          } else {
            e.target.classList.add("selected");
            window.catalogData.storeTypes[storeType] = true;
          }
        }.bind(this),
        handleSortClick: function(){
          var self = this;
          if(this.state.sortResult === 'all'){
            self.setState({
              sortResult: 'availableOnly',
              isSort: true,
              isChecked: true
            });
            self.sortStoreListByAvailability('availableOnly');
          } else {
            self.setState({
              sortResult: 'all',
              isSort: true,
              isChecked: false
            });
            self.sortStoreListByAvailability('all');
          }
        }.bind(this),
        handleHoursClick: function(storeNumber){
			var store = this.state.selectedStore || {};			
          if(this.state.selectedStore && this.state.selectedStore[storeNumber] === true) {
            store[storeNumber] = false;
          } else{
			  store[storeNumber] = true;
		  }
           this.setState({selectedStore: store});
          
        }.bind(this),
        handleMakeMyStoreClick: function(location){
          var storeLocation = location;
          var loc = {latitude: storeLocation.latitude, longitude: storeLocation.longitude};
          console.log(locationInfowindow);
          utils.setCookieValue('myStoreLatitude', loc.latitude);
          utils.setCookieValue('myStoreLongitude', loc.longitude);
          this.setState({
            myStoreLatLng: loc
          });
          if(locationInfowindow) {
            $('.location-info-window #my_store').removeClass('display-none').addClass('display-block');
            $('.location-info-window #make_store').removeClass('display-block').addClass('display-none');
          }
        }.bind(this),
        handleDirectionClick: function(latlng){
          var myLocationLatitude = utils.getCookieValue('geoip_lat'),
            myLocationLongitude = utils.getCookieValue('geoip_lng'),
            acceptMyLocation = (myLocationLatitude && myLocationLongitude) ? new google.maps.LatLng(myLocationLatitude, myLocationLongitude) : this.state.postalCode,
            storeLocation;
            if(acceptMyLocation) {
              storeLocation = (latlng.latitude && latlng.longitude) ? new google.maps.LatLng(latlng.latitude, latlng.longitude) : '';
            }
            if(storeLocation) {
              var directionUrl = "http://maps.google.com/?";
              directionUrl += "saddr=" + encodeURIComponent(acceptMyLocation);
              directionUrl += "&daddr=" + encodeURIComponent(storeLocation);
              window.open(directionUrl, '_blank')
            } else {
              alert(this.fisCommonErrorMessage.NOCURRENTLOCATION)
            }


        }.bind(this),
        addToBag: function(index){
          let product = this.props.selectedProduct.selectedSkus[this.props.selectedProduct.selectedSkus.length - 1];
          let storeNum = index;
          let quantity = parseInt(this.state.inputQuantity['inpQuantity-'+index], 10);
          let skuCode = product.skuCode;
          let isBopus = product.isBopusEligible;
          let webID = this.props.selectedProduct.webID;
          let isGift = false;
          let registryID = '-1';
          let collId = '-1';
          //show continue shopping modal
          //$('.t-login-mask').scrollTop(0);
          this.setState({continueShopModel: true});
          document.body.classList.add('modal-overlay');
          //call add to bag
          cart.addToBag(null, skuCode, webID, quantity, isGift, registryID, collId, isBopus, storeNum);
        }.bind(this),
        gotoCart: function(e) {
          this.setState({continueShopModel: false});        
          window.location.href = "/checkout/checkout.jsp#/shoppingBag";
        }.bind(this),
        gotoCheckout: function(e) {
          this.setState({continueShopModel: false});
          utils.goToCheckout();
			  }.bind(this),
        handleStoreSelection: function (index) {
          let storeNum = index;
          successCallback(storeNum);
          findInStoreHelper.unmountModal();
          document.body.classList.remove('find-in-store-mask')
        }.bind(this),
        handleCancelClick: function(){
          this.setState({continueShopModel: false});
          document.body.classList.remove('modal-overlay', 't-login-mask');
				}.bind(this),
        inputSearchHandle: function(e){
          this.setState({postalCode: e.target.value});
        }.bind(this),
        inputQuantityHandle: function(e){
          var valueAllowed = ""
          var value = e.target.value;
          var id = e.target.id;
          var minAllowed = parseInt(e.target.min);
          var maxAllowed = parseInt(e.target.max);

          valueAllowed = parseInt(value) > maxAllowed ?
                  value.slice(0,3) :
                  parseInt(value) < minAllowed ?
                  minAllowed :
                  value;

          const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: parseInt(valueAllowed,10)});
          this.setState({inputQuantity: newQuantity});
        }.bind(this),
        increseQuantity: function(e){
          e.preventDefault();
          var id = e.target.dataset.refid;
          let quantity = this.state.inputQuantity[id];
          if(parseInt(quantity) < 999) {
            const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: ++quantity});
            this.setState({inputQuantity: newQuantity});
          }
        }.bind(this),
        decreseQuantiy: function(e){
          e.preventDefault();
          var id = e.target.dataset.refid;
          let quantity = this.state.inputQuantity[id];
          if (parseInt(quantity) > 1){
            const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: --quantity});
            this.setState({inputQuantity: newQuantity});
          }
        }.bind(this),
        inputHandleBlur: function(e){
          var defaultValue = e.target.value || 1;
          var id = e.target.id;
          const newQuantity =  Object.assign(this.state.inputQuantity, {[id]: defaultValue});
          this.setState({inputQuantity: newQuantity});
        }.bind(this),
        userHandleDirection: function(searchTerm, addrLocation) {
          var direction = addrLocation.latitude && addrLocation.longitude ? new google.maps.LatLng(addrLocation.latitude,addrLocation.longitude) : "";
          var url = "http://maps.google.com/?saddr=" + encodeURIComponent(searchTerm) + "&daddr=" + encodeURIComponent(direction);
              window.open(url, "_blank");
        }.bind(this),
        handleClearIconTextInput: function(){
          let clearIcon = document.querySelector(".fix-text-box-container .clear-search");
          if(clearIcon) {
            clearIcon.style.visibility = "visible";
          }
        }.bind(this),
        handleClearIconClick: function(e){
            e.target.style.visibility = "hidden";
            let searchBox = document.querySelector(".fix-text-box-container .fix-text-box");
            searchBox.value = "";
            searchBox.focus();
        }.bind(this),
        storesNearMe: function(){
            this.searchNearBy();
        }.bind(this),
        showFindInStoreInfoWindow: function(index, storeObj){
            this.showFindInStoreInfoWindow(markers[index], index, storeObj)();
        }.bind(this)
      }
    }

    render(){
      return <FindInStoreView {...this.props} {...this.state}
        eventHandlers={this.eventHandlers()}
        />
    }
  }

}
