import React from 'react';
import ContinueShopModal from '../pdp-shop-model-view';
import {displayPrice} from '../pdp-helper';

export default class FindInStoreView extends React.Component{

    StockAvailability(props, index, flag, selectedStore) {
      const eventHandlers = props.eventHandlers;
        if(flag === 'qty') {
            return (
                <div className={"quantity-section " + (selectedStore ? 'fis_quantity_selection': '')}>
                    <div className="quantity-title">Quantity</div>
                    <div className="quantity-selector">
                      <div data-refid={'inpQuantity-'+index}
                         className={"m-black-plus-icon" + (props.inputQuantity['inpQuantity-'+index] === 1 ? " quantity-disabled" : "")}
                         onClick={eventHandlers.decreseQuantiy}>-</div>
                      <div className="quantity">
                        <input type='number' min="1" max="999" id={'inpQuantity-'+index}
                            value={props.inputQuantity['inpQuantity-'+index]}
                            onChange={eventHandlers.inputQuantityHandle}
                            onBlur={eventHandlers.inputHandleBlur} />
                      </div>
                      <div data-refid={'inpQuantity-'+index}
                         className={"m-black-plus-icon" + (props.inputQuantity['inpQuantity-'+index] === 999 ? " quantity-disabled" : "")}
                         onClick={eventHandlers.increseQuantity}>+</div>
                    </div>
                </div>);
        } else if(flag === 'addtobag'){
            return (
                <div className="add-to-bag-container">
                <button id="add-to-bag-btn" className="enabled" onClick={eventHandlers.addToBag.bind(null, index)}>Add to Bag</button>
              </div>);
        }
    }

    render(){
        const props = this.props;
        const eventHandlers = props.eventHandlers;
        const noResult = 'Enter your current location city or code to view a list of stores near you that have this product';
        const noSearchResult = "We couldn't find your location. Please try again or enter a city or ZIP code.";
        const productDetails = this.props.selectedProduct;
        const selectedSkus = productDetails.selectedSkus[this.props.selectedProduct.selectedSkus.length - 1];
        let selectedStore = false;
		let price = selectedSkus && selectedSkus.price;

		let priceObj = displayPrice(price);
 		const clsName = priceObj.isRedLabel ? "sale-price" : "blackLabel";
		const regPrice = priceObj.combainWithReg ? "or "+priceObj.regPrice+" each" : priceObj.regPrice;

		const salePriceMarkup = (priceObj.specialPrice) && (<div id="product-sale-price" className={clsName}>{priceObj.specialPrice}</div>);

		const origPriceMarkup = (price.regularPrice) ? (<div className="orig-price">{regPrice}</div>) : '';
		
        function ReviewRating(props) {
            return (
              productDetails.avgRating &&
              <div>
                <div className="prod-image-container">
                    <div className="pmp-rate-image"></div>
                </div>
                <div className="avg-count">
                    ({productDetails.ratingCount} Reviews)
                </div>
              </div>
            );
        };

        return <div id="fis-modal" className="t-fis-modal" onKeyPress={eventHandlers.frmSubmit}>
          <div id="tcom-fis-modal">
            <div className="fis-modal-header">
              <div className="modal-title">FIND IN STORE</div>
              <div className="cancel-btn" title="FIND IN STORE" onClick={eventHandlers.handleModalCloseClick}></div>
            </div>
            <div className="modal-body">
                    <div className="tcom-fis-modal-left">
                        <div><img width="80px" height="80px"src={selectedSkus.images[0].url} /></div>
                        <div>{productDetails.productTitle}</div>
                        <div>
						              {salePriceMarkup}
						              {origPriceMarkup}
                          {selectedSkus.color ? <div><span>Color : </span><span>{selectedSkus.color}</span></div>  : ''}
                          {(selectedSkus.size !== null) ? <div><span>Size : </span><span>{selectedSkus.size}</span></div> : ''}
                          <div><span>SKU: </span><span>{selectedSkus.skuCode}</span></div>
                        </div>
                        {<ReviewRating {...this.props} />}
                    </div>
                    <div className="tcom-fis-modal-middle" id="findInStoreGoogleMap">
                        Google Map
                    </div>
                    <div className="tcom-fis-modal-right">

                        <div className="fis-tcom-top-controls">
                            <div className="fis-tcom-search-cont" onClick={eventHandlers.storesNearMe}>
                                <div className="fis-tcom-search-label"> SEARCH NEAR YOU </div>
                                <div className="fis-tcom-search-img"></div>
                            </div>
                            <div className="fis-tcom-Sperate">OR</div>
                            <div className="fis-tcom-auto-complete">
                                <input id="autocomplete" placeholder="SEARCH CITY OR ZIP" onFocus={window.setGeolocationBound}  onKeyUp={eventHandlers.handleClearIconTextInput} type="text"></input>
                                <div className="fis-tcom-auto-complete-img"></div>
                            </div>
                        </div>
                        <div className="fis-error">
                        {(props.fisErrorMessage) && <div className="show-stores-availability">{props.fisErrorMessage}</div>}
                        </div>
                        {(props.availabilityList.length > 0 || props.isSort) &&
                            <div className="fis-sort-results ">
                                <input type="checkbox" id="t-fis-check-box" defaultChecked={false} checked={props.isChecked} onChange={eventHandlers.handleSortClick}/><label htmlFor="t-fis-check-box"></label>
                                    <span> Only show stores with availability </span>
                            </div>
                        }
                        <div className="fis-results">
                                {(props.availabilityList.length > 0) && props.availabilityList.map((inventory, index) => {
                                selectedStore = props.myStoreLatLng.latitude === inventory.storeDetail.address.location.latitude &&
                                props.myStoreLatLng.longitude === inventory.storeDetail.address.location.longitude;
                                return (
                                 <div className="fis-tcom-store-result">
                                     <div className="store-results-left">
                                        <div className="result-count" onClick={() => {eventHandlers.showFindInStoreInfoWindow(index, inventory)}}>{index + 1}</div>
                                     </div>
                                    <div className="store-results-middle">
                                        <div className="detailBlock">
                                            <div className="storeName">
                                                {inventory.storeDetail.storeName}
                                            </div>
                                            <div>
                                                {inventory.storeDetail.address.addr1}
                                            </div>
                                            <div>
                                                {inventory.storeDetail.address.city}, {inventory.storeDetail.address.state}, {inventory.storeDetail.address.postalCode}
                                            </div>
                                            <div>
                                                {(inventory.storeDetail.address.phoneNumber).replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3")}
                                            </div>
                                            <div>
                                               Approx {parseFloat(inventory.storeDetail.distanceFromOrigin).toFixed(1)} mi away
                                            </div>
                                        </div>

                                        <div className="statusBlock">
                                             {inventory.availability === 'Out of Stock' && <div className="status-image FL"><span className="red-close"></span><span className="available-stock">Not Available</span></div>}
                                             {inventory.availability === 'Limited Stock' && <div className="status-image FL"><span className="tick-icon"></span><span className="available-stock">Limited Available</span></div>}
                                             {inventory.availability === 'In Stock' && <div className="status-image FL"><span className="tick-icon"></span><span className="available-stock">Available</span></div>}
                                        </div>
                                        {(inventory.availability === 'Limited Stock' || inventory.availability === 'In Stock') && this.StockAvailability(props, index, 'qty', selectedStore)}
                                        <div className="storeHours" onClick={() => {eventHandlers.handleHoursClick(inventory.storeNum)}}>
                                            <div className={'km-iconCirclePlus store-hours-accordion ' + ((props.selectedStore && props.selectedStore[inventory.storeNum] == true) ? ' km-iconCircleMinus' : '')}></div>
                                            <div className="store-hours-label">STORE HOURS</div>
                                        </div>
                                        <div className={'store-hours-accordion-content' + (props.selectedStore && props.selectedStore[inventory.storeNum] == true ? '' : ' hide')} >
                                            {inventory.storeDetail.storeHours.days.map((day, key) => {
                                                return (
                                                    <div  className="store-timing" key={key}><span className="day">{day.name}</span>:{day.hours.open} - {day.hours.close}</div>
                                                );
                                            })}
                                        </div>
                                     </div>
                                    <div className="store-results-right">
                                        <div className="tcom-only-block direction-make-store-cont">
                                            <div className="directionsImg"></div>
                                            <div className="direction-make-store-cont direction fis-direction" onClick={() => {eventHandlers.handleDirectionClick(inventory.storeDetail.address.location)}}>DIRECTIONS
                                            </div>
                                            { selectedStore ? (
                                                <div className="fis-selection FL">
                                                    <div className="fis-home-icon"></div>
                                                    <div className="direction-make-store-cont direction fis-direction">MY STORE</div>
                                                </div>) : (<div className="direction-make-store-cont makeStore" onClick={() => {eventHandlers.handleMakeMyStoreClick(inventory.storeDetail.address.location)}}>MAKE THIS MY STORE</div>)
                                            }
                                         {(inventory.availability === 'Limited Stock' || inventory.availability === 'In Stock') && this.StockAvailability(props, index, 'addtobag', selectedStore)}
                                        </div>
                                     </div>
                                </div>
                                );
                            })}
                        </div>

                    </div>
            </div>
            {!props.isCartModal && props.continueShopModel && <ContinueShopModal {...props} />}
          </div>
          <div className="find-in-store-overlay" onClick={eventHandlers.handleCancelClick}></div>
        </div>


    }

}
