import React from 'react';
import {labels} from '../global/label-utils';
import * as utils from '../global/utils';
import OffersView from './offers/offers-view';


export default  React.createClass({
    render: function(){
        /**
         * accordionMetaData used as source to generate html
         */
        const accordionMetaData = [{attributeKey: 'productDetails', title: 'Product Details'},
            {attributeKey: 'shippingAndReturn', title: 'Shipping & Returns'},
            {attributeKey: 'relatedInformation', title: 'Related Information'},
            {attributeKey: 'ingredients', title: 'Ingredients'},
            {attributeKey: 'careInstructions', title: 'Care Instructions'},
            {attributeKey: 'rebate', title: 'Rebates'},
            {attributeKey: 'pricingDetails', title: 'Pricing Details'}];
        const props = this.props;
		const product = props.data.payload.products[0];
    	const eventHandlers = props.eventHandlers;

        /**
         * assign htmlId and data properties to accordionMetaData array
         * htmlId - div Id of accordion row container
         * data - accordion inner data
         */
        var accordion = accordionMetaData.filter(obj => {
            let accordionHtmlIdPrefix = 'acc-';
            switch(obj.attributeKey) {
                case 'productDetails':
                    if (utils.checkEmptyString(product[obj.attributeKey])) {
                        obj.htmlId = accordionHtmlIdPrefix + obj.attributeKey;
                        obj.data = (props.isTcom) ? product.productDetails : product.productDetails.replace(/<p>.*?<\/p>/, '');
                        obj.isComp=false;
                        return obj;
                    }
                    break;
                case 'rebate':
                    if (utils.checkEmptyString(product[obj.attributeKey]['longDescription'])) {
                        obj.htmlId = accordionHtmlIdPrefix + obj.attributeKey;
                        obj.data = product[obj.attributeKey]['shortDescription'] + product[obj.attributeKey]['longDescription'];
                        obj.isComp=false;
                        return obj;
                    }
                    break;
                default:
                    if (utils.checkEmptyString(product[obj.attributeKey])) {
                        obj.htmlId = accordionHtmlIdPrefix + obj.attributeKey;
                        obj.data = product[obj.attributeKey];
                        obj.isComp=false;
                        return obj;
                    }
            }

		});

        /**
         * add GWP and PWP accodions if it is Tcom
         * htmlId - div Id of accordion row container
         * data - accordion inner data
         */

        var gwpProduct = null;
        var pwpProduct = null;
        if (props.isTcom) {
            var prodOffers = product.productOffers;
            if(prodOffers) {
                let grpType = prodOffers[0].groupType;
                let itemType = prodOffers[0].itemType;
                if(grpType && itemType && itemType.toUpperCase() == "BUY") {
                    switch (grpType.toUpperCase()) {
                        case 'GWP':
                            accordion.push({attributeKey: 'gwpProduct', title: labels.GWPTxt, htmlId: 'acc-gwpProduct', data: <OffersView prdId={product.webID} />, isComp:true})
                            break;
                        case 'PWP':
                            accordion.push({attributeKey: 'pwpProduct', title: labels.PWPTxt, htmlId: 'acc-pwpProduct', data: <OffersView prdId={product.webID} />, isComp:true})
                            break;
                    }
                }
            }
        }

        /**
         * render
         * @return <Accordion> markup
         */
        return(
            <div className="pdp-accordion">
                {Array.apply(null, accordion).map(function(item, i){
					if(this.props.isTcom) {
						return (
							<div key={i} id={item.htmlId} className="product-info" onClick={() => {eventHandlers.handleInfoSectionClick(item.htmlId)}}>
								<div className="pdp-accordion-head">
									<div className={'km-iconCirclePlus' + ((props.selectedSection === item.htmlId) ? ' km-iconCircleMinus' : '')}></div>
									<div className="pdp-accordion-title">{item.title}</div>
								</div>
								{!item.isComp?<div className={'content' + (props.selectedSection === item.htmlId ? '' : ' hide')} dangerouslySetInnerHTML={{__html: item.data}} />:<div className={'content' + (props.selectedSection === item.htmlId ? '' : ' hide')}>{props.selectedSection === item.htmlId && item.data}</div>}
							</div>
						);
					} else {
						return (
							<div key={i} id={item.htmlId} className="product-info" onClick={() => {eventHandlers.handleInfoSectionClick(item.htmlId)}}>
								<div className="pdp-accordion-head">
									<div className="pdp-accordion-title">{item.title}</div>
									<div className={'pdp-accordion-close' + ((props.selectedSection === item.htmlId) ? ' pdp-accordion-open' : '')}></div>
								</div>
								{(item.attributeKey === 'productDetails') ? <div className="pdp-accordion-short-desc" dangerouslySetInnerHTML={{__html: product.productDetails.match(/<p>.*?<\/p>/)}} /> : ''}
								<div className={'content' + (props.selectedSection === item.htmlId ? '' : ' hide')} dangerouslySetInnerHTML={{__html: item.data}} />
							</div>
						);
					}
                }, this)}
			</div>
        );
    }
});
