import React from 'react';
import * as utils from '../global/utils';
import {labels} from '../global/label-utils';
import ShopModel from './pdp-shop-model-view';
import QuantityView from './quantity/quantity-view';
import AddtobagView from './addtobag/pdp-addtobag-view';
import {displayPrice} from './pdp-helper';

export default React.createClass({

	showMore:false,
	highlightSale:false,
	slideImages: function(offset){
		$( '#image-carousel' ).animate({
    		'margin-left': offset
  		}, 200, function() {});
	},
	swatchImages: function(product,item){
		let props = this.props;
		var swatchMarkup;
		if(product.swatchImages && product.swatchImages.length > 0){
			var defaultSwatchLimit = 20;
			var toggleAllColorsMessage = (props.showAllColors) ? 'SHOW FEWER COLORS' : 'SHOW MORE COLORS';
			var showToggleAllColors = (product.swatchImages.length > defaultSwatchLimit);
			var selColor = (props.collection["swatch-image-"+item] && props.collection["swatch-image-"+item].clr) || props.data.payload.products[0].collection[item].preSelectedColor
			swatchMarkup = (
				<div id="swatch-section">
					<h3>COLOR: <span>{selColor}</span></h3>
					<div id="swatches" className={(!props.showAllColors) ? 'limited-swatch-height' : ''}>
					{product.swatchImages.map((swatchImage, index) => {
						var swatchImgUrl = utils.getImageUrl(swatchImage.URL, 55, (index > (defaultSwatchLimit - 1) && !props.showAllColors));
						var available = (props.collection["productSizeCln-"+item] === '' || (props.collection["colorAvl-productSizeCln-"+item] ? props.collection["colorAvl-productSizeCln-"+item][swatchImage.color]:swatchImage.color));
						var availablityImage = (available) ? '' : (<div className="swatch-unavailable"><img src="/images/swatch_unavailable.png" /></div>);
						return(
							<div className="swatch" key={index}>
								<a href="#" title={swatchImage.color +' color'} className={selColor == swatchImage.color ? "colr-selected" : ""} onClick={props.eventHandlers.handleSwatchClick}>
									<img className={"swatch-img swatch-image-"+item+(((props.collection["swatch-image-"+item] && props.collection["swatch-image-"+item].selected) === "swatch-image-"+item+"-"+index)?" selected":"")}
										src={utils.getImageUrl(swatchImage.URL, 55, (index > (defaultSwatchLimit - 1) && !props.showAllColors))}
										data-color={swatchImage.color} data-url={swatchImgUrl} data-item={item} id={"swatch-image-"+item+"-"+index} />
								</a>

								{availablityImage}

							</div>
						)
					})}
					</div>

					<div id="show-all-swatches" className={(showToggleAllColors) ? '' : 'display-none'}>
						<a href="#" onClick={props.eventHandlers.toggleAllColors}>{toggleAllColorsMessage}</a>
					</div>
				</div>
			);
		}else{
			swatchMarkup = '';
		}
		return swatchMarkup;
	},
	styleGuide: function (product) {
		var styleGuideMarkup = '';
		if (product.styleGuide && product.styleGuide.sizeChartText) {
			styleGuideMarkup = (
				<div id="style-guide-section">
					<h4 className="mcom-only">Not sure about the size?</h4>
					<div id="style-guide-content">
						<span className="mcom-only">Check out our </span><a href={product.styleGuide.sizeChartURL}><span dangerouslySetInnerHTML={{__html: product.styleGuide.sizeChartText}} /></a>
					</div>
				</div>
			);
		}
		return styleGuideMarkup;
	},
	onlineImageCol:function(product)
	{
		var onlineImgMarkup = '';
		/*
		if(product.valueAddedIcons && product.valueAddedIcons.length > 0) {
			// const valueImgName1 = (product.valueAddedIcons[0].indexOf('bogo_images') > -1) ? (product.valueAddedIcons[0].split('/media/images/bogo_images/')[1].split('_v1')[0] :
			// product.valueAddedIcons[0].split('/media/images/product_badges/')[1].split('_v1')[0];

			const valueImgName1 = product.valueAddedIcons[0].indexOf('bogo_images') > -1 ? (
				(product.valueAddedIcons[0].split('/media/images/bogo_images/').length > 1) && product.valueAddedIcons[0].split('/media/images/bogo_images/')[1].split('_v1')[0]
			) : product.valueAddedIcons[0].indexOf('bogo_images') > -1 ? (
				(product.valueAddedIcons[0].split('/media/images/product_badges/').length > 1) && product.valueAddedIcons[0].split('/media/images/product_badges/')[1].split('_v1')[0]
			) : product.valueAddedIcons[0];


			let valueImgName2;
			product.valueAddedIcons[1] ? (valueImgName2 = (product.valueAddedIcons[1].indexOf('bogo_images') > -1) ? product.valueAddedIcons[1].split('/media/images/bogo_images/')[1].split('_v1')[0] :
			product.valueAddedIcons[1].split('/media/images/product_badges/')[1].split('_v1')[0]) : ''
			onlineImgMarkup = (<div id="valueAddBlock"><div className={`pdp-onlineOnlyCont marginTop10`} id={valueImgName1}></div>
				{ product.valueAddedIcons[1] && <div className="pdp-onlineOnlyCont" id={valueImgName2}></div>}
				</div>)
		}
		*/


		return onlineImgMarkup;
	},
	productDetails: function (props,product,index) {
		return (<div className="collection-details-block">
			<QuantityView {...props} collectionIndex={index} callbackQuantity={props.eventHandlers.onQuantityChange} />

			<AddtobagView {...props} collectionIndex={index} isBopus={product.isBopusEligible} callbackAddtoBag={props.eventHandlers.callbackAddtoBag} />

			{props.isTcom && (
				<div className="tcom-only-block">
					<div>{this.onlineImageCol(product)}</div>
					{window.kohlsData && window.kohlsData.isFindInStoreEnabled ? <div className="t-find-stores">FIND IN STORES</div> : ""}
					<div className="t-add-list">ADD TO LIST</div>
					<div className="t-add-registry">ADD TO REGISTRY</div>
					<div className="t-add-share">SHARE</div>
				</div>
			)}
		</div>)
	},
	productInfo: function (props, product,item) {
		return (<div className="collection-product-info">
			<div id={"product-details"+item} className="product-info" onClick={() => { props.eventHandlers.handleInfoSectionClick('product-details'+item) } }>
				<div className={'content' + ((props.collection["pdp-show-more-"+item]) ? ' show-more' : ' show-less')} dangerouslySetInnerHTML={{ __html: product.productDetails }} />
				<a href="#" id={"pdp-show-more-"+item} onClick={props.eventHandlers.showMoreLess}>{(props.collection["pdp-show-more-"+item])?"SHOW LESS":"SHOW MORE"}</a>
			</div>
		</div>);
	},
	componentDidMount: function(){
		this.highlightSale && document.querySelector("#product-sale-price") && ReactDOM.findDOMNode(document.querySelector("#product-sale-price")).classList.add("no-sale-price");
	},
	render: function(){
    	const props = this.props;
		const product = props.data.payload.products[0];
    	const eventHandlers = props.eventHandlers;
		const imgUrl = utils.getImageUrl(product.images[0].url, props.mainImgWidth);
		const prodImgWidth = product.images[0].width;
		const price = product.price;
		let mixedPrice = (price.salePrice && price.salePrice.substr(price.salePrice.indexOf(" ")+1)) || (price.clearancePrice && price.clearancePrice.substr(price.clearancePrice.indexOf(" ")+1));
		let priceMatrix = {Mixed:mixedPrice,Sale:price.salePrice,Clearance:price.clearancePrice};
		let priceObj = displayPrice(price);
		const clsName = priceObj.isRedLabel ? "sale-price" : "blackLabel";
		const regPrice = priceObj.combainWithReg ? "or "+product.price.regularPrice+" each" : product.price.regularPrice;
		const salePriceMarkup = (priceObj.specialPrice) ? (<div id="product-sale-price" className={clsName}>{priceObj.specialPrice}</div>) : '';
		const origPriceMarkup = (priceObj.regPrice) ? (<div className="orig-price">{priceObj.regPrice}</div>) : '';

		const productImages = props.productImages;
		const stdCarouselItems = 7;
		//const imageCounterMarkup = (productImages.length > 1) ? <div className="img-count">{(props.selectedImageIndex +1)} OF {productImages.length}</div> : '';
		let storeId = (props.serverRender) ? '' : utils.getUrlParam("storeid",location.href) || "";
		storeId = storeId && storeId.split(",")[0];
		storeId = storeId ? (location.href.indexOf("?") === -1 ? "&storeid="+storeId : "?storeid="+storeId) : "";

		{/* Product Image Counter Checking
			- Product Images = Main + Alternate images
			- Null Checking AND only for length > 1 */}

		const imageCounterMarkupMcom = productImages.length && (
			(productImages.length > 1) && (
				(productImages.length > stdCarouselItems) ? (
					<div className="img-count">{props.selectedImageIndex +1} OF {productImages.length}</div>
				) : (<ul className="carousel-dots">
						{productImages.map((image, index) => {
							return (
								<li key={index.toString()}
									data-key={"dot-" +index}
								 	className={(props.selectedImageIndex == index) ? "active-img" : ""}
									onClick = {props.eventHandlers.swipeImage}></li>
							)
						})}
					</ul>
				)
			)
		);

		const imageCounterMarkupTcom = productImages.length && (
			(productImages.length > 1) && (
				(productImages.length > stdCarouselItems) ? (
					<div className="img-count">{props.selectedImageIndex +1} OF {productImages.length}</div>
				) : (<ul className="carousel-tiles">
						{productImages.map((image, index) => {
							return (
								<li key={index.toString()}><img src={image.url}
											data-key={"tile-" +index}
											className={(props.selectedImageIndex == index) ? "active-img" : ""}
											onClick = {props.eventHandlers.swipeImage} /></li>
							)
						})}
					</ul>
				)
			)
		);

		let mainImageMarkup;

		if (!props.selectedSwatchImgUrl){
			mainImageMarkup = (
				<div id="image-carousel">
					{productImages.map((image, index) => {
						return (
							<div className="product-img" key={index}>
								<img id={"zoom-img-" +index} src={utils.getImageUrl(image.url, prodImgWidth, !image.rendered)}  alt={image.altText}/>
							</div>
						)
					})}
				</div>
			);
		}else{
			mainImageMarkup = (
				<div id="image-carousel" style={{marginLeft:0}}><img src={props.selectedSwatchImgUrl} /></div>
			);
		}

		let pdp_collection_view = '';
		let pdp_reviews_view = (<div id="BVRRContainer"></div>);
		let pdp_qa_view = (<div id="BVQAContainer"></div>);

		var getSizeInfoArr = function(item){
			var sizeInfoArr = props.collectionSize[item].map((size, index) => {
				if(!size){
					return [];
				}

				var available = !!props.col_sizeAvailability[item][size];
				return { size: size, avail: available };

			});

			return sizeInfoArr;
		}
		let pdpTabItems = props.isTcom ? (<div id="pdp-tab-selection">
			<a id="pdp_collection" href="#" onClick={props.eventHandlers.getPdpTabContent} className="pdp-tab selected">COLLECTION DETAILS</a>
			<a id="pdp_reviews" href="#" onClick={props.eventHandlers.getPdpTabContent} className="pdp-tab">RATINGS & REVIEWS<span id="RRreview_count">(0)</span></a>
			<a id="pdp_qa" href="#" onClick={props.eventHandlers.getPdpTabContent} className="pdp-tab">Q&A</a>
		</div>) : "";

		pdp_collection_view = props.data.payload.products[0].collection.map((product, index) => {
			let imgUrl = utils.getImageUrl((props.collection["swatch-image-"+index] ? props.collection["swatch-image-"+index].imageUrl : (((product.images.length >= 1) && (utils.checkEmptyString(product.images[0].url)) ) ? product.images[0].url : '#')), props.mainImgWidth);
			const activePrice = props.isCollectionConfigDone[index] ? props.col_selectedSkus && props.col_selectedSkus[index] && props.col_selectedSkus[index].length && props.col_selectedSkus[index][0] && props.col_selectedSkus[index][0].price || product.price : product.price;
			let priceObj = {};
			priceObj = activePrice && displayPrice(activePrice);
			const clsName = priceObj && priceObj.isRedLabel ? "sale-price" : "blackLabel";
			const regPrice = priceObj && priceObj.combainWithReg ? "or "+product.price.regularPrice+" each" : product.price.regularPrice;
			let salePriceMarkup = (priceObj && priceObj.specialPrice) ? (<div className={clsName}>{priceObj.specialPrice}</div>) : '';
			let origPriceMarkup = (priceObj.regPrice) ? (<div className="orig-price">{priceObj.regPrice}</div>) : '';
			let productImages = props.productImages;
			let imageMarkup = (<a href={product.seoURL + storeId}><div className="pdp-collection-image"><img id={"pdp-swt-image"+index} src={imgUrl} /></div></a>);
			!product.price.salePrice && (this.highlightSale=true);

			var sizeInfoArr = getSizeInfoArr(index);

			var selectBoxMarkup = '';
			if(props.isTcom){
				selectBoxMarkup = sizeInfoArr && sizeInfoArr.length && sizeInfoArr[0].size && (
					<div className='t-selectBox'>
						<div data-item={index} className={'product-size' + (props.tryAddtoBag && props.tryAddtoBag[index] && !props.col_selectedSize[index] ? ' req-size' : '')} onClick={eventHandlers.showSizeList}>
							{props.collection["productSizeCln-"+index] ? props.collection["productSizeCln-"+index] : 'Select a size'}
						</div>

						{(props.showSizeListBox) && ((props.showSizeListBox == index) ? (<div className='sel-list'>
							<div className='size-dropdown'><ul>
								{sizeInfoArr.map((sizeInfo, idx) => {
									return (
										<li id={"productSizeCln-"+index} data-item={index} className={(props.collection["productSizeCln-"+index]==sizeInfo.size ? 'active ' : '') + (!sizeInfo.avail ? 'sel-disabled' : '')} key={idx} onClick={eventHandlers.handleSizeSelection} value={sizeInfo.size}>{
											sizeInfo.size}
										</li>
									)
								})}
							</ul></div>
						</div>) : '')}

						{props.tryAddtoBag && props.tryAddtoBag[index] && !props.isCollectionConfigDone[index] && !props.col_selectedSize[index] ? <div className="req-size-txt">{labels[props.reqSize]}</div> : ''}
					</div>
				);
			} else {
				selectBoxMarkup = (
					<div className='m-selectBox'> {
						/* checks Size Length */
						sizeInfoArr && (
							(sizeInfoArr.length == 1 && sizeInfoArr[0].size) ? (
								<h3>SIZE</h3>,<div className='product-size'>{'SIZE:' +sizeInfoArr[0].size}</div>
							) : (sizeInfoArr.length > 1 ? (
								<h3>SIZE</h3>,<div data-item={index} id={"productSizeCln_"+index} className={'product-size' + (props.tryAddtoBag && props.tryAddtoBag[index] && !props.col_selectedSize[index] ? ' req-size' : '')} onClick={eventHandlers.showSizeList}>
									{props.collection["productSizeCln-"+index] ? ('SIZE:' +props.collection["productSizeCln-"+index]) : 'Select a size'}
								</div>
							) : '')
						)
					}

					{/* only required for Multi-Size options */
						(props.showSizeListBox) && ((props.showSizeListBox == index) ? (<div className='sel-list'>
							<div className="m-size-backdrop" onClick={eventHandlers.showSizeList} onTouchMove={(e) => e.preventDefault()}></div>

							<div className='size-dropdown'><ul>
								<li className='sizelist-title'>SIZE</li>
								{sizeInfoArr.map((sizeInfo, idx) => {
									return (
										<li className={(props.collection["productSizeCln-"+index]==sizeInfo.size ? 'active ' : '') + (!sizeInfo.avail ? 'sel-disabled' : '')} key={idx}>
											<div id={"productSizeCln-"+index} data-item={index} onClick={eventHandlers.handleSizeSelection} value={sizeInfo.size}>{sizeInfo.size}</div>
										</li>
									)
								})}
							</ul></div>
						</div>) : '')
					}

					{/* Validation Message */
						props.tryAddtoBag && props.tryAddtoBag[index] && !props.isCollectionConfigDone[index] && !props.col_selectedSize[index] ? <div className="req-size-txt">{labels[props.reqSize]}</div> : ''
					}
					</div>
				);
			}

			if(product.productStatus != 'In Stock'){
				return (null);
			}

			return (
				<div className={"pdp-collection-item"} key={index}>
					<span className="item-arr"></span>
					<div className="collection-product-block">
						<div className="collection-main-img">
								{imageMarkup}
						</div>
						<div className="collection-content">
							<a href={product.seoURL + storeId}><div className="mcom-only collection-cnt-mcom">
								<div id="price-section">
									<div className="pdpPriceContent" itemProp="offers" itemScope="" itemType="http://schema.org/Offer">
										{product.price.isSuppressed ? salePriceMarkup : ""}
										{origPriceMarkup}
										<meta itemProp="priceCurrency" content="USD"/>
									</div>
								</div>
								<div id="product-desc">
									<h1 dangerouslySetInnerHTML={{ __html: product.productTitle }} />
								</div>
								<div>{this.onlineImageCol(product)}</div>
							</div></a>
							<div className="tcom-only-block">
								<div id="product-desc">
									<a href={product.seoURL + storeId}><h1 dangerouslySetInnerHTML={{ __html: product.productTitle }} /></a>
								</div>
								<div id="price-section">
									<div className="pdpPriceContent" itemProp="offers" itemScope="" itemType="http://schema.org/Offer">
										{salePriceMarkup}
										{origPriceMarkup}
										<meta itemProp="priceCurrency" content="USD"/>
									</div>
								</div>
							</div>

							<div className="mcom-only">{this.productInfo(props, product,index)}</div>
							{this.swatchImages(product,index)}

							{typeof(props.col_sizeAvailability) && !utils.isObjectEmpty(props.col_sizeAvailability) && !props.col_sizeAvailability[null] && (
								<div id="size-section">
									{selectBoxMarkup}
									{this.styleGuide(product)}
								</div>
							)}

							<div className="tcom-only-block">{this.productInfo(props, product,index)}</div>
						</div>
					</div>

					<div className="collection-addbag">
						{this.productDetails(props,product,index)}
					</div>
				</div>
			)
		})
		let tabview = {"pdp_collection":pdp_collection_view,"pdp_reviews":pdp_reviews_view,"pdp_qa":pdp_qa_view};


		return(
			<div id="product-content" className={(props.isTcom?"pdp-tcom":"pdp-mcom")}>
			<div itemScope="" itemType="http://schema.org/Product">
			{props.isTcom && props.errGlobal && <div className="globalErrorMsg">{labels[props.errGlobal]}</div>}

			<div className="pdp-title tcom-only-block"><span><a href="javascript:history.go(-1)" className="t-arrow_back"></a></span><span dangerouslySetInnerHTML={{__html: product.productTitle}} /></div>
				 <div id="section-1">
				 	{!props.isTcom && props.errGlobal && <div className="globalErrorMsg">{labels[props.errGlobal]}</div>}

					<div id="main-img">
						<div id="product-img-section" onClick={!props.isTcom && props.eventHandlers.productCarouselZoom}>
							{mainImageMarkup}

						</div>
						<a href="#" className={"tap-to-zoom "+(!props.isTcom?"display-none":"")} onClick={props.eventHandlers.productCarouselZoom}>TAP TO ZOOM</a>
						{props.isTcom ? imageCounterMarkupTcom : imageCounterMarkupMcom}
					</div>
					<div id="main-product-content">
						<div id="product-desc">
							<h1 dangerouslySetInnerHTML={{__html: product.productTitle}} />
						</div>
						<div id="price-section">
							<div className="pdpPriceContent" itemProp="offers" itemScope="" itemType="http://schema.org/Offer">
								{salePriceMarkup}
								{origPriceMarkup}
								<meta itemProp="priceCurrency" content="USD"/>
							</div>
							<div className="mcom-only cOnline">{this.onlineImageCol(product)}</div>
							<div id="rating-review-section"> <div id="BVRRSummaryContainer"></div><div id="BVQASummaryContainer"></div></div>
						</div>
						{this.swatchImages(product)}
					</div>

					<div id="product-zoom-cntr" className={props.productCarousel.productZoom?"zoom":""}>
					<div id="product-zoom-overlay" className={"product-zoom-overlay "+(props.isTcom?"t-com":"")}>
					<div id="product-zoom-carousel" className="product-zoom-carousel" >
					<div role="button" className="close" id="product-overly-close" onClick={eventHandlers.productCarouselZoom}></div>
					<button id="zoomedSliderPrevBtn" className={"nav-prev "+(!props.isTcom?"display-none ":"")+(props.productCarousel.nav===0?"disabled":"")} onClick={()=>eventHandlers.navCarousel(false,1)}></button>
					<div id="img-container" className={"img-container "+(!props.productCarousel.productZoom?"display-none":"")}>
					<ul className="carousel-slides" style={{left:props.productCarousel.value,width:(productImages.length*(props.isTcom?props.mainZoomImgWidth:props.mainImgWidth))}}>
					{productImages && productImages.map((image, index) => {
						return (
							<li className="product-img panZoom-img" key={index}>
								<img id={"zoom-overlay-img-"+index} src={utils.getImageUrl(image.url, (props.isTcom?props.mainZoomImgWidth:props.mainImgWidth), false)} style={{transform: 'matrix('+props.productZoom.prodZoomVal+', 0, 0, '+props.productZoom.prodZoomVal+', 0, 0)'}}  alt={image.altText}/>
							</li>
						)
					})}
					</ul>

					</div>
					<button id="zoomedSliderNextBtn" className={"nav-next "+(!props.isTcom?"display-none ":"")+(props.productCarousel.nav+1===productImages.length?"disabled":"")} onClick={()=>eventHandlers.navCarousel(true,1)}></button>
					<div className="zoom-nav-titles">
					<button id="nav-zoome-prev" className={"nav-prev "+(!props.isTcom || (productImages.length <= props.productZoom.carouselLimit)?"display-none ":"")+(props.productZoom.currSlide===0?"disabled":"")} onClick={()=>eventHandlers.navMinCarousel(false)}></button>
					<div id="nav-img-container" className={"nav-img-container "+(!props.productCarousel.productZoom || (props.productImages.length <= 1)?"display-none":"")}>
					<ul className="carousel-slides" style={{left:-props.productZoom.slideVal}} >
						{props.productImages.length >1 && productImages.map((image, index) => {
						return (
							<li className={"product-img "+(("product-img-"+index)==="product-img-"+props.productCarousel.nav?"nav-active":"")} key={index} id={"product-img-"+index} onClick={()=>eventHandlers.navCarousel(null,index)}>
								<img src={utils.getImageUrl(image.url, props.mainImgWidth, false)}  alt={image.altText}/>
							</li>
						)
					})}

					</ul>
					</div>
					<button id="nav-zoome-next" className={"nav-next "+(!props.isTcom || (productImages.length <= props.productZoom.carouselLimit)?"display-none ":"")+(props.productZoom.slideEnd?"disabled":"")} onClick={()=>eventHandlers.navMinCarousel(true)}></button>
					<div id="tcomPdpZoomContainer" className="tcomPdpZoomContainer" className={!props.isTcom?"display-none":""}>
						<button id="tcomzoomMinus" className="zoom-button" onClick={()=>eventHandlers.productZoom(false)}>-</button>
						<div className="zoomTxt" id="zoomTxt"> zoom </div>
						<button id="zoomPlus" className="zoom-button" onClick={()=>eventHandlers.productZoom(true)}>+</button>
					</div>
					</div>

					</div>
					</div>
					<div id="product-zoom-mask" className="product-zoom-mask" onClick={eventHandlers.productCarouselZoom}></div>
					</div>

				</div>
				<div id="section-2" className="tcom-only-block">
					<div className="choose-items-below">Choose Items below</div>
					<div className="t-add-share">SHARE</div>
					<div className="cOnline">{this.onlineImageCol(product)}</div>
				</div>
				<div className="Collection-PDP-bundle">
					<div id="pdp-collection-tabs">
						{pdpTabItems}
						<div id="pdp-tab-content" className={props.collectionPdpContent ==="pdp_reviews"?'display-none':''} >{tabview[props.collectionPdpContent]}</div>
						<div id="BVRRContainer" className={props.collectionPdpContent ==="pdp_reviews"?'display-block':'display-none'}></div>
						<div id="BVQAContainer" className={props.collectionPdpContent ==="pdp_qa"?'display-block':'display-none'}></div>
					</div>
				</div>

				<div id="section-4" className="mcom-only">
					<div id="recommendationsMcom"></div>
				</div>

				<div id="collection-recommendations-block" className="tcom-only-block">
					<div id="recommendationsTcom" className="pdpRecommendationsTcom"></div>
				</div>
				{!props.isCartModal && props.continueShopModel && <ShopModel {...props} />}
				<script src="/lib/jquery.cookie.js"></script>
				   {product && product.collection.map((products, index) => {
					   return (
					   <div key={index}>
				   <meta itemProp="productID" content={products.webID}/>
				   <meta itemProp="itemCondition" content="http://schema.org/NewCondition"/>
				   <meta itemProp="brand" content={products.brand}/>
				   <meta itemProp="URL" content={products.seoURL}/>
				   {products && products.SKUS && products.SKUS.map((skus, index) => {
					   return (
					   <div className="pdpSchemaPriceContainer display-none" key={index}>
						  <div itemProp="offers" itemScope="" itemType="schema.org/Offer">
							 <span itemProp="sku">{skus.skuCode}</span>
							 <link itemProp="availability" href="http://schema.org/InStock"/>
							 <meta itemProp="itemCondition" content="http://schema.org/NewCondition"/>
							 <span itemProp="price">
								<div className="cls_pdtPrice"> {skus.price.salePrice ? "$"+skus.price.salePrice : "$"+skus.price.regularPrice} </div>
							 </span>
							 <meta itemProp="priceCurrency" content="USD"/>
						  </div>
					   </div>
					   )
				   })}
				   </div>)
				   })}
			</div>
			</div>
		);
	}
});
