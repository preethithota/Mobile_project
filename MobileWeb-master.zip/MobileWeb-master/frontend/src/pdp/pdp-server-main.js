import PdpContainer from './pdp-container';

global.renderServerPDP = function(dataFromJava, isTcom){
    var data = JSON.parse(dataFromJava);
    return ReactDOMServer.renderToString(
        <div><PdpContainer data={data} serverRender={true} isTcom={isTcom}/></div>
    );
};
