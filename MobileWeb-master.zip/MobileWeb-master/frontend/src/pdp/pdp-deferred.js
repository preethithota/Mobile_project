import '../misc/z1Loyalty-v2';
import {setOrderCalcData} from '../../public/lib/brightTag-util';
window.brightTag = {};
brightTag.setOrderCalcData = setOrderCalcData;
