import React from 'react';

export default React.createClass({
	render: function(){
		const props = this.props;
		const eventHandlers = props.eventHandlers;

    	return (
			<div className="continue-shop-modal" role="dialog" onTouchMove={(e) => e.preventDefault()}>
				<div className={!props.isTcom?"continue-shop-main":"continue-shop-main t-continue-shop-main"}>
					<div className="close-btn" onClick={eventHandlers.handleCancelClick}></div>
					<div className="continue-shop-bag">
						<div className="bag-icon" onClick={eventHandlers.gotoCart}></div>
						<div className="addbag-txt">Item added to Bag</div>
						<div className="continue-btn" onClick={eventHandlers.handleCancelClick}>CONTINUE SHOPPING</div>
						<div><div className="view-bag-btn view-bag-promo"><a href="/checkout/checkout.jsp#/shoppingBag" onClick={() => eventHandlers.showShopModel(false)}>VIEW BAG & APPLY PROMO</a></div><div className="view-bag-btn view-bag-check" onClick={eventHandlers.gotoCheckout}>CHECKOUT</div></div>
					</div>
					<div className="earn-shipping-block">EARN FREE SHIPPING WITH $55.01 MORE IN  YOUR ORDER</div>
					<div className="earn-shipping-block display-none">YOUVE EARNED <span className="bldtxt">FREE SHIPPING!</span></div>
				</div>
				<div className="overlay-backdrop" aria-hidden="true" onClick={eventHandlers.handleCancelClick}></div>
			</div>
		)
	}
});
