
/**
 * Function from current website for time conversion
 * @param {*} time 
 * @param {*} type 
 */
export function convertTime24Format(time, type) {
	if(time)
	{
		var TYPE_START_TIME = 1, TYPE_END_TIME = 2;
		var tempTime = time;
		tempTime = tempTime.replace(/[^.:0-9]/g,"");
		tempTime = tempTime.replace(/[^0-9]/g,".");
		var timeArr = tempTime.split(".");
		timeArr[1] = timeArr[1] ? timeArr[1] : "0";

		var timeStr = (time.toUpperCase().indexOf("PM") != -1) ? "PM" : (time.toUpperCase().indexOf("AM") != -1) ? "AM" : "", 
			hours = parseInt(timeArr[0]);

		if(type == TYPE_START_TIME && timeStr == "AM" && hours == 12){				
			timeArr[0]= 0;
		}else if(type == TYPE_END_TIME && timeStr == "AM" && hours == 12){
			timeArr[0]= 24;
		}else{
			if(timeStr == "PM" && hours < 12) {
				timeArr[0]= hours + 12;
			}				
		}

		time = timeArr.join(".");
	}
	return time || "";
}

/**
 * function check open time
 * @param {*} timingArray
 * @return string status 
 */
export function getOpenOrCloseStatus(timingArray){
    
    var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    		if(timingArray && timingArray.length) {
                let d = new Date();
                let currentTime = d.getTime();
                let currentTimestamp = new Date(currentTime);
                let localTime = currentTimestamp.toLocaleTimeString();
                let n = d.getDay()
				let localTimeObject = {};
                localTimeObject.day = weekday[n];
                localTimeObject.localTime = currentTimestamp.toLocaleTimeString();

				for(var i = 0; i < timingArray.length;i++) {
						if(timingArray[i].name == localTimeObject.day) {
							var startTime= convertTime24Format(timingArray[i].hours.open, 1);
							var endTime= convertTime24Format(timingArray[i].hours.close, 2);
							var currentTime = convertTime24Format(localTimeObject.localTime, null);
		
							startTime = startTime.split(".");
							currentTime = currentTime.split(".");
							endTime = endTime.split(".");
							
							startTime[0] = parseInt(startTime[0]);
							currentTime[0] = parseInt(currentTime[0]);
							endTime[0] = parseInt(endTime[0]);
							
							startTime[1] = parseInt(startTime[1]);
							currentTime[1] = parseInt(currentTime[1]);
							endTime[1] = parseInt(endTime[1]);
							
							if((startTime[0] < currentTime[0] || (startTime[0] == currentTime[0] && startTime[1] <= currentTime[1] )) &&  (currentTime[0] < endTime[0] || (endTime[0] == currentTime[0] && endTime[1] >= currentTime[1]) ))
							{
								status = "open";
							}
							else {
								status = "closed";
							}
						}
				}
		}
	return status;
}



