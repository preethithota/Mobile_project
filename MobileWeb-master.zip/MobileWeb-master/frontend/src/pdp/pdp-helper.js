import * as utils from '../global/utils';
import * as carHelper from '../global/cart-helper';
import {labels} from '../global/label-utils';

// This applies to both regular products and collections
export function getCollectionState(currentCollection, currentId, selectedSize, colorAvailability){
  let items = currentCollection;
  items[currentId] = selectedSize;
  items["colorAvl-" + currentId] = colorAvailability;
  return items;
}

export function getSku(skus, skuCode){
  const defaultValue = {};
  if (!skus){
    return defaultValue;
  }

  for (let i = 0; i < skus.length; i++) {
    let currentSku = skus[i];
    if (currentSku.skuCode === skuCode){
      return currentSku;
    }
  }

  return defaultValue;
}

export function getSelectedSkus(availableSkus, size, color){

  if (availableSkus && availableSkus.length > 0){
    let filteredSkus = availableSkus.filter((sku) => {
      let includeSku = true;
      if (size){
        includeSku = includeSku && (sku.size === size);
      }

      if (color){
        includeSku = includeSku && (sku.color === color);
      }
      return includeSku;
    });
    return filteredSkus;
  }else{
    return availableSkus;
  }
}

export function getInventoryInfo(sku, store, errorCallback, callback) {
	//sku = "94527122";
	let stores = store;

	let data = 'storeNum=' + stores + '&channel=store';

	sku && stores && $.ajax({
		url: '/api/v1/inventory/sku/' + sku,
		method: 'GET',
		data: data,
		contentType: 'application/json',
		headers: {
			'Accept': 'application/json'
		}
	}).then(function(responseObj) {
		if (responseObj && responseObj.payload) {
			callback && callback(responseObj);
		} else {
			errorCallback(responseObj);
		}
	}).fail(() => {
		errorCallback({
			errors: [{
				message: 'error'
			}]
		});
	});
}

export function getInventoryFiftyMilesRadius(sku, postalCode, errorCallback, callback) {
	let data = 'postalCode=' +postalCode+ '&radius=50&channel=store';

	sku && postalCode && $.ajax({
		url: '/api/v1/inventory/sku/' + sku,
		method: 'GET',
		data: data,
		contentType: 'application/json',
		headers: {
			'Accept': 'application/json'
		}
	}).then(function(responseObj) {
		if (responseObj && responseObj.payload) {
			callback && callback(responseObj);
		} else {
			errorCallback(responseObj);
		}
	}).fail(() => {
		errorCallback({
			errors: [{
				message: 'error'
			}]
		});
	});
}

export function getStoreCity(store, errorCallback, callback) {
// /v1/stores?storeNum=994
	let data = 'storeNum=' + store;

	store && $.ajax({
		url: '/api/v1/stores',
		method: 'GET',
		data: data,
		contentType: 'application/json',
		headers: {
			'Accept': 'application/json'
		}
	}).then(function(responseObj) {
		if (responseObj && responseObj.payload) {
			callback && callback(responseObj);
		} else {
			errorCallback(responseObj);
		}
	}).fail(() => {
		errorCallback({
			errors: [{
				message: 'error'
			}]
		});
	});
}


export function checkIsConfig(sizeAvailability, colorAvailability, selectedSize, selectedColor){
	let sizeConfig = false;
	let colorConfig = false;
	let isConfigDone = false;

	if(!utils.isObjectEmpty(sizeAvailability) && Object.keys(sizeAvailability).length > 1 && selectedSize){
		sizeConfig = true;
	}else if(utils.isObjectEmpty(sizeAvailability) || (Object.keys(sizeAvailability).length == 1 && selectedSize)){
		sizeConfig = true
	}

	if(!utils.isObjectEmpty(colorAvailability) && Object.keys(colorAvailability).length > 1 && selectedColor){
		colorConfig = true;
	}else if(utils.isObjectEmpty(colorAvailability) || (Object.keys(colorAvailability).length == 1 && selectedColor)){
		colorConfig = true
	}

	if(sizeConfig && colorConfig){
		isConfigDone = true;
	}

	return isConfigDone;
}

export function displayPrice(priceObj) {
	try{
		let priceText = {specialPrice: "", isRedLabel: true, combainWithReg: false,regPrice: ""};
		let promotionText = priceObj.promotion ? " | "+priceObj.promotion : "";
		const salePriceStatus = priceObj.salePriceStatus && priceObj.salePriceStatus.toUpperCase();
		var regPrice = priceObj.regularPrice && priceObj.regularPrice.toLowerCase();
		regPrice = regPrice && regPrice.replace(/original/g,'');
		regPrice = regPrice && regPrice.replace(/regular/g,'');
		var dollar = (regPrice && regPrice.indexOf('$') == -1) ? ' $' : '';
		priceText.regPrice = regPrice && (priceObj.regularPriceType || "") + dollar + regPrice;

		if(priceObj.isSuppressed) {
			priceText.specialPrice = labels.supressText;
			priceText.isRedLabel = false;
		} else if(salePriceStatus) {
			if(salePriceStatus == "SALE" && priceObj.salePrice) {
				var label = (priceObj.salePrice.toUpperCase().indexOf('SALE') == -1) ? salePriceStatus : '';
				var dollar = label!="" && !(priceObj.salePrice[0] == "$") ? ' $' : ' ';
				priceText.specialPrice = label + dollar + priceObj.salePrice.toUpperCase()
				//priceText.specialPrice = label + dollar + priceObj.salePrice.toUpperCase() + promotionText
			} else if(salePriceStatus == "CLEARANCE" && priceObj.clearancePrice) {
				var label = (priceObj.clearancePrice.toUpperCase().indexOf('CLEARANCE') == -1) ? salePriceStatus : '';
				var dollar = (priceObj.clearancePrice.indexOf('$') == -1) ? ' $' : '';
				priceText.specialPrice = label + dollar + priceObj.clearancePrice.toUpperCase() + promotionText
			} else if(salePriceStatus == "MIXED" || salePriceStatus == "SALE+CLEARANCE") {
				let price = (priceObj.salePrice && priceObj.salePrice.replace(/Sale/g,'')) || (priceObj.clearancePrice && priceObj.clearancePrice.replace(/Clearance/g,''));
				priceText.specialPrice = price + promotionText;
				if(salePriceStatus == "MIXED") {
					priceText.isRedLabel = false;
				}
			}
		} else if(priceObj.salePrice || priceObj.promotion){
			priceText.specialPrice = priceObj.salePrice || priceObj.promotion;
			priceText.combainWithReg = true;
			priceText.isRedLabel = false;
		}
		return priceText;
	}catch(e) {
		console.log(e);
	}
}

export function getStoreInfo(){
	let storeFromURL = {},
		storeFromMyStores = {},
		storesFromGeoloc = {};

	storeFromURL.storeNum = utils.getUrlParam('storeid', location.href);
	let topStoresInfo = storeFromURL.storeNum && utils.getFromLocalStorage(topStoresInfo);
	storeFromURL.storeName = function(topStoresInfo){
		if(topStoresInfo){
			var topStoreArray = topStoresInfo.split(',');

			try {
				for(store of topStoreArray){
					var storeInfo = store.split('|');

					if(storeInfo[1] = storeFromURL.storeNum){
						return storeInfo[0];
					}
				}
			} catch (e){
				console.log(e);
			}
		}

		return;
	}(topStoresInfo);;

	let myStoreInfo = utils.getCookieValue('mystore') && JSON.parse(utils.getCookieValue('mystore'));
	storeFromMyStores.storeNum = myStoreInfo.storeNums;
	storeFromMyStores.storeName = myStoreInfo.name;
	storeFromMyStores.storeZip = myStoreInfo.zipcode;

	let closestStoreInfo = utils.getCookieValue('closeststore') && JSON.parse(utils.getCookieValue('closeststore'));
	storesFromGeoloc.storeNum = closestStoreInfo.id;
	storesFromGeoloc.storeName = closestStoreInfo.name;
	storesFromGeoloc.storeZip = closestStoreInfo.zipcode;
	storesFromGeoloc.nearbyStores = closestStoreInfo.storeNums;

	var storeInfo = {};
	storeFromURL.storeNum ? (
		storeInfo = storeFromURL,
		storeInfo.storeFrom = 'stringURL'
	) : (
		storeFromMyStores.storeNum ? (
			storeInfo = storeFromMyStores,
			storeInfo.storeFrom = 'stringMystore'
		) : (
			storesFromGeoloc.storeNum ? (
				storeInfo = storesFromGeoloc,
				storeInfo.storeFrom = 'stringGeoloc'
			) : (
				""
			)
		)
	);

	return storeInfo;
};

//This fucntion performs skuconfig validation in pdp page
export function validatePdpSkuConfig(_state, _pdp_stateupdtae){
  let tryAddtoBag = true,
    errGlobal = "",
    reqSize = "";

  if(!utils.isObjectEmpty(_state.sizeAvailability) && !_state.selectedSize && !utils.isObjectEmpty(_state.colorAvailability) && !_state.selectedColor) {
    errGlobal = 'chooseBothConfigs';
    reqSize = 'reqSize';
    _pdp_stateupdtae({
      tryAddtoBag, errGlobal, reqSize
    });
    $("html, body").animate({ scrollTop: 0 }, "slow");
    return false;
  } else if(!utils.isObjectEmpty(_state.sizeAvailability) && !_state.selectedSize) {
    errGlobal = 'chooseSizeConfigs';
    reqSize = 'reqSize';
    _pdp_stateupdtae({
      tryAddtoBag, errGlobal, reqSize
    });
    $("html, body").animate({ scrollTop: 0 }, "slow");
    return false;
  } else if(!utils.isObjectEmpty(_state.colorAvailability) && !_state.selectedColor) {
    errGlobal = 'chooseColorConfigs';
    reqSize = 'reqSize';
    _pdp_stateupdtae({
      tryAddtoBag, errGlobal, reqSize
    });
    $("html, body").animate({ scrollTop: 0 }, "slow");
    return false;
  }

  return true; //Validation passed!
}
