import PdpContainer from './pdp-container';
import { setPDPOmniture } from '../../public/lib/omniture-util';
if(window.catalogData.payload){
	ReactDOM.render(
	<div><PdpContainer data={window.catalogData} isTcom={kohlsData.isTcom}/></div>,
	document.getElementById('main-content')
);
}
else{
	ReactDOM.render(
			<div>
				<div className="noproduct-found">No Product Found</div>
				<div className="mcom-only">
					<div id="recommendationsMcom"></div>
				</div>

				<div id="no_product_found" className="tcom-only-block">
					<div id="recommendationsTcom" className="pdpRecommendationsTcom"></div>
				</div>	
			</div>,
	document.getElementById('main-content')
);
	
}
setPDPOmniture()