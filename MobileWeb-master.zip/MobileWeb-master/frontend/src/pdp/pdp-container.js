import React from 'react';
import ReactDOM from 'react-dom';
import PdpView from './pdp-view';
import * as utils from '../global/utils';
import PdpCollectionView from './pdp-collection-view';
import * as pdpHelper from './pdp-helper';
import * as monetization from '../monetization/monetization';
import * as googleAd from '../monetization/googleAd';
import * as bazarVoice from '../../public/lib/bazarVoice';
import {setFindInStoreInitialClickOmniture} from '../../public/lib/omniture-util';
import {showRegistryModal} from './registry/registry-helper';
import {validatePdpSkuConfig} from './pdp-helper';
//import {setOrderCalcData} from '../../public/lib/brightTag-util';

export default React.createClass({
	// React Lifecycle function
	getInitialState: function() {
		var product = this.props.data.payload.products[0];

		var productZoomData = {
			"prodZoomVal": 1,
			"carouselLimit": 6,
			"currSlide": 0,
			"slideVal": 0,
			slideEnd: false
		};
		var carsoulVal = {
			"productZoom": false,
			"value": 0,
			"nav": 0
		};
		var productImages;

		if(product.altImages) {
			productImages = product.images.concat(product.altImages);
		} else {
			productImages = product.images;
		}

		for(var i = 1; i < productImages.length; i++) {
			productImages[i].rendered = false;
		}

		if(productImages.length > 0) {
			productImages[0].rendered = true;
		}

		if(productImages.length > 1) {
			productImages[1].rendered = true;
		}

		var sizes = this.getSizes(product.SKUS);

		const isBopusEligible = product.isBopusEligible;
		const propAddedToBag = {};

		var inputQuantity = {},
			collectionSize = {};

		let selectedSize, selectedColor, userSelectedColor, selectedSwatchImgUrl = '',
			collection = {
				"dyn-quantityNum": 1
			},
			sizeAvailability, selectedSkus, colorAvailability, isSizeToBeChoosed;

		let isCollectionConfigDone = [],
			isConfigDone = false;


		let col_colorAvailability = {},
			col_isSizeToBeChoosed = {},
			col_sizeAvailability = {},
			col_selectedColor = {},
			col_selectedSize = {},
			col_selectedSkus = {};

		if(this.props.isCartModal === true) {
			const skus = product.SKUS;
			const selectedSku = pdpHelper.getSku(skus, this.props.cartSkuCode);
			selectedColor = selectedSku.color;
			userSelectedColor = selectedSku.color;
			isSizeToBeChoosed = Object.keys(this.getSizeAvailability(product.SKUS)).length > 1 ? true : false;
			sizeAvailability = this.getSizeAvailability(product.SKUS, selectedColor);
			colorAvailability = product.swatchImages.length ? this.getAvailableColors(product.SKUS) : {};
			if(isSizeToBeChoosed && selectedSku.size) {
				selectedSize = selectedSku.size;
				colorAvailability = this.getAvailableColors(product.SKUS, selectedSize);
			} else {
				selectedSize = isSizeToBeChoosed ? '' : Object.keys(sizeAvailability).length == 1 ? utils.getObjPropertyWithOneLength(sizeAvailability) : '';
			}
			if(selectedSku.images && selectedSku.images.length > 0) {
				selectedSwatchImgUrl = selectedSku.images[0].url;
			}

			inputQuantity['inpQuantity'] = this.props.cartQuantity;
			selectedSkus = [selectedSku];
			let updatedCollectionValues = pdpHelper.getCollectionState(collection, 'productSizeCln-0', selectedSize, colorAvailability);
			collection = Object.assign(collection, updatedCollectionValues);

			isConfigDone = pdpHelper.checkIsConfig(sizeAvailability, colorAvailability, selectedSize, selectedColor);



			if(product.collection){
				//
			}
			else {
				propAddedToBag.productTitle = product.productTitle;
				propAddedToBag.ratingCount = product.ratingCount;
				propAddedToBag.avgRating = product.avgRating;
				propAddedToBag.webID = product.webID;
				propAddedToBag.selectedSkus = product.SKUS;
			}
		}
		 else {
			if(product.collection) {
				for(let i = 0; i < product.collection.length; i++) {
					propAddedToBag[i] = {};
					propAddedToBag[i].productTitle = product.collection[i].productTitle;
					propAddedToBag[i].ratingCount = product.collection[i].ratingCount;
					propAddedToBag[i].avgRating = product.collection[i].avgRating;
					propAddedToBag[i].webID = product.collection[i].webID;
					propAddedToBag[i].selectedSkus = product.collection[i].SKUS;


					inputQuantity['inpQuantity-' + i] = 1;

					collectionSize[i] = this.getSizes(product.collection[i].SKUS);
					col_selectedColor[i] = product.collection[i].preSelectedColor;
					col_isSizeToBeChoosed[i] = Object.keys(this.getSizeAvailability(product.collection[i].SKUS)).length > 1 ? true : false;
					col_sizeAvailability[i] = this.getSizeAvailability(product.collection[i].SKUS, col_selectedColor[i]);
					col_colorAvailability[i] = product.collection[i].swatchImages.length ? this.getAvailableColors(product.collection[i].SKUS) : {};
					col_selectedSize[i] = col_isSizeToBeChoosed[i] ? '' : (
						Object.keys(col_sizeAvailability[i]).length == 1 ? utils.getObjPropertyWithOneLength(col_sizeAvailability[i]) : ''
					);
					col_selectedSkus[i] = product.collection[i].SKUS;

					isCollectionConfigDone[i] = pdpHelper.checkIsConfig(col_sizeAvailability[i], col_colorAvailability[i], col_selectedSize[i], col_selectedColor[i]);
				}

				console.log('inside collection')
			}
			 else {
				propAddedToBag.productTitle = product.productTitle;
				propAddedToBag.ratingCount = product.ratingCount;
				propAddedToBag.avgRating = product.avgRating;
				propAddedToBag.webID = product.webID;
				propAddedToBag.selectedSkus = product.SKUS;


				inputQuantity['inpQuantity'] = 1;

				userSelectedColor = '';
				selectedColor = product.preSelectedColor;
				isSizeToBeChoosed = Object.keys(this.getSizeAvailability(product.SKUS)).length > 1 ? true : false;
				sizeAvailability = this.getSizeAvailability(product.SKUS, selectedColor);
				colorAvailability = product.swatchImages.length ? this.getAvailableColors(product.SKUS) : {};
				selectedSize = (isSizeToBeChoosed ? '' : (Object.keys(sizeAvailability).length == 1 ? utils.getObjPropertyWithOneLength(sizeAvailability) : ''));

				selectedSkus = pdpHelper.getSelectedSkus(product.SKUS, selectedSize, selectedColor);
				isConfigDone = pdpHelper.checkIsConfig(sizeAvailability, colorAvailability, selectedSize, selectedColor);
			}
		}

		// Search Redirect based on SKU or webID
		var searchRedirectTerm=utils.getUrlParam("search-redirect", location.href) || "";
		var regex      = /^[0-9c]+$/;
		var checking = regex.test(searchRedirectTerm);

		if(searchRedirectTerm && checking){
			let _this = this;

			if(product.webID != searchRedirectTerm){
				product.SKUS.map(function(sku) {
					if(searchRedirectTerm==sku.skuCode) {
						selectedColor = sku.color;
						selectedSize = sku.size;
						isSizeToBeChoosed = false;
						sizeAvailability = _this.getSizeAvailability(product.SKUS, selectedColor);
					}
				});

				let colorAvailability = this.getAvailableColors(product.SKUS, selectedSize);
				selectedSkus = pdpHelper.getSelectedSkus(product.SKUS, selectedSize, selectedColor);
				isConfigDone = true;

				//Updating Find in store - BUY Product SKU
				propAddedToBag.selectedSkus = selectedSkus;

				collection["productSizeCln-0"] = selectedSize;
				collection["colorAvl-productSizeCln-0"] = colorAvailability;
			}
		}

		let storeInfo, bagObjForCart;
		if(this.props.isCartModal){
			bagObjForCart = {};
			bagObjForCart.isCheckout = true;

			if(this.props.bagItem && this.props.bagItem.storeNum && this.props.bagItem.storeNum > 0){
				bagObjForCart.storeNum = this.props.bagItem.storeNum;
			}
		}
		storeInfo = this.getStoreInfo(bagObjForCart);

		let tryAddtoBag;

		return {
			isBopusEligible: isBopusEligible,
			selectedColor,
			col_selectedColor,
			userSelectedColor,
			showAllColors: false,
			selectedImageIndex: 0,
			mainImgWidth: 321,
			mainZoomImgWidth: 512,
			productImages: productImages,
			selectedSwatchImgUrl,
			sizes,
			collectionSize,
			sizeAvailability,
			col_sizeAvailability,
			selectedSize,
			col_selectedSize,
			showSizeListBox: false,
			colorAvailability,
			col_colorAvailability,
			selectedSection: 'acc-productDetails',
			collectionPdpContent: "pdp_collection",
			collection,
			productCarousel: carsoulVal,
			productZoom: productZoomData,
			showCollectionItemIndex: '',
			continueShopModel: false,
			selectedSkus,
			col_selectedSkus,
			selectedProductInfo: propAddedToBag,
			tryAddtoBag,
			globeErr: "",
			errGlobal: "",
			reqSize: "",
			isConfigDone,
			isCollectionConfigDone,
			inputQuantity,
			setZoom: null,
			storeOutofstock: {},
			checkAnotherStore: false,
			aToBagPreloadImg: false,
			storeInfo: storeInfo,
			triggerAddtoBag: false,
			triggerQuantity: false,
			availOfferData: "",
			triggerSizeSelction: "",
			updateCart: false,
			col_updateCart: {}
		};
	},

	componentDidUpdate:function(){
		if(!this.props.isTcom && !this.isZoomMounted) {
			let _container = document.getElementById('img-container');
			let _slides = document.querySelectorAll('#img-container ul li').length;
			for(var i=0;i<=_slides-1;i++){
				this.pinchZoom(_container, document.getElementById('zoom-overlay-img-'+i), true);
			}
			this.isZoomMounted = true;
		}
	},

	// React Lifecycle function
	componentDidMount: function() {
		let _this = this;
		const product = this.props.data.payload.products[0];
		const imageCarouselElem = document.getElementById('image-carousel');
		let storeInfo = this.state.storeInfo;

		if(window && window.Hammer && imageCarouselElem) {
			var mc = new window.Hammer(imageCarouselElem);

			mc.on('swipeleft', function(e) {
				_this.slideImagesLeft();
			});

			mc.on('swiperight', function(e) {
				_this.slideImagesRight();
			});

			if(this.props.isTcom) {
				this.setState({
					setZoom: this.pinchZoom
				});
			}
		}

		if(!this.props.isCartModal) {
			let carousel = ReactDOM.findDOMNode(document.getElementById('img-container'));
			carousel && (new window.Hammer(carousel)).on('swipeleft', function(e) {
				_this.slideCarousel(true, 1)
			}).on('swiperight', function(e) {
				_this.slideCarousel(false, 1)
			});
			googleAd.initGOOGLE_ADSENSE();
			monetization.initMonetization();
			bazarVoice.initBazarVoice();
		}


		/* Pick up in store*/
		let selectedSkuItem;

		if(product.collection){
			product.collection.forEach((item, index) => {
				if(item.isBopusEligible){
					selectedSkuItem = _this.state.isCollectionConfigDone[index] && _this.state.col_selectedSkus[index][0];
					_this.setStoreAndCityByInventory(storeInfo, selectedSkuItem);
				}
			});
		}
		else {
			if(product.isBopusEligible){
				selectedSkuItem = this.state.isConfigDone && this.state.selectedSkus[0]
				this.setStoreAndCityByInventory(storeInfo, selectedSkuItem);
			}
		}



		if(this.props.isTcom) {
			let _container = document.getElementById('image-carousel');
			let _slides = document.querySelectorAll('#image-carousel > div').length;
			for(var i=0;i<=_slides-1;i++){
				this.pinchZoom(_container, document.getElementById('zoom-img-'+i), false);
			}
		}
	},
  triggerAddToRegistry(listType){
		var base = this;
		if( utils.isLoggedIn() ){
			showRegistryModal(listType, base.state);
		}else{
			utils.showLogin(kohlsData.isTcom, false, function(){ base.triggerAddToRegistry(listType) }, 'login-modal');
		}
  },
	updatePDPState(_stateObj){
		this.setState(_stateObj);
	},
	eventHandlers: function() {
    var _this = this;
		return {
			showAddToRegistry: function(listType, isButtonEnabled){
        //show Registry/List modal only if button is enabled
				//validate sku configurations
				let _validationStatus =  validatePdpSkuConfig(this.state, this.updatePDPState);
				if(_validationStatus && isButtonEnabled){
					//Validation success!, Show list/registry modal
					_this.triggerAddToRegistry(listType);
				}
				return false;
			}.bind(this),
			handleSizeSelection: function(e) {
				var _this = this;
				const storeInfo = this.state.storeInfo;
				const selectedProductInfo = this.state.selectedProductInfo;
				let selectedSkuItem;

				if(!e.target.parentNode.classList.contains('sel-disabled')) {
					var selectedSize = e.target.textContent;
					var product = this.props.data.payload.products[0];
					var isCollection = product.collection;

					var showSizeListBox = (e.target.className == "product-size") ? true : false;
					if(!this.props.isTcom && showSizeListBox) {
						document.body.classList.add("modal-overlay");
					} else {
						document.body.classList.remove("modal-overlay");
					}

					this.state.errGlobal = "";

					if(isCollection) {
						var index = e.target.dataset.item;
						var col_selectedSize = this.state.col_selectedSize;
						col_selectedSize[index] = selectedSize;

						var col_colorAvailability = this.state.col_colorAvailability;
						col_colorAvailability[index] = this.getAvailableColors(product.collection[index].SKUS, selectedSize);

						var col_selectedSkus = this.state.col_selectedSkus;
						col_selectedSkus[index] = pdpHelper.getSelectedSkus(product.collection[index].SKUS, selectedSize, this.state.col_selectedColor[index]);
						selectedProductInfo[index].selectedSkus = col_selectedSkus[index];

						var isCollectionConfigDone = this.state.isCollectionConfigDone;

						// Omitting available SKU color if swatch images has empty array - means no color config
						if(product.collection[index].swatchImages.length == 0) {
							col_colorAvailability[index] = {}
						}
						isCollectionConfigDone[index] = pdpHelper.checkIsConfig(this.state.col_sizeAvailability[index], col_colorAvailability[index], selectedSize, this.state.col_selectedColor[index]);

						let items = pdpHelper.getCollectionState(this.state.collection, e.target.id, col_selectedSize, col_colorAvailability);

						let collectionItems = this.state.collection;
						collectionItems[e.target.id] = selectedSize;
						collectionItems["colorAvl-" + e.target.id] = col_colorAvailability[index];

						/* Pick up in store*/
						if(product.collection[index].isBopusEligible){
							selectedSkuItem = isCollectionConfigDone[index] && col_selectedSkus[index][0];
							_this.setStoreAndCityByInventory(storeInfo, selectedSkuItem);
						}

						var col_updateCart = {};
						col_updateCart[index] = true;

						this.setState({
							showSizeListBox,
							col_selectedSize,
							col_selectedSkus,
							isCollectionConfigDone,
							collection: collectionItems,
							selectedProductInfo,
							col_updateCart
						});
					}
					else {
						var colorAvailability = this.getAvailableColors(product.SKUS, selectedSize);
						let selectedSkus = pdpHelper.getSelectedSkus(product.SKUS, selectedSize, this.state.selectedColor);

						selectedProductInfo.selectedSkus = selectedSkus;

						// Omitting available SKU color if swatch images has empty array - means no color config
						if(product.swatchImages.length == 0) {
							colorAvailability = {}
						}
						var isConfigDone = pdpHelper.checkIsConfig(this.state.sizeAvailability, colorAvailability, selectedSize, this.state.selectedColor);

						let collectionItems = this.state.collection;
						collectionItems[e.target.id] = selectedSize;
						collectionItems["colorAvl-" + e.target.id] = colorAvailability;

						/* Pick up in store*/
						if(product.isBopusEligible){
							selectedSkuItem = isConfigDone && selectedSkus[0];
							this.setStoreAndCityByInventory(storeInfo, selectedSkuItem);
						}

						this.setState({
							showSizeListBox,
							selectedProductInfo,
							selectedSize,
							selectedSkus: selectedSkus,
							isConfigDone,
							collection: collectionItems,
							triggerSizeSelction: true,
							updateCart: true
						});
					}
				}


			}.bind(this),
			showSizeList: function(e) {
				e.preventDefault();
				var showSizeListBox = (e.target.className == "product-size") ? true : false;
				if(!this.props.isTcom && showSizeListBox) {
					document.body.classList.add("modal-overlay");
				} else {
					document.body.classList.remove("modal-overlay");
				}

				this.setState({
					showSizeListBox: e.target.dataset.item,
				});
			}.bind(this),
			handleCancelClick: function() {
				if(this.state.isHomeRedirect) {
					location.href = '/';
				}
				this.setState({
					continueShopModel: false
				});
				document.body.classList.remove('modal-overlay', 't-login-mask');
				utils.modalActionPosition.setFocusPosition();
			}.bind(this),
			handleSwatchClick: function(e) {
				e.preventDefault();
				var _this = this;
				var color = e.target.dataset.color;
				var url = e.target.dataset.url.replace('_sw', '');
				url = utils.getImageUrl(url, this.state.mainImgWidth);

				const product = this.props.data.payload.products[0];
				const selectedProductInfo = this.state.selectedProductInfo;
				const storeInfo = this.state.storeInfo;
				let selectedSkuItem;

				this.state.errGlobal = "";

				this.eventHandlers().swipeImage(e, 0);

				if(product.collection) {
					var col_sizeAvailability = this.state.col_sizeAvailability,
						col_selectedSkus = this.state.col_selectedSkus,
						isCollectionConfigDone = this.state.isCollectionConfigDone,
						index = e.target.dataset.item;

					col_sizeAvailability[index] = this.getSizeAvailability(product.collection[index].SKUS, color);
					col_selectedSkus[index] = pdpHelper.getSelectedSkus(product.collection[index].SKUS, this.state.col_selectedSize[index], color);

					isCollectionConfigDone[index] = pdpHelper.checkIsConfig(col_sizeAvailability[index], this.state.col_colorAvailability[index], this.state.col_selectedSize[index], color);

					var items = this.state.collection;
					var obj = {
						imageUrl: url,
						selected: e.target.id,
						clr: color
					};
					items[e.target.classList[1]] = obj;

					var col_updateCart = {};
					col_updateCart[index] = true;

					this.setState({
						selectedColor: color,
						userSelectedColor: color,
						selectedSwatchImgUrl: url,
						col_sizeAvailability,
						selectedProductInfo,
						col_selectedSkus,
						isCollectionConfigDone,
						collection: items,
						col_updateCart
					});

					/* Pick up in store*/
					if(col_selectedSkus[index].isBopusEligible){
						selectedSkuItem = isCollectionConfigDone[index] && col_selectedSkus[index][0];
						_this.setStoreAndCityByInventory(storeInfo, selectedSkuItem);
					}
				}
				else {
					var sizeAvailability = this.getSizeAvailability(product.SKUS, color);
					var selectedSkus = pdpHelper.getSelectedSkus(product.SKUS, this.state.selectedSize, color);
					selectedProductInfo.selectedSkus = selectedSkus;

					let isConfigDone = pdpHelper.checkIsConfig(sizeAvailability, this.state.colorAvailability, this.state.selectedSize, color);

					/* Pick up in store*/
					if(product.isBopusEligible){
						selectedSkuItem = isConfigDone && selectedSkus[0];
						this.setStoreAndCityByInventory(storeInfo, selectedSkuItem);
					}

					this.setState({
						selectedColor: color,
						userSelectedColor: color,
						selectedSwatchImgUrl: url,
						sizeAvailability,
						selectedProductInfo,
						selectedSkus,
						isConfigDone,
						updateCart: true
					});
				}
			}.bind(this),
			handleSwatchCol: function(e) {
				e.preventDefault();
				var color = e.target.dataset.color;
				var url = e.target.dataset.url.replace('_sw', '');
				url = utils.getImageUrl(url, this.state.mainImgWidth);
				var items = this.state.collection;
				var obj = {
					imageUrl: url,
					selected: e.target.id,
					clr: color
				};
				items[e.target.classList[1]] = obj;
				this.setState({
					collection: items
				});

			}.bind(this),
			handleInfoSectionClick: function(section) {
				$ && $('html, body').animate({
					scrollTop: $('#' + section).parent().offset().top - 50
				}, 100);
				if(this.state.selectedSection === section) {
					this.setState({
						selectedSection: ''
					});
				} else {
					this.setState({
						selectedSection: section
					});
				}
			}.bind(this),
			openAndFocusAccordion: function(section) {
				this.setState({
					selectedSection: section
				});
				$('html, body').animate({
					scrollTop: $('#' + section).parent().offset().top + 50
				}, 100);

			}.bind(this),
			toggleAllColors: function(e) {
				e.preventDefault();
				var showAllColors = !this.state.showAllColors;
				this.setState({
					showAllColors: showAllColors
				});
			}.bind(this),
			showMoreLess: function(e) {
				e.preventDefault();
				let items = this.state.collection;
				items[e.target.id] = !items[e.target.id];
				this.setState({
					collection: items
				});
			}.bind(this),
			getPdpTabContent: function(e) {
				e.preventDefault();
				this.setState({
					collectionPdpContent: e.target.id
				});
				for(var tab of document.querySelectorAll(".pdp-tab")) {
					tab.classList.remove('selected');
				}
				e.target.classList.add("selected");
			}.bind(this),
			productCarouselZoom: function(e) {
				var chosenItemIndex = this.state.selectedImageIndex;
				var imageWidth = 320;
				var offset = "-" + imageWidth * chosenItemIndex;

				let values = {
					productZoom: !this.state.productCarousel.productZoom,
					value: offset,
					nav: chosenItemIndex
				};
				this.setState({
					productCarousel: values
				});
				values.productZoom ? ReactDOM.findDOMNode(document.body).classList.add("zoom") : ReactDOM.findDOMNode(document.body).classList.remove("zoom");
				let crslVal = {
					"prodZoomVal": 1,
					"carouselLimit": this.state.productZoom.carouselLimit,
					"currSlide": 0,
					"slideVal": 0,
					slideEnd: false
				};

				this.setState({
					productZoom: crslVal,
					setZoom: this.pinchZoom
				});

			}.bind(this),
			navCarousel: function(swipe, nav) {
				event.preventDefault();
				this.slideCarousel(swipe, nav);
			}.bind(this),
			productZoom: function(direction) {
				event.preventDefault();
				let crslVal = this.state.productZoom;
				let zoom = crslVal.prodZoomVal + (direction ? 0.2 : -0.2);
				crslVal['prodZoomVal'] = zoom;
				zoom >= 1 && zoom <= 2 && this.setState({
					productZoom: crslVal
				});
			}.bind(this),
			navMinCarousel: function(direction) {
				event.preventDefault();
				var prdCnt = this.state.productImages.length,
					crslCnt = this.state.productZoom.carouselLimit,
					minWdt = ReactDOM.findDOMNode(document.querySelectorAll("#nav-img-container .product-img")[0]).offsetWidth;
				if(prdCnt > crslCnt) {
					let slds = new Array(Math.ceil(prdCnt / crslCnt));
					let crslVal = this.state.productZoom;
					var crtVal = 0;
					for(var i = 0; i < slds.length; i++) {
						slds.length == i + 1 ? (crtVal = prdCnt - (crtVal ? crtVal : crslCnt)) : (crtVal = i * crslCnt);
						slds[i] = crtVal * minWdt;
					}
					let navSld = crslVal.currSlide - (direction ? -1 : 1);
					navSld < slds.length && navSld >= 0 && this.setState({
						productZoom: {
							prodZoomVal: crslVal.prodZoomVal,
							carouselLimit: crslVal.carouselLimit,
							currSlide: navSld,
							slideVal: slds[navSld],
							slideEnd: (slds.length - 1 == navSld)
						}
					});
				}
			}.bind(this),
			swipeImage: function(e, chosenItem) {
				var chosenItemNumber;

				if(typeof chosenItem != 'undefined'){
					chosenItemNumber = chosenItem;
				} else {
					chosenItemNumber = parseInt(e.target.dataset.key.split('-')[1]);
				}

				var imageWidth = 320;
				var offset = "-" + imageWidth * chosenItemNumber;
				var productImages = this.state.productImages;

				if(chosenItemNumber < productImages.length) {
					productImages[chosenItemNumber].rendered = true;
				}

				this.slideImages(offset);
				this.setState({
					selectedImageIndex: chosenItemNumber,
					productImages
				})
			}.bind(this),
			onQuantityChange: function(inputQuantity) {
				var isConfigDone = pdpHelper.checkIsConfig(this.state.sizeAvailability, this.state.colorAvailability, this.state.selectedSize, this.state.selectedColor);
				this.setState({
					inputQuantity: inputQuantity,
					isConfigDone: isConfigDone,
					triggerQuantity: true
				})
			}.bind(this),
			stopTriggerQuantity: function(update){
				this.setState({triggerQuantity:false, triggerSizeSelction:false})
			}.bind(this),
			triggerAddtoBag: function(triggerAddtoBag) {
				this.setState({triggerAddtoBag});
			}.bind(this),
			callbackAddtoBag: function(tryAddtoBag, errGlobal, reqSize) {
				this.setState({
					tryAddtoBag, errGlobal, reqSize
				});
			}.bind(this),
			resetValidationMsg: function(){
				this.setState({errGlobal: ''});
			}.bind(this),
			offerDataAvail: function(availOfferData){
				this.setState({availOfferData: availOfferData});
			}.bind(this),
			callbackStorePickup: function(checkAnotherStore, storeName, storeOutofstock) {
				checkAnotherStore && this.setState({checkAnotherStore});
				storeName && this.setState({storeName});
				storeOutofstock && this.setState({storeOutofstock});
			}.bind(this),
			selectStoreForHybrid: function(storeInfo, selectedSkuItem){
				this.setStoreAndCityByInventory(storeInfo, selectedSkuItem);
			}.bind(this),
			validatePdpForFIS: function(bool, productInfo) {
				setFindInStoreInitialClickOmniture();
				let _validationStatus =  validatePdpSkuConfig(this.state, this.updatePDPState);
				if(_validationStatus){
					utils.showFindInStoreModal(bool, productInfo);
				}
			}.bind(this),
			showShopModel: function(shopFlag) {
				this.setState({continueShopModel: shopFlag});
				document.body.classList.add('modal-overlay');
				//if(shopFlag)setOrderCalcData();
				if(shopFlag) window && window.brightTag && window.brightTag.setOrderCalcData();
			}.bind(this),
			gotoCart: function (e) {
				this.setState({
					continueShopModel: false
				});
				console.log('taking to cart page');
				window.location.href = "/checkout/checkout.jsp#/shoppingBag";
			}.bind(this),
			gotoCheckout: function(e) {
				this.setState({continueShopModel: false});
				utils.goToCheckout();
			}.bind(this)
		}
	}, // end eventHandlers
	getStoreInfo: function(bagObjForCart){
		let storeFromURL = {},
			storeFromMyStores = {},
			storesFromGeoloc = {};

		storeFromURL.storeNum = utils.getUrlParam('storeid', location.href);

		let topStoresInfo = storeFromURL.storeNum && utils.getFromLocalStorage(topStoresInfo);
		storeFromURL.storeName = function(topStoresInfo){
			if(topStoresInfo){
				var topStoreArray = topStoresInfo.split(',');

				try {
					for(store of topStoreArray){
						var storeInfo = store.split('|');

						if(storeInfo[1] = storeFromURL.storeNum){
							return storeInfo[0];
						}
					}
				} catch (e){
					console.log(e);
				}
			}

			return;
		}(topStoresInfo);;

		let myStoreInfo = utils.getCookieValue('mystore') && JSON.parse(utils.getCookieValue('mystore'));
		storeFromMyStores.storeNum = myStoreInfo.storeNums;
		storeFromMyStores.storeName = myStoreInfo.name;
		storeFromMyStores.storeZip = myStoreInfo.zipcode;

		let closestStoreInfo = utils.getCookieValue('closeststore') && JSON.parse(utils.getCookieValue('closeststore'));
		storesFromGeoloc.storeNum = closestStoreInfo.id;
		storesFromGeoloc.storeName = closestStoreInfo.name;
		storesFromGeoloc.storeZip = closestStoreInfo.zipcode;
		storesFromGeoloc.nearbyStores = closestStoreInfo.storeNums;

		var storeInfo = {};
		storeFromURL.storeNum ? (
			storeInfo = storeFromURL,
			storeInfo.storeFrom = 'stringURL'
		) : (
			storeFromMyStores.storeNum ? (
				storeInfo = storeFromMyStores,
				storeInfo.storeFrom = 'stringMystore'
			) : (
				storesFromGeoloc.storeNum ? (
					storeInfo = storesFromGeoloc,
					storeInfo.storeFrom = 'stringGeoloc'
				) : (
					""
				)
			)
		);

		// This obj will be used later to check availability in 50 mile radius;
		storeInfo.storeCheck = {};

		// For Now over-writting store info for checkout
		if(bagObjForCart){
			storeInfo = {};

			if(bagObjForCart.storeNum){
				storeInfo.storeNum = bagObjForCart.storeNum;
			}
		}

		return storeInfo;
	},
	setStoreAndCityByInventory: function(storeInfo, selectedSkuItem){
		let _this = this;

		var storeOutofstock = this.state.storeOutofstock;

		if(storeInfo.storeNum){
			this.setState({aToBagPreloadImg: true})
		}

		let storeNumForInventory = ((storeInfo.storeFrom == 'stringGeoloc') ? storeInfo.nearbyStores : storeInfo.storeNum);
		storeInfo && selectedSkuItem && pdpHelper.getInventoryInfo(selectedSkuItem.skuCode, storeNumForInventory, function(){}, function(data){
			var stores = data.payload.skus[0].stores;

			if(stores && stores.length && stores.length == 1){
				/* This check only for URL and mystore cookie */
				if(stores[0].availability == "In Stock"){
					storeOutofstock[selectedSkuItem.skuCode] = false;
					_this.setState({checkAnotherStore: true, storeOutofstock});
				}
				if(stores[0].availability == "Out of Stock") {
					if(storeInfo.storeZip){
						pdpHelper.getInventoryFiftyMilesRadius(selectedSkuItem.skuCode, storeInfo.storeZip, function(){}, function(data){
							var storesFromFifyMileRadius = data.payload.skus[0].stores;
							var storeCheckCounter = 0;

							for(var i=0; i<stores.length; i++){
								if(stores[i].availability == "In Stock"){
									++storeCheckCounter;
									break;
								}
							}

							if(storeCheckCounter == 0){
								storeInfo.storeCheck[selectedSkuItem.skuCode] = 'fityMileRadius';
							}

							storeOutofstock[selectedSkuItem.skuCode] = true;
							_this.setState({checkAnotherStore: true, storeOutofstock});

						})
					} else {
						storeOutofstock[selectedSkuItem.skuCode] = true;
						_this.setState({checkAnotherStore: true, storeOutofstock});
					}
				}
			}
			else if(stores && stores.length && stores.length > 1) {
				/* This check is only for CLosest store cookie */

				/* Checks Out of stock only for First item
					if In-stock was present then the next Loop will take care and over write it.
				*/
				if(stores[0].availability == "Out of Stock") {
					storeOutofstock[selectedSkuItem.skuCode] = true;
					_this.setState({checkAnotherStore: true, storeOutofstock});
					_this.setState({aToBagPreloadImg: false});

					/* Here Closesest store - not needed to know city or store name
					By default says no stores in 50 mile radius */
					return;
				}

				for(var i=0; i<stores.length; i++){
					if(stores[i].availability == "In Stock"){
						if(storeInfo.storeNum == stores[i].storeNum){
							/* Existing store num info matches the Instock store num */
							storeOutofstock[selectedSkuItem.skuCode] = false;
							_this.setState({checkAnotherStore: true, storeOutofstock});
						}
						else {
							storeInfo.storeNum = stores[i].storeNum;
							storeOutofstock[selectedSkuItem.skuCode] = true;
							_this.setState({storeInfo, checkAnotherStore: true, storeOutofstock});

							/* We are getting a new store from Closest store cookie - so trying to get a store name */
							storeInfo.storeNum && pdpHelper.getStoreCity(storeInfo.storeNum, function(){}, function(data){
								if(data.payload.stores && data.payload.stores.length){
									storeInfo.storeName = data.payload.stores[0].storeName;
									_this.setState({storeInfo, aToBagPreloadImg: false});
								}
							});
						}

						/* We need the closest Available or Instock Store so breaking out when we
						find the earliest one */
						break;
					}
				}
			}

			if(storeInfo.storeName){
				_this.setState({aToBagPreloadImg: false});
			}
		});

		storeInfo.storeNum && !storeInfo.storeName && pdpHelper.getStoreCity(storeInfo.storeNum, function(){}, function(data){
			if(data.payload.stores && data.payload.stores.length){
				storeInfo.storeName = data.payload.stores[0].storeName;
				_this.setState({storeInfo, aToBagPreloadImg: false})
			}
		});
	},
	isSlide: true,
	isMainSlide: true,
	isZoomMounted: false,
	isSwipe:false,
	pinchZoom: function(imageContainer, zoomImage, isDoubleTap) {
		var MIN_SCALE = 1,
			MAX_SCALE = 2,
			imgWidth = null,
			imgHeight = null,
			viewportWidth = null,
			viewportHeight = null,
			scale = null,
			lastScale = null,
			container = null,
			img = null,
			x = 0,
			lastX = 0,
			y = 0,
			lastY = 0,
			pinchCenter = null,
			doubleTap = false;
			self = this;
		var disableImgEventHandlers = function() {
			var events = ['onclick', 'onmousedown', 'onmousemove', 'onmouseout', 'onmouseover',
				'onmouseup', 'ondblclick', 'onfocus', 'onblur'
			];
			events.forEach(function(event) {
				img[event] = function() {
					return false;
				};
			});
		};
		var absolutePosition = function(el) {
			var x = 0,
				y = 0;
			while(el !== null) {
				x += el.offsetLeft;
				y += el.offsetTop;
				el = el.offsetParent;
			}
			return {
				x: x,
				y: y
			};
		};
		var restrictScale = function(scale) {
			if(scale < MIN_SCALE) {
				scale = MIN_SCALE;
			} else if(scale > MAX_SCALE) {
				scale = MAX_SCALE;
			}
			return scale;
		};
		var restrictRawPos = function(pos, viewportDim, imgDim) {
			if(pos < viewportDim / scale - imgDim) {
				pos = viewportDim / scale - imgDim;
			} else if(pos > 0) {
				pos = 0;
			}
			return pos;
		};
		var updateLastPos = function(deltaX, deltaY) {
			lastX = x;
			lastY = y;
		};
		var translate = function(deltaX, deltaY) {
			var newX = restrictRawPos(lastX + deltaX / scale,
				Math.min(viewportWidth, curWidth), imgWidth);
			x = newX;
			img.style.marginLeft = Math.ceil(newX * scale) + 'px';
			var newY = restrictRawPos(lastY + deltaY / scale,
				Math.min(viewportHeight, curHeight), imgHeight);
			y = newY;
			img.style.marginTop = Math.ceil(newY * scale) + 'px';
		};

		var zoom = function(scaleBy) {
			scale = !doubleTap ? restrictScale(lastScale * (scaleBy)) : (scale > MIN_SCALE ? MIN_SCALE : MAX_SCALE);
			self.isSlide = (scale == MIN_SCALE);

			self.isMainSlide = (scale == MIN_SCALE);

			curWidth = imgWidth * scale;
			curHeight = imgHeight * scale;
			img.style.width = Math.ceil(curWidth) + 'px';
			img.style.height = Math.ceil(curHeight) + 'px';
			translate(0, 0);
			doubleTap = false;
		};
		var rawCenter = function(e) {
			var pos = absolutePosition(container);
			var scrollLeft = window.pageXOffset ? window.pageXOffset : document.body.scrollLeft;
			var scrollTop = window.pageYOffset ? window.pageYOffset : document.body.scrollTop;
			var zoomX = -x + (e.center.x - pos.x + scrollLeft) / e.scale;
			var zoomY = -y + (e.center.y - pos.y + scrollTop) / e.scale;
			return {
				x: zoomX,
				y: zoomY
			};
		};
		var updateLastScale = function() {
			lastScale = scale;
		};
		var zoomAround = function(scaleBy, rawZoomX, rawZoomY, doNotUpdateLast) {
			zoom(scaleBy);
			var rawCenterX = -x + Math.min(viewportWidth, curWidth) / 2 / scale;
			var rawCenterY = -y + Math.min(viewportHeight, curHeight) / 2 / scale;
			var deltaX = (rawCenterX - rawZoomX) * scale;
			var deltaY = (rawCenterY - rawZoomY) * scale;
			translate(deltaX, deltaY);
			if(!doNotUpdateLast) {
				updateLastScale();
				updateLastPos();
			}
		};
		img = zoomImage;
		container = imageContainer;
		disableImgEventHandlers();
		imgWidth = img.offsetWidth;
		imgHeight = img.offsetHeight;
		viewportWidth = img.offsetWidth;
		scale = viewportWidth / imgWidth;
		lastScale = scale;
		viewportHeight = container.offsetHeight;

		var pinchCenterOffset = {};
		var curWidth = imgWidth * scale;
		var curHeight = imgHeight * scale;
		var hammer = new Hammer(container, {
			domEvents: true
		});
		hammer.get('pinch').set({
			enable: true
		});
		hammer.on('pan', function(e) {
			var zoomX = -x + Math.min(viewportWidth, curWidth)/2/scale;
		    var zoomY = -y + Math.min(viewportHeight, curHeight)/2/scale;
			self.isSwipe? zoomAround(1/2, zoomX, zoomY) : translate(e.deltaX, e.deltaY);
		});
		hammer.on('panend', function(e) {
			updateLastPos();
		});


		hammer.on('pinch', function(e) {
			if(pinchCenter === null) {
				pinchCenter = rawCenter(e);
				var offsetX = pinchCenter.x * scale - (-x * scale + Math.min(viewportWidth, curWidth) / 2);
				var offsetY = pinchCenter.y * scale - (-y * scale + Math.min(viewportHeight, curHeight) / 2);
				pinchCenterOffset = {
					x: offsetX,
					y: offsetY
				};
			}
			var newScale = restrictScale(scale * e.scale);
			var zoomX = pinchCenter.x * newScale - pinchCenterOffset.x;
			var zoomY = pinchCenter.y * newScale - pinchCenterOffset.y;
			var zoomCenter = {
				x: zoomX / newScale,
				y: zoomY / newScale
			};
			zoomAround(e.scale, zoomCenter.x, zoomCenter.y, true);
		});
		hammer.on('pinchend', function(e) {
			updateLastScale();
			updateLastPos();
			pinchCenter = null;
			self.isSwipe=false;
		});
		if(isDoubleTap) {
			hammer.on('doubletap', function(e) {
				var c = rawCenter(e);
				doubleTap = true;
				self.isSwipe=false;
				zoomAround(1, c.x, c.y);
			});
		}
	},
	inventoryCheckPickUpInStore: function(sku) {
		sku = sku[0].skuCode;
		let ajaxConfig = {
			ulr: '/api/v1/inventory/sku/' + sku[0].skuCode,
			cache: true,
			accept: 'application/json',
			method: 'get'
		};
		let successCallback = function(data) {
			console.log(data)
		};
		let failCallback = function(err) {
			console.log(err)
		};

		$.ajax(ajaxConfig).done(successCallback).fail(failCallback);
	},
	getAvailableColors: function(skus, selectedSize) {
		var allSizes = (typeof selectedSize === 'undefined' || !selectedSize);
		var colorAvailability = {};

		skus.map((sku) => {

			if('In Stock' === sku.availability && (sku.color && (allSizes || selectedSize === sku.size))) {
				colorAvailability[sku.color] = true;
			}
		});

		return colorAvailability;
	},
	slideCarousel: function(swipe, nav) {
		//if(this.isSlide) {
		//	$('.product-img.panZoom-img').find('img').css({"width":"320px", "height":"320px", "margin-left":"0","margin-top":"0"});
		this.isSwipe=true;
			let carousel = this.state.productCarousel,
				currNav = carousel.nav;
			!swipe ? (currNav = swipe === null ? (nav) : (currNav - nav)) : (currNav = currNav + nav);
			let sldWdt = this.props.isTcom ? this.state.mainZoomImgWidth : this.state.mainImgWidth;
			if(currNav >= 0) {
				carousel['value'] = -(currNav < this.state.productImages.length ? (currNav * sldWdt) : (carousel.nav * sldWdt));
				let evalSld = Math.abs(parseInt(this.state.productCarousel.value) / sldWdt);
				evalSld < this.state.productImages.length && (carousel['nav'] = evalSld);
				this.setState({
					productCarousel: carousel
				});
			}
		//}
	},
	getSizes: function(skuInfo){
		var skus = skuInfo || [];
		var sizes = [];
		var seen = {};

		skus.map(function(sku) {
			if(seen[sku.size]) {
				return;
			}

			seen[sku.size] = true;
			sizes.push(sku.size);
		});

		return sizes;
	},
	slideImages: function(offset) {
		$('#image-carousel').animate({
			'margin-left': offset
		}, 200, function() {});
	},
	slideImagesLeft: function() {
		if(this.isMainSlide) {
			// if (this.state.selectedSwatchImgUrl){
			// 	return;
			// }

			var productImages = this.state.productImages;
			if(this.state.selectedImageIndex < (productImages.length - 1)) {
				this.slideImages('-=' + this.state.mainImgWidth);
				var newSelectedImageIndex = this.state.selectedImageIndex + 1;
				var nextSelectedImageIndex = newSelectedImageIndex + 1;
				if(nextSelectedImageIndex < productImages.length) {
					productImages[nextSelectedImageIndex].rendered = true;
				}

				this.setState({
					selectedImageIndex: newSelectedImageIndex,
					productImages: productImages
				});
			}
		}
	},

	slideImagesRight: function() {
		if(this.isMainSlide) {
			// if (this.state.selectedSwatchImgUrl){
			// 	return;
			// }
			var productImages = this.state.productImages;
			var newImageIndex = this.state.selectedImageIndex -1;

			productImages[newImageIndex].rendered = true;

			if(this.state.selectedImageIndex > 0) {
				this.slideImages('+=' + this.state.mainImgWidth);

				this.setState({
					selectedImageIndex: newImageIndex,
					productImages
				});
			}
		}
	},

	getSizeAvailability: function(skuInfo, userSelectedColor) {
		// Get Size available for a color
		var skus = skuInfo || [];
		var allColors = (typeof userSelectedColor === 'undefined' || !userSelectedColor);
		var sizeAvailability = {};

		skus.map(function(sku) {
			if('In Stock' === sku.availability && (sku.size && (allColors || userSelectedColor === sku.color))) {
				sizeAvailability[sku.size] = true;
			}
		});

		return sizeAvailability;
	},

	render(){
		let isCollectionPdp = this.props.data.payload.products[0].collection;
		return (isCollectionPdp ? (
			<PdpCollectionView {...this.props} {...this.state} eventHandlers={this.eventHandlers()}/>
		) : (
			<PdpView {...this.props} {...this.state} eventHandlers={this.eventHandlers()}/>
		));
	}
});
