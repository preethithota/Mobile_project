import * as menuHelper from '../containers/menu-helper';

const categoryData = require('./category-data.json').payload;

describe('getCurrentCategoryLists', () => {

  it('should return top level data, (i.e. [categoryData]) if not categories are selected', () => {
    let selectedCategories = [];
    let currentCategoryLists = menuHelper.getCurrentCategoryLists(categoryData, selectedCategories);
    expect(currentCategoryLists).toEqual([categoryData]);
  });

});
