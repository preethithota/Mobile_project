import React from 'react';
import {mount} from 'enzyme';
import HeaderView from '../views/header-view';

describe('HeaderView', () => {
  let headerView = mount(
    <HeaderView isTcom={false} serverRender={true} isLoggedIn={false} firstName={''}
      eventHandlers={{}} setCategoryData={{}}/>
  );

  it('contains mcom-logo', () => {
    expect(headerView.find('#mcom-logo').exists()).toBe(true);
  });

  it('contains menu-section', () => {
    expect(headerView.find('#menu-section').exists()).toBe(true);
  });

});
