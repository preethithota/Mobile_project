import React from 'react';
import {mount} from 'enzyme';
import HamburgerMenuContainer from '../containers/hamburger-menu-container';

const categoryData = require('./category-data.json').payload;
const mockFn = jest.fn();

describe('HamburgerMenuContainer', () => {
  const mockFn = jest.fn();
  let hamburgerMenuContainer = mount(
    <HamburgerMenuContainer
        setMcomHamburgerMenuVisibility={mockFn}
        toggleTcomHamburgerMenuVisibility={mockFn}
        setCategoryMenuVisibility={true}
        showLogin={mockFn}
        isCategoryMenuVisible={true}
        isMcomHamburgerMenuVisible={true}
        isTcomHamburgerMenuVisible={false}
        categoryData={categoryData}
        setCategoryData={mockFn}
      />
  );

  it('contains #mcom-category-menu', () => {
    expect(hamburgerMenuContainer.find('#mcom-category-menu').exists()).toBe(true);
  });

  it('#mcom-category-menu > ul contains 15 items', () => {
    expect(hamburgerMenuContainer.find('#mcom-category-menu > ul').children().length).toBe(15);
  });

});

describe('HamburgerMenuContainer', () => {

  const dealsData = {
    categories: [
      {
        ID: "1",
        categories: [],
        index: 2,
        name: "Local Ad",
        seoURL: "http://kohls.shoplocal.com/Kohls/Entry/LandingContent?storeid=2482787&sneakpeek=N&listingid=0"
      },
      {
        ID: "2",
        categories: [],
        index: 3,
        name: "Today's Deals",
        seoURL: "/sale-event/coupons-deals.jsp"
      }
    ]
  };

  let hamburgerMenuContainer = mount(
    <HamburgerMenuContainer
        setMcomHamburgerMenuVisibility={mockFn}
        toggleTcomHamburgerMenuVisibility={mockFn}
        setCategoryMenuVisibility={true}
        showLogin={mockFn}
        isCategoryMenuVisible={true}
        isMcomHamburgerMenuVisible={true}
        isTcomHamburgerMenuVisible={false}
        categoryData={dealsData}
        setCategoryData={mockFn}
      />
  );

  it('#mcom-category-menu > ul contains 3 items', () => {
    expect(hamburgerMenuContainer.find('#mcom-category-menu > ul').children().length).toBe(3);
  });



});
