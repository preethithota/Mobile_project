import React from 'react';
export default React.createClass({

  render: function(){
    debugHeader && console.log('inside search thumbnails view');

    const props = this.props;

    return (
      <div>
        {props.showThumbNails && props.previewData && props.previewData.productItems &&
            <div id="preview">
              <div className="title">{props.previewData.featuredResultsLabel}</div>
              <ul>
                {props.previewData.productItems.map((product, index) => {
                      return (
                        <li key={index}>
                          <a href={product.productURL}>
                            <img src={product.imageURL}/>
                            <div>{product.displayName}</div>
                          </a>
                        </li>
                      )
                  })
                }
              </ul>
            </div>
        }
      </div>
    );
  }
});
