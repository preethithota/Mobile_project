import React from 'react';

export default React.createClass({

  render: function(){
    const props = this.props;
    const selectedCategory = (props.selectedCategoryIndex < props.selectedCategories.length) ?
      props.selectedCategories[props.selectedCategoryIndex] : {};

    const showAllCategory = props.showAllCategory;

    return <ul className="menu-list">
    {showAllCategory && (
      <li><a href={showAllCategory.seoUrl}>Shop All {showAllCategory.name}</a></li>
    )}
		{props.categories.map((category) => {
      const isCurrentCategory = (category.ID === selectedCategory.id);
      //const isLinkClick = (category.categories) ? false : true;
			return (
				<li key={category.index}
          onClick={() => props.handleCategorySelection(category, props.selectedCategoryIndex)}
          className={(isCurrentCategory) ? 'selected-category': ''} dangerouslySetInnerHTML={{__html: category.name}}>
				</li>
			)
		})}
		</ul>
  }
});
