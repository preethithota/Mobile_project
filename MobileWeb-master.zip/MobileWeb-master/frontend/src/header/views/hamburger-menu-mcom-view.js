import React from 'react';
import CategoryList from './category-list-component';
//import {getCookieValue} from '../../global/utils';
import * as utils from '../../global/utils';
import {showRegistryModal} from '../../pdp/registry/registry-helper';

export default React.createClass({

  // ReactJS Lifecyle function
  render: function(){
    const props = this.props;
    const shopByCategoryLabel = 'Shop By Category';
    const listMenuLabel = 'Lists';
    const RegistryMenuLabel = 'Registries';
    const isCategoryMenuVisible = props.isCategoryMenuVisible;
    let categories, headerLabel;
    const isLoggedIn = this.props.isLoggedIn;
    const showLogin = this.props.showLogin;
    const listData = this.props.listData;

    // Get sub-menu when clicked on main menu
    if(props.showDealsMenu){
      categories = this.getDealsCategories();
      headerLabel = 'Deals & Coupons';
    }else if(props.showListMenu) {
      if(isLoggedIn) {
          categories = this.getAllListCategories(listData, isLoggedIn);
       } else {
          categories = this.getListCategories(isLoggedIn);
      }
      headerLabel = listMenuLabel;
    } else if(props.showRegistryMenu){
      categories = this.getRegistryCategories(isLoggedIn);
      headerLabel = RegistryMenuLabel;
    }else if(isCategoryMenuVisible){
      categories = props.currentCategoryLists[props.currentCategoryLists.length - 1].categories;
      headerLabel = shopByCategoryLabel;
    }

    var _selected_Store = utils.getCookieValue('mystore') || window.localStorage && window.localStorage.getItem("closeststore");
    var _sld_Store_Name = _selected_Store && JSON.parse(_selected_Store).name;
    var _sld_store_Path = _selected_Store && "/stores/goto-"+JSON.parse(_selected_Store).id+".m.shtml";

    const eventHandlers = props.eventHandlers;
    const selectedCategories = props.selectedCategories;
    const selectedCategory = (selectedCategories.length > 0) ? selectedCategories[selectedCategories.length - 1] : {};
    const isHomePage = (window.location.pathname === "/") ? true : false;
    return (
      <div id="mcom-hamburger-main">
      <div id="mcom-hamburger-overlay" onClick={() => props.setMcomHamburgerMenuVisibility(false)} >
	  <div className="menu-section-overlay">
                <div className="menu-icon"></div>
                <div className="menu-text">Menu</div>
              </div>
	  </div>
      <div id="mcom-hamburger-menu">
      	<a href={(isHomePage) ? 'javascript:void(0);': '/'}><h3 id="hamburger-header" className={(props.isCategoryMenuVisible) ? 'display-none': ''} onClick={() => props.setMcomHamburgerMenuVisibility(false)}>
          <span className="m-home-icon"></span>Home
        </h3></a>
		<h3 id="m-hamburger-menu-bck" className={(props.isCategoryMenuVisible) ? 'display-block': 'display-none'} onClick={(e) => props.setCategoryMenuVisibility(e, false)}>
          <span className="m-back-icon"></span>Menu
        </h3>
      	<div id="home-menu" className={(props.isCategoryMenuVisible) ? 'display-none': ''}>
      		<ul className="top-menu">
      			<li>
              <a href="#" id="shop-by-cat-link" onClick={(e) => props.setCategoryMenuVisibility(e, true, false, false, false)}>
                {shopByCategoryLabel}
              </a>
            </li>
			    <li><a href="/walletpage" className ="m-walletmenu">Wallet</a></li>
      			<li><a href="/feature/rewards.jsp" className ="m-yes2you-icon" alt="yes2you rewards"></a><span className="screen-reader-text">yes2you rewards</span></li>
				<li className={_selected_Store?"active-store":""}><a href={_selected_Store?_sld_store_Path:"/stores/search.m.shtml"}><span className ="m-shop-my-store"></span><span className='mystore-ctr'>{_selected_Store?"Change My Store":"Shop My Store"}{_selected_Store && <span className='store-name'>{_sld_Store_Name}</span>}</span></a></li>
      			<li><a href="#" onClick={props.showLogin}>Account</a></li>
      			<li><a href="#" >Lists</a></li>
      			<li><a href="#" >Registries</a></li>
      			<li><a href="#" id="deals-link" onClick={e => props.setCategoryMenuVisibility(e, true, true, false, false)}>Deals & Coupons</a></li>
				<li><a href="/catalog/kohl-s-gift-cards-gift-cards.jsp?CN=Product:Kohl%27s%20Gift%20Cards+Department:Gift%20Cards">Gift Cards</a></li>
      			<li><a href="#">Welcome to Kohl's</a></li>
      		</ul>
      		<ul className="bottom-menu">
      			<li><a href="#" onClick={e => props.switchOrderPage(e)}>Order Status</a></li>
      			<li><a href="#"><span className ="m-kohlscharge-icon"></span>My Kohl's Charge</a></li>
      			<li><a href="/feature/contactus.jsp">Help/Contact Us</a></li>
      		</ul>
      	</div>

        {props.isCategoryMenuVisible && <div id="mcom-category-menu">
          <ul>
  					<li className={(props.isSelectedMenu)?'selected-category':'m-main-catagory'}><a href="#" onClick={eventHandlers.resetCategoryList}>{headerLabel}</a></li>
  					{selectedCategories.map((currentSelectedCategory) => {
  						let isCurrentCategory = (currentSelectedCategory.id === selectedCategory.id && !props.selectedCategoryItem);
  						return(
  							<li key={currentSelectedCategory.id}
  								className={(isCurrentCategory) ? 'selected-category': ''}>
  								<a href='#' onClick={(e) => eventHandlers.selectPreviousCategory(e, currentSelectedCategory.id)}>
  									{currentSelectedCategory.name}
  								</a>
  							</li>
  						)
  					})}
  					{selectedCategory.seoUrl && (
  						<li className={(props.selectedCategoryId === selectedCategory.id) ? 'selected-category': ''}>
  							<a href='#' onClick={(e) => eventHandlers.handleCategorySelection(selectedCategory)}>
  								Shop All {selectedCategory.name}
  							</a>
  						</li>
  					)}
            {categories && categories.map((category) => {
              return (
  							<li key={category.index} className={(props.selectedCategoryId === category.ID) ? 'selected-category': ''}
                  onClick={(e) => eventHandlers.handleCategorySelection(category)} dangerouslySetInnerHTML={{__html: category.name}}>
  							</li>
  						)
            })}
          </ul>
        </div>}
      </div><div id="add-to-registry-container"></div>
      </div>
    )
  },

  getDealsCategories: function(){
    return [
      {
        ID: "1",
        categories: [],
        index: 2,
        name: "Local Ad",
        seoURL: "http://kohls.shoplocal.com/Kohls/Entry/LandingContent?storeid=2482787&sneakpeek=N&listingid=0",
        onClick: () => {
          window.open("http://kohls.shoplocal.com/Kohls/Entry/LandingContent?storeid=2482787&sneakpeek=N&listingid=0", "_blank", "width=596,height=550,scrollbars=yes");
        }
      },
      {
        ID: "2",
        categories: [],
        index: 3,
        name: "Today's Deals",
        seoURL: "/sale-event/coupons-deals.jsp",
        onClick: () => {
          location.href = "/sale-event/coupons-deals.jsp";
        }
      }
    ];
  },

  getRegistryCategories: function(isLoggedIn) {
    return [
      {
        ID: "1",
        categories: [],
        index: 2,
        name: "Find a Registry",
        seoURL: "/gift-registry/gift-registry.jsp",
        onClick: () => {
          location.href = "/gift-registry/gift-registry.jsp";
        }
      },
      {
        ID: "2",
        categories: [],
        index: 3,
        name: "Create a Registry",
        seoURL: "/upgrade/gift_registry/kohlsgrw_home.jsp?section=mylists&action=createregistry",
        onClick: () => {
          if(isLoggedIn) {
            location.href = "/upgrade/gift_registry/kohlsgrw_home.jsp?section=mylists&action=createregistry";
          } else {
            utils.showLogin(kohlsData.isTcom, false, function(){ location.href = "/upgrade/gift_registry/kohlsgrw_home.jsp?section=mylists&action=createregistry"; }, 'login-modal');
          }
        }
      },
      {
        ID: "3",
        categories: [],
        index: 4,
        name: "Manage a Registry",
        seoURL: "/gift-registry/gift-registry.jsp",
        onClick: () => {
          if(isLoggedIn) {
            location.href = "/gift-registry/gift-registry.jsp";
          } else {
            utils.showLogin(kohlsData.isTcom, false, function(){ location.href = "/gift-registry/gift-registry.jsp";}, 'login-modal');
          }
        }
      },
      {
        ID: "4",
        categories: [],
        index: 5,
        name: "Gift Registry",
        seoURL: "/gift-registry/gift-registry.jsp",
        onClick: () => {
          location.href = "/gift-registry/gift-registry";
        }
      },{
        ID: "5",
        categories: [],
        index: 6,
        name: " Wedding ",
        seoURL: "/gift-registry/wedding-registry.jsp",
        onClick: () => {
          location.href = "/gift-registry/wedding-registry.jsp";
        }
      },
      {
        ID: "6",
        categories: [],
        index: 7,
        name: "Baby",
        seoURL: "/gift-registry/baby-registry.jsp",
        onClick: () => {
          location.href = "/gift-registry/baby-registry.jsp";
        }
      },
      {
        ID: "7",
        categories: [],
        index: 8,
        name: "Celebration",
        seoURL: "/gift-registry/celebrations-registry.jsp",
        onClick: () => {
          location.href = "/gift-registry/celebrations-registry.jsp";
        }
      }
    ];
  },

  getListCategories: function(isLoggedIn){
    return [
      {
        ID: "2",
        categories: [],
        index: 1,
        name: " View My lists ",
        seoURL: "/upgrade/giftinglisting/wishlist.jsp?section=mylists",
        onClick: () => {
          if(isLoggedIn) {
            location.href = "/upgrade/giftinglisting/wishlist.jsp?section=mylists";
          } else {
            utils.showLogin(kohlsData.isTcom, false, function(){ location.href = "/upgrade/giftinglisting/wishlist.jsp?section=mylists"; }, 'login-modal');
          }
        }
      },
       {
        ID: "3",
        categories: [],
        index: 2,
        name: " Create a list ",
        seoURL: "upgrade/giftinglisting/wishlist.jsp?section=mylists",
        onClick: () => {
          if(isLoggedIn) {
            //pdpContainer.triggerAddToRegistry("LIST");
            showRegistryModal("LIST",{"showCreateListModal":true})
            //location.href = "/upgrade/giftinglisting/wishlist.jsp?section=mylists";
          } else {
            utils.showLogin(kohlsData.isTcom, false, function(){ showRegistryModal("LIST",{"showCreateListModal":true})}, 'login-modal');
          }
        }
      },
       {
        ID: "4",
        categories: [],
        index: 3,
        name: " Find a list ",
        seoURL: "upgrade/giftinglisting/wishlist.jsp?section=search",
        onClick: () => {
          location.href = "/upgrade/giftinglisting/wishlist.jsp?section=search";
        }
      }
    ];
  },
  getAllListCategories: function(listData, isLoggedIn) {
    var categories = this.getListCategories(isLoggedIn);
    var index = categories[categories.length-1].index;

    for(var i = 0; i<listData.length-1;i++) {
      index = index+1;
      var seoURL= "/upgrade/giftinglisting/wishlist.jsp?section=list&listid="+listData[i].listId;
        var obj = {
          ID: i,
          index: index,
          name: listData[i].listName,
          seoURL: seoURL,
          onClick: ()=>{
            location.href= seoURL
          }
      }
      categories.unshift(obj);
    }
    return categories
  }
});
