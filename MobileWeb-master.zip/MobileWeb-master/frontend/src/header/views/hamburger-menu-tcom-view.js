import React from 'react';
import CategoryList from './category-list-component';

export default React.createClass({
  // ReactJS Lifecyle function
	render: function(){
		const eventHandlers = this.props.eventHandlers;
		const currentCategoryLists = this.props.currentCategoryLists;
		const leftColumnCategories = currentCategoryLists[0].categories;
		const selectedCategories = this.props.selectedCategories;

		const showAddtionalCategories = currentCategoryLists.length > 1;
		let additionalCategoriesList;
		if (showAddtionalCategories){
			additionalCategoriesList = [];
			for (let i = 1; i < currentCategoryLists.length; i++){
				additionalCategoriesList.push(currentCategoryLists[i].categories);
			}
		}
		return (
			<div id="shop-menu-container">
				<div id="shop-menu">
					<div className="column">
						{leftColumnCategories && <div><CategoryList categories={leftColumnCategories}
							handleCategorySelection={eventHandlers.handleCategorySelection}
							selectedCategories={selectedCategories}
							selectedCategoryIndex={0}/>
							<div id="more-section">
								<h3>MORE</h3>
								<ul>
									<li><span className="t-menu-sprite t-Registries"></span>Registries</li>
									<li><span className="t-menu-sprite t-Lists"></span>Lists</li>
									<li><span className="t-menu-sprite t-kohls-Charge"></span>Kohls Charge</li>
								</ul>
								<h3>WELCOME TO KOHL'S</h3>
								<ul>
									<li><span className="t-menu-sprite t-my-Store"></span>My Store</li>
									<li><span className="t-menu-sprite t-Weekly-ad"></span>Weekly Ad</li>
									<li  onClick={() => window.open('http://cs.kohls.com','_blank', 'width=600,height=600')}><span className="t-menu-sprite t-Contact-us"></span>Help/Contact Us</li>
									<li><span className="t-menu-sprite t-another-store"></span>Find another store</li>
								</ul>
							</div></div>}
					</div>
					{showAddtionalCategories && additionalCategoriesList.map((additionalCategories, index) => {
						let showAllCategory = (selectedCategories.length > 0 && index == 0) ? selectedCategories[0] : null;
						return (
						<div className="column" key={index}>
							<CategoryList categories={additionalCategories}
								handleCategorySelection={eventHandlers.handleCategorySelection}
								selectedCategories={selectedCategories}
								selectedCategoryIndex={(index + 1)}
								showAllCategory={showAllCategory}/>
						</div>)
					})}
				</div>
				<div className="t-menu-overlay" onClick={() => this.props.toggleTcomHamburgerMenuVisibility()}></div>
			</div>
		);
	}
});
