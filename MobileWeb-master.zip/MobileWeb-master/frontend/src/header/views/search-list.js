import React from 'react';

export default React.createClass({

  render: function(){
    debugHeader && console.log('inside search list view');
    const props = this.props;
    const eventHandlers = props.eventHandlers;
    const suggestionData = (props.showRecentSearches) ? props.recentSearchData : props.typeAheadData;
    let searchTermWithoutSpecialChars = props.searchTerm.replace(new RegExp("&", 'g'), " ").replace(new RegExp("/", 'g'), " ").replace(new RegExp("-", 'g'), " ").replace(new RegExp("\\+", 'g'), " ").replace(/[`~!@#$%^*()_|=?;:'",.<>\{\}\[\]\\\/]/gi, '');


    return (
      <ul>
        {(props.showRecentSearches ) && <li className="clear-recent-searches">
          <a href="#" onClick={eventHandlers.clearRecentSearches}>Clear recent searches</a>
        </li>}

        {suggestionData.map((suggestion, index) => {
          const pattern = new RegExp(searchTermWithoutSpecialChars, 'gi');
          const searchTermHtml = suggestion.term.replace(pattern, function($1){
                                                                    return '<strong>' + $1 + '</strong>';
                                                                  }
                                                         );

          return (
            <li key={index} onClick={(e) => eventHandlers.handleSearchTermClick(e, suggestion)} className={(props.searchTerm !=="" && suggestion.department && index == 3) ? "searchMargin":""}>
              <a href='#'>
              <span dangerouslySetInnerHTML={{__html: searchTermHtml}} /> {suggestion.department && <span className="suggested-dept">in {suggestion.department}</span>}
              </a>
            </li>
          )
        })}
      </ul>
    );
  }
});
