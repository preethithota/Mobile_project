import React from 'react';
import SearchList from '../views/search-list';

export default React.createClass({
  formPreventDefault: function(e) {
		e.preventDefault();
  },
  componentDidUpdate :function(){
    const props = this.props;
    const showResults = props.showRecentSearches || props.showTypeAheadResults;
    if (props.isSearchVisible && showResults && props.isShowSearch) {
      this.refs.mcomSearchInput.focus();
    }
  },
  render: function(){
    //debugHeader && console.log('inside search mcom view');
    const props = this.props;
    const eventHandlers = props.eventHandlers;
    const showResults = props.showRecentSearches || props.showTypeAheadResults;

    return (
      <div id="mcom-search-container"  className={'mcom-only ' + (props.isSearchVisible ? 'display-block' : 'display-none')}>
        <div id="search-content">
          <div id="search-bar">
            <div className="search-input">
			 <form action="." onSubmit={this.formPreventDefault}>
            <label htmlFor="mcom-search-input" className="hide">Search for:</label>
              <input type="search" autoComplete="off" autoCorrect="off" placeholder="Search" id="mcom-search-input"
                ref="mcomSearchInput" onClick={eventHandlers.enableSearch} onChange={eventHandlers.handleSearchChange} value={props.searchTerm} onKeyDown={eventHandlers.handleSearchKeyDown}></input>

              <input type="button" id="clear-search" onClick={() => eventHandlers.clearSearchTerm('mcom-search-input')} ></input><span className="screen-reader-text">Cancel for search term</span>

			 </form>
            </div>
            <div className="cancel-search" id="mcom-cancel-search" onClick={eventHandlers.handleCancelClick}>
              Cancel <span className="screen-reader-text">Cancel for search</span>
            </div>
          </div>
          {showResults && props.showSearch ? (
          <div id="typeahead-results">
            <SearchList {...this.props} />
          </div>) : (props.showNoResultsMsg ? (
            <div id="typeahead-results"><ul><li>No suggested search for "{props.searchTerm}"</li></ul></div>
          ) : "")
          }
        </div>
      </div>
    );
  }
});
