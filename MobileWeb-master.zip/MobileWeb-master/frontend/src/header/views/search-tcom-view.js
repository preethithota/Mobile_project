import React from 'react';
import SearchList from '../views/search-list';
import SearchThumbNail from '../views/search-thumbnail';

export default React.createClass({
  formPreventDefault: function(e) {
		e.preventDefault();
  },
  render: function(){
    debugHeader && console.log('inside search tcom view');

    const props = this.props;
    const eventHandlers = props.eventHandlers;
    const showResults = props.showRecentSearches || props.showTypeAheadResults;

    return (
      <div>
		<form action="." onSubmit={this.formPreventDefault}>
      <label htmlFor="tcom-search-input" className="hide">Search for:</label>
			<input type="search" autoComplete="off" autoCorrect="off" placeholder="Let's find what you're searching for..." id="tcom-search-input"
			onClick={eventHandlers.enableSearch} onChange={eventHandlers.handleSearchChange} value={props.searchTerm} onKeyDown={eventHandlers.handleSearchKeyDown}></input>
			<input type="button" id="clear-search" onClick={() => eventHandlers.clearSearchTerm('tcom-search-input')} ></input>
		</form>
        {showResults && props.showSearch &&
          <div className="ipad-results-wrapper">
            <div className="ipad-arrow"></div>
            <div id="typeahead-results" className={props.showThumbNails ? "ipad-results ipad-results-withThumbNails" : "ipad-results"}>
              <SearchList {...this.props} />
              <SearchThumbNail {...this.props} />
            </div>
          </div>
        }
        </div>
    );
  }
});
