import React from 'react';
import HamburgerMenuContainer from '../containers/hamburger-menu-container';
import SearchContainer from '../containers/search-container';
import * as utils from '../../global/utils';

export default React.createClass({
  // ReactJS Lifecyle function
  render: function(){
    const props = this.props;
    const eventHandlers = props.eventHandlers;
    const loadHamburgerMenuContainer = (props.isMcomHamburgerMenuVisible || props.isTcomHamburgerMenuVisible);
    const suggestionData = (props.showRecentSearches) ? props.recentSearchData : props.typeAheadData;
    const showResults = props.showRecentSearches || props.showTypeAheadResults;

    return (
      <header>
        <div id="header-top">
          <div id="tcom-header" className="tcom-only-flex">
            <div id="shop-section" onClick={eventHandlers.toggleTcomHamburgerMenuVisibility}>
              <div className="shop-icon"><span className="screen-reader-text">shop icon</span></div>
              <div id="shop-link"><a href="#">SHOP</a></div>
            </div>
            <div className="search-box">
            {!this.props.serverRender && this.props.isTcom && <SearchContainer
              isTcom={this.props.isTcom}
              />}
            </div>
            <div className="tcom-header-icon" onClick={() => window.location.href= '/sale-event/coupons-deals.jsp'}><div className="deals-icon"><span className="screen-reader-text">deals icon</span></div><div>Deals</div></div>
            <div className="tcom-header-icon"><a href="/walletpage"><div className="wallet-icon"><span className="screen-reader-text">wallet icon</span></div><div>Wallet</div></a></div>
            <div className="tcom-header-icon"><div className="signin-icon" onClick={eventHandlers.showLogin}><span className="screen-reader-text">signin icon</span></div><div>
              {props.isLoggedIn ? 'Hi ' + props.firstName : 'Sign In'}
            </div></div>

            <div className="tcom-cart-link" onClick={evt => {window.location.href=window.location.origin + "/checkout/checkout.jsp#/shoppingBag";}}><div className="cart-icon"><span className="screen-reader-text">cart icon</span></div><div className="cart-total">$0.00</div></div>
            <div className="tcom-checkout-link">Checkout <span className="screen-reader-text">Checkout</span></div>
          </div>

          <div id="mcom-header"  className='mcom-only'>
            <div className="left-links">
              <div id="menu-section" onClick={() => eventHandlers.setMcomHamburgerMenuVisibility(true)}>
                <div className="menu-icon"><span className="screen-reader-text">menu icon</span></div>
                <div className="menu-text">Menu</div>
              </div>
              <div className="mcom-logo-visible"><a id="mcom-logo" href="/" title="kohls" alt="kohls"> </a></div>
            </div>
            <div className="right-links">
              <div id="mcom-search-link" className={'mcom-header-icon' + ((props.isSearchVisible) ? ' selected': '')}
              onClick={() => eventHandlers.setSearchVisibility(!props.isSearchVisible)} alt="search icon">
                <div className="mcom-search-icon"><span className="screen-reader-text">search icon</span></div>
              </div>
              <div className="mcom-cart-link mcom-header-icon" onClick={evt => {const cartUrl=window.location.origin + "/checkout/checkout.jsp#/shoppingBag";if(window.location.hash == "#/shoppingBag"){window.location.reload(true);}else{window.location.href=cartUrl;}}}>
          <div className={"mcom-cart-icon" + (props.bagTotal ? " cart-enabled" : "")}  alt="cart icon">
          {props.bagTotal ? <span>{props.bagTotal}</span> : ""} <span className="screen-reader-text">cart bag icon</span>
        </div>
      </div>
            </div>
      {<SearchContainer
            isSearchVisible={props.isSearchVisible}
            isShowSearch={props.isShowSearch}
            isSearchClicked={props.isSearchClicked}
            focusSearchBox={props.focusSearchBox}
            setIsSearchClicked={eventHandlers.setIsSearchClicked}
            setCancelIsSearchVisible={eventHandlers.setCancelIsSearchVisible}
            setSearchVisibility={eventHandlers.setSearchVisibility} setIsSearchVisible={eventHandlers.setIsSearchVisible}
            />}
          </div>
        </div>
        {loadHamburgerMenuContainer && <HamburgerMenuContainer
            setMcomHamburgerMenuVisibility={eventHandlers.setMcomHamburgerMenuVisibility}
            toggleTcomHamburgerMenuVisibility={eventHandlers.toggleTcomHamburgerMenuVisibility}
            setCategoryMenuVisibility={eventHandlers.setCategoryMenuVisibility}
            showLogin={eventHandlers.showLogin}
            switchOrderPage={eventHandlers.switchOrderPage}
            isCategoryMenuVisible={props.isCategoryMenuVisible}
            isMcomHamburgerMenuVisible={props.isMcomHamburgerMenuVisible}
            isTcomHamburgerMenuVisible={props.isTcomHamburgerMenuVisible}
            categoryData={props.categoryData}
            setCategoryData={props.setCategoryData}
            showDealsMenu={props.showDealsMenu}
            showListMenu={props.showListMenu}
            showRegistryMenu={props.showRegistryMenu}
            isLoggedIn={this.props.isLoggedIn}
            listData={this.props.listData}
          />}

      </header>
    )
  }
});
