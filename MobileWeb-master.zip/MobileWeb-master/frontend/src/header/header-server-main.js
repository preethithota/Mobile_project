import HeaderView from './views/header-view';

global.renderServer = function(isTcom){
    return ReactDOMServer.renderToString(
        <div><HeaderView isTcom={isTcom} serverRender={true} isLoggedIn={false} firstName={''}
          eventHandlers={{}} setCategoryData={{}}/></div>
    );

};
