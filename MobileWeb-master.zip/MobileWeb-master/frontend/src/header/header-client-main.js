import HeaderContainer from './containers/header-container';
import * as utils  from '../global/utils';
import {getCartFromStorage} from '../global/cart-helper';
import { callBrightTag } from '../../public/lib/brightTag-util';
window.debugHeader = true;
window.kohlsUtils = {};
window.kohlsUtils = utils;

ReactDOM.render(
    <div><HeaderContainer isTcom={kohlsData.isTcom} serverRender={false} ref={(header)=> window._header = header} isLoggedIn={utils.isLoggedIn()}
      firstName={utils.getFirstName()}/></div>,
    document.getElementById('header-container')
);

/*Sticky Header*/
	window.onload = function(e) {
		callBrightTag();
		if(navigator.userAgent.match(/iPad/i) != null) {
			document.body.classList.add('ipad');
		}

		//Nudata inialization on page load
		if(kohlsData.nuDataFlag) {
			var sessionId = utils.getCookieValue("nuDataSessionId");
			if(!sessionId) {
				sessionId = utils.createSessionId();
				utils.setCookieValue("nuDataSessionId",sessionId);
			}
			var nuDataDomain = kohlsData.nuDataDomainName;
			var clientId = kohlsData.nuDataLleClientId;
			if(location.host == "m.kohls.com" || location.host == "mobile.kohls.com") {
				clientId = kohlsData.nuDataProdClientId;
			}
			var nuDataSDKUrl = nuDataDomain+"/2.2/w/"+clientId+"/sync/js/";
			utils.initalizeNuDataSDK(nuDataSDKUrl);

			var nds = window.ndsapi;
			nds.config.ready(function() {
				nds.setSessionId(sessionId);
			});
		}
	};

	window.onunload = function() {
		if(kohlsData.nuDataFlag)
			utils.deleteCookie("nuDataSessionId");
	}

	window.onpageshow = function(event) {
		var cartArr = getCartFromStorage();
    	window._header.updateCartCount(cartArr);

		if(event.persisted && pageData.pageDetails.pageType == "Product Detail Page") {
	        window.location.reload()
	    }
	}
	/*window.onscroll = function(event){

		document.body.classList.add('stickyHeader');
		$(".ipad-results-wrapper").css("display", "none");

		if(document.body.scrollTop == 0){
			document.body.classList.remove('stickyHeader');
		}
	};*/
