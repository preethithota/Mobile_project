import React from 'react';
import HamburgerMenuMcomView from '../views/hamburger-menu-mcom-view';
import HamburgerMenuTcomView from '../views/hamburger-menu-tcom-view';
import * as menuHelper from './menu-helper';
import {fetch, getCookieValue, setCookieValue, deleteCookie, putInSessionStorage} from '../../global/utils';

const categoryUrl = '/service/category';

export default React.createClass({

  // ReactJS Lifecyle function
  getInitialState: function(){
    return {
      selectedCategories: [],
      tierValues: [],
      currentCategoryLists: [this.props.categoryData],
      isSelectedCategory:true,
      isSelectedMenu:false,
      isLoggedIn: this.props.isLoggedIn,
      listData: this.props.listData
    }
  },

  // ReactJS Lifecyle function
  componentDidMount: function(){
    var getSelectedCategoryItem = getCookieValue('selectedCategoryItem');
    if (!this.props.categoryData.categories){
      fetch(categoryUrl).done(data => {
        data.payload && this.props.setCategoryData(data.payload);
      }).then(function(data) {
        this.setSelectedCategoryMenu(this.props.categoryData);
      }.bind(this));
    } else {
      getSelectedCategoryItem && this.setSelectedCategoryMenu(this.props.categoryData);
    }
  },

  //HB menu isCategory visible state captured
  shouldComponentUpdate: function (nextProps, nextState) { return this.state !== nextState; },

  // ReactJS Lifecyle function
  componentWillReceiveProps: function(nextProps){

    this.setState({
      currentCategoryLists: [nextProps.categoryData],
    });
    this.setSelectedCategoryMenu(nextProps.categoryData);
  },

  eventHandlers: function(){
    return {
      resetCategoryList: function(e){
        e.preventDefault();
        this.updateCategorySelectionState([]);
        this.setState({isSelectedMenu: true });
      }.bind(this),

      selectPreviousCategory: function(e, categoryId){
        const selectedCategories = this.state.selectedCategories;
        const newSelectedCategories = [];
        this.setState({selectedCategoryItem: false, selectedCategoryId: null,isSelectedMenu:false});
        for (let i = 0; i < selectedCategories.length; i++){
          let selectedCategory = selectedCategories[i];
          newSelectedCategories.push(selectedCategory);
          if (selectedCategory.id === categoryId){
            break;
          }
        }
        this.updateCategorySelectionState(newSelectedCategories,true);
      }.bind(this),

      handleCategorySelection: function(category, selectedCategoryIndex = -1){
        if (category.onClick){
          category.onClick();
          this.props.setMcomHamburgerMenuVisibility(false);
          return;
        }

        const isLinkClick = (category.categories) ? false : true;
        const newCategory = {id: category.ID ? category.ID : category.id, name: category.name, seoUrl: category.seoURL};
         this.state.tierValues.push(category.name);
        if (isLinkClick){
          setCookieValue('selectedCategoryItem', category.ID ? category.ID : category.id);
          setCookieValue('tiervalues', this.state.tierValues.join("|"));
          let url = category.seoURL ? category.seoURL: category.seoUrl;
          url += "&fromMenu=true";
          location.href = url;
          return;
        }
        this.setState({isSelectedCategory: false, selectedCategoryItem: false, selectedCategoryId: null,isSelectedMenu:false });
        let currentSelectedCategories = this.state.selectedCategories;
        const selCatLength = currentSelectedCategories.length;

        if (selectedCategoryIndex > -1 && selectedCategoryIndex !== selCatLength){
          //the user is on tcom and choosing from previous columns, so we need to pop the last x
          //selections(columns) from the stack and re-render based on the current selection
          currentSelectedCategories = currentSelectedCategories.slice(0, selectedCategoryIndex);
        }
        currentSelectedCategories.push(newCategory);
        this.updateCategorySelectionState(currentSelectedCategories, true);
      }.bind(this)
    }
  },// end eventHandlers

  updateCategorySelectionState: function(newSelectedCategories, currentCategory=false){
    const currentCategoryLists = menuHelper.getCurrentCategoryLists(this.props.categoryData, newSelectedCategories);

    this.setState({
      selectedCategories: newSelectedCategories,
      currentCategoryLists: currentCategoryLists
    });
    if(currentCategory) {
      setCookieValue('selectedCategories', encodeURIComponent(JSON.stringify(newSelectedCategories)));
    }
  },

  setSelectedCategoryMenu: function (categoryData) {
    var getSelectedCategoryItem = getCookieValue('selectedCategoryItem');
    var _getSelectedCategories=[];

    if(getCookieValue('selectedCategories')){
      _getSelectedCategories = JSON.parse(decodeURIComponent(getCookieValue('selectedCategories')));
    }
    const currentCategoryLists = menuHelper.getCurrentCategoryLists(categoryData, _getSelectedCategories);
    this.setState({selectedCategoryItem: getSelectedCategoryItem?true:false,
      selectedCategoryId: getSelectedCategoryItem,
      isSelectedCategory: true,
      isSelectedMenu:getCookieValue('selectedCategories')?false:true,
      selectedCategories:  _getSelectedCategories,
      currentCategoryLists: currentCategoryLists});


  },

  // ReactJS Lifecyle function
  render: function(){
    return (
      <div>
      {this.props.isMcomHamburgerMenuVisible && <HamburgerMenuMcomView {...this.props} {...this.state} eventHandlers={this.eventHandlers()}/>}
      {this.props.isTcomHamburgerMenuVisible && <HamburgerMenuTcomView {...this.props} {...this.state} eventHandlers={this.eventHandlers()}/>}
      </div>
    )
  }

});
