import React from 'react';
import HeaderView from '../views/header-view';
import {showLogin, isLoggedIn, isSoftedLoggedIn} from '../../global/utils';
import * as monetization from '../../../src/monetization/monetization';
import * as locationUtils from '../../global/location-utils';
import * as utils from '../../global/utils';
import * as cartHelper from '../../global/cart-helper';
import {login} from '../../account/login-util';
import ShopModel from '../../pdp/pdp-shop-model-view';
import { setShopMenuOmniture } from '../../../public/lib/omniture-util';
import { getListData } from '../../pdp/registry/registry-helper';

export default React.createClass({
  // ReactJS Lifecyle function
  getInitialState: function(){
    let isSearchVisible = true;
    if(!this.props.serverRender) {
		if(!this.props.isTcom) {
			//const match = /search=[^&]+/.exec(location.search);
			// const pageMatch = (kohlsData.page =="homepage") || (kohlsData.page == "wallet") || (kohlsData.page == "pmp") || (kohlsData.page == "more-like-this") || (kohlsData.page == "password_reset") || (kohlsData.page == "manageorder") || (kohlsData.page == "myaccount_orderSummary") || (kohlsData.page == "review") || (kohlsData.page == "content") || (kohlsData.page == "rewards") || (kohlsData.page == "storelocator");


			//(match || pageMatch) && (isSearchVisible = true);

			const pageMatch = (kohlsData.page =="pdp") || (kohlsData.page == "checkout");
			(pageMatch) && (isSearchVisible = false);

			(!isSearchVisible ?
				document.body.classList.remove("search-visible") :
				document.body.classList.add("search-visible")
			);
		}

		if(this.props.isTcom && typeof $ !== 'undefined') {
			$(document).click(function(e) {
				if (e.target.getAttribute("id") != "tcom-search-input" && $(e.target).closest(".ipad-results-wrapper").get(0) == null) {
					$(".ipad-results-wrapper").hide();
				}
			});
		}
	}

	let skbag = utils.getFromLocalStorage('skBag');
	let bagTotal = 0;

	if(skbag){
		skbag = JSON.parse(skbag);

		for(let value of skbag){
			bagTotal += parseInt(value.split('|')[2]);
		}
	};

	return {
      isMcomHamburgerMenuVisible: false,
      isTcomHamburgerMenuVisible: false,
      isCategoryMenuVisible: false,
      isSearchVisible,
      categoryData: {},
      continueShopModel: false,
      showDealsMenu: false,
	    bagTotal: bagTotal,
      isSearchClicked: isSearchVisible,
      isShowSearch: false,
      showListMenu: false,
      showRegistryMenu: false,
      listData: {}
    }
  },

  componentDidMount: function(){
    locationUtils.askLocation();
    // pmp selected category HB menu captured
    if(location.pathname.indexOf('/catalog')<0) {
      utils.deleteCookie('selectedCategories');
      utils.deleteCookie('selectedCategoryItem');
    } else {
      const categoryUrl = '/service/category';
      var getSelectedCategoryItem = utils.getCookieValue('selectedCategoryItem');
      getSelectedCategoryItem && utils.fetch(categoryUrl).done(data => {
        data.payload && this.setCategoryData(data.payload);
      })
    }
	  monetization.initMonetization();
  },
  componentDidUpdate: function() {
    if(this.state.focusSearchBox == false) {
      document.getElementById("mcom-search-input").blur();
    }
  },

  setCategoryData: function(categoryData){
    this.setState({categoryData: categoryData});
  },
  setListData: function(Data){
    this.setState({listData: Data.lists});
  },
  updateCartCount: function(cartEntries){
	  var cartCount = 0;
	  for(let i = 0; i < cartEntries.length; i++){
		  cartCount += parseInt(cartEntries[i].quantity);
	  }

	  this.setState({
		  bagTotal : cartCount
	  })
  },
  eventHandlers: function(){

    function toggleMenu(isMcomHamburgerMenuVisible){
      isMcomHamburgerMenuVisible ?(document.body.classList.add('m-slide')):(document.body.classList.remove('m-slide'));
    }

    return {
      setMcomHamburgerMenuVisibility: function(isMcomHamburgerMenuVisible){
        let isCategoryItemSelected = utils.getCookieValue('selectedCategories') ? true : ((isMcomHamburgerMenuVisible) ? this.state.isCategoryMenuVisible : false);
        this.setState({
          isMcomHamburgerMenuVisible: true,
          isTcomHamburgerMenuVisible: false,
          isCategoryMenuVisible: isCategoryItemSelected,
          isShowSearch: false
        });
		if(isMcomHamburgerMenuVisible){
      //Commenting because of blocker MRP-1830
			setShopMenuOmniture();
		}
        toggleMenu(isMcomHamburgerMenuVisible);
      }.bind(this),

      toggleTcomHamburgerMenuVisibility: function(){
        this.setState({
          isTcomHamburgerMenuVisible: !this.state.isTcomHamburgerMenuVisible,
          isMcomHamburgerMenuVisible: false,
          isCategoryMenuVisible: true
        });
		!this.state.isTcomHamburgerMenuVisible ?(document.body.classList.add('t-menu-mask')):(document.body.classList.remove('t-menu-mask'));

		if(!this.state.isTcomHamburgerMenuVisible && document.querySelector("#tcom-results-header #filter-content")) {
          window.filterButton.click();
        }
		if(!this.state.isTcomHamburgerMenuVisible){
			setShopMenuOmniture();
		}
      }.bind(this),

      setCategoryMenuVisibility: function(e, isCategoryMenuVisible, showDealsMenu, showRegistryMenu, showListMenu){
        e.preventDefault();

        const isDealsMenuVisible = showDealsMenu ? isCategoryMenuVisible : false;
        const isRegistryMenuVisible = showRegistryMenu ? isCategoryMenuVisible : false;
        const isListMenuVisible = showListMenu ? isCategoryMenuVisible : false;


        this.setState({
          showDealsMenu: isDealsMenuVisible, isCategoryMenuVisible: isCategoryMenuVisible, showRegistryMenu: isRegistryMenuVisible, showListMenu: isListMenuVisible
        });

      }.bind(this),

      setSearchVisibility: function(isSearchVisible){
        this.eventHandlers().setIsSearchVisible(isSearchVisible, isSearchVisible);
        this.eventHandlers().setIsSearchClicked();
        if(!this.props.isTcom) {
          if(!isSearchVisible) {
            $('body').removeClass("search-visible stopScroll search-disabled");
          } else {
            $('body').addClass("search-visible stopScroll");
            this.setState({
              isShowSearch: true,
              focusSearchBox: true
            });
          }
        }


      }.bind(this),
      //This function is to switch between order pages for logged in vs guest user.
      switchOrderPage: function(evt){
        toggleMenu(false);
        var orderManagementUrl = "/checkout/myaccount.jsp#/orderManagement";
        if(isLoggedIn()){
          // No url change if already stay with 'noOrderDetails'/'orderHistory'
          var changeOrderManagementStatusPage = /#\/noOrderDetails|#\/orderHistory/i;
          if (location.pathname.match(/myaccount\.jsp/) && changeOrderManagementStatusPage.test(location.hash)) {
            evt.preventDefault();
            return;
          }
          location.href = orderManagementUrl;
        } else if(isSoftedLoggedIn()){
          // Opened softlogin
          showLogin(this.props.isTcom, false, () => {
            window.history.pushState({path:orderManagementUrl},'',orderManagementUrl);
            document.body.classList.remove('t-login-mask');
            location.reload();
            return;
          });
        }else{
          location.href = "/upgrade/myaccount/manageorder.jsp";
        }
      }.bind(this),
      showMonetization: function(){
        monetization.initMonetization();
      }.bind(this),
      hideMonetization: function(){
        if(document.getElementById("recommendationsMcom")){
        document.getElementById("recommendationsMcom").remove();}
        var getLen = document.getElementsByClassName("dfp_class").length
        for(var i=0;i<getLen;i++) { document.getElementsByClassName("dfp_class")[i].remove(); }
      }.bind(this),
      setIsSearchVisible: function(isSearchVisible, focuss, isshow=false){
        this.setState({
          isSearchVisible: isSearchVisible,
          isShowSearch: isshow,
          focusSearchBox: focuss
        });
         document.body.classList.remove("search-icon")
      }.bind(this),
      setCancelIsSearchVisible: function(isSearchVisible){
        this.setState({
          isSearchVisible: isSearchVisible
        });

      }.bind(this),
      setIsSearchClicked: function(flag) {
        this.setState({
          isSearchClicked: flag ? false : !this.state.isSearchVisible,
          focusSearchBox: flag ? false : !this.state.focusSearchBox,
          isShowSearch: false
        });
      }.bind(this),

      showLogin: function(e,page){
		  if(!page){
			  page = "account";
		  }
        e.preventDefault();
        console.log('inside header-container showLogin');
        let redirectSuccessUrl = '/checkout/myaccount.jsp#/myInfoLanding';
        toggleMenu(false);
        if (isLoggedIn()){
          location.href = redirectSuccessUrl;
          //if(location.hash && location.pathname.match(/myaccount\.jsp/)) location.reload();
          return;
        }
        showLogin(this.props.isTcom, false, () => {
          if(location.pathname.match(/manageorder\.jsp/)) {
            redirectSuccessUrl = '/checkout/myaccount.jsp#/orderManagement';
          }
          location.href = redirectSuccessUrl;
          document.body.classList.remove('t-login-mask');
        },page);
        this.setState({
          isTcomHamburgerMenuVisible: false,
          isMcomHamburgerMenuVisible: false,
          isCategoryMenuVisible: false
        });
		    document.body.classList.add('t-login-mask');
	}.bind(this) ,
  showAddToBag:function(target){
    ReactDOM.render(<ShopModel eventHandlers={this.eventHandlers()} />, target);
    document.body.classList.add('modal-overlay');
  }.bind(this),
  handleCancelClick: function() {
        ReactDOM.unmountComponentAtNode(document.getElementById('add-to-bag'));
        document.body.classList.remove('modal-overlay', 't-login-mask');
        utils.modalActionPosition.setFocusPosition();
      }.bind(this),
  gotoCart: function() {
        window.location.href = "/checkout/checkout.jsp#/shoppingBag";
      }.bind(this),
  shoppingCart:function(action){return cartHelper}.bind(this),
	doLogin: function(email, password, errorCallBk, successCallBk){
		login(email, password, errorCallBk, successCallBk);
	 }.bind(this)
    }
  },// end eventHandlers

// ReactJS Lifecyle function
  render: function(){
    return <HeaderView {...this.state} eventHandlers={this.eventHandlers()} serverRender={this.props.serverRender} isTcom={this.props.isTcom}
    setCategoryData={this.setCategoryData} isLoggedIn={this.props.isLoggedIn} firstName={this.props.firstName}/>
  }
});
