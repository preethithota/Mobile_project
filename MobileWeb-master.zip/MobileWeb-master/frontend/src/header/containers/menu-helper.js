

export function getCurrentCategoryLists(categoryData, selectedCategories){
  let currentCategories, currentCategory, nextCategories = categoryData.categories;
  let currentCategoryLists = [categoryData];

  if (selectedCategories.length === 0){
    return currentCategoryLists;
  }

  for (let i = 0; i < selectedCategories.length; i++) {
    let selectedCategory = selectedCategories[i];
    currentCategories = nextCategories;
    currentCategory = currentCategories.find((category) => {
      return (category.ID === selectedCategory.id);
    });

    if (typeof currentCategory === 'undefined') break;
    currentCategoryLists.push(currentCategory);
    if (typeof currentCategory.categories != 'undefined' && currentCategory.categories){
      nextCategories = currentCategory.categories;
    }
  }

  return currentCategoryLists;
};
