import {setStoreLocatorOmniture} from '../../public/lib/omniture-util';
setStoreLocatorOmniture();
window.KOHLS_COVARIO = {};
KOHLS_COVARIO.setStoreLocatorOmniture = setStoreLocatorOmniture;
