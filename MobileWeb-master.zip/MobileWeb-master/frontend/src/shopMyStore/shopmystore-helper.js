export function removeParameterFromUrl(url, parameter) {
    return url.replace(new RegExp('[?&]' + parameter + '=[^&#]*(#.*)?$'), '$1').replace(new RegExp('([?&])' + parameter + '=[^&]*&'), '$1');
};

export function getUpdatedUrl() {
    var currentUrl = location.href;
    var newUrl = removeParameterFromUrl(currentUrl, "CN");
    newUrl = removeParameterFromUrl(newUrl, "storeid");
    var activeDimNode = catalogData.activeDimensions;
    var filters = "";
    for(var activeDimensions in activeDimNode) {
        var dimentionValues = activeDimNode[activeDimensions].activeDimensionValues;
        for(var ids in dimentionValues) {
            filters = filters + "+" +dimentionValues[ids].currentDimensionId;
        }
    }
    filters = filters.substr(1);
    return filters ? newUrl + "&CN=" + filters : newUrl;
};