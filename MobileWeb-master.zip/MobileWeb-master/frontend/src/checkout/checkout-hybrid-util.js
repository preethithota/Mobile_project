import React from 'react';
import * as utils from '../global/utils';
import * as loginUtil from '../account/login-util';
import * as cartHelper from '../global/cart-helper';
import {askLocation, setLocation, geoCodeLatLng, geoCodeByZip} from '../global/location-utils';
import { setHybridOmniture,setAccountLandingOmniture } from '../../public/lib/omniture-util';


window.KOHLS_HYBRID = {};
KOHLS_HYBRID.utils = utils;
KOHLS_HYBRID.loginUtil = loginUtil;
KOHLS_HYBRID.cartHelper = cartHelper;
KOHLS_HYBRID.askLocation = askLocation;
KOHLS_HYBRID.setLocation = setLocation;
KOHLS_HYBRID.geoCodeLatLng = geoCodeLatLng;
KOHLS_HYBRID.geoCodeByZip = geoCodeByZip;
KOHLS_HYBRID.setHybridOmniture = setHybridOmniture;

if(location.href.indexOf("/checkout/myaccount.jsp#/myInfoLanding") > -1){
setAccountLandingOmniture();
}


let callbackUnmountModal = void 0;

KOHLS_HYBRID.showPdpModal = (bagItemId, bagItem, isBottomFocus, callback) => {
  require(['../pdp/pdp-container'], (pdpContainer) => {
    const PdpContainer = pdpContainer.default;
    const pdpModalDivId = 'pdp-modal-container';
    let pdpModalDiv = document.getElementById(pdpModalDivId);

    if (!pdpModalDiv){
      pdpModalDiv = document.createElement('div');
      pdpModalDiv.setAttribute('id', pdpModalDivId);
      document.body.appendChild(pdpModalDiv);
    }

    const cartMaskDivId = 'cart-mask';
    const cartMaskDiv = document.createElement('div');
    cartMaskDiv.setAttribute('id', cartMaskDivId);
    document.body.appendChild(cartMaskDiv);

    //TODO: update this
    let kohlsData = kohlsData || {};
    kohlsData.isTcom = false;

    const unmountModal = () => {
      const cartMaskDiv = document.getElementById(cartMaskDivId);
      if(!cartMaskDiv) {
        return;
      }
      document.body.removeChild(cartMaskDiv);
      document.body.classList.remove("hybrid-stop-scroll");
      ReactDOM.unmountComponentAtNode(document.getElementById(pdpModalDivId));
      const pdpModalDiv = document.getElementById(pdpModalDivId);
      document.body.removeChild(pdpModalDiv);
    };
    callbackUnmountModal = unmountModal;

    const handleImageLoaded = () => {
      let getQuantitySection = document.getElementById('section-2');
      pdpModalDiv.scrollTop = getQuantitySection.offsetTop;
    };

    const productUrl = `/api/v1/product/${bagItem && bagItem.webID}?skuDetail=true&invFilter=true`;
    utils.fetch(productUrl).done(data => {
      !isBottomFocus && utils.scrollTop();
      let quantitySectionFocus = (isBottomFocus && handleImageLoaded);
      ReactDOM.render(
        <div><PdpContainer data={data} isTcom={kohlsData.isTcom} isCartModal={true} cartSkuCode={bagItem && bagItem.skuCode}
          modalCallback={callback} cartQuantity={bagItem && bagItem.quantity} unmountModal={unmountModal} bagItemId={bagItemId} bagItem={bagItem} handleImageLoaded={quantitySectionFocus}/></div>,
        document.getElementById(pdpModalDivId)
      );
    });

  });

};


KOHLS_HYBRID.hybridUrlStateChange = (toStateName, fromStateName, rootScope) => {

  const STATE_CHANGE = {
    /**
      * applicable screen names to show the Search bar on landing.
    */
    _srch_Screen_Names: /orderHistory|orderDetails|manageOrder|orderManagement|orderBasicInfo|noOrderDetails|invalidOrderDetails|trackOrder|myInfoLanding|orderConfirmation/i,
    _orderToStateName: /orderHistory|orderManagement/i,
    _orderFromStateName: /noOrderDetails|orderHistory/i,
    _showFooterPageName: /shoppingBag/i,
    _changeOrderManagementStatusPage: /noOrderDetails|orderHistory/i,
    /**
     * Hide & Show the footer content if toStateName='shoppingBag' and pathname like checkout.jsp
    */
    _showOrHideFooterContent:function(){
      const footerDiv = document.getElementById('mobile-footer');
      if (footerDiv){
        footerDiv.style.display= (this._showFooterPageName.test(toStateName)) ? 'block' : 'none';
      }
    },
    /**
      * defnition to invoke the Search bar for specified screens only.
    */
    _showOrHideSearchBar:function(_isSearchable){
      var _docCls = document.body.classList;
      _header && _header.eventHandlers().setIsSearchVisible(_isSearchable,false);
      _header && _header.setState({isSearchClicked: _isSearchable});
      _isSearchable?_docCls.add("search-visible"):_docCls.remove("search-visible");
      _header && _header.state.isMcomHamburgerMenuVisible &&  _docCls.remove("m-slide");
    },
    _run:function(){
      /**
       * Show the footer content if toStateName='shoppingBag' and pathname like checkout.jsp
       * Hide the footer content if toStateName!='shoppingBag' and pathname like checkout.jsp
      */
      if (location.pathname.match(/checkout\.jsp/) && fromStateName) {
        this._showOrHideFooterContent();
        if(fromStateName === 'shoppingBag' && typeof callbackUnmountModal === 'function' ) {
          callbackUnmountModal();
          callbackUnmountModal = void 0;
        }
      }
      /**
       * Check only for myinfo/order management page
       */
      if (location.pathname.match(/myaccount|checkout\.jsp/)) {
        // To trigger the Search bar in open state by default
        this._showOrHideSearchBar(this._srch_Screen_Names.test(toStateName));
        // Redirect to myinfolanding page when clicked back button in browser and matches 'noOrderDetails'/'orderHistory'
        if (this._orderToStateName.test(toStateName) && this._orderFromStateName.test(fromStateName)) {
          location.hash='#/myInfoLanding';
        }
        if (this._changeOrderManagementStatusPage.test(toStateName) && rootScope.hasReachedOrderManagement) {
          rootScope.hasReachedOrderManagement = false;
        }
      }
    }
  };
 STATE_CHANGE._run();
};
