import {getCookieValue, setCookieValue} from '../global/utils';

const corIdCookieName = 'Correlation-Id', deviceIdCookieName = 'k_deviceId';

function generateRandomString(groups){
  let randomString = '';
  for (let i = 0; i < groups; i++){
    let newGroup = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    console.log('newGroup is ' + newGroup);
    randomString += newGroup;
  }
  return randomString;
}

function getFutureDate(msInFuture){
  const currentDate = new Date();
  const newExpiration = new Date(currentDate.getTime() + msInFuture);
  return newExpiration.toUTCString()
}

function setCorrelationIdCookie(){
  let deviceId = getCookieValue(deviceIdCookieName);
  if (!deviceId){
    deviceId = generateRandomString(6);
    const twoYearsFromNow = 63072000000;
    const deviceIdExpiry = getFutureDate(twoYearsFromNow);
    setCookieValue(deviceIdCookieName, deviceId, deviceIdExpiry);
  }

  let correlationId = getCookieValue(corIdCookieName);
  if (!correlationId){
    //const sessionId = generateRandomString(0x1000000000000000);
    const sessionId = generateRandomString(4);
    const prefix = (kohlsData.isTcom) ? 'TCOM' : 'MCOM';
    correlationId = `${prefix}-${deviceId}-${sessionId}`;
    setCookieValue(corIdCookieName, correlationId);
  }

}

setCorrelationIdCookie();
