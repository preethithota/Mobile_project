import ManageContainer from './containers/manage-container';
ReactDOM.render(<ManageContainer isTcom={kohlsData.isTcom}/>, document.getElementById('manage-container'));
