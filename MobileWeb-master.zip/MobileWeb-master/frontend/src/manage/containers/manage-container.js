import * as loginHelper from '../../account/login-helper';
import ManageView from '../views/manage-view';
import * as utils from '../../global/utils';
import {setManageOrderGuestOmniture} from '../../../public/lib/omniture-util';

export default class extends React.Component{    
	componentDidMount() {
		setManageOrderGuestOmniture();
	}
    render(){
      return (<ManageView {...this.props}/>)
    }
};
