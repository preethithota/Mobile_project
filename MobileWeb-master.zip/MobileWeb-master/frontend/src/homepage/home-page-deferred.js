import '../misc/z1Loyalty-v2';
/*  import { default as omnitureUtilFun, browseSiteCatalyst } from '../../public/lib/omniture-util';
var homeOmniValue =  {};
homeOmniValue.pageName = homeOmniValue.eVar68 = homeOmniValue.prop53 = omnitureUtilFun.omnitureUtil.fnGetChannelType() + ">homepage";
homeOmniValue.prop4 = omnitureUtilFun.omnitureUtil.fnGetChannelType() + "|homepage";
homeOmniValue.prop9 = "homepage|homepage";
browseSiteCatalyst(homeOmniValue);  */
//import { setBTHomePage } from '../../public/lib/brightTag-util';
import { setHPOmniture } from '../../public/lib/omniture-util';
//setBTHomePage();
setHPOmniture()  