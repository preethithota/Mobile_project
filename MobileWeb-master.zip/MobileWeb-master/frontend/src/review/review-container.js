import ReviewView from './review-view';
import * as utils from '../global/utils';
import * as bazarVoice from '../../public/lib/bazarVoice';


export default React.createClass({
	// React Lifecycle function
	componentDidMount: function(){
		bazarVoice.initBazarVoice();
	},
	render: function(){
		return (<ReviewView/>)
	}
});
