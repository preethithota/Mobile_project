import * as utils from '../global/utils';

export default React.createClass({
	render: function(){
    	return (
			<div id="BV_container"></div>
		)
	}
});
