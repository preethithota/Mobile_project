import ReviewContainer from './review-container';
import {setReviewOmniture} from '../../public/lib/omniture-util';
ReactDOM.render(
	<div><ReviewContainer /></div>,
	document.getElementById('BV_reviews')
);
setReviewOmniture();
