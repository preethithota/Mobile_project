import OrderSummaryContainer from './orderSummary-container';

ReactDOM.render(
	<OrderSummaryContainer/>,
	document.getElementById('Order_Summary')
);
