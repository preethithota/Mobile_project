export default React.createClass({	
		
	render: function(){
		const props = this.props;
		const orderData = props && props.orderData;
		const data = orderData && orderData.payload && orderData.payload.order;
		const OS_date = data && data.dateTime && new Date(data.dateTime);		
		const OS_day = OS_date && OS_date.getDate();
		var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var month_short = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		var weekday_short = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
		const OS_month = OS_date && month[OS_date.getMonth()];
		const OS_year = OS_date && OS_date.getFullYear();
		const OS_dateFormated = OS_date && OS_month + " " + OS_day + ", " + OS_year;
		const OD_weekday = OS_date && weekday[OS_date.getDay()];
		var hours = OS_date &&  OS_date.getHours();
		var minutes = OS_date && OS_date.getMinutes();
		var ampm = hours >= 12 ? 'PM' : 'AM';
		hours = hours % 12;
		hours = hours ? hours : 12; 
		hours = hours < 10 ? '0'+hours : hours;
		minutes = minutes < 10 ? '0'+minutes : minutes;
		const strTime = hours + ':' + minutes + ampm;
		const OD_dateFormated = OS_date && OD_weekday + " " + OS_month + " " + OS_day + ", " + OS_year + " at "+strTime;
		const isTcom = kohlsData.isTcom;
    	return (
			<div>
				{!isTcom ? 	
				<div>
				{data && ((window.location.pathname.indexOf("/myaccount/v2/myaccount_orderSummary.jsp") > -1 && window.location.hash.indexOf("#orderDetails") > -1)  || (window.location.pathname.indexOf("/myaccount/v2/order_detail_anonymous.jsp") > -1)) ? 						
					(<div id="OD_container">
						<div className="m-od-header">ORDER DETAILS</div>
						<div className="m-od-orderNoDet pad-lefrig20">
							<div>Order Number: <span className="m-od-orderNum"> {data.orderNumber} </span></div>
							<div>Placed: <span> {OD_dateFormated} </span></div>
						</div>
						{data.shipments.map((shipment, index) => {
							var message = (shipment.shippingMethod.name!="BOPUS" && shipment.shippingMethod.estimatedArrivalMessage) && shipment.shippingMethod.estimatedArrivalMessage;
							var fromDate = message && shipment.shippingMethod.estimatedArrivalMessage.indexOf('between') !== -1 && new Date(message.split("between ")[1].split("and")[0]+ new Date().getFullYear());
							var toDate = message && shipment.shippingMethod.estimatedArrivalMessage.indexOf('between') !== -1 && new Date(message.split("between ")[1].split("and")[1]+ new Date().getFullYear());
							var fromMonth = fromDate && month_short[fromDate.getMonth()];
							var fromDay = fromDate && fromDate.getDate();
							var fromWeekday = fromDate && weekday_short[fromDate.getDay()];
							var toMonth = toDate && month_short[toDate.getMonth()];
							var toDay = toDate && toDate.getDate();
							var toWeekday = toDate && weekday_short[toDate.getDay()];
							var ItemTxt = shipment.orderItems.length == 1 ? "ITEM" : "ITEMS";
							return (
								<div className="m-od-productShipDet" key={index}>
									<div className="pad-lefrig20">
									<div className="m-od-storePic">{shipment.inStorePickUp.storeNum ? 'STORE PICK UP' : 'SHIPPING ADDRESS'}</div>
									<div className="m-od-storeName">{shipment.inStorePickUp.storeName ? "Kohl's "+shipment.inStorePickUp.storeName : ''}</div>
									{shipment.shippingMethod.name!="BOPUS" ? 
									<div className="m-od-billPerson">{data.paymentTypes.creditCards[0].billAddress.firstName ? data.paymentTypes.creditCards[0].billAddress.firstName + " " + data.paymentTypes.creditCards[0].billAddress.lastName : ''}</div>
									: ''}
									<div className="m-od-addr">{shipment.shipAddress.addr1 ? shipment.shipAddress.addr1 : ''}</div>
									<div>{shipment.shipAddress.addr2 ? shipment.shipAddress.addr2 : ''}</div>
									<div className="m-od-addr">{shipment.shipAddress.city ? shipment.shipAddress.city.toLowerCase() : ''}
										 {shipment.shipAddress.state ? ", " + shipment.shipAddress.state : ''}
										 {shipment.shipAddress.postalCode ? " " + shipment.shipAddress.postalCode : ''}
									</div>
									<div className="m-od-phoneNum">{shipment.shipAddress.phoneNumber ? shipment.shipAddress.phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3") : ''}</div>
									<div className="m-od-hours">{shipment.inStorePickUp && shipment.inStorePickUp.storeHours && shipment.inStorePickUp.storeHours.days && shipment.inStorePickUp.storeHours.days[1].hours.open ? 'OPEN '+ shipment.inStorePickUp.storeHours.days[new Date(shipment.inStorePickUp.pickupByDate).getDay()].hours.open + '-' + shipment.inStorePickUp.storeHours.days[new Date(shipment.inStorePickUp.pickupByDate).getDay()].hours.close : ''}</div>
									<div>{shipment.shippingMethod.name=="BOPUS" ? <div className="m-od-pickupOption">PICKUP OPTIONS</div> : 'Shipping Method:' + shipment.shippingMethod.name}</div>
									{shipment.shippingMethod.name=="BOPUS" ? 
									<div className="m-od-pickupPerson">{data.alternatePickUpPersons ? data.alternatePickUpPersons[0].firstName+ " " + data.alternatePickUpPersons[0].lastName : data.paymentTypes.creditCards[0].billAddress.firstName + " " + data.paymentTypes.creditCards[0].billAddress.lastName}</div> : ""}
									<div className="m-od-pickupEmail">{shipment.shippingMethod.name=="BOPUS" && data.alternatePickUpPersons && data.alternatePickUpPersons[0].email ? data.alternatePickUpPersons[0].email : ''}</div>
									<div className="m-od-phoneNumber">{shipment.shippingMethod.name=="BOPUS" && shipment.shipAddress.phoneNumber ? shipment.shipAddress.phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3") : ''}</div>
									<div>{shipment.shippingMethod.name=="BOPUS" ? <div className="m-od-pickupInfoBopus">PICK UP INFORMATION</div> : <div className="m-od-pickupInfoShip">Expected Delivery</div> }</div>
									<div className="m-od-pickupMessage">{shipment.shippingMethod.name=="BOPUS" && shipment.inStorePickUp.estimatedPickUpMessage ? shipment.inStorePickUp.estimatedPickUpMessage: '' }</div>
									<div className="m-od-pickupDate">{shipment.shippingMethod.name!="BOPUS" && message && fromMonth ? 
									<div>
										<div className="m-od-pickFromDate">
											<div className="m-od-pickDateMonth">{fromMonth}</div>
											<div className="m-od-pickDateDay">{fromDay}</div>
											<div className="m-od-pickDateWeekDay">{fromWeekday}</div>
										</div>
										<div className="m-od-pickDateToTxt">TO</div>
										<div className="m-od-pickToDate">
											<div className="m-od-pickDateMonth">{toMonth}</div>
											<div className="m-od-pickDateDay">{toDay}</div>
											<div className="m-od-pickDateWeekDay">{toWeekday}</div>
										</div>
									</div>
									: <div> {message} </div>
									}</div>
									</div>
									<div className="m-od-border"></div>
									{shipment.orderItems && shipment.orderItems[0].trackingInfo ?
										<div className="m-od-trackingInfo">
											<span> Tracking Number: </span>
											<a href={shipment.orderItems[0].trackingInfo.URL} target="_blank"> {shipment.orderItems[0].trackingInfo.trackingNumber }</a>
										</div> : '' }
									
									<div className="m-od-productStatus">{shipment.orderItems && shipment.orderItems[0].status ? shipment.orderItems[0].status + "(" + shipment.orderItems.length +" "+ItemTxt+")" : ''}</div>
									{shipment.orderItems.map((orderItem, index) => {
										return(
											<div className="m-od-productDetail pad-lefrig20" key={index}>											
												<div className="m-od-productDets">
												<div className="m-od-productImg">
													<img src={orderItem.image && orderItem.image.URL} alt={orderItem.image && orderItem.image.altText}></img>
												</div>
												<div className="m-od-productDet">
													<div className="m-od-prod_name">{orderItem.productTitle}</div>
													<div className="m-od-prod_size">Size: {orderItem.size}</div>
													<div className="m-od-prod_color">Color: {orderItem.color}</div>
													<div className="m-od-prod_quantity">Quantity: {orderItem.qty}</div>
													<div className="m-od-prod_sku">SKU #{orderItem.skuCode}</div>
													<div className="m-od-itemTotal">Item total: ${orderItem.price.regularPrice}</div>
												</div>
												</div>
											</div>
										)
									})}
									<div className="m-od-borderBlk"></div>
								</div>								
							)			
						})}
						<div className="m-od-paymentDetails pad-lefrig20">
							<div className="m-od-paymeth">PAYMENT METHOD</div>
							<div className="m-od-cardDet">								
								{data.paymentTypes.creditCards && data.paymentTypes.creditCards[0].type=="VISA" ? <div className="m-od-cardImg m-od-visa"></div> : data.paymentTypes.creditCards && data.paymentTypes.creditCards[0].type=="MC" ? <div className="m-od-cardImg m-od-mc"></div> : data.paymentTypes.creditCards && data.paymentTypes.creditCards[0].type=="AMEX" ? <div className="m-od-cardImg m-od-amex"></div> : ''}
								<div className="m-od-cardInfo">
								<div className="m-od-cardType">{data.paymentTypes.creditCards[0].type && data.paymentTypes.creditCards[0].type=="MC" ? 'Mastercard' : data.paymentTypes.creditCards[0].type && data.paymentTypes.creditCards[0].type=="VISA" ? 'Visa' : data.paymentTypes.creditCards[0].type && data.paymentTypes.creditCards[0].type=="AMEX" ? 'American Express' : data.paymentTypes.creditCards[0].type ? data.paymentTypes.creditCards[0].type : ''}</div>
								<div className="m-od-cardNum">{data.paymentTypes.creditCards[0].cardNum && data.paymentTypes.creditCards[0].cardNum.length==16 ? data.paymentTypes.creditCards[0].cardNum.replace(/(\D{4})(\D{4})(\D{4})(\d{4})/, "$1-$2-$3-$4") : data.paymentTypes.creditCards[0].cardNum.replace(/(\D{3})(\D{4})(\D{4})(\d{4})/, "$1-$2-$3-$4")}</div>
								</div>
								<div className="m-od-cardVal">
								<div className="m-od-cardValApp">{data.paymentTypes.creditCards[0].valueApplied && data.paymentTypes.creditCards[0].valueApplied.toString().indexOf(".") !=-1 ? "$" + data.paymentTypes.creditCards[0].valueApplied : "$" + data.paymentTypes.creditCards[0].valueApplied + ".00"}</div>
								</div>
							</div>
							{data.paymentTypes.kohlsGiftCards.length > 0 ? 
							<div className="m-od-cardDet">								
								<div className="m-od-cardImg m-od-kcgift">{data.paymentTypes.kohlsGiftCards.length > 0 ? '' : ''}</div>
								<div className="m-od-cardInfo">
								<div className="m-od-cardType">Kohl's Gift Card</div>
								<div className="m-od-cardNum">{data.paymentTypes.kohlsGiftCards[0].giftCardNum ? data.paymentTypes.kohlsGiftCards[0].giftCardNum.replace(/(\D{2})(\D{4})(\d{4})/, "$1-$2-$3") : ''}</div>
								</div>
								<div className="m-od-cardVal">
								<div className="m-od-cardValApp">{data.paymentTypes.kohlsGiftCards[0].valueApplied && data.paymentTypes.kohlsGiftCards[0].valueApplied.toString().indexOf(".") !=-1 ? "$" + data.paymentTypes.kohlsGiftCards[0].valueApplied : "$" + data.paymentTypes.kohlsGiftCards[0].valueApplied + ".00"}</div>
								</div>
							</div> : ""}
							{data.paymentTypes.kohlsCash.length > 0 ? 
							<div className="m-od-cardDet">								
								<div className="m-od-cardImg m-od-kcash">{data.paymentTypes.kohlsCash.length > 0 ? '' : ''}</div>
								<div className="m-od-cardInfo">
								<div className="m-od-cardType">Kohl's Cash</div>
								<div className="m-od-cardNum">{data.paymentTypes.kohlsCash[0].kohlsCashNum ? data.paymentTypes.kohlsCash[0].kohlsCashNum.replace(/(\D{3})(\D{4})(\D{4})(\d{4})/, "$1-$2-$3-$4") : ''}</div>
								</div>
								<div className="m-od-cardVal">
								<div className="m-od-cardValApp">{data.paymentTypes.kohlsCash[0].valueApplied && data.paymentTypes.kohlsCash[0].valueApplied.toString().indexOf(".") !=-1 ? "$" + data.paymentTypes.kohlsCash[0].valueApplied : "$" + data.paymentTypes.kohlsCash[0].valueApplied + ".00"}</div>
								</div>
							</div> : ""}
							<div className="m-od-border"></div>
							<div className="m-od-billInfo">BILLING INFORMATION</div>
							<div className="m-od-billPerson">
								{data.paymentTypes.creditCards[0].billAddress.firstName ? data.paymentTypes.creditCards[0].billAddress.firstName : ''}
								{data.paymentTypes.creditCards[0].billAddress.lastName ? " " + data.paymentTypes.creditCards[0].billAddress.lastName: ''}
							</div>
							<div className="m-od-billAddr">
								{data.paymentTypes.creditCards[0].billAddress.addr1 ? data.paymentTypes.creditCards[0].billAddress.addr1 : ''}
								{data.paymentTypes.creditCards[0].billAddress.addr2 ? " "+data.paymentTypes.creditCards[0].billAddress.addr2 : ''}
							</div>
							<div className="m-od-billAddr">{data.paymentTypes.creditCards[0].billAddress.city ? data.paymentTypes.creditCards[0].billAddress.city + ", " + data.paymentTypes.creditCards[0].billAddress.state +" "+ data.paymentTypes.creditCards[0].billAddress.postalCode : ''}</div>
							<div className="m-od-phoneNum">{data.paymentTypes.creditCards[0].billAddress.phoneNumber ? data.paymentTypes.creditCards[0].billAddress.phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3") : ''}</div>
						</div>
						<div className="m-od-borderBlk"></div>
						<div className="m-od-orderSumm pad-lefrig20">
							<div className="m-od-orderSummTxt"> ORDER SUMMARY </div>
							<div className="m-od-totTax">
							<div className="m-od-subTotal">Subtotal <span className="m-od-floatRight">${data.totals.subTotal.toString().indexOf(".") !=-1 ? data.totals.subTotal : data.totals.subTotal+".00"}</span></div>
							<div className="m-od-kohlsCashDis">Kohl's Cash & Discounts ({data.totals.discountsOnlyTotal}) <span className="m-od-floatRight">-${data.totals.discountsTotal.toString().indexOf(".") !=-1 ? data.totals.discountsTotal : data.totals.discountsTotal+".00"}</span></div>
							<div className="m-od-shipping">Shipping <span className="m-od-floatRight">{data.totals.shipTotal=="0.00" ? "FREE" : "$"+data.totals.shipTotal}</span></div>	
					
							<div className="m-od-tax">{data && data.totals && data.totals.surchargeTotals && data.totals.feeDetails ? "Surcharge, Fees & Tax" : data && data.totals && data.totals.feeDetails ? "Fees & Tax" : data && data.totals && data.totals.surchargeTotals ? "Surcharge & Tax" : "Tax"} <span className="m-od-floatRight">${data.totals.tax_feeTotal ? data.totals.tax_feeTotal : data.totals.taxTotal}</span></div>
							{data && data.totals && data.totals.surchargeTotals ? 
								<div>{data.totals.surchargeTotals.map((surcharge, index) => {
									return(
											<div className="m-od-fees" key={index}> {surcharge.type} Surcharge <span className="m-od-floatRight"> ${surcharge.value.toString().indexOf(".") !=-1 ? surcharge.value : surcharge.value+".00"} </span> </div> 												
									)
								})}</div>
							: ""}
							{data && data.totals && data.totals.feeDetails ? 
								<div>{data.totals.feeDetails.map((fees, index) => {
									return(
											<div className="m-od-fees" key={index}> {fees.name} ({fees.location}) <span className="m-od-floatRight"> ${fees.cost.toString().indexOf(".") !=-1 ? fees.cost : fees.cost+".00"} </span> </div> 												
									)
								})}</div>
							: ""}
							<div className="m-od-salesTax">Sales Tax <span className="m-od-floatRight">${data.totals.salesTax}</span></div>
							</div>
							<div className="m-od-borderBlk2"></div>
							<div className="m-od-totalDet">
							<div className="m-od-total">TOTAL <span className="m-od-totalCount">({data.shipments[0].orderItems.length ==1 ? data.shipments[0].orderItems.length + " ITEM" : data.shipments[0].orderItems.length+ " ITEMS"})</span> <span className="m-od-floatRight">${data.totals.orderTotal}</span></div>
							<div className="m-od-earning">EARNINGS <span className="m-od-floatRight"></span></div>
							<div className="m-od-kohlsCash">Kohl's Cash <span className="m-od-floatRight">${data.totals.kohlsCashTotal}</span></div>
							<div className="m-od-y2yRew"> Yes2You Rewards (Estimated) <span className="m-od-floatRight">{data.kohlsRewards.earnedRewards.split(".")[0]} points</span></div>
							</div>
						</div>
					</div>) :
					(<div>
						{data ? 
						<div id="OS_container">
							<div className="pad-lefrig20">
								 <div id="m-os-breadcrum"> &lt; HISTORY</div>
								<div className="m-os-header">ORDER SUMMARY</div>
								<div id="m-os-orderDetails">
									<div>Order Number: <span className="m-os-orderNum"> {data.orderNumber} </span></div>
									<div>Date: <span> {OS_dateFormated} </span></div>
									<div>Location: Kohl's.com</div>
									<div>Price: <span className="m-os-total">${data.totals.orderTotal}</span></div>
								</div>
								<div id="m-os-orderDetailsbtn"><a href="#orderDetails" onClick={evt => {window.location.reload()}}>ORDER DETAILS</a></div>
							</div>
							<div className="m-os-border"></div>
							{data.shipments.map((shipment, index) => {
								return( <div key={index}>
								{shipment.orderItems.map((orderItem, index) => {
									const WRLink = window.location.origin+"/bvreviews/read_review.jsp?bvType=ratings&pCode="+orderItem.image.URL.split("/image/kohls/")[1].split("_")[0];
									return (
									<div className="pad-lefrig20" key={index}>
										<div className="m-os-productDetails">
											<div className="m-os-productImg">
												<img src={orderItem.image.URL} alt={orderItem.image.altText}></img>
											</div>
											<div className="m-os-productDet">
												<div className="m-os-prod_name" dangerouslySetInnerHTML={{__html: orderItem.productTitle}}/>
												<div className="m-os-prod_size">Size: {orderItem.size}</div>
												<div className="m-os-prod_color">Color: {orderItem.color}</div>
												<div className="m-os-prod_quantity">Quantity: {orderItem.qty}</div>
												<div className="m-os-prod_sku">SKU #{orderItem.skuCode}</div>
												<div className="m-os-wirteReviewBtn"><a href={WRLink}>WRITE A REVIEW</a></div>
											</div>
										</div>
									</div>)
								})}<div className="m-os-border"></div></div>)
								})}							
						</div> : ""}
					</div>)
					}
			</div>  : <div>
			{data && ((window.location.pathname.indexOf("/myaccount/v2/myaccount_orderSummary.jsp") > -1 && window.location.hash.indexOf("#orderDetails") > -1)  || (window.location.pathname.indexOf("/myaccount/v2/order_detail_anonymous.jsp") > -1)) ? 						
					(<div id="OD_container" className="pad-lefrig20">
						<div className="t-od-header">ORDER DETAILS</div>
						<div className="t-od-orderNoDet">
							<div className="t-od-orderNo">Order #<span className="m-od-orderNum"> {data.orderNumber} </span></div>
							<div className="t-od-tracking"> TRACKING #: <a href={data.shipments[0].orderItems[0].trackingInfo && data.shipments[0].orderItems[0].trackingInfo.URL} target="_blank"> {data.shipments[0].orderItems[0].trackingInfo && data.shipments[0].orderItems[0].trackingInfo.trackingNumber }</a></div>
						</div>
						{data.shipments.map((shipment, index) => {
							var message = (shipment.shippingMethod.name!="BOPUS" && shipment.shippingMethod.estimatedArrivalMessage) && shipment.shippingMethod.estimatedArrivalMessage;
							var fromDate = message && shipment.shippingMethod.estimatedArrivalMessage.indexOf('between') !== -1 && new Date(message.split("between ")[1].split("and")[0]+ new Date().getFullYear());
							var toDate = message && shipment.shippingMethod.estimatedArrivalMessage.indexOf('between') !== -1 && new Date(message.split("between ")[1].split("and")[1]+ new Date().getFullYear());
							var fromMonth = fromDate && month[fromDate.getMonth()];
							var fromDay = fromDate && fromDate.getDate();
							var fromWeekday = fromDate && weekday[fromDate.getDay()];
							var toMonth = toDate && month[toDate.getMonth()];
							var toDay = toDate && toDate.getDate();
							var toWeekday = toDate && weekday[toDate.getDay()];
							return (
								<div className="t-od-productShipDet" key={index}>
									<div className="t-od-left"><div className="t-od-storePic">{shipment.inStorePickUp.storeNum ? 'PICKUP STORE' : 'SHIPPING ADDRESS'}</div>
									<div><span className="t-od-storeName">{shipment.inStorePickUp.storeName ? shipment.inStorePickUp.storeName : ''}</span>
									{shipment.inStorePickUp.storeName ? ' Store' : ''}</div>
									<div className="t-od-billName">
									{shipment.shipAddress.firstName!="Store" ? shipment.shipAddress.firstName : ''}
									{shipment.shipAddress.lastName!="Pickup" ? " "+shipment.shipAddress.lastName : ''} </div>
									<div className="t-od-addr">{shipment.shipAddress.addr1 ? shipment.shipAddress.addr1 : ''}
									{shipment.shipAddress.addr2 ? ", "+shipment.shipAddress.addr2 : ''}</div>
									<div className="t-od-addr">{shipment.shipAddress.city ?  shipment.shipAddress.city : ''}
										 {shipment.shipAddress.state ? ", " + shipment.shipAddress.state : ''}
										 {shipment.shipAddress.postalCode ? " " + shipment.shipAddress.postalCode : ''}
									</div>
									<div className="t-od-phoneNum">{shipment.shippingMethod.name!="BOPUS" &&shipment.shipAddress.phoneNumber ? shipment.shipAddress.phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3") : ''}</div>
									<div>{shipment.shippingMethod.name=="BOPUS" ? <div className="t-od-pickupInfoBopus">PICK UP INFORMATION</div> : "" }</div>
									<div className="t-od-pickupMessage">{shipment.shippingMethod.name=="BOPUS" && shipment.inStorePickUp.estimatedPickUpMessage ? "Pickup orders are typically ready within 2 hours after they're processed. We'll notify you when the order is ready." : '' }</div></div>
									<div className="t-od-right">
									<div>{shipment.shippingMethod.name=="BOPUS" ? <div className="t-od-pickupOption">PICKUP PERSON</div> : <div className="t-od-pickupInfoShip">EXPECTED DELIVERY</div> }</div>		
									<div className="t-od-pickupOption">{shipment.shippingMethod.name=="BOPUS" ? "" : shipment.shippingMethod.name}</div>
									{shipment.shippingMethod.name=="BOPUS" ? 
									<div className="t-od-pickupPerson">{data.alternatePickUpPersons ? data.alternatePickUpPersons[0].firstName + " " + data.alternatePickUpPersons[0].lastName : data.paymentTypes.creditCards[0].billAddress.firstName + " " + data.paymentTypes.creditCards[0].billAddress.lastName}</div>	: ""}				
									<div className="t-od-phoneNum">{shipment.shippingMethod.name=="BOPUS" && data.paymentTypes && data.paymentTypes.creditCards && data.paymentTypes.creditCards[0] && data.paymentTypes.creditCards[0].billAddress && data.paymentTypes.creditCards[0].billAddress.phoneNumber ? data.paymentTypes.creditCards[0].billAddress.phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3") : ''}</div>
									<div className="t-od-pickupDate">{shipment.shippingMethod.name!="BOPUS" && message ? 
									<div>
										<div className="t-od-pickFromDate">
											<div className="t-od-pickDateMonth">{fromMonth}</div>
											<div className="t-od-pickDateDay">{fromDay}</div>
											<div className="t-od-pickDateWeekDay">{fromWeekday}</div>
										</div>
										<div className="t-od-pickDateToTxt">to</div>
										<div className="t-od-pickToDate">
											<div className="t-od-pickDateMonth">{toMonth}</div>
											<div className="t-od-pickDateDay">{toDay}</div>
											<div className="t-od-pickDateWeekDay">{toWeekday}</div>
										</div>
									</div>
									: '' }</div> </div>									
									{shipment.orderItems.map((orderItem, index) => {
										return(
											<div className="t-od-productDetail" key={index}>
												<div className="t-od-productStatus">{orderItem.status && orderItem.qty ? orderItem.status + " (" + orderItem.qty +" ITEM)" : ''}</div>
												<div className="t-od-quantity">QUANTITY</div>
												<div className="t-od-itemTotal">ITEM TOTAL</div>		
												<div className="t-od-borderBlk"></div>
												<div className="t-od-productDets">
												<div className="t-od-productImg">
													<img src={orderItem.image && orderItem.image.URL} alt={orderItem.image && orderItem.image.altText}></img>
												</div>
												<div className="t-od-productDet">
													<div className="t-od-prod_name">{orderItem.productTitle}</div>
													<div className="t-od-prod_size">Size: {orderItem.size}, Color: {orderItem.color}</div>
													<div className="t-od-prod_sku">sku #{orderItem.skuCode}</div>
													<div className="t-od-prodPrice"> Original ${orderItem.price.regularPrice}</div>
												</div>
												</div>
												<div className="t-od-quantityVal"> {orderItem.qty} </div>
												<div className="t-od-itemTotalVal"> ${orderItem.price.regularPrice} </div>
											</div>
										)
									})}
								</div>								
							)			
						})}
						
						<div className="t-od-Pay_Bill">
							<div className="t-od-PayDet">
								<div className="t-od-paymentMet">PAYMENT METHOD</div>
								{data.paymentTypes.creditCards && data.paymentTypes.creditCards[0].type=="VISA" ? <div className="t-od-cardIcon t-od-visa"></div> : data.paymentTypes.creditCards && data.paymentTypes.creditCards[0].type=="MC" ? <div className="t-od-cardIcon t-od-mc"></div> : data.paymentTypes.creditCards && data.paymentTypes.creditCards[0].type=="AMEX" ? <div className="t-od-cardIcon t-od-AMEX"></div> : ''}
								<div className="t-od-cardType">{data.paymentTypes.creditCards[0].type && data.paymentTypes.creditCards[0].type=="MC" ? 'Mastercard' : data.paymentTypes.creditCards[0].type && data.paymentTypes.creditCards[0].type=="VISA" ? 'Visa' : data.paymentTypes.creditCards[0].type && data.paymentTypes.creditCards[0].type=="AMEX" ? 'American Express' : data.paymentTypes.creditCards[0].type ? data.paymentTypes.creditCards[0].type : ''}</div>
								<div className="t-od-cardValApp">{data.paymentTypes.creditCards[0].valueApplied && data.paymentTypes.creditCards[0].cardNum ? "$" + data.paymentTypes.creditCards[0].valueApplied + data.paymentTypes.creditCards[0].cardNum.slice(-5) : ''}</div>											
							</div>
							<div className="t-od-BillDet">
								<div className="t-od-billInfo">BILLING INFORMATION</div>
								<div className="t-od-billPerson">{data.paymentTypes.creditCards[0].billAddress.firstName ? data.paymentTypes.creditCards[0].billAddress.firstName + " " + data.paymentTypes.creditCards[0].billAddress.lastName : ''}</div>
								<div className="t-od-billAddr">
									{data.paymentTypes.creditCards[0].billAddress.addr1 ? data.paymentTypes.creditCards[0].billAddress.addr1 : ''}
									{data.paymentTypes.creditCards[0].billAddress.addr2 ? " "+data.paymentTypes.creditCards[0].billAddress.addr2 : ''}
								</div>
								<div className="t-od-billAddr">{data.paymentTypes.creditCards[0].billAddress.city ? data.paymentTypes.creditCards[0].billAddress.city + ", " + data.paymentTypes.creditCards[0].billAddress.state +" "+ data.paymentTypes.creditCards[0].billAddress.postalCode : ''}</div>
								<div className="t-od-phoneNum">{data.paymentTypes.creditCards[0].billAddress.phoneNumber ? data.paymentTypes.creditCards[0].billAddress.phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3") : ''}</div>
							</div>
						</div>
						<div className="t-od-orderSumm">
							<div className="t-od-orderSumLeft">
								<div className="t-od-orderSummTxt"> ORDER SUMMARY </div>
									<div className="t-od-totTax">
									<div className="t-od-subTotal">Subtotal <span className="t-od-floatRight">${data.totals.subTotal}</span></div>
									{data.totals.discountsOnlyTotal > 0 ? 
									<div className="t-od-kohlsCashDis">Kohl's Cash & Discounts ({data.totals.discountsOnlyTotal}) <span className="t-od-floatRight">-${data.totals.discountsTotal.toString().indexOf(".") !=-1 ? data.totals.discountsTotal : data.totals.discountsTotal+".00"}</span></div>
									: ''}
									<div className="t-od-shipping">Shipping <span className="t-od-floatRight">${data.totals.shipTotal}</span></div>
									<div className="t-od-tax">{data && data.totals && data.totals.surchargeTotals && data.totals.feeDetails ? "Surcharge, Fees & Tax" : data && data.totals && data.totals.feeDetails ? "Fees & Tax" : data && data.totals && data.totals.surchargeTotals ? "Surcharge & Tax" : "Tax"} <span className="t-od-floatRight">${data.totals.tax_feeTotal ? data.totals.tax_feeTotal : data.totals.taxTotal}</span></div>
									{data && data.totals && data.totals.surchargeTotals ? 
										<div>{data.totals.surchargeTotals.map((surcharge, index) => {
											return(
													<div className="t-od-fees" key={index}> {surcharge.type} Surcharge <span className="t-od-salesTaxVal t-od-floatRight"> ${surcharge.value.toString().indexOf(".") !=-1 ? surcharge.value : surcharge.value+".00"} </span> </div> 												
											)
										})}</div>
									: ""}
									{data && data.totals && data.totals.feeDetails ? 
										<div>{data.totals.feeDetails.map((fees, index) => {
											return(
													<div className="t-od-fees" key={index}> {fees.name} ({fees.location}) <span className="t-od-salesTaxVal t-od-floatRight"> ${fees.cost.toString().indexOf(".") !=-1 ? fees.cost : fees.cost+".00"} </span> </div> 												
											)
										})}</div>
									: ""}
									<div className="t-od-salesTax">Sales Tax <span className="t-od-salesTaxVal t-od-floatRight">${data.totals.salesTax}</span></div>
									<div className="t-od-total">TOTAL <span className="t-od-floatRight">${data.totals.orderTotal}</span></div>
								</div>
							</div>
							<div className="t-od-orderSumRight">
								<div className="t-od-totalDet">								
									<div className="t-od-earning">YOUR EARNINGS <span className="t-od-floatRight"></span></div>
									<div className="t-od-kohlsCash">Kohl's Cash <span className="t-od-floatRight">${data.totals.kohlsCashTotal} Earned</span></div>
									<div className="t-od-y2yRew">Yes2You Rewards <span className="t-od-floatRight">{data.kohlsRewards.earnedRewards.split(".")[0]} points Earned</span></div>
									<div className="t-od-savings">YOUR SAVINGS</div>
									<div className="t-od-savingsTotal">Savings <span className="t-od-floatRight">${data.totals.kohlsCashTotal}</span></div>
								</div>
							</div>
						</div>
					</div>) : ""					
					}
				</div>
			}
		</div>
		)
	}
});