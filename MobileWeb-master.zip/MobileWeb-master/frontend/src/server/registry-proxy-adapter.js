const cheerio = require('cheerio');

//shim for nashhorn
global.getRegistryPageHead = getRegistryPageHead;
global.getRegistryPageBody = getRegistryPageBody;
global.getRegistryProfileData = getRegistryProfileData;

// takes the inputHtml from http://m.kohls.com/gift-registry/gift-registry.jsp
export function getRegistryPageHead(inputHtml, debugEnabled, isTcom){
  //debugEnabled && console.log('getRegistryPageHead called with inputHtml: ' + inputHtml);
  let $ = cheerio.load(inputHtml);
  const head = $('head');
  // do DOM manipulations here
  const headHtml = head.html();
  debugEnabled && console.log('getRegistryPageHead returning headHtml : ' + headHtml);
  return headHtml;
}

// takes the inputHtml from http://m.kohls.com/gift-registry/gift-registry.jsp
export function getRegistryPageBody(inputHtml, debugEnabled, isTcom){
  debugEnabled && console.log('transformRegistryPage called with inputHtml: ' + inputHtml);
  let $ = cheerio.load(inputHtml);
  const body = $('body');
  body.find('.mcom_header').remove();
  body.find('#mcom_footer').remove();
  const bodyHtml = body.html();
  debugEnabled && console.log('transformRegistryPage returning bodyHtml : ' + bodyHtml);
  return bodyHtml;
}

// this function should produce the correct response for /skavastream/xact/v5/kohls/profile/get
// it takes the registry hash which is generated server side
// and the mspProfileData which is the respose from /v1/profile
export function getRegistryProfileData(registryHash, mspProfileDataStr, debugEnabled, isTcom){
  // for this call we only need to populate the 'hash' field with the registry hash
  debugEnabled && console.log(`getRegistryProfileData called with registryHash: ${registryHash}, mspProfileData: ${mspProfileData}`);
  const hashString = `{\"wallettimestamp\":0,\"wallethash\":\"\",\"hash\":\"${registryHash}\"}`;
  const mspProfileData = JSON.parse(mspProfileDataStr);
  const customerName = mspProfileData.payload.profile.customerName;
  const returnObj = {
    "identifier": "",
    "type": "profile",
    "properties": {
      "iteminfo": {},
      "userinfo": [
        {
          "firstname": customerName.firstName,
          "phoneextension": null,
          "phonenumber": null,
          "middlename": customerName.middleName,
          "type": "customerName",
          "hash": hashString,
          "email": mspProfileData.payload.profile.email,
          "additionalinfo": [],
          "lastname": customerName.lastName
        }
      ]
    }
  };
  const responsStr = JSON.stringify(returnObj);
  debugEnabled && console.log('getRegistryProfileData returning: ' + responsStr);
  return responsStr;
}
