import {getRegistryPageBody, getRegistryProfileData} from '../registry-proxy-adapter';

const cheerio = require('cheerio');
const read = require('read-file');

const pageData = read.sync(__dirname + '/test-registry-page.html', 'utf8');

describe('getRegistryPageBody', () => {
  it('should properly transform the page', () => {
    let $ = cheerio.load(pageData);

    const elementString = '.mcom_header';
    const initialLength = $(elementString).length;
    const transformedPage = getRegistryPageBody(pageData, false, false);

    $ = cheerio.load(transformedPage);
    const postTransformLength = $(elementString).length;

    expect(initialLength).toEqual(1);
    expect(postTransformLength).toEqual(0);
  });
});

describe('getRegistryProfileData', () => {
  it('should return the correct response', () => {
    const registryHash = 'test-hash-123';
    //const mspProfileData = require('./test-msp-profile-data.json');
    // we want to read the data in as a string
    const mspProfileData = read.sync(__dirname + '/test-msp-profile-data.json', 'utf8');
    const registryProfileData = JSON.parse(getRegistryProfileData(registryHash, mspProfileData, false, false));
    const userInfo = registryProfileData.properties.userinfo[0];

    expect(userInfo.firstname).toEqual('brant');
    expect(userInfo.lastname).toEqual('rouse');

    const hashObj = JSON.parse(userInfo.hash);
    expect(hashObj.hash).toEqual(registryHash);
  });
});
