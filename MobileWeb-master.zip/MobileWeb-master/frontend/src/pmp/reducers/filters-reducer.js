import * as utils from '../../global/utils';

const filtersReducer = function(state = {}, action) {
  let previousSelectedFilterIds = null;
  let previousAppliedFilterLabels = null;
  let previousAvailabilityList = null;
  let previousStoreOrder = null;
  let previousSort = null;
  switch(action.type) {
    case 'INIT_FILTERS':
      debugPmp && console.log('INIT_FILTERS in filtersReducer dispatched');

      //TODO: do this via default value assignment
      return Object.assign({}, state, {
        currentFilters: [],
        selectedFilterIds: [],
        appliedFilterIds: [],
        isApplyButtonActive: false,
        selectedGroup: '',
        isTcom: action.isTcom,
        appliedFilterLabels: {},
        sorts: [],
        availabilityList: [],
        noStores: false,
        inValidEntry: false,
        previousSelectedFilterIds: null,
        previousAppliedFilterLabels: null,
        previousStoreOrder: null,
        previousSort: null,
        bGetLatestFilters: false,
        storeOrder:[]
      });
    case 'CANCEL_FILTERS':
      debugPmp && console.log('CANCEL_FILTERS in filtersReducer dispatched');
      //TODO: use Object.assign more intelligently here
      previousSelectedFilterIds = state.previousSelectedFilterIds || state.selectedFilterIds;
      previousAppliedFilterLabels = state.previousAppliedFilterLabels || state.appliedFilterLabels;
      previousAvailabilityList = state.previousAvailabilityList || state.availabilityList;
      previousStoreOrder = state.previousStoreOrder || state.storeOrder;
      previousSort = state.previousSort || state.sorts;
      return Object.assign({}, state, {
        currentFilters: state.availableFilters,
        selectedFilterIds: previousSelectedFilterIds,
        availabilityList: previousAvailabilityList,
        isApplyButtonActive: false,
        selectedGroup: '',
        appState: {showStoreFilter:false},
        showStoreFilter: false,
        appliedFilterLabels: previousAppliedFilterLabels,
        noStores: false,
        inValidEntry: false,
        previousSelectedFilterIds: null,
        previousAppliedFilterLabels: null,
        previousAvailabilityList: null,
        previousSort: null,
        storeOrder: previousStoreOrder,
        sorts: previousSort
      });
    case 'UPDATE_AVAILABLE_FILTERS': //dispatched when catalog updates
      debugPmp && console.log('UPDATE_AVAILABLE_FILTERS in filtersReducer dispatched');
      const updatedAppliedFilters = getAppliedFilters(action.activeDimensions);
      const appliedFilterLabels = getAppliedFilterLabels(action.activeDimensions);
      const availFilters = getPriceFirstFilters(action.availableFilters);
      //TODO: use Object.assign more intelligently here
      return Object.assign({}, state, {
        availableFilters: availFilters, //all filters returned from OAPI
        currentFilters: availFilters, //filters available after user selection
        selectedFilterIds: updatedAppliedFilters,
        appliedFilterIds: updatedAppliedFilters,
        appliedFilterLabels,
        isApplyButtonActive: false,
        selectedGroup: '',
        sorts: action.sorts,
        previousSelectedFilterIds: null,
        previousAppliedFilterLabels: null,
        previousAvailabilityList: null
      });
    // case 'UPDATE_CURRENT_FILTERS': //dispatched when user selects different filter group
    //   debugPmp && console.log('UPDATE_CURRENT_FILTERS in filtersReducer dispatched');
    //   return Object.assign({}, state, {currentFilters: action.currentFilters});
    case 'SELECT_FILTER':
      debugPmp && console.log('SELECT_FILTER in filtersReducer dispatched');
      previousSelectedFilterIds = state.previousSelectedFilterIds;
      previousAppliedFilterLabels = state.previousAppliedFilterLabels;
      previousSort = state.previousSort;
      if(!state.previousSelectedFilterIds) {
        previousSelectedFilterIds = [].concat(state.selectedFilterIds);
      }
      if(!state.previousAppliedFilterLabels) {
        previousAppliedFilterLabels = [].concat(state.appliedFilterLabels);
      }
      let updatedSelectedFilterIds = state.selectedFilterIds;
      if(action.selectedFilter.currentDimensionId) {
        updatedSelectedFilterIds = getUpdatedSelections(action.selectedFilter.currentDimensionId, state.selectedFilterIds, isAnyStoreOrSortSelected(action.filterGroupLabel, state.availabilityList));
      }
      const updatedAppliedFilterLabels = addAppliedFilterLabels(action.selectedFilter.name, action.filterGroupLabel, state.appliedFilterLabels);

      debugPmp && console.log('selected filters now: ' + JSON.stringify(updatedSelectedFilterIds));
      let isApplyButtonActive = !utils.areSortedArraysEqual(updatedSelectedFilterIds, state.appliedFilterIds);
      if(isAnyStoreOrSortSelected(action.filterGroupLabel, state.availabilityList, state.sorts)) {
        isApplyButtonActive = true;
      }
      return Object.assign({}, state, {
        selectedFilterIds: updatedSelectedFilterIds,
        isApplyButtonActive: isApplyButtonActive,
        appliedFilterLabels: updatedAppliedFilterLabels,
        previousSelectedFilterIds,
        previousAppliedFilterLabels,
        previousSort,
        bGetLatestFilters: true
        //appliedFilterLabels: updatedFilterLabels
      });
    case 'SELECT_GROUP':
      debugPmp && console.log('SELECT_GROUP in filtersReducer dispatched');
      let selectedGroup = action.selectedGroup;
      if (selectedGroup === state.selectedGroup){
        //filter group already selected, so de-select
        selectedGroup = '';
      }

      let currentFilters = (action.currentFilters) ? getPriceFirstFilters(action.currentFilters) : state.currentFilters;

      //debugPmp && console.log('currentFilters will be set to ' + JSON.stringify(currentFilters));
      return Object.assign({}, state, {
        selectedGroup: selectedGroup,
        currentFilters: currentFilters,
        noStores: false,
        inValidEntry: false,
        bGetLatestFilters: false
      });
      case 'CLOSE_SORT':
        return Object.assign({}, state, {
          appState: { showSort : false}
        });
      case 'SHOW_STORE_FILTER':
        return Object.assign({}, state, {
          showStoreFilter : true
        });
      case 'UPDATE_STORE_AVAILABILITY':
        return Object.assign({}, state, {
          previousAvailabilityList: null,
          availabilityList: action.availabilityList,
          noStores: action.noStores,
          inValidEntry: action.inValidEntry
        });
      case 'SELECT_STORE':
        previousAvailabilityList = state.previousAvailabilityList;
        previousStoreOrder = state.previousStoreOrder;
        if(!previousAvailabilityList) {
          previousAvailabilityList = JSON.parse(JSON.stringify(state.availabilityList));
        }
        if(!previousStoreOrder) {
          previousStoreOrder = JSON.parse(JSON.stringify(state.storeOrder));
        }
        let selectedStore = state.availabilityList.find((store) => {
          return store.storeNum == action.store.storeNum;
        });

        if(state.storeOrder.indexOf(action.store.storeNum) != -1) {
          state.storeOrder.splice(state.storeOrder.indexOf(action.store.storeNum),1);
        }

        if(selectedStore.active) {
          selectedStore.active = false;
        } else {
          selectedStore.active = true;
          state.storeOrder.push(action.store.storeNum);
        }

        return Object.assign({}, state, {
          availabilityList: state.availabilityList,
          previousAvailabilityList,
          previousStoreOrder
        });
  }
return state;
}

export function getAppliedFilterLabels(activeDimensions){
    let appliedFilterLabels = {};
    activeDimensions.map((activeDimension) => {
      let labels = activeDimension.activeDimensionValues.map((activeDimensionValue) => {
        return activeDimensionValue.name;
      })

      if (labels && labels.length > 0){
        appliedFilterLabels[activeDimension.label] = labels.join(', ');
      }
    });
    return appliedFilterLabels;
}

export function addAppliedFilterLabels(filterName, filterGroupName, appliedFilterLabels){
  if (!appliedFilterLabels[filterGroupName]){
    appliedFilterLabels[filterGroupName] = filterName;
    return appliedFilterLabels;
  }

  const currentFilterGroupLabels = appliedFilterLabels[filterGroupName];
  const currentLabelArr = currentFilterGroupLabels.split(', ');
  const updatedLabelArr = getUpdatedSelections(filterName, currentLabelArr);

  if (updatedLabelArr.length === 0){
    delete appliedFilterLabels[filterGroupName];
  }else{
    appliedFilterLabels[filterGroupName] = updatedLabelArr.join(', ');
  }

  return appliedFilterLabels;
}

function getAppliedFilters(activeDimensions){
  const appliedFilters = [];
  activeDimensions && activeDimensions.map((activeDimension) => {
    activeDimension.activeDimensionValues.map((activeDimensionValue) => {
      appliedFilters.push(activeDimensionValue.currentDimensionId);
    });
  });

  debugPmp && console.log('applied filters are ' + JSON.stringify(appliedFilters));
  return appliedFilters.sort();
}

// return filters array with price first
export function getPriceFirstFilters(currentFilters){
  let firstElement, newFilters = [];

  newFilters = currentFilters.filter((filter) => {
    if (filter.name === 'Price'){
      firstElement = filter;
      return false;
    }
    return true;
  });

  if (firstElement){
    newFilters.unshift(firstElement);
    return newFilters;
  }
  return currentFilters;
}

export function getUpdatedSelections(newSelection, currentSelections){
  let alreadySelected = false;
  let newSelections = currentSelections.filter((value) => {
    if (value === newSelection){
      alreadySelected = true;
      return false;
    }else{
      return true;
    }
  });

  if (!alreadySelected){
    newSelections.push(newSelection);
  }

  const sortedSelections = newSelections.sort();
  return sortedSelections;
}

export function isAnyStoreOrSortSelected(filterGroupLabel, availabilityList, sorts) {
  if(availabilityList && filterGroupLabel == "Store Avalibility") {
    return availabilityList.find((store) => {
      return store.active === true;
    });
  }

  if(sorts && filterGroupLabel == "Sort By") {
    return sorts.find((sort) => {
      return sort.active === true;
    });
  }
}

export default filtersReducer;
