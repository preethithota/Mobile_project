import * as pmpHelper from '../util/pmp-helper';

//TODO:remove these
const backendParams = ['CN', 'N', 'WS', 'limit', 'S', 'search'];
const backendBaseCatalogUrl = '/service/catalog/';

const defaultStateValues = {
  nextState: [],
  nextQueryString: '',
  nextUriPath: '',
  shouldRefreshFilters: false
}

const appStateReducer = function(state = {}, action) {

  switch(action.type) {
    case 'INIT_STORE':
      debugPmp && console.log('INIT_STORE in appStateReducer dispatched');
      return Object.assign({}, state, {
        currentState: pmpHelper.getAppStateFromQueryString(action.queryString),
        currentUriPath: action.uriPath,
        currentQueryString: action.queryString
      });
    // case 'UPDATE_APPSTATE_FROM_URI':
    //   debugPmp && console.log('UPDATE_APPSTATE_FROM_URI dispatched');
    //   return getNextState(action.nextUri, null, action.shouldRefreshFilters, state);
    // case 'UPDATE_APPSTATE_FROM_PARAMS':
    //   debugPmp && console.log('UPDATE_APPSTATE_FROM_PARAMS dispatched');
    //   return getNextState(null, action.updatedParams, action.shouldRefreshFilters, state);
    case 'UPDATE_CATALOG_DATA':
      debugPmp && console.log('UPDATE_CATALOG_DATA in appStateReducer dispatched');
      return Object.assign({}, state, {
        currentUriPath: action.nextUri,
        currentState: action.nextAppState,
        currentQueryString: action.nextQueryString
      });
    case 'SHOW_MCOM_FILTERS':
      let menuFilterUrl = state.menuFilterUrl;
      if(!menuFilterUrl && window.location.href.indexOf("fromMenu") != -1) {
        menuFilterUrl = window.location.href;
      }
      return Object.assign({}, state, {
        menuFilterUrl
      });
  }

  return state;
}

export default appStateReducer;
