import * as utils from '../../global/utils';
import * as smsHelper from '../../shopMyStore/shopmystore-helper';

const catalogReducer = function(state = {}, action) {
  switch(action.type) {
    case 'UPDATE_CATALOG_DATA':
      debugPmp && console.log('UPDATE_CATALOG_DATA in catalogReducer dispatched');
      const updatedState = Object.assign({}, state, action.catalogData);
      // if (state.hookLogicData){
      //   updatedState.products = combineHooklogicWithExistingProducts(action.catalogData.products, state.hookLogicData);
      // }
      return updatedState;
    case 'INIT_STORE':
      debugPmp && console.log('INIT_STORE in catalogReducer dispatched');
      return Object.assign({}, action.catalogData);
    case 'UPDATE_HOOKLOGIC_DATA':
        debugPmp && console.log('UPDATE_HOOKLOGIC_DATA in catalogReducer dispatched');
        const currentProducts = (state.products) ? state.products : [];
        const updateProducts = combineHooklogicWithExistingProducts(currentProducts, action.hookLogicData);
        return Object.assign({}, state, {
          hookLogicData: action.hookLogicData,
          products: updateProducts
        });
  }
  return state;
}

function combineHooklogicWithExistingProducts(currentProducts, hookLogicData){
	//TODO: replace this concat function with actual function to add Hooklogic products
	let hlProducts = hookLogicData && hookLogicData.SearchProductAd || hookLogicData.ProductAd || [];
	var insertPos = 1;
	var insertStepper = 2;
	if(kohlsData.isTcom) {
		insertPos = 3;
		insertStepper = 4;
	}
	Array.prototype.insert = function ( index, item ) {
	this.splice( index, 0, item );
	};

	var hl_b;
	function hl_beacon(b) {
		if (!b || b.length == 0)
		{ return }
		var p = window.location.protocol;
		var e = document.createElement("img");
		if (b.slice(0, 4) != "http")
		{ b = p + b; }
		e.src = b;
		hl_b = hl_b || [];
		hl_b.push(e);
	};
	//Hooklogic page beacon
	if(hookLogicData.PageBeacon)
		hl_beacon(hookLogicData.PageBeacon);
	for(var product in hlProducts) {
		if((hlProducts.hasOwnProperty(product))) {
		  	var hlProduct = hlProducts[product];
		  	if(hlProduct.ParentSKU)
		  		currentProducts = removeDuplicateProduct(hlProduct.ParentSKU,currentProducts);
		  	var renderingAttributes = hlProduct.RenderingAttributes && JSON.parse(hlProduct.RenderingAttributes);
		  	var seoUrl = hlProduct.ProductPage || "";
		  	if(seoUrl) {
		  		var dest = new URL(decodeURIComponent(utils.getUrlParam("dest",seoUrl)));
		  		dest = location.protocol+ "//" +location.host+ dest.pathname+ dest.search;
		  		seoUrl = smsHelper.removeParameterFromUrl(seoUrl,"dest");
		  		seoUrl = location.protocol + "//"+seoUrl+"&dest="+dest;
		  	}
		  	//Impression beacon
		  	if(hlProduct.ImpBeacon)
					hl_beacon(hlProduct.ImpBeacon);
		  	var catalogMapper = {
			    "webID": hlProduct.AdvertiserId || "",
			    "productTitle": hlProduct.ProductName || "",
			    "image": {
			        "url": hlProduct.Image || "",
			        "height": "180",
			        "width": "180"
			    },
			    "prices": [{
			        "regularPrice": {
			            "minPrice": (hlProduct.ComparePrice && parseFloat(hlProduct.ComparePrice)) || null,
			            "maxPrice": null
			        },
			        "salePrice": {
			            "minPrice": (hlProduct.Price != hlProduct.ComparePrice) ? (hlProduct.Price && parseFloat(hlProduct.Price)) : null,
			            "maxPrice": null
			        },
			        "regularPriceType": "Original",
			        "statusCode": "20",
			        "priceCode": "Normal",
			        "salePriceStatus": (hlProduct.Price != hlProduct.ComparePrice) ? "sale" : "",
			        "isCurrentPrice": true,
			        "isHlProduct": true
			    }],
			    "rating": {
			        "avgRating": hlProduct.Rating || null,
			        "count": renderingAttributes.numberofreviews || "0",
			        "isHlProduct": true
			    },
			    "seoURL": seoUrl || ""
				};

			if(currentProducts[insertPos]) {
				currentProducts.insert(insertPos, catalogMapper);
				insertPos += insertStepper;
			} else {
				currentProducts.insert(currentProducts.length, catalogMapper);
			}
		}
	}
	return currentProducts;
}

function removeDuplicateProduct(hlProdId,catalogProducts) {
	for(var index=0; catalogProducts.length > index; index++) {
		if(catalogProducts[index].webID == hlProdId) {
			catalogProducts.splice(index,1);
			break;
		}
	}
	return catalogProducts;
}

export default catalogReducer;
