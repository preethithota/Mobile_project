import * as filtersReducer from '../filters-reducer';

const filtersData = require('./filters.json');

describe('priceFirstFilters', () => {

    it('should return array of same length', () => {
      const updatedFilters = filtersReducer.getPriceFirstFilters(filtersData);
      expect(updatedFilters.length).toEqual(filtersData.length);
    });

    it('should return price filter first', () => {
      const updatedFilters = filtersReducer.getPriceFirstFilters(filtersData);
      expect(updatedFilters[0].name).toEqual("Price");
    });

    if('should not modify the array if there is no price filter', () => {
      const noPriceFiltersData = currentFilters.filter((filter) => {
        return (filter.name !== 'Price');
      });
      const updatedFilters = filtersReducer.getPriceFirstFilters(noPriceFiltersData);
      expect(updatedFilters).toBe(noPriceFiltersData);
    });

});

describe('getUpdatedSelections', () => {

    it('should return correct updated filter array', () => {
      const selectedFilter = 'Product:Cutting%20Boards+Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining';
      const currentFilterSelections = ["Category:Cutlery%20%26%20Knives","Department:Kitchen%20%26%20Dining"];
      const updatedFilterSelections = filtersReducer.getUpdatedSelections(selectedFilter, currentFilterSelections);
      const expectedUpdatedSelections = ["Category:Cutlery%20%26%20Knives","Department:Kitchen%20%26%20Dining","Product:Cutting%20Boards+Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining"];
      expect(updatedFilterSelections).toEqual(expectedUpdatedSelections);
    });

    it('should add new filters to the list', () => {
      const selectedFilter = "Product:Knife%20Sets";
      const currentFilterSelections = ["Category:Cutlery%20%26%20Knives", "Department:Kitchen%20%26%20Dining"];
      const expectedFilters = ["Category:Cutlery%20%26%20Knives", "Department:Kitchen%20%26%20Dining", "Product:Knife%20Sets"];

      expect(filtersReducer.getUpdatedSelections(selectedFilter, currentFilterSelections)).toEqual(expectedFilters);
    });

    it('should remove selectedFilter if it is already in the listd', () => {
      const selectedFilter = "Product:Knife%20Sets";
      const currentFilterSelections = ["Category:Cutlery%20%26%20Knives", "Department:Kitchen%20%26%20Dining", "Product:Knife%20Sets"];
      const expectedFilters = ["Category:Cutlery%20%26%20Knives", "Department:Kitchen%20%26%20Dining"];

      expect(filtersReducer.getUpdatedSelections(selectedFilter, currentFilterSelections)).toEqual(expectedFilters);
    });

});

describe('getAppliedFilterLabels', () => {

  it('should return correct filter labels', () => {
    const activeDimensions = [{"name":"Department","label":"Department","index":1,"activeDimensionValues":[{"name":"Kitchen & Dining","index":1,"productCount":29,"seoURL":"/catalog.jsp?CN=0&S=0&WS=0","currentDimensionId":"Department:Kitchen%20%26%20Dining","ID":"0"}]},{"name":"Category","label":"Category","index":2,"activeDimensionValues":[{"name":"Cutlery & Knives","index":1,"productCount":29,"seoURL":"/catalog/kitchen-dining.jsp?CN=Department:Kitchen%20%26%20Dining&S=0&WS=0","currentDimensionId":"Category:Cutlery%20%26%20Knives","ID":"Department:Kitchen%20%26%20Dining"}]}];
    let appliedFilterLabels = filtersReducer.getAppliedFilterLabels(activeDimensions);
    expect(appliedFilterLabels.Department).toEqual("Kitchen & Dining");
  });

  it('should return multiple labels separated by a comma', () => {
    const activeDimensions = [{"name":"Department","label":"Department","index":1,"activeDimensionValues":[{"name":"Kitchen & Dining","index":1,"productCount":7,"seoURL":"/catalog.jsp?CN=0&S=0&WS=0","currentDimensionId":"Department:Kitchen%20%26%20Dining","ID":"0"}]},{"name":"Category","label":"Category","index":2,"activeDimensionValues":[{"name":"Cutlery & Knives","index":1,"productCount":7,"seoURL":"/catalog/kitchen-dining.jsp?CN=Department:Kitchen%20%26%20Dining&S=0&WS=0","currentDimensionId":"Category:Cutlery%20%26%20Knives","ID":"Department:Kitchen%20%26%20Dining"}]},{"name":"Product","label":"Product","index":3,"activeDimensionValues":[{"name":"Boning & Fillet Knives","index":1,"productCount":1,"seoURL":"/catalog/knife-sets-cutlery-knives-kitchen-dining.jsp?CN=Product:Knife%20Sets+Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining&S=0&WS=0","currentDimensionId":"Product:Boning%20%26%20Fillet%20Knives","ID":"Product:Knife%20Sets+Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining"},{"name":"Knife Sets","index":2,"productCount":6,"seoURL":"/catalog/boning-fillet-knives-cutlery-knives-kitchen-dining.jsp?CN=Product:Boning%20%26%20Fillet%20Knives+Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining&S=0&WS=0","currentDimensionId":"Product:Knife%20Sets","ID":"Product:Boning%20%26%20Fillet%20Knives+Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining"}]}];
    let appliedFilterLabels = filtersReducer.getAppliedFilterLabels(activeDimensions);
    expect(appliedFilterLabels.Product).toEqual('Boning & Fillet Knives, Knife Sets');
  });

});

describe('addAppliedFilterLabels', () => {

  let currentLabels;

  beforeEach(() => {
    currentLabels = {Department: "Kitchen & Dining", Category: "Cutlery & Knives", Product: "Boning & Fillet Knives, Knife Sets"};
  });

  it('should properly add new label to new filter group', () => {
    const filterName = 'Some New Filter Name';
    const filterGroupName = 'Some New Filter Group Name';
    const actualLabels = filtersReducer.addAppliedFilterLabels(filterName, filterGroupName, currentLabels);
    expect(actualLabels[filterGroupName]).toEqual(filterName);
  });

  it('should properly append new label to existing filter group', () => {
    const filterGroupName = 'Category';
    const filterName = 'Some New Category';
    const expectedCategoryLabel = 'Cutlery & Knives, Some New Category';
    const actualLabels = filtersReducer.addAppliedFilterLabels(filterName, filterGroupName, currentLabels);
    expect(actualLabels[filterGroupName]).toEqual(expectedCategoryLabel);
  });

  it('should properly remove first label from existing filter group', () => {
    const filterGroupName = 'Product';
    const filterName = 'Boning & Fillet Knives';
    const expectedProductLabel = 'Knife Sets';
    const actualLabels = filtersReducer.addAppliedFilterLabels(filterName, filterGroupName, currentLabels);
    expect(actualLabels[filterGroupName]).toEqual(expectedProductLabel);

  });

  it('should properly remove last label from existing filter group', () => {
    const filterGroupName = 'Product';
    const filterName = 'Knife Sets';
    const expectedProductLabel = 'Boning & Fillet Knives';
    const actualLabels = filtersReducer.addAppliedFilterLabels(filterName, filterGroupName, currentLabels);
    expect(actualLabels[filterGroupName]).toEqual(expectedProductLabel);
  });

  it('should properly remove label and filter group if it containers no more labels', () => {
    const filterGroupName = 'Category';
    const filterName = 'Cutlery & Knives';
    const actualLabels = filtersReducer.addAppliedFilterLabels(filterName, filterGroupName, currentLabels);
    expect(actualLabels[filterGroupName]).toBeUndefined();
  });

});
