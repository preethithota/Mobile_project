export const intialUiState = {
  showViewOptions: false,
  resultsViewType: 'GRID',
  mcomFiltersVisible: false,
  tcomFiltersVisible: false
}

const uiReducer = function(state = intialUiState, action) {
  switch(action.type) {
    case 'TOGGLE_VIEW_OPTIONS':
      debugPmp && console.log('SHOW_VIEW_OPTIONS in uiReducer dispatched');
      return Object.assign({}, state, {showViewOptions: !state.showViewOptions});
    case 'SET_VIEW_TYPE':
      debugPmp && console.log('SHOW_GRID_VIEW in uiReducer dispatched');
      return Object.assign({}, intialUiState, {resultsViewType: action.viewType});
    case 'SHOW_MCOM_FILTERS':
      debugPmp && console.log('SHOW_MCOM_FILTERS in uiReducer dispatched');
      return Object.assign({}, state, {
        mcomFiltersVisible: true,
        tcomFiltersVisible: false
      });
    case 'TOGGLE_TCOM_FILTERS':
      debugPmp && console.log('SHOW_TCOM_FILTERS in uiReducer dispatched');
      return Object.assign({}, state, {
        mcomFiltersVisible: false,
        tcomFiltersVisible: !state.tcomFiltersVisible
      });
    case 'HIDE_FILTERS':
      debugPmp && console.log('HIDE_FILTERS in uiReducer dispatched');
      return Object.assign({}, state, {
        mcomFiltersVisible: false,
        tcomFiltersVisible: false
      });
    case 'CANCEL_FILTERS':
      debugPmp && console.log('CANCEL_FILTERS in uiReducer dispatched');

      return Object.assign({}, state, {
        mcomFiltersVisible: false,
        tcomFiltersVisible: false
      });
    case 'UPDATE_AVAILABLE_FILTERS': //dispatched when catalog updates
      return Object.assign({}, state, {
        mcomFiltersVisible: false,
        tcomFiltersVisible: false
      });
     case 'TOGGLE_TCOM_STORE_FILTERS':
      debugPmp && console.log('SHOW_TCOM_FILTERS in uiReducer dispatched');
      return Object.assign({}, state, {
        mcomFiltersVisible: false,
        tcomFiltersVisible: !state.tcomFiltersVisible,
        tcomStoreAvailability: true
      });

  }
  return state;
}

export default uiReducer;