import {combineReducers} from 'redux';
import catalogReducer from './catalog-reducer';
import appStateReducer from './app-state-reducer';
import filtersReducer from './filters-reducer';
import uiReducer from './ui-reducer';

const pmpReducer = combineReducers({
  catalogData: catalogReducer,
  appState: appStateReducer,
  filtersState: filtersReducer,
  uiState: uiReducer
});

export default pmpReducer;
