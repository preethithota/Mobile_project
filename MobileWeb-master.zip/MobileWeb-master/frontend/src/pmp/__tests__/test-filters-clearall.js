import * as filtersContainer from '../containers/filters-clearall';

describe('Test handleClearAll', () => {
    it('should remove filters and redirect to previous page', () => {
      let newURL = filtersContainer.clearAll("socks-hosiery-clothing.jsp?CN=4294719514+4294719810&searchTerm=Socks");
      expect(newURL).toEqual('socks-hosiery-clothing.jsp?searchTerm=Socks');
    });

    it('should do nothing', () => {
      let newURL = filtersContainer.clearAll("socks-hosiery-clothing.jsp?searchTerm=Socks");
      expect(newURL).toBeUndefined();
    });
});
