import * as moreLikeThisHelper from '../util/morelikethis-helper';

//const recsData = require('./recs-data.json');

describe('moreLikeThisHelper.getCurrentRecs', () => {
  let testProducts = [];

  for (let i = 0; i < 15; i++){
    testProducts.push('product ' + i);
  }

  it('should return the correct results given an offset', () => {
    let limit = 5, offset = 1;
    let currentRecs = moreLikeThisHelper.getCurrentRecs(testProducts, offset, limit);
    expect(currentRecs.length).toEqual(limit);
    expect(currentRecs[limit - 1]).toEqual('product 4');

    limit = 3;
    offset = 13;
    currentRecs = moreLikeThisHelper.getCurrentRecs(testProducts, offset, limit);
    expect(currentRecs[limit - 1]).toEqual('product 14');
    expect(currentRecs[0]).toEqual('product 12');
  });

  it('should handle limit > length', () => {
    let limit = 100, offset = 1;
    let currentRecs = moreLikeThisHelper.getCurrentRecs(testProducts, offset, limit);
    expect(currentRecs.length).toEqual(15);

    limit = 100;
    offset = 15;
    currentRecs = moreLikeThisHelper.getCurrentRecs(testProducts, offset, limit);

    expect(currentRecs.length).toEqual(1);
  });

  it('should handle offset < 1', () => {
    let limit = 5;
    let offset = -3;
    const currentRecs = moreLikeThisHelper.getCurrentRecs(testProducts, offset, limit);
    expect(currentRecs.length).toEqual(limit);
  });

});
