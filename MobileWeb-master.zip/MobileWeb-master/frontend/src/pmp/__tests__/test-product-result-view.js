import React from 'react';
import {shallow} from 'enzyme';
import ProductResultView from '../views/product-result-view';

const productData = require('./product-data.json');

describe('ProductResultView', () => {
  let productResulstView = shallow(
    <ProductResultView product={productData} serverRender={true} />
  );

  // it('has correct SEO url link', () => {
  //   let seoUrl = productResulstView.find('.productDtls').props().href;
  //   expect(seoUrl).toEqual(productData.seoURL);
  // });

  it('has correct ratings count', () => {
    let ratingCount = productResulstView.find('.avgCount').text();
    expect(ratingCount).toEqual('(' + productData.rating.count + ')');
  });

});
