import catalogReducer from '../reducers/catalog-reducer';

const testCatalogData = require('./catalog-data.json');
const testHookLogicData = require('./hookLogicData.json');

global.debugPmp = false;
global.kohlsData = {};
global.kohlsData.isTcom = false;

describe('catalogReducer', () => {
  it('should properly update catalogData', () => {
    const action = {type:'UPDATE_CATALOG_DATA', catalogData: testCatalogData}
    expect(catalogReducer({}, action)).toEqual(testCatalogData);
  });

  it('should properly update Hooklogic data', () => {
    const action = {type:'UPDATE_HOOKLOGIC_DATA', hookLogicData: testHookLogicData}
    const updatedState = catalogReducer({}, action);
    expect(updatedState.hookLogicData).toEqual(testHookLogicData);
  });

  it('if catalog data is preset, updating Hooklogic data should also update catalog data', () => {
    const action = {type:'UPDATE_HOOKLOGIC_DATA', hookLogicData: testHookLogicData};
    const updatedState = catalogReducer(testCatalogData, action);
    const updatedProducts = updatedState.products;
    expect(updatedProducts.length).toEqual(testCatalogData.products.length);
    // expect(updatedProducts.filter(product => product.webID === '123').length).toEqual(1);
    // expect(updatedProducts.filter(product => product.webID === '456').length).toEqual(1);
    // expect(updatedProducts.filter(product => product.webID === '789').length).toEqual(1);
  });

  // it('if Hooklogic data is preset, updating catalogData data should include Hooklogic products in product list', () => {
  //   const action = {type:'UPDATE_CATALOG_DATA', catalogData: testCatalogData};
  //   const currentState = {hookLogicData: testHookLogicData};
  //   const updatedState = catalogReducer(currentState, action);
  //   const updatedProducts = updatedState.products;
  //   expect(updatedProducts.length).toEqual(testCatalogData.products.length);
  //   expect(updatedProducts.filter(product => product.webID === '123').length).toEqual(1);
  //   expect(updatedProducts.filter(product => product.webID === '456').length).toEqual(1);
  //   expect(updatedProducts.filter(product => product.webID === '789').length).toEqual(1);
  // });
});
