import React from 'react';
import {mount} from 'enzyme';
import PmpView from '../views/pmp-view';
import intialUiState from '../reducers/ui-reducer';

describe('PmpView', () => {

  var catalogData = require('./catalog-data.json');
  const isTcom = true, serverRender = true;
  let pmpView = mount(
    <PmpView catalogData={catalogData} serverRender={serverRender} uiState={intialUiState} isTcom={isTcom}/>
  );

  it('contains #product-results', () => {
    expect(pmpView.find('#product-results').exists()).toBe(true);
  });

});
