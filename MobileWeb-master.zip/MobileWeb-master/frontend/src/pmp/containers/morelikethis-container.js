import React from 'react';
import * as moreLikeThisHelper from '../util/morelikethis-helper';
import PmpView from '../views/pmp-view';
import intialUiState from '../reducers/ui-reducer';
import * as utils from '../../global/utils';

export default class MoreLikeThisContainer extends React.Component{
  constructor(props){
    super(props);
    this.resultsPerPage = 24;
    this.state = {
      recsData: {}, //incoming data from recs call
      currentProducts: {}, //data
      offset: 1,
      showViewOptions: false,
      uiState: intialUiState
    };
	const newUiState =  Object.assign(this.state.uiState, {
      resultsViewType: "GRID"
    });
	this.setState({uiState: newUiState});
    this.updatePage = this.updatePage.bind(this);
    this.toggleViewOptions = this.toggleViewOptions.bind(this);
    this.setViewType = this.setViewType.bind(this);
  }

  componentDidMount(){
    moreLikeThisHelper.initRecs((data) => {
      const updatedProducts = moreLikeThisHelper.getCurrentRecs(data.products, 1, this.resultsPerPage);
      this.setState({
        recsData: data,
        currentProducts: updatedProducts
      });
    });
  }
  updatePage(e){
    e.preventDefault();
    var offset = e.target.dataset.offset;
    console.log('getting updatedProducts with offset: ' + offset);
    const updatedProducts = moreLikeThisHelper.getCurrentRecs(this.state.recsData.products, new Number(offset), this.resultsPerPage);
    this.setState({
      currentProducts: updatedProducts,
      offset: offset
    });
    utils.scrollTop();
  }

  toggleViewOptions(e){
    e.preventDefault();
    console.log('inside toggleViewOptions');
    const newShowViewOptions = !this.state.uiState.showViewOptions
    const newUiState =  Object.assign(this.state.uiState, {showViewOptions: newShowViewOptions});
    this.setState({uiState: newUiState});
  }

  setViewType(viewType){
    console.log('inside viewType: ' + viewType);
    const newUiState =  Object.assign(this.state.uiState, {
      resultsViewType: viewType,
      showViewOptions: false
    });
    this.setState({uiState: newUiState});
  }

  render(){
    const updatedCatalogData =  Object.assign({}, this.state.recsData, {
      products: this.state.currentProducts,
      offset: this.state.offset
    });

    return <div><PmpView
      {...this.props}
      {...this.state}
      catalogData={updatedCatalogData}
      isMoreLikeThis={true}
      updatePage={this.updatePage}
      toggleViewOptions={this.toggleViewOptions}
      setViewType={this.setViewType}
      /></div>
  }

}
