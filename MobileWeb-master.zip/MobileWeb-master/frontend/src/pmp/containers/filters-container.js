import React from 'react';
import {connect} from 'react-redux';
import * as utils from '../../global/utils';
import * as pmpHelper from '../util/pmp-helper';
import * as actions from '../actions/actions';
import * as clearFilters from './filters-clearall'
import McomFiltersView from '../views/filters-mcom-view';
import TcomFiltersView from '../views/filters-tcom-view';

const backendBaseDimensionsUrl = '/service/catalog/dimensions';

const FiltersContainer = React.createClass({

	componentDidMount: function(){
		const props = this.props;
		debugPmp && console.log('Inside FiltersContainer componentDidMount');
		let filtersResponse = utils.fetch(backendBaseDimensionsUrl + this.props.appState.currentQueryString);

		filtersResponse.done((filtersData) => {
			debugPmp && console.log('Received filters data:');
			props.updateAvailableFilters(filtersData, props.catalogData.activeDimensions, props.catalogData.sorts);
		});

		if(!document.getElementById("googlePlaces")) {
			window.initGoogleAutocomplete = function () {
          //autocomplete = new google.maps.places.Autocomplete(/** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),{types: ['geocode'], country: 'us'});
          //autocomplete.addListener('place_changed', findAddressComponents);
      };
			const clientKey = 'gme-kohlsdepartmentstores';
			var script = document.createElement('script');
			script.setAttribute("id", "googlePlaces");
			script.src = "https://maps.googleapis.com/maps/api/js?client="+ clientKey + "&libraries=places&callback=initGoogleAutocomplete";
	    	document.getElementsByTagName('head')[0].appendChild(script);
		}

    var myLocation = utils.getCookieValue('myLocation');
    var postalCode = (utils.checkEmptyString(myLocation)) ? JSON.parse(myLocation).zipCode.long_name : '';
    var geoip_lat = utils.getCookieValue('geoip_lat');
    var geoip_lng = utils.getCookieValue('geoip_lng');

		var bUseCurrentLocation = utils.checkEmptyString(postalCode) || (utils.checkEmptyString(geoip_lat) && utils.checkEmptyString(geoip_lng));
		var bUseMyStoreLocation = false;
		if(!bUseCurrentLocation) {
			let myStore = utils.getCookieValue("mystore");
			if(myStore) {
				bUseMyStoreLocation = true;
				myStore = JSON.parse(myStore);
				postalCode = myStore.zipcode;
			}
		}

      if(bUseCurrentLocation) {
      window.zipCode = postalCode;
      //this.props.setZipCode(postalCode);
    } else {
      window.zipCode = null;
    }
    /* When user comes from other pages
     *Check for user's location and call inventory service
     */
    if (bUseCurrentLocation || bUseMyStoreLocation) {
        //call inventory for
        this.props.updateAvailabilityList(postalCode, '', '', geoip_lat, geoip_lng, true);
    } else {
			let topStoresInfo = utils.getFromLocalStorage("topStoresInfo");
			if(topStoresInfo) {
				var stores = topStoresInfo.split(",");
				var storesList = [];
				var storesArray = [];
				var storeListSize = stores.length;
				for(var i = 0; i < stores.length; i++) {
					var storeNum = stores[i].split("|")[0];
					var storeName = stores[i].split("|")[1];
					storesList.push(storeNum);

					storesArray.push({"storeNum": storeNum, "storeName": storeName});
				}

				let stores = storesList.join();
				this.props.filtersState.storesArray = storesArray;
				this.props.filtersState.storeListSize = storeListSize;
				let activeDimensions = this.props.getActiveDimensions();
				$.ajax({
					url: '/api/v1/catalog/productCount/' + activeDimensions + '?storeNum=' + stores + "&keyword=" + window.catalogData.searchTerm,
					dataType: 'json',
					cache: true,
					context: this.props,
					success: this.props.availabilityCount
				});
			}
		}
	},
	unMountFilter:function(props){
		window.setTimeout(function(){
		var ele = document.querySelectorAll(".filter-content")[props.productPopup?0:1];
		ele && ele.classList.add("slide-filter");
		 },30);
		return <TcomFiltersView {...this.props}/>
	},
	render: function(){
		debugPmp && console.log('Rendering McomFiltersView');
	  return (
				<div>
	      {this.props.mcomFiltersVisible && <McomFiltersView {...this.props}/>}
				{this.unMountFilter(this.props)}
				</div>
	  );
	}
});

const mapStateToProps = function(store) {
  return {
    filtersState: store.filtersState,
		catalogData: store.catalogData,
    appState: store.appState
  };
}

const mapDispatchToProps = function(dispatch) {

  return {
		updateAvailableFilters: function(filtersData, activeDimensions, sorts){
			actions.updateAvailableFilters(dispatch, filtersData, activeDimensions, sorts);
		},
		handleCancelClick: function(){
			document.body.classList.remove("stop-scroll");
			actions.cancelFilters(dispatch);
		},
		handleMcomSortSelection: function(e, selectedSortOption) {
			let sortId = selectedSortOption.ID;
			let sorts = this.filtersState.sorts;
			if(!this.filtersState.previousSort) {
        this.filtersState.previousSort = JSON.parse(JSON.stringify(this.filtersState.sorts));
      }
			for(var i = 0; i < sorts.length; i++) {
				let sortOption = sorts[i];
				if(sortOption.ID == sortId) {
					sortOption.active = true;
					this.appState.showSort = false;
					//actions.selectGroup(dispatch, "SortBy", null);
					//sortOption.currentDimensionId = "S:" + sortOption.ID;
					this.handleFilterOptionClick(e, sortOption, "Sort By");
				} else {
					sortOption.active = false;
				}
			}

		},
		isLocationAvailable: function(){
            var locationasked = utils.getCookieValue('locationasked');
            let topStoresInfo = utils.getFromLocalStorage("topStoresInfo");
            if(locationasked) {
							let myLocation = utils.getCookieValue('myLocation');
					    let postalCode = (utils.checkEmptyString(myLocation)) ? JSON.parse(myLocation).zipCode.long_name : '';
							let autocomplete = document.getElementById("autocomplete");
							if(postalCode && autocomplete) {
								autocomplete.value = postalCode;
							}
						}
            if(kohlsData && kohlsData.isTcom === false) {
				!locationasked && !topStoresInfo && alert('Your location services are currently turned off. Please enable the location services and proceed');
			}
        },
		handleStoreSelection: function(e, store) {
			//store.active = true;
			actions.selectStore(dispatch, store);
			store.currentDimensionId = "S:" + store.storeNum;
			this.handleFilterOptionClick(e, store, "Store Avalibility");
		},

		showStoreFinder: function(e) {
			actions.showStoreFilter(dispatch);
		},
		closeSort: function(e) {
			//e.target.style.display = "none";
			//document.getElementById("sort-modal").style.display = "none";
			actions.closeSort(dispatch);
			this.appState.showSort = false;
			//this.updateAvailableFilters(this.filtersState.currentFilters, this.catalogData.activeDimensions, this.catalogData.sorts);
		},
		handleFilterGroupClick: function(e, dimensionName, filtersState, appState){
			e.preventDefault();
			var filterGroup = e.target;
			if(kohlsData && kohlsData.isTcom === false){

				while(!filterGroup.classList.contains("filter-group-container")) {
					filterGroup = filterGroup.parentNode;
					if(filterGroup.classList.contains('filter-sel'))
					{filterGroup.classList.remove('filter-sel');}
					else{filterGroup.classList.add('filter-sel');}
				}

				var filterGroups = document.querySelectorAll(".filter-group-container .filter-group-list");
				for(var i = 0; i < filterGroups.length; i++) {
					var group = filterGroups[i];
					group.classList.add("display-none");
				}


				filterGroup.childNodes[1].classList.remove("display-none");
				var filterList = document.getElementById("filter-list");
				filterList.scrollTop = filterGroup.offsetTop - filterList.offsetTop;
			}

			if(dimensionName.toLowerCase() == 'sortby') {
				this.appState.showSort = true;
			}

			if(dimensionName.toLowerCase() == 'instoreonline') {
				var autocomplete = document.querySelector("#autocomplete");
				if(autocomplete) {
					autocomplete.value = '';
				}
			}

			if(utils.areSortedArraysEqual(filtersState.selectedFilterIds, filtersState.appliedFilterIds)){
		    actions.selectGroup(dispatch, dimensionName, null);
			}else if(filtersState.bGetLatestFilters && dimensionName !="SortBy" && filtersState.selectedGroup != "SortBy"){
				utils.showLoader();
				const updatedCNValue = pmpHelper.getUpdatedCNValue(filtersState.selectedFilterIds);
				const updatedParams = [{CN: updatedCNValue}];


				let sorts = filtersState.sorts;
				let sortParam;
				for(var i = 0; i < sorts.length; i++) {
					let sortOption = sorts[i];
					if(sortOption.active) {
						sortParam = {"S":sortOption.ID};
						break;
					}
				}
				if(sortParam) {
					updatedParams.push(sortParam);
				}
				if(filtersState.availabilityList) {
					let storeid = "";
					/*for(let i = 0; i < filtersState.availabilityList.length; i++) {
						let store = filtersState.availabilityList[i];
						if(store.active) {
							storeid += store.storeNum + ",";
						}
					}*/
					storeid = filtersState.storeOrder.join(",");
					let storeTypes = "";
						//storeid = storeid.substring(0, storeid.length-1);
						updatedParams.push({"storeid": storeid});
						//storeTypes += "InStoreOnline:Pick%20Up%20in%20Store" + "+";

					if(storeTypes) {
						storeTypes = storeTypes.substring(0, storeTypes.length-1);
						//updatedParams.push({"N": storeTypes});
					}
				}

				const updatedAppState = pmpHelper.getUpdatedState(updatedParams, appState.currentState);
				const updatedQueryString = pmpHelper.getQSFromAppState(updatedAppState)

				//appState.currentState, updatedParams
				const filtersResponse = utils.fetch(backendBaseDimensionsUrl + updatedQueryString);
				filtersResponse.done(filtersData => {
					debugPmp && console.log('Received filters data');
					actions.selectGroup(dispatch, dimensionName, filtersData);
					utils.hideLoader();
				});


			} else {
				actions.selectGroup(dispatch, dimensionName, null);
			}

		},
		handleStoreTypeSelection: function(e) {
			var storeType = "InStoreOnline:Online%20Only";
			if(e.target.classList.contains("selected")) {
				e.target.classList.remove("selected");
				window.catalogData.storeTypes[storeType] = false;
			} else {
				e.target.classList.add("selected");
				window.catalogData.storeTypes[storeType] = true;
			}
		},
		handleDoneClick: function(filtersState, appState){
			document.body.classList.remove('stop-scroll');
			utils.showLoader();
			actions.hideFilters(dispatch);
			if(this.productPopup || this.storePopup) {
				this.eventHandle();
			}
			filtersState.previousSort = null;
			const updatedCNValue = pmpHelper.getUpdatedCNValue(filtersState.selectedFilterIds);

			const updatedParams = [{CN: updatedCNValue}, {WS: 1}];
			let sorts = filtersState.sorts;
			let sortParam;
			for(var i = 0; i < sorts.length; i++) {
				let sortOption = sorts[i];
				if(sortOption.active) {
					sortParam = {"S":sortOption.ID};
					break;
				}
			}
			if(sortParam) {
				updatedParams.push(sortParam);
			}
			if(filtersState.availabilityList) {
				let storeid = "";
				/*for(let i = 0; i < filtersState.availabilityList.length; i++) {
					let store = filtersState.availabilityList[i];
					if(store.active) {
						storeid += store.storeNum + ",";
					}
				}*/
				storeid = filtersState.storeOrder.join(",");
				let storeTypes = "";
				/*let myStore = utils.getCookieValue("mystore");
				myStore = myStore && JSON.parse(myStore);
				if(myStore && storeid.indexOf(myStore.id) == -1) {
				 //storeid += myStore.id + ",";
                 storeid += (storeid ? "," : "") + myStore.id;
                }*/

        //storeid = storeid.substring(0, storeid.length-1);
				updatedParams.push({"storeid": storeid});
				//storeTypes += "InStoreOnline:Pick%20Up%20in%20Store" + "+";

				if(storeTypes) {
					storeTypes = storeTypes.substring(0, storeTypes.length-1);
					//updatedParams.push({"N": storeTypes});
				}
			}

			const shouldRefreshFilters = true;
			updatedParams.push({fromMenu:""});
			pmpHelper.updateAppState(dispatch, appState.currentState, updatedParams, shouldRefreshFilters, appState.currentUriPath);
		},

		handleClearAll: function(filtersState, appState) {
			document.body.classList.remove('stop-scroll');
			if(filtersState && filtersState.isTcom && filtersState.selectedGroup) {
				for(let i = 0; i < filtersState.selectedFilterIds.length; i++) {
					let item = filtersState.selectedFilterIds[i];
					let arr = item.split(":");
					if(arr[0] == filtersState.selectedGroup) {
						filtersState.selectedFilterIds.splice(i, 1);
						i--;
					}
				}

				this.handleDoneClick(filtersState, appState);
			} else {
				let newURL = clearFilters.clearAll(window.location.href);
				let previousFilterURL = appState.menuFilterUrl;
				if(previousFilterURL) {
					newURL = previousFilterURL;
				}
				if(newURL) {
					let proceed = true;
					if(previousFilterURL && previousFilterURL.indexOf("?") != -1 &&
						 window.location.href.indexOf("?") != -1 &&
						 window.location.href.split("?")[1].indexOf(previousFilterURL.split("?")[1]) != -1) {
						proceed = false;
					}
					if(proceed) {
						location.href="#products-container";
						window.location.href = newURL;
					}
					return;
				} else {
					if(document.querySelector("#tcom-results-header #filter-content")) {
	          			window.filterButton.click();
						location.reload();
			        }
				}
				this.handleCancelClick();
			}
		},

		handleFilterOptionClick: function(e, selectedFilter, filterGroupLabel){
			if(e) {
				e.preventDefault();

				$(e.currentTarget).toggleClass("selected");
			}
			actions.selectFilter(dispatch, selectedFilter, filterGroupLabel);
		},

		/*showFindInStoreFilter: function(e, isTcom) {
			if(!isTcom) {
				this.appState.showStoreFilter = true;
				//this.availabilityList = [];
				//actions.showStoreFilter(dispatch, this);
				this.handleFilterOptionClick(e, {currentDimensionId: "Store:123"}, "Store Avalibility");
			}
		},*/

		findAddressComponents: function() {
			let that = this;
			window.findAddressComponents = function() {
				let place = window.autocomplete.getPlace();
				let addressComponent = {
	        street_number: 'short_name',
	        route: 'long_name',
	        locality: 'long_name',
	        administrative_area_level_1: 'short_name',
	        country: 'long_name',
	        postal_code: 'short_name'
	      };
				let selectedLoc = {};
				for (var i = 0; i < place.address_components.length; i++) {
					var addressType = place.address_components[i].types[0];
					if (addressComponent[addressType]) {
						selectedLoc[addressType] = place.address_components[i][addressComponent[addressType]];
					}
				}
				//window.fisSelectedLocation = selectedLoc;
				/**
				 * make inventory call and update availability list
				 */
				that.updateAvailabilityList(selectedLoc.postal_code, selectedLoc.locality, selectedLoc.administrative_area_level_1);
			};
		},

		updateAvailabilityList: function(postalCode, city, state, lat, lng, onLoad) {
			let radius = 50;
			let storeApi = "/api/v1/stores?radius=" + radius;
			let zip = postalCode ? "&postalCode=" + postalCode : "";
			let state_city = (city && state) ? "&city=" + city + "&state=" + state : "";
			const url = storeApi + (zip ? zip : state_city);
			let successCallback = function(data) {
				this.storeListCallback(data, onLoad);
			}
			$.ajax({
  			url: url,
  			dataType: 'json',
  			cache: true,
				context: this,
				success: successCallback
  		});
		},

		searchButtonClicked: function(e) {
			var searchText = e.target.parentNode.querySelector("#autocomplete").value;
			if(!searchText) {
				return true;
			}
			var isNum = /^\d+/.test(searchText);
			if(isNum) {// if all digitys entered
				this.updateAvailabilityList(searchText);
			} else if(searchText.indexOf(",") != -1) {
				var arr = searchText.split(",");
				this.updateAvailabilityList(null, arr[0], arr[1]);
			} else { // other case. show error msg
				this.updateAvailabilityList(null,searchText);
			}
		},

		getActiveDimensions: function() {
			//let activeDimensions = 'InStoreOnline%3APick%20Up%20in%20Store';
			let activeDimensions = '';
			/* InStoreOnline:Online Only+InStoreOnline:Pick Up in Store */
			for(var i=0; i < window.catalogData.activeDimensions.length; i++) {
				let activeDimension = window.catalogData.activeDimensions[i];
				for(var j=0; j < activeDimension.activeDimensionValues.length; j++) {
					let activeDimensionValue = activeDimension.activeDimensionValues[j];
					activeDimensions += activeDimensionValue.ID + '+';
				}
			}

			if(activeDimensions) {
				activeDimensions = activeDimensions.substring(0, activeDimensions.length - 1);
			}

			return activeDimensions;
		},

		storeListCallback: function(data, onLoad) {
			let storesArray;
			let activeDimensions = this.getActiveDimensions();
			let searchKey = window.catalogData.searchTerm ? "keyword=" +window.catalogData.searchTerm : "";

			let storesList = [];
			const myStoreCookie = $.cookie("mystore") && JSON.parse($.cookie("mystore"));
			let myStore = null;
			if(myStoreCookie) {
				myStore = {
					"storeName": myStoreCookie.name,
					"storeNum": myStoreCookie.storeNums,
					"myStore": true
				};
			}
			if(!data.payload) {
				if(myStoreCookie) {
					this.showErrorWithMyStore(myStoreCookie, myStore, activeDimensions, searchKey, false, true);
					return;
				}
				actions.updateStoreAvailability(dispatch, [], false, true);
				return;
			}
			let storeListSize = 5;
			let topStoresInfo = "";
			window.catalogData.stores = {};
			if (data.payload.stores.length > 0) {
				storesArray = data.payload.stores;
				let closeststore = JSON.parse(utils.getFromLocalStorage("closeststore"));

				if(closeststore) {
					closeststore.storeNum = closeststore.id;
					closeststore.storeName = closeststore.name;
					if(data.payload.stores.length > 0) {
							let bAddStore = true;
							for (let i=0 ;i < data.payload.stores.length && i < storeListSize; i++) {
								if(data.payload.stores[i].storeNum == closeststore.storeNum) {
									bAddStore = false;
									var a = data.payload.stores.splice(i,1);   // removes the item
									data.payload.stores.unshift(a[0]);
									break;
								}
							}
							if(bAddStore) {
								data.payload.stores.unshift(closeststore);
							}
					}
				}
				if(myStoreCookie) {
					if(data.payload.stores.length > 0) {
						let bAddMyStore = true;
						for (let i=0 ;i < data.payload.stores.length && i < storeListSize; i++) {
							if(data.payload.stores[i].storeNum == myStoreCookie.storeNums) {
								bAddMyStore = false;
								var a = data.payload.stores.splice(i,1);   // removes the item
								data.payload.stores.unshift(a[0]);
								break;
							}
						}
						if(bAddMyStore) {
							data.payload.stores.unshift(myStore);
						}
					}
				}
				for (let i=0 ;i < data.payload.stores.length && i < storeListSize; i++) {
					storesList.push(data.payload.stores[i].storeNum);
					topStoresInfo += data.payload.stores[i].storeNum + "|" + data.payload.stores[i].storeName + ",";
					window.catalogData.stores[data.payload.stores[i].storeNum] = false;
				}
				topStoresInfo = topStoresInfo.substring(0, topStoresInfo.length - 1);
			}
			utils.putInLocalStorage("topStoresInfo", topStoresInfo);
			if (storesList.length > 0) {

					let stores = storesList.join();
					this.filtersState.storesArray = storesArray;
					this.filtersState.storeListSize = storeListSize;
					$.ajax({
						url: '/api/v1/catalog/productCount/' + activeDimensions + '?storeNum=' + stores + "&" + searchKey,
						dataType: 'json',
						cache: true,
						context: this,
						success: this.availabilityCount
					});
			} else {
				if(myStoreCookie) {
					this.showErrorWithMyStore(myStoreCookie, myStore, activeDimensions, searchKey, !onLoad);
					return;
				}
				actions.updateStoreAvailability(dispatch, [], !onLoad);
			}
		},

		handleScroll: function(e) {

			if(!window.scrollTimeOut) {
				let target = e.target;
				let event = e;
				console.log("eventPhase: " + e.eventPhase);
				window.scrollTimeOut = setTimeout(function() {
					let currentScrollTop = document.getElementById("filter-list").scrollTop;
					if(!window.previousScrollTop) window.previousScrollTop = currentScrollTop;
					let eleAtTop = "eleAtTop";
					let previousEleAtTop = "previousEleAtTop";
					let scrollAdjust = 0;
					let direction = "";
					if(currentScrollTop >= window.previousScrollTop) {
						eleAtTop = "eleAtTop";
						previousEleAtTop = "previousEleAtTop";
						//scrollAdjust = 130;
						direction = "up";
					} else {
						direction = "down";
						/*if(previuosTopEle) {
							if(!window.previousEleTimeOut) {
								window.previousEleTimeOut = setTimeout(function() {
									window.previousEleTimeOut = null;
									previuosTopEle.classList.remove(previousEleAtTop);
								}, 500);
							}
						}*/
						//scrollAdjust = -70;
						/*eleAtTop = "previousEleAtTop";
						previousEleAtTop = "eleAtTop";
						scrollAdjust = -70;*/
					}
					window.previousScrollTop = currentScrollTop;
					window.scrollTimeOut = null;
					let element = document.elementFromPoint(25, 110 + scrollAdjust);
					let topEle = target.getElementsByClassName(eleAtTop)[0];
					//event.type;
					if(topEle) {
						scrollAdjust = 130;
						element = document.elementFromPoint(25, 110 + scrollAdjust);
					}
					if(element.classList.contains("filter-option")) {
						if(direction == "down") {
							if((element.offsetTop - element.parentNode.firstElementChild.offsetTop) < 88) {
								topEle && topEle.classList.remove(eleAtTop);
								return;
							}
						} else if(direction == "up") {
							if(topEle) {
								element = document.elementFromPoint(25, 110 + scrollAdjust - 55);
							} else {
								element = document.elementFromPoint(25, 110 + 50);
							}
							if((element.parentNode.lastElementChild.offsetTop - element.offsetTop) <= 49) {
								topEle && topEle.classList.remove(eleAtTop);
								return;
							}
						}
					}
					if(topEle) {
						//element = document.elementFromPoint(25, 110 + scrollAdjust);
						if(topEle.contains(element)) {
							return;
						} else {
							topEle.classList.remove(eleAtTop);
							//topEle.classList.add(previousEleAtTop);
						}
					}

					/*let previuosTopEle = target.getElementsByClassName(previousEleAtTop)[0];
					if(previuosTopEle) {
						if(previuosTopEle.contains(element)) {
							if(direction == "down") {
								previuosTopEle.classList.remove(previousEleAtTop);
							}
							return;
						}
					}*/

					if(element.getAttribute("id") == "filter-list") {
						return;
					}

					while(element.getAttribute("id") != "filter-list") {
						/*if(element.classList.contains("filter-group")) {
							return;
						}*/
						if(element.classList.contains("filter-group-container")) {
							break;
						}
						element = element.parentNode;
					}
					let filterGrp = element.getElementsByClassName("filter-group-list")[0];
					if(filterGrp.classList.contains("display-none")) {
						return;
					}
					element.classList.add(eleAtTop);
					/*if(previuosTopEle) {
						previuosTopEle.classList.remove(previousEleAtTop);
					}*/
				}, 500);
			}
		},

		showErrorWithMyStore: function(myStoreCookie, myStore, activeDimensions, searchKey, noStores, inValidEntry) {
			var storeArr = [];
			if(myStoreCookie) {
				for (let i=0 ;i < this.filtersState.availabilityList.length; i++) {
					if(this.filtersState.availabilityList[i].storeNum == myStoreCookie.storeNums) {
						storeArr.push(this.filtersState.availabilityList[i]);
						break;
					}
				}
				if(storeArr.length == 0) {
					storeArr.push(myStore);
				}
				this.filtersState.storesArray = storeArr;
				this.filtersState.storeListSize = 1;
				let callback = function(noStores, inValidEntry) {
					return function(data, successStr, obj) {
						this.availabilityCount(data, successStr, obj, noStores, inValidEntry);
					};
				}(noStores, inValidEntry);
				$.ajax({
					url: '/api/v1/catalog/productCount/' + activeDimensions + '?storeNum=' + storeArr[0].storeNum + "&" + searchKey,
					dataType: 'json',
					cache: true,
					context: this,
					success: callback
				});
			}
		},

		availabilityCount: function(data, successStr, obj, noStores, inValidEntry) {
			let availabilityList = [];
			let storesArray = this.filtersState.storesArray;
			this.appState.showStoreList = true;

			const match = /storeid=[^&]+/.exec(location.search);
			let storeids = [];
			if(match) {
				var stores = match.toString().split('=')[1];
				storeids = stores.split(",");
			}

			if(!data.payload) {
				utils.putInLocalStorage("topStoresInfo", "");
				return;
			}

			for(var i=0; i < storesArray.length && i < this.filtersState.storeListSize; i++) {
				for(var j=0; j < data.payload.stores.length; j++) {
					if(storesArray[i].storeNum == data.payload.stores[j].storeNum) {
						storesArray[i].availableProductCount = data.payload.stores[j].availableProductCount;
						if(storeids.indexOf(storesArray[i].storeNum) != -1) {
							storesArray[i].active = true;
						}
					}
				}

				availabilityList.push(storesArray[i]);
			}
			actions.updateStoreAvailability(dispatch, availabilityList, noStores, inValidEntry);
		},

		isDimensionSelected: function(dimensionValue, selectedFilterIds){
			return selectedFilterIds.indexOf(dimensionValue.currentDimensionId) > -1;
		}
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(FiltersContainer);
