import React from 'react';
import {connect} from 'react-redux';
import PmpView from '../views/pmp-view';
import * as utils from '../../global/utils';
import * as actions from '../actions/actions';
//import * as googleAd from '../../../public/lib/googleAd';
import * as googleAd from '../../monetization/googleAd';
import * as pmpHelper from '../util/pmp-helper';
import * as smsHelper from '../../shopMyStore/shopmystore-helper';

const PmpContainer = React.createClass({

  componentDidMount: function(){
    if (!this.props.serverRender){
      	googleAd.initGOOGLE_ADSENSE();
	    if(window.kohlsData["isMCOMHooklogic"] || (window.kohlsData["isTCOMHooklogic"] && kohlsData.isTcom)){
	        this.props.updateHooklogicData(this.props.catalogData);
		}
    }
  },

  render: function(){
    // The ... spread operator (...this.props) passes all of the props from this
    // container to the PmpView component.  So for example this.props.handleCatalogLinkClick
    // which is defined in this container will also be available in pmp-view
    return (
        <PmpView {...this.props} />
    );
  }
});

// mapStateToProps binds the Redux store state to this component's props
// store.catalogData is managed in catalog-reducer and
// store.appState is managed in app-state-reducer
// for example state.shouldRefreshFilters which is set in the app-state-reducer
// is now available to this component (and pmp-view) via props.appState.shouldRefreshFilters
const mapStateToProps = function(store) {
  return {
    catalogData: store.catalogData,
    appState: store.appState,
    uiState: store.uiState,
  };
}

// mapDispatchToProps binds the defined dispatch functions to the props
// so for example this.props.updateCatalog will be available to this container
// and the view (pmp-view).  These functions will have access to the Redux store's
// dispatch function to send events/data to the store
const mapDispatchToProps = function(dispatch, ownProps) {
  return {

    updateAvailableFilters: function(filtersData, activeDimensions, sorts){
      actions.updateAvailableFilters(dispatch, filtersData, activeDimensions, sorts);
    },

    updateHooklogicData: function(catalogData){
      pmpHelper.updateHooklogicData(dispatch,catalogData);
    },

    handleSortSelection: function(e, appState){
      console.log('sort selection');
      utils.showLoader();
      var sortValue = e.target.value;
      //actions.updateAppStateFromParams(dispatch, [{S: sortValue}], false);
      pmpHelper.updateAppState(dispatch, appState.currentState, [{S: sortValue}], false, appState.currentUriPath);
    },
    //
    // handleCatalogLinkClick: function(e){
  	// 	e.preventDefault();
    //   utils.showLoader();
  	// 	var uri = e.currentTarget.href;
    //   actions.updateAppStateFromUri(dispatch, uri);
  	// },
	updatePage: function(e, appState){
		e.preventDefault();
		utils.showLoader();
		var offset = e.target.dataset.offset;
		if(offset){
			const updatedParams = [{WS: offset}];
			const shouldRefreshFilters = false;
			pmpHelper.updateAppState(dispatch, appState.currentState, updatedParams, shouldRefreshFilters, appState.currentUriPath);
		}
	},
    showMcomFilters: function(e){
      if(document.body.classList.contains("stop-scroll")) {
        document.body.classList.remove('stop-scroll');
      } else {
        document.body.classList.add('stop-scroll');
      }
      e.preventDefault();
      if (kohlsData.isTcom){
        document.body.classList.add("stop-scroll");
      }
      dispatch({
        type: 'SHOW_MCOM_FILTERS'
      });
    },
    toggleTcomFilters: function(e){
      if(document.body.classList.contains("stop-scroll")) {
        document.body.classList.remove('stop-scroll');
      } else {
        document.body.classList.add('stop-scroll');
      }
      e.preventDefault();
      dispatch({
        type: 'TOGGLE_TCOM_FILTERS'
      });
    },
    toggleTcomStoreFilters: function(e) {
      e.preventDefault();
      dispatch({
        type: 'TOGGLE_TCOM_STORE_FILTERS'
      });
    },
    toggleViewOptions: function(e){
      e.preventDefault();
      dispatch({
        type: 'TOGGLE_VIEW_OPTIONS'
      });
    },
    setViewType: function(viewType){
      dispatch({
        type: 'SET_VIEW_TYPE',
        viewType
      });
    },
    pmpSetMystore : function(e) {var returnUrl = smsHelper.getUpdatedUrl();
      location.href = "/stores/search.m.shtml?returnUrl=" + encodeURIComponent(returnUrl);
    },
    pmpBrowseMystore : function(e) {
      if (e.target.className.indexOf("active") != -1) {
        return false;
      }
      let myStore = utils.getCookieValue("mystore");
      myStore = myStore ? JSON.parse(myStore) : "";
      let url = smsHelper.getUpdatedUrl();
      url = utils.getUrlParam("navFromBopusstore",location.href) ? url : (url + (url.indexOf("?") === -1 ? "?" : "&") + "navFromBopusstore=true");
      //location.href = url + "&storeid=" + myStore.id + "&CN=InStoreOnline:Pick%20Up%20in%20Store";
      let cnParam = utils.getUrlParam("CN", url);
      if(cnParam) {
         let cnValue = url.split("CN=")[1];
         let urlArr = [];
         urlArr.push(url.split("CN=")[0]);
         urlArr.push("CN=");
         if(cnValue.split("&")[0].indexOf("InStoreOnline") == -1) {
           urlArr.push(cnValue.split("&")[0] + "+InStoreOnline:Pick%20Up%20in%20Store");
         } else {
           urlArr.push(cnValue.split("&")[0]);
         }
         if(cnValue.split("&").length == 2) {
           urlArr.push("&" + cnValue.split("&")[1]);
         }
         url = "";
        for(let i = 0; i < urlArr.length; i++) {
           url += urlArr[i];
         }
       } else {
         url += "&CN=InStoreOnline:Pick%20Up%20in%20Store";
       }
       location.href = url + "&storeid=" + myStore.id;
    },
    undoMystore : function(e) {
      if (e.target.className.indexOf("active") != -1) {
        return false;
      }
      let newUrl = location.href;
      newUrl= newUrl.replace('&CN=InStoreOnline:Pick%20Up%20in%20Store', '')
      newUrl = smsHelper.removeParameterFromUrl(newUrl, "storeid");
      newUrl = utils.getUrlParam("navFromBopusstore",location.href) ? newUrl : (newUrl + (newUrl.indexOf("?") === -1 ? "?" : "&") + "navFromBopusstore=true");
      location.href = newUrl;
    }

  }
}

// The Redux connect function wires up this container and makes the data/functions
// defined in mapStateToProps and mapDispatchToProps available to the props
export default connect(mapStateToProps, mapDispatchToProps)(PmpContainer);
