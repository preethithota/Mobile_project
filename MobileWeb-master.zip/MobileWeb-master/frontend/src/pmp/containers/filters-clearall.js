export function clearAll(url) {
  var urlArr = url.split("?");
  if(urlArr.length == 2) {
    var params = urlArr[1].split("&");
    var removeFilter = false;
    var filterParamIndex = -1;
    for(var i = 0; i < params.length; i++) {
      var param = params[i];
      var paramArr = param.split("=");
      if(paramArr.length == 2) {
        if(paramArr[0].toLowerCase() == "cn" || paramArr[0].toLowerCase() == "storeid" || paramArr[0].toLowerCase() == "s") {
          params.splice(i, 1);
          i--;
          removeFilter = true;
        }
      }
    }
    if(removeFilter) {
      return urlArr[0] + "?" + params.join("&");
    }
  }
}
