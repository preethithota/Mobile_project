import MoreLikeThisContainer from './containers/morelikethis-container';

ReactDOM.render((
  <div><MoreLikeThisContainer serverRender={false} isTcom={kohlsData.isTcom}/></div>
), document.getElementById('main-content'));
