import React from 'react';
import {connect} from 'react-redux';
import * as utils from '../../global/utils';
import ProductResultView from './product-result-view';
import {labels} from '../../global/label-utils';
import * as smsHelper from '../../shopMyStore/shopmystore-helper';

function storeFilterButton(el) {
  window.filterButton = el;
}

function storeAvailabilityFilterButton(el) {
  window.availabilityFilterButton = el;
}

export default React.createClass({

  getInitialState: function(){
    return {
      shouldLoadFilters: false,
      filterProduct:false,
      stroreAvailability:false
    }
  },

  componentDidMount: function(){
    if (this.props.serverRender === false && !this.props.isMoreLikeThis){ //filters only loaded from the browser
      require.ensure(['../containers/filters-container.js'], () => {
        this.filterContainer = require('../containers/filters-container.js').default;
        this.setState({shouldLoadFilters: true});
      });
    }

  },
  filterProductPopup: function(obj) {
    obj.setState({filterProduct: !obj.state.filterProduct, storeAvailability:false});
  },
  filterPopup: function(obj,flag){
    if(flag) {
      if(obj.state.filterProduct) {
         var ele = document.querySelectorAll(".filter-content")[0];
        if(ele) {
          document.body.classList.remove("stop-scroll");
          ele.classList.remove("slide-filter");
        }
        window.setTimeout(function(){
          obj.filterProductPopup(obj,flag);
         },250);
      } else {
        document.body.classList.add("stop-scroll");
        obj.filterProductPopup(obj,flag);
      }
    } else {
      document.body.classList.remove("stop-scroll");
      obj.setState({storeAvailability:!obj.state.storeAvailability, filterProduct:false});
    }
  },

  filterContainer: {},//this will be defined asynchronously

  getTileImageUrl: function(url){
    // Fixing the size for Visual Nav title to 130 for Image Quality
    var imgSize = '130';
    return utils.getImageUrl(url, imgSize);
  },
  render: function() {
    const FilterContainer = this.filterContainer;

    const props = this.props;
    const viewType = props.uiState.resultsViewType;
    const viewToggleContClass = (props.isTcom ? 't-grid-view' : (viewType === 'LIST' ? 'm-list-view' : 'm-grid-view'));
    const viewSelList = (viewType === 'LIST' ? 'selected' : '');
    const viewSelGrid = (viewType === 'GRID' ? 'selected' : '');
    const catalogData = props.catalogData;
    const products = catalogData.products;
    const catalogDataText = (props.serverRender) ? JSON.stringify(catalogData) : "";
    const offset = catalogData.offset;
    const limit = catalogData.limit;
    let prevOffset = 1, nextOffset = parseInt(offset) + limit, showPrev = false, showNext = true;
    const dimensions = catalogData.dimensions;
    let isStoreAvailable;
    const visualNavAlignment = (catalogData.visualNavTiles && catalogData.visualNavTiles.visualNavTile && catalogData.visualNavTiles.visualNavTile.length == 1) ? 'visual-nav-tile visual-nav-tile-single' : 'visual-nav-tile';
    const visualNavClass = (catalogData.visualNavTiles && catalogData.visualNavTiles.visualNavTile && catalogData.visualNavTiles.visualNavTile.length == 2) ? 'visual-nav-centre-align' : '';
    let tab1_active = "";
    let tab2_active = "";
    let myStore = (props.serverRender) ? '' : utils.getCookieValue("mystore");
    const qsStoreId =  (props.serverRender) ? '' : utils.getUrlParam("storeid",location.href);
    const freePickup = (utils.getUrlParam("CN",location.href)=="InStoreOnline:Pick Up in Store") ?  labels.freePickupLabel : '';
    myStore = myStore ? JSON.parse(myStore) : "";
    if (myStore && (myStore.id == qsStoreId)) {
      tab2_active = "active";
      //utils.putInLocalStorage("ssFilter", myStore.name + "|" + myStore.id);
    } else {
      tab1_active = "active";
    }
    let setStoreMarkUp = (myStore) ? (<div id="myStoreTab" className={`myStorePMP ${tab2_active}`} onClick={(e) => props.pmpBrowseMystore(e)}><span className="starIcon"></span>Shop My Store </div>) : (<div id="setMyStoreTab" className="myStorePMP" onClick={(e) => props.pmpSetMystore(e)}><span className="starIcon"></span>Shop My Store</div>);
    let shopStoreMarkup = (
      <div className="setMyStoreTabs mcom-only">
        <div id="defultPMPTab" className={`defaultPMP ${tab1_active}`} onClick={(e) => props.undoMystore(e)}>Shop Kohls.com</div>
        {setStoreMarkUp}
      </div>
    )

    if (offset > 1) showPrev = true;
    if (offset > (limit + 1)) prevOffset = offset - limit;
    if (nextOffset > catalogData.count) showNext = false;
    var pageNum = offset && Math.ceil((parseInt(offset)+23) / 24);
    var totalPages = catalogData.count && Math.ceil(parseInt(catalogData.count) / 24);

    // const pageItems = <div id="page-items">{labels.viewTxt} {labels.pageTxt} {pageNum} {labels.ofTxt} {totalPages}</div>
    // const previousBtn = (showPrev) ? (<a href="#" data-offset={prevOffset} >Previous</a>) : '';
    // const nextBtn = (showNext) ? (<a href="#" data-offset={nextOffset} >Next ({nextOffset}-{(nextOffset + limit -1) > catalogData.count ? catalogData.count : (nextOffset + limit -1)})</a>) : '';


  const pageItems = props.isTcom ? (
    <div id="page-items">{labels.viewTxt} {labels.pageTxt} {pageNum} {labels.ofTxt} {totalPages}</div>
  ) : (
    <div id="page-items" onClick={(e) => props.updatePage(e, props.appState)}>
      <a className={"nav-arrow" + (showPrev ? '' : ' disabled')} data-offset={(showPrev ? prevOffset : "")} href="#">&lt;</a>
      <span className="nav-label">{pageNum} {labels.ofTxt} {totalPages}</span>
      {(showNext) ? <a className="nav-arrow" href="#" data-offset={nextOffset} >&gt;</a> : ""}
    </div>
  );

    const previousBtn = (showPrev) ? (<a href="#" data-offset={prevOffset} >Previous</a>) : '';
    const nextBtn = (showNext) ? (<a href="#" data-offset={nextOffset} >Next ({nextOffset}-{(nextOffset + limit -1) > catalogData.count ? catalogData.count : (nextOffset + limit -1)})</a>) : '';


    let sortDefaultValue = '0';
    if (catalogData.sorts){
      for (var i = 0; i < catalogData.sorts.length; i++){
        if (catalogData.sorts[i].active){
          sortDefaultValue = catalogData.sorts[i].ID
        }
      }
    }

    let visualNavTilesMarkup;
    if (catalogData.visualNavTiles){
      visualNavTilesMarkup = (
        <div id="visual-nav-section">

            <div id="category-title" dangerouslySetInnerHTML={{__html: catalogData.visualNavTiles.visualNavTitle}}/>
            <div id="visual-nav-tiles" className={visualNavClass}>
            {catalogData.visualNavTiles.visualNavTile.map((tile, index) => {
              let inx = {index};
        if (inx.index < 5) {
          return (
          <div className={visualNavAlignment} key={index}>
          {/*TODO: have this link update the app state*/}
            <a href={tile.navLink+(qsStoreId ? '&storeid='+qsStoreId : '')+"&VisualNavFrom="+(utils.getUrlParam("search-redirect", location.href) ? "search redirect visual nav" : utils.getUrlParam("isFromSearch", location.href) ? "search visual nav" : utils.getUrlParam("fromMenu", location.href) ? "browse visual nav" : "")} title={tile.navLabel} alt={tile.navLabel}>
            <img src={this.getTileImageUrl(tile.imageUrl)} />
            <div className="visual-nav-label">{tile.navLabel}</div>
            </a>
          </div>
          )
        }
            })}
          </div>
        </div>
      )
    }

  /* let topStoresInfo = utils.getFromLocalStorage("topStoresInfo");
    var storeObjs = {};
    if(topStoresInfo) {
      var stores = topStoresInfo.split(",");
      for(var i = 0; i < stores.length; i++) {
        var storeNum = stores[i].split("|")[0];
        var storeName = stores[i].split("|")[1];
        storeObjs[storeNum] = storeName;
      }
    }

    const match = /storeid=[^&]+/.exec(location.search);
    let selectedStores = [];
    if(match) {
      selectedStores = match.toString().split("=")[1].split(",");
    }*/

    let activeDimensionsMarkup;
    let activeDimensionsButtons = [];
    let activeDimensionsNames = [];
    let activeStores = [];
    let topStoreArr = {};
    let topStoresInfo = (this.props.serverRender) ? [] : utils.getFromLocalStorage("topStoresInfo") && utils.getFromLocalStorage("topStoresInfo").split(',');
    let mystore = utils.getCookieValue("mystore");
    mystore = mystore && JSON.parse(mystore);
   /* for(var i = 0; i < selectedStores.length; i++) {
      var storeid = selectedStores[i];
      var name = storeObjs[storeid];
      var url = location.href;
      var replaceStr = "S:" + storeid;
      if(selectedStores.length != 1) {

        if(i != selectedStores.length - 1) {
          replaceStr += "+";
        } else {
          replaceStr = "+" + replaceStr;
        }
      }
      url = url.replace(replaceStr, "");

      replaceStr = storeid;
      if(selectedStores.length != 1) {
        if(i != selectedStores.length - 1) {
          replaceStr += ",";
        } else {
          replaceStr = "," + replaceStr;
        }
      }
      url = url.replace(replaceStr, "");

      activeDimensionsButtons.push({
        seoURL: url,
        name: name
      });
    } */

    catalogData.activeDimensions && catalogData.activeDimensions.map(function(activeDimension){
      activeDimension.activeDimensionValues.map(function(activeDimensionValue){
         if(activeDimensionValue.name == "Pick Up in Store") {
          return false;
        }
        var dimensionId = activeDimensionValue.ID;

        if (activeDimensionsNames.indexOf(activeDimensionValue.name) >  -1){
          return;
        }
        activeDimensionsNames.push(activeDimensionValue.name);

        activeDimensionsButtons.push({
          ID: dimensionId,
          seoURL: activeDimensionValue.seoURL,
          name: activeDimensionValue.name
        });
      });
    });

    if(catalogData.activeStores) {

      topStoresInfo && topStoresInfo.map((store) => {
      let storeSplit = store.split("|");
      topStoreArr[storeSplit[0]] = storeSplit[1];
      });
      mystore && (topStoreArr[mystore.id] = mystore.name);
      let seoUrlStores = (props.serverRender) ? [] : utils.getUrlParam("storeid",location.href).split(',');
      activeDimensionsButtons.map((activeDimensionsButton) =>{
        activeDimensionsButton.seoURL += "&storeid=" + seoUrlStores.join();
      });
      let seoUrl = (props.serverRender) ? '' : smsHelper.removeParameterFromUrl(location.href, "storeid");
      catalogData.activeStores.map((store) =>{
        let storeName = topStoreArr[store.storeNum];
        let storeId = store.storeNum;
        let stores = seoUrlStores.slice();
        const index = stores.indexOf(store.storeNum);
        if (index > -1) {
          stores.splice(index, 1);
        }
        activeDimensionsButtons.push({
          ID: storeId,
          seoURL: seoUrl /*+ ( stores.length ? "&storeid=" + stores.join(",") : "")*/,
          name: storeName
        });
      });
    }

    if (activeDimensionsButtons && activeDimensionsButtons.length > 0){
      activeDimensionsMarkup = (
        <div id="active-dimensions">
          {activeDimensionsButtons.map((activeDimensionValue, index) => {
            return (
              <div key={index}>
                {/*TODO: add back in onClick={props.handleCatalogLinkClick}*/}
                <a href={activeDimensionValue.seoURL} className="active-dimension" >{activeDimensionValue.name}</a>
              </div>
            );
          })}
        </div>
      )
    }else{
      activeDimensionsMarkup = (<div id="active-dimensions"></div>);
    }

    let resultsPaddingArr = [null, null, null, null];
    var h1Title = (catalogData.searchTerm) ? catalogData.searchTerm : ((catalogData.h1Tag) ? catalogData.h1Tag: freePickup);

    let moreLikeThisProductImage;
    if (catalogData.moreLikeThisProduct){
      const moreLikeThisProduct = catalogData.moreLikeThisProduct;
      moreLikeThisProductImage = (moreLikeThisProduct.images && moreLikeThisProduct.images.length > 0) ? moreLikeThisProduct.images[0] : {};
    }
  if(dimensions && dimensions.length > 0) {
    for (var i = 0; i < dimensions.length; i++) {
      if (dimensions[i].name == "InStoreOnline") {
      isStoreAvailable = true;
      break;
      }
    }
  }

  // if(this.props.catalogData.products.length > 24){
  //  //return (null);
  //
  //  console.log(this.props.catalogData.products)
  // }

    return (
      <div id="products-container"
      className={viewToggleContClass}>
        {catalogData.count>0 && !this.props.isMoreLikeThis && shopStoreMarkup}
    {catalogData.count>0 &&
        <div id="mcom-filter-header" className={"mcom-only " +  (this.props.isMoreLikeThis ? 'more-like-this' : '')}>
      {!this.props.isMoreLikeThis ?
          (<div className="current-dimension">
          <h1 className="h1width">{h1Title}</h1>&nbsp;
          <span className="category-count">({catalogData.count})</span>
          </div>) :
      (<div className="current-dimension">
          <h1 className="h1widthauto">{h1Title}</h1>&nbsp;
          </div>)
      }

          <div className="filter-links">
            <a href="#" onClick={this.props.toggleViewOptions}>VIEW</a>
            <div id="filter-view-options" className={this.props.uiState.showViewOptions ? '' : 'display-none'}>
              <span className={`list-view ${viewSelList}`}
               onClick={() => props.setViewType('LIST')}></span>
               <span className="seprator">|</span>
              <span className={`grid-view ${viewSelGrid}`}
              onClick={() => props.setViewType('GRID')}></span>
            </div>
            {!this.props.isMoreLikeThis && <a href="#" onClick={this.props.showMcomFilters}>SORT & FILTER</a>}
            <div id="mcom-filters-container">
              {this.state.shouldLoadFilters && !this.props.isMoreLikeThis &&
              <FilterContainer mcomFiltersVisible={props.uiState.mcomFiltersVisible}
              tcomFiltersVisible={props.uiState.tcomFiltersVisible} count={catalogData.count}
              isTcom={props.isTcom}/>}
            </div>
          </div>

        </div>
     }
     { 
    products && products.length > 0 ? (
      <div id="tcom-results-header" className="tcom-only-block">
        <div id="filters-section">
          <div id="filters">
            <div className="filter-btn">
              <a href="#" ref={storeFilterButton} onClick={()=>this.filterPopup(this,true)}>FILTER PRODUCTS</a>
            </div>
            {this.state.shouldLoadFilters && this.state.filterProduct &&
            <FilterContainer productPopup={this.state.filterProduct} eventHandle={()=>this.filterProductPopup(this)} mcomFiltersVisible={props.uiState.mcomFiltersVisible}
            tcomFiltersVisible={props.uiState.tcomFiltersVisible} count={catalogData.count} isTcom={props.isTcom}/>}
          </div>
          <div id="filters-store">
            <div className="filter-btn store-filter">
              <a href="#" ref={storeAvailabilityFilterButton} onClick={()=>this.filterPopup(this,false)}>STORE AVAILABILITY</a>
            </div>
            {this.state.shouldLoadFilters && this.state.storeAvailability &&
            <FilterContainer storePopup={this.state.storeAvailability} eventHandle={()=>this.filterPopup(this,false)} mcomFiltersVisible={props.uiState.mcomFiltersVisible}
            tcomFiltersVisible={props.uiState.tcomFiltersVisible} count={catalogData.count} isTcom={props.isTcom} tcomStoreAvailability={props.uiState.tcomStoreAvailability}/>}
          </div>
        </div>
        {isStoreAvailable && <div id="t-store-availability" className="filter-btn" >{labels.storeAvailabilityTxt}</div>}
        <div id="t-breadCrumbTxt"><a href="javascript:history.go(-1)" className="t-breadCrumbLeftArrow"></a>{h1Title}</div>
        <span className="t-paginationTxt">{labels.viewTxt} {offset}-{nextOffset-1 > catalogData.count ? catalogData.count : nextOffset-1} {labels.ofTxt} {catalogData.count}</span>

        <div id="sort-options">
          <select defaultValue={sortDefaultValue} onChange={(e) => props.handleSortSelection(e, props.appState)}>
            <option value="0" disabled>SORT BY</option>
              {catalogData.sorts && catalogData.sorts.map(function(sort) {
                return (
                <option key={sort.ID} value={sort.ID}>
                  {sort.name}
                </option>
                )
              })}
          </select>
        </div>
      </div> ) : ''
    }
    {this.props.isMoreLikeThis && catalogData.moreLikeThisProduct && catalogData.moreLikeThisProduct.productTitle &&
        <div id="more-like-this-product" className="mcom-only">
          <a href={catalogData.moreLikeThisProduct.seoURL}>
            <div className="mlt-img">
              <img src={utils.getImageUrl(moreLikeThisProductImage.url, 55, false)} />
            </div>
            <div className="mlt-description">
              <div className="mlt-similar-to">Items similar to:</div>
              <div className="mlt-product-title" dangerouslySetInnerHTML={{__html: catalogData.moreLikeThisProduct.productTitle}} />
            </div>
          </a>
        </div>/*end more-like-this-product*/}
        {catalogData.count>0 && activeDimensionsMarkup}
        {catalogData.count>0 && catalogData.visualNavTiles && visualNavTilesMarkup}
    {
      products && products.length > 0 ? (
        <div id="pmp-results-available">
          <div id="product-results" className="product-results">
            {products.map((product, index) => {
        return <ProductResultView key={index} product={product} serverRender={props.serverRender} isTcom={props.isTcom}/>;
            })}

            {resultsPaddingArr.map(function(val, index){
              return <div className="product-result" key={index}></div>;
            })}
          </div>

      <div className={"pmp-footer" + (props.isTcom ? ' tcom-block' : '')}>
        <div className={`tcom-only-block t-footer-pagination`}><a href="javascript:history.go(-1)" className="t-breadCrumbLeftArrow"></a>{h1Title}</div>

        {pageItems}

        {props.isTcom && (
          <div id="nav-buttons" onClick={(e) => props.updatePage(e, props.appState)}>
            {previousBtn}
            {nextBtn}
          </div>
        )}
      </div>
        </div>
      ) : (!this.props.isMoreLikeThis &&
        <div>
          <div className={`search-noproducts mcom-only`}>
            <div id="noProductsText" >
              <div className="magifier_img"></div>
              <div className="zero-seach-txt">{labels.sorryNoResultsTxt}</div>
              <div className="zero-seach-txt">"{h1Title}"</div>
            </div>
            <div className={props.isTcom ? "":"product-results"}></div>
            <div id="recommendationsMcom"></div>
            <div className="ZeroSearchRecommendationsMcom"></div>



          </div>
          <div className={`t-noProductsBlock tcom-only-block`}>
              <div className="magifier_img"></div>
              <div className="zero-seach-txt">{labels.sorryNoResultsTxt} "{h1Title}"</div>

          <div className={props.isTcom ? "product-results":""}></div>
          </div>
          <div id="recommendationsTcom" className="ppRecommendationsTcom ZeroSearchRecommendationsTcom"></div>


        </div>
      )

    }

      </div>
    );
  }
});
