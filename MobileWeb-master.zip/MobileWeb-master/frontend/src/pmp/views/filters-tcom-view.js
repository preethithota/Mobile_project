import {findInArray} from '../../global/utils';
import StoreSearchView from './filters-store-area-search';

export default React.createClass({
  
  render: function(){
		debugPmp && console.log('inside filters-tcom-view render');
    const props = this.props;
    const filtersState = props.filtersState;
		const dimensions = filtersState.currentFilters;
    const dimensionListDivId = 'dimension-list';
		let backLinkMarkup, listMarkup, clearLabel;
    let h1Title = (catalogData.searchTerm) ? catalogData.searchTerm : ((catalogData.h1Tag) ? catalogData.h1Tag: '');

    if (filtersState.selectedGroup){
      clearLabel = "CLEAR";
      backLinkMarkup = <a href="#" onClick={(e) => props.handleFilterGroupClick(e, '', filtersState, props.appState)}>&lt; Back</a>;

      let selectedDimension = findInArray(dimensions, (dimension) => {
        return (dimension.name === filtersState.selectedGroup);
      });
   let scrollClass = "";
      if(selectedDimension) {
        let length = selectedDimension.dimensionValues.length;
        scrollClass = (length > 40 ? "scroll" : "");
      }

      listMarkup = <ul id={dimensionListDivId} className={scrollClass}>
        <li className="filters-header">Filter by {filtersState.selectedGroup}</li>
      {selectedDimension && selectedDimension.dimensionValues.map((dimensionValue, index) => {
        return (
          <li key={index} onClick={(e) => {props.handleFilterOptionClick(e, dimensionValue, selectedDimension.label)}} className={props.isDimensionSelected(dimensionValue, props.filtersState.selectedFilterIds) ? 'selected' : ''}>
            <a href="#">
            <span className="color-box" style={{backgroundColor:dimensionValue.name}} data-color={dimensionValue.name}></span>
              {dimensionValue.name} ({dimensionValue.productCount})
            </a>
          </li>
        );
      })}
      </ul>
    }else{
      clearLabel = "CLEAR ALL";
      backLinkMarkup = '';
      listMarkup = <ul id={dimensionListDivId}>
      {dimensions.map((dimension, index) => {
          return (
            <li className={(dimension.dimensionValues && dimension.dimensionValues.length > 0) ? "arrow" : ""} key={index} onClick={(e) => props.handleFilterGroupClick(e, dimension.name, filtersState, props.appState)}>
              <div>{dimension.label}</div>
              {filtersState.appliedFilterLabels[dimension.label] && <div className="sub-label">{filtersState.appliedFilterLabels[dimension.label]}</div>}
            </li>
          );
      })}
      </ul>
    }

		return (
      <div className='fade-filter'>
  			
         {this.props.productPopup &&
          <div id='filter-content' className='filter-content display-block'>
            <div>
      				  <div className="dimensions-header">
      					{backLinkMarkup}
      					&nbsp;<span>{props.count}&nbsp; {h1Title}</span>
      				</div>
              {listMarkup}
                   <div className="dimensions-footer">
                <div className="links">
                  <a href="#" onClick={() => props.handleClearAll(filtersState, props.appState)}>{clearLabel}</a>
                  <a href="#" className="done-btn" onClick={() => props.handleDoneClick(filtersState, props.appState)}>DONE</a>
                </div>
              </div>
           </div>
          </div>
        }
        
        {this.props.storePopup &&  
        <div className="filter-content store-avail  display-block">  
         <div className="store-avail-cnt"><span className="freeTxt">FREE</span>&nbsp;PICK UP IN STORE</div>
          <StoreSearchView {...this.props}/>  
          <div className="store-avail-cnt" onClick={(e) => {props.handleFilterOptionClick(e, null, "ONLINE ONLY")}}>ONLINE ONLY</div>
          <div className="dimensions-footer">
            <div className="links">
              <a href="#" onClick={() => props.handleClearAll(filtersState, props.appState)}>{clearLabel}</a>
              <a href="#" className="done-btn" onClick={() => props.handleDoneClick(filtersState, props.appState)}>DONE</a>
            </div>
          </div>
        </div>  
        }
    </div>  
		);
	}
});
