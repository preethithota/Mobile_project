import React from 'react';
import * as utils from '../../global/utils';
import {labels} from '../../global/label-utils';
import KohlsPrice from '../util/price-component';


export default React.createClass({

	render: function(){

		const props = this.props;
		const product = props.product;
		const prodRatings = product.rating.avgRating;
		const ratingProdCount = product.rating.count;
		let onlineImgMarkup;
		let swatchImagesMarkup;
		let gwpMarkup;
		let storeId = (props.serverRender) ? '' : utils.getUrlParam("storeid",location.href) || "";
		storeId = storeId && storeId.split(",")[0];
		storeId = storeId ? (location.href.indexOf("?") === -1 ? "&storeid="+storeId : "?storeid="+storeId) : "";

		function getRatingsClass(ratings){
			return (window.outerWidth > 680) ? (13*ratings) : (18*ratings)
		}

		if (prodRatings){
			var getRatingsWidth = getRatingsClass(prodRatings);
			var ratingsMarkUp =(<div className="pmpRateImage"  style={{width:getRatingsWidth}}></div>);

		}

		let hlClass = product.rating.isHlProduct ? "hlProduct" : "";

		var imgSize = (props.isTcom) ? '180' : '155';
		var imageUrl = utils.getImageUrl(product.image.url, imgSize);

		product.valueAddedIcons = product.valueAddedIcons || [];
		product.valueAddedIcons = product.valueAddedIcons.filter(function(item){
			return item.indexOf('warning') === -1;
		});

		if(product.valueAddedIcons && product.valueAddedIcons.length > 0) {
			// Removing out Warning labels
			let valueAddedIcons = product.valueAddedIcons.filter(function(item){
				return item.indexOf('warning') === -1;
			});

			//Priority order of badges
		let sortingOrder = ['bogo', 'rebate', 'online', 'morecolors', 'kohls-exclusive', 'buy', 'closeout','closeout-deal','final-call'];

			//sort value added icons based on priority
			valueAddedIcons.sort(function(icon1, icon2){
				icon1 = icon1 && icon1.split('_')[0].toLowerCase();
				icon2 = icon2 && icon2.split('_')[0].toLowerCase();
				return sortingOrder.indexOf(icon1) < sortingOrder.indexOf(icon2) ? -1 : 1;
			});

			// const valueImgName1 = product.valueAddedIcons[0].split(".")[0];
			// let valueImgName2;
			//
			// product.valueAddedIcons[1] ? (valueImgName2 = product.valueAddedIcons[1].split(".")[0]) : ''

			onlineImgMarkup = (<div id="valueAddBlock">
				<div className={`onlineOnlyCont marginTop10`} id={valueAddedIcons[0]}></div>
				{valueAddedIcons[1] && <div className="onlineOnlyCont" id={valueAddedIcons[1]}></div>}
			</div>)
		}

		if(product.swatchImages && product.swatchImages.length > 0) {
			swatchImagesMarkup = (
				<div>
					<div id="swatchContainer" className="mcom-only">{product.swatchImages.length} {labels.swatchColorsAvailable}</div>
					<div id="tcom-swatch-cont" className="tcom-only-block">
						{product.swatchImages.map((swatchImage, index) => {
							let inx = {index};
							if (inx.index < 5) {
								return <span key = {index} className="swatchImg"><img src={swatchImage.URL} /></span>
							}
						})}
						{
                        (product.swatchImages.length > 5) && (<span className="swatchMore">+{product.swatchImages.length-5}more</span>)
                        }
					</div>
				</div>
			)
		}
		else {
			swatchImagesMarkup = '';
		}

		var prodOffers = product.productOffers;
		if(prodOffers) {
			let grpType = prodOffers[0].groupType;
			let itemType = prodOffers[0].itemType;
			if(itemType && itemType.toUpperCase() == "BUY") {
				(grpType) ? (grpType.toUpperCase() == "GWP") ? (gwpMarkup = labels.GWPTxt) : (grpType.toUpperCase() == "PWP") ? (gwpMarkup = labels.PWPTxt) :'':''
			}
		}



		return (
			<div className={`product-result ${hlClass}`}>
				<div onClick={(e) => {window.localStorage.setItem("ProductIndexInPMP", this._reactInternalInstance._mountIndex+1);window.location.href=product.seoURL + storeId}} className="productDtls">
					<div className="product-image">
						<img alt={product.productTitle} src={imageUrl} />
					</div>
					<div className="product-details">
                        <div className="product-info">
                            <div className="product-name" dangerouslySetInnerHTML={{__html: product.productTitle}} />
                            {<KohlsPrice products={product}/>}
                        </div>
                        {prodRatings && <div>
                            <div className="prodImagecontainer">
                                {ratingsMarkUp}
                            </div>
                            <div className="avgCount">
                                ({ratingProdCount})
                            </div>
                        </div>
                        }
                        <div className="gift-purchase">{gwpMarkup}</div>
                        {swatchImagesMarkup}
                        {onlineImgMarkup}
                    </div>
                    <span className="m-list-action"></span>
				</div>
				{hlClass && <div className="hl_sponsored">SPONSORED PRODUCT</div>}
				{!hlClass && <div id="moreLikeCont" className={'mcom-only'}><a href={'/morelikethis?prdId=' + product.webID} className="moreLikeImg">{labels.moreLikeThisTxt}</a></div>}
			</div>
		);
	}
});
