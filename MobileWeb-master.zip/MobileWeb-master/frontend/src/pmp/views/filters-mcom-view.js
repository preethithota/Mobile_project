import * as utils from '../../global/utils';
import StoreSearchView from './filters-store-area-search';
export default React.createClass({

	__store_Sort : function (x,y,Ary) {
		  if(!window.sort){
		  var _tmp = Ary[x];
		  Ary[x] = Ary[y];
		  Ary[y] = _tmp;
		  window.sort = true;
		}
	},
	render: function(){
		const props = this.props;
		const filtersState = props.filtersState;
		const dimensions = filtersState.currentFilters;
		const sorts = filtersState.sorts;

		//TODO: move this to a container for both m and t
		let sortDefaultValue = '0';
		let selectedSortLabel = '';
    if (sorts){
      for (var i = 0; i < sorts.length; i++){
        if (sorts[i].active){
          sortDefaultValue = sorts[i].ID;
					selectedSortLabel = sorts[i].name;
					var selected = sorts.splice(i,1) [0];
 				    sorts.unshift(selected);
 				    break;
        }
      }
    }

		let isStoreSelected = false;

		for(let i = 0; i < filtersState.availabilityList.length; i++) {
			if(filtersState.availabilityList[i].active) {
				isStoreSelected = true;
				break;
			}
		}

		var buttonsMarkup = (
			<div className="filter-buttons">
				<button className={'apply-btn' + ((filtersState.isApplyButtonActive) ? '' : ' disabled')}
				 onClick={() => props.handleDoneClick(filtersState, props.appState)}>APPLY</button>
           <button className="clear-btn" onClick={() => props.handleClearAll(props.filtersState, props.appState)}>CLEAR ALL</button>
			</div>
		);
		return (
			<div id="mcom-filters" >

				{this.props.appState.showSort && <div>
					<div id="filters-mask" onClick={(e) => props.closeSort(e)}></div>
					<div id="sort-modal">
						<div id="sort-options">
							<div className="header">SORT BY</div>
							{sorts && sorts.map((sort, index) => {
									return <div className={"option" + ((sort.active)? " bldmedium" :"")} key={index} onClick={(e) => props.handleMcomSortSelection(e, sort)}>
										{sort.name}
									</div>
							})}
						</div>
					</div>

				</div>}
				<div className="filter-header">
					<div className="cancel-link" onClick={props.handleCancelClick}>Cancel</div>
					<div className="filter-title">Sort & Filter</div>
					<div>&nbsp;</div>
				</div>
				{buttonsMarkup}
				<div id="filter-list">
					<div className="filter-group-container">

						<div className="filter-group" onClick={(e) => props.handleFilterGroupClick(e, "SortBy", filtersState, props.appState)}>
							<div className="filter-label">
								<div><strong>SORT BY</strong></div>
							</div>
							<div><i className="filter-chevron"></i></div>
						</div>
						<div className='filter-group-list select-always'>
							{selectedSortLabel &&
								<div className="filter-option">{selectedSortLabel}</div>
							}
						</div>
					</div>

					{dimensions.map((dimension) => {
						return(
							<div className="filter-group-container" key={dimension.index}>
								<div className="filter-group" onClick={(e) => props.handleFilterGroupClick(e, dimension.name, filtersState, props.appState)}>
									<div className="filter-label">
										<div><strong>{dimension.label}</strong></div>
										{filtersState.appliedFilterLabels[dimension.label] && <div className="sub-label">{filtersState.appliedFilterLabels[dimension.label]}</div>}
									</div>
									<i className="filter-chevron"></i>
								</div>
								<div className={'filter-group-list' + ((dimension.name === filtersState.selectedGroup) ? '' : ' display-none')}>
								{dimension.label === 'Store Availability' && (this.__store_Sort(0,1,dimension.dimensionValues))}
								{dimension.dimensionValues.map((dimensionValue, index) => {
									if(dimensionValue){
									let filterOptionClassNames = 'filter-option' + (props.isDimensionSelected(dimensionValue, props.filtersState.selectedFilterIds) ? ' selected' : '');
									let subFilterMarkup = (
										<div className={filterOptionClassNames} key={index}
											onClick={(e) => {props.handleFilterOptionClick(e, dimensionValue, dimension.label)}}>
											{dimensionValue.name} ({dimensionValue.productCount})
										</div>
									)
									if(dimensionValue.name == "Pick Up in Store") {
										console.log("Pick Up in Store");
										subFilterMarkup = (
													<div onClick={(e) => {props.showStoreFinder(e)}}>
														<div id="pickUpInStore" className={isStoreSelected ? "filter-option selected" : "filter-option"} onClick={() => {props.isLocationAvailable()}}>
															<span className="freeTxt">FREE</span>&nbsp;Pick Up In Store
														</div>
														{props.filtersState.showStoreFilter &&
															<StoreSearchView {...this.props}/>
														}
													</div>
										)

									}
									return (subFilterMarkup)
								}
								})}
								</div>
							</div>
						)
					})}
				</div>
				{buttonsMarkup}
			</div>
		)
	}
});
