import * as utils from '../../global/utils';
export default React.createClass({
  componentDidMount: function() {
    let autocomplete = new google.maps.places.Autocomplete(/** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),{types: ['geocode'], country: 'us'});
    let that = this;
    window.findAddressComponents = function() {
      let place = autocomplete.getPlace();
      let addressComponent = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };
      let selectedLoc = {};
      if(place.address_components) {
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (addressComponent[addressType]) {
            selectedLoc[addressType] = place.address_components[i][addressComponent[addressType]];
          }
        }
      }else if(place.name) {
        if(place.name.indexOf(",") > -1) {
          var placeArr = place.name.split(',');
          selectedLoc.postal_code = placeArr[0];
        }else{
			selectedLoc.postal_code = place.name;
		}
      }
      //window.fisSelectedLocation = selectedLoc;
      /**
       * make inventory call and update availability list
       */
      that.props.updateAvailabilityList(selectedLoc.postal_code, selectedLoc.locality, selectedLoc.administrative_area_level_1);
    };

    autocomplete.addListener('place_changed', window.findAddressComponents);
    //window.autocomplete = autocomplete;
    if(window.zipCode) {
      document.getElementById("autocomplete").value = window.zipCode;
      window.zipCode = null;
    }
  },

  render: function() {
    const closeststore = JSON.parse(utils.getFromLocalStorage("closeststore"));
    const cookie = $.cookie("mystore") && JSON.parse($.cookie("mystore"));

    /*if(cookie) {
      for (let i=0; i < this.props.filtersState.availabilityList.length; i++) {
        if (this.props.filtersState.availabilityList[i].storeNum == cookie.storeNums) {
            var a = this.props.filtersState.availabilityList.splice(i,1);   // removes the item
            this.props.filtersState.availabilityList.unshift(a[0]);         // adds it back to the beginning
            break;
        }
      }
    }*/

    return (
          <div className={this.props.filtersState.noStores || this.props.filtersState.inValidEntry ? "error" : ""} >
             <div className="filter-option PT15" style={{position: 'relative'}}>
              <input id="autocomplete" className="store-search" onFocus={window.setGeolocationBound} type="search" autoComplete="off" autoCorrect="off" placeholder="Zip or City, State"/>
              <div className="search-button" onClick={(e) => {this.props.searchButtonClicked(e)}}></div>
              <div className="search_geoIcon" onClick={this.props.isLocationAvailable}></div>
            </div>
            {!closeststore && (!this.props.filtersState.availabilityList || this.props.filtersState.availabilityList.length == 0)
              && !this.props.filtersState.noStores && !this.props.filtersState.inValidEntry &&
              <div className="filter-option no-stores">
                Browse inventory at local stores available for<span className="freeTxt">&nbsp;FREE</span>&nbsp;pickup.
              </div>
            }
            {this.props.filtersState.noStores &&
             <div className="filter-option no-stores error-msg">
                <b>No stores found within 50 miles.<br/> Please try another location.</b>
              </div>
            }
            {this.props.filtersState.inValidEntry &&
             <div className="filter-option no-stores error-msg">
                <b>Please enter a valid ZIP code or <br/> City, State, separated by a comma.</b>
              </div>
            }

            {/*{closeststore &&
              <div className="filter-option" onClick={(e) => {this.props.handleStoreSelection(e, closeststore)}}>
                {closeststore.name} ({closeststore.availableProductCount})
              </div>
            }*/}
            {this.props.filtersState.availabilityList.map((store, index) => {
              let filterOptionClassNames = 'filter-option store';
              if(store.active) {
                filterOptionClassNames += " selected";
              }
              let myStoreMarkup = "";
              if(cookie && store.storeNum == cookie.storeNums) {
                 myStoreMarkup = (
                  <span className='myLocation'></span>
                );
              }

              return (
                <div className={filterOptionClassNames} key={index}
                  onClick={(e) => {this.props.handleStoreSelection(e, store)}}>
                  {myStoreMarkup}
                  {store.storeName.toLowerCase()} <div className="filter-option-count">&nbsp;({store.availableProductCount})</div>
                </div>
                )
            })}
          </div>
    )
  }
});
