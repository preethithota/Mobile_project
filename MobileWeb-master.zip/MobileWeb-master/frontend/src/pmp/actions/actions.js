
// export function updateAppStateFromUri(dispatch, nextUri){
//   dispatch({
//     type: 'UPDATE_APPSTATE_FROM_URI',
//     nextUri
//   });
// }

export function updateAppStateFromParams(dispatch, updatedParams, shouldRefreshFilters){
  dispatch({
    type: 'UPDATE_APPSTATE_FROM_PARAMS',
    updatedParams,
    shouldRefreshFilters
  });
}

export function initStore(dispatch, catalogData, uriPath, queryString) {
  dispatch({
    type: 'INIT_STORE',
    catalogData,
    uriPath,
    queryString
  });
}

export function updateCatalogData(dispatch, newCatalogData, nextUri, nextAppState, nextQueryString) {
  dispatch({
    type: 'UPDATE_CATALOG_DATA',
    catalogData: newCatalogData,
    nextUri,
    nextAppState,
    nextQueryString
  });
}

export function updateHooklogicData(dispatch, hookLogicData) {
  dispatch({
    type: 'UPDATE_HOOKLOGIC_DATA',
    hookLogicData
  });
}

export function initFilters(dispatch, isTcom) {
  dispatch({
    type: 'INIT_FILTERS',
    isTcom
  });
}

export function updateAvailableFilters(dispatch, availableFilters, activeDimensions, sorts) {
  dispatch({
    type: 'UPDATE_AVAILABLE_FILTERS',
    availableFilters,
    activeDimensions,
    sorts
  });
}

// export function updateCurrentFilters(dispatch, currentFilters) {
//   dispatch({
//     type: 'UPDATE_CURRENT_FILTERS',
//     currentFilters
//   });
// }

export function selectFilter(dispatch, selectedFilter, filterGroupLabel) {
  dispatch({
    type: 'SELECT_FILTER',
    selectedFilter,
    filterGroupLabel
  });
}

export function selectGroup(dispatch, selectedGroup, currentFilters = {}) {
  dispatch({
    type: 'SELECT_GROUP',
    selectedGroup,
    currentFilters
  });
}

export function cancelFilters(dispatch) {
  dispatch({
    type: 'CANCEL_FILTERS'
  });
}

export function hideFilters(dispatch){
  dispatch({
    type: 'HIDE_FILTERS'
  });
}

export function closeSort(dispatch){
  dispatch({
    type: 'CLOSE_SORT'
  });
}

export function showStoreFilter(dispatch){
  dispatch({
    type: 'SHOW_STORE_FILTER'
  });
}

export function updateStoreAvailability(dispatch, availabilityList, noStores, inValidEntry) {
  dispatch({
    type: 'UPDATE_STORE_AVAILABILITY',
    availabilityList,
    noStores,
    inValidEntry
  });
}

export function selectStore(dispatch, store) {
  dispatch({
    type: 'SELECT_STORE',
    store
  });
}
