import * as pmpClientInitializer from './pmp-client-initializer';
//import { setBTPMPPage } from '../../public/lib/brightTag-util';
import { setPMPOmniture } from '../../public/lib/omniture-util';

pmpClientInitializer.init(window.catalogData);
//setBTPMPPage();
setPMPOmniture();