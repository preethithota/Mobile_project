import {Provider} from 'react-redux';
import {createStore} from 'redux';
import PmpContainer from './containers/pmp-container';
import pmpReducer from './reducers/pmp-reducer';
import * as actions from './actions/actions';

export function init(catalogData, isMoreLikeThis = false){
  window.debugPmp = true;
  let store;
  if (window.debugPmp){
    store = createStore(pmpReducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
  }else{
    store = createStore(pmpReducer);
  }

  actions.initStore(store.dispatch, catalogData, location.pathname, location.search);

  ReactDOM.render((
    <Provider store={store}>
      <div><PmpContainer serverRender={false} isTcom={kohlsData.isTcom} isMoreLikeThis={isMoreLikeThis}/></div>
    </Provider>
  ), document.getElementById('main-content'));

  actions.initFilters(store.dispatch, kohlsData.isTcom);
  //TODO: Init onpopstate
}
