import React from 'react';
import * as utils from '../../global/utils';
import {labels} from '../../global/label-utils';

export default class kohlsPrice extends React.Component {
	constructor(props) {
	    super(props);
	}
	render(){
		let priceElement;
		let originalPrice = '';
		let productPrices = this.props.products.prices[0];
		let salePrice ='';
		if(productPrices) {
			try{
				if(productPrices.isCurrentPrice) {
					/*TODO: Need to confirn the below if condition is required or not*/
					if(productPrices.regularPriceType.match(/Regular|Original/i)) {
							originalPrice = productPrices.regularPriceType + " " + utils.convertToDollar(productPrices.regularPrice.minPrice) + (productPrices.regularPrice.maxPrice?' - '+utils.convertToDollar(productPrices.regularPrice.maxPrice):'');
					}
					let salePriceStatus = productPrices.salePriceStatus;

					if(productPrices.isSuppressed) {
						salePrice = productPrices.suppressedPricingText ? <div className="sale-price suppressedPrice">{productPrices.suppressedPricingText}</div> 
						: <div className="sale-price suppressedPrice">{labels.supressText}</div> 
					}

					if(salePriceStatus) {

						if((salePriceStatus.match(/sale/i) || salePriceStatus.match(/clearance/i)) && !(salePriceStatus.match(/sale\+clearance/i))){
								salePrice = <div className="sale-price">{salePriceStatus.toUpperCase() + " " + utils.convertToDollar(productPrices.salePrice.minPrice) + (productPrices.salePrice.maxPrice?' - '+utils.convertToDollar(productPrices.salePrice.maxPrice)+fnGetPromotions(productPrices):'')}</div>;
						}else if(salePriceStatus.match(/Mixed/i)) {
								salePrice = <div className="sale-price-black">{utils.convertToDollar(productPrices.salePrice.minPrice) + (productPrices.salePrice.maxPrice?' - '+utils.convertToDollar(productPrices.salePrice.maxPrice)+fnGetPromotions(productPrices):'')}</div>;
						} else if(salePriceStatus.match(/sale\+clearance/i)) {
								salePrice = <div className="sale-price">{utils.convertToDollar(productPrices.salePrice.minPrice) + (productPrices.salePrice.maxPrice?' - '+utils.convertToDollar(productPrices.salePrice.maxPrice)+fnGetPromotions(productPrices):'')}</div>;
						} else {
								salePrice = <div className="sale-price">{utils.convertToDollar(productPrices.salePrice.minPrice) + (productPrices.salePrice.maxPrice?' - '+utils.convertToDollar(productPrices.salePrice.maxPrice)+fnGetPromotions(productPrices):'')}</div>;
						}
					}else{
						/* Group price legal scenario Starts */ 
						let promotions = fnGetPromotions(productPrices);
						//salePrice = productPrices.salePrice.minPrice ? : promotions ? <div className="sale-price-black">{promotions}  + ' or  '+{originalPrice.toLowerCase()} +' each':'')}</div> :''.;

						if(productPrices.salePrice && productPrices.salePrice.minPrice){
							salePrice = <div className="sale-price-black">{utils.convertToDollar(productPrices.salePrice.minPrice) + (productPrices.salePrice.maxPrice?' - '+utils.convertToDollar(productPrices.salePrice.maxPrice) :'')}</div>;
							//originalPrice = <span className="lowercase"> or {originalPrice} </span>;
							originalPrice = <span className="lowercase"> or {originalPrice} each</span>;
						}
						else if(promotions){
							salePrice = <div className="sale-price-black">{promotions.replace("|","")} </div>;
							originalPrice = <span className="lowercase"> or {originalPrice} each</span>;
							
						}
						/* Group price legal scenario Ends */ 
					}
				}
			}catch(err){console.error('error rendering price: ' + err)}
		} else {
			priceElement = '';
		}

		return(
			<div id="price-section" >
					{salePrice}
				<div id="origprice" className="org-price">
					{originalPrice}
				</div>
			</div>
		);
	}
}
export function fnGetRegularPrice(){

}

export function fnGetPromotions(productPrices){
	let promotionText = "";
	promotionText = productPrices.promotion ? " | "+productPrices.promotion : '';
	//TBD Promotions -S8
	return promotionText;
}
