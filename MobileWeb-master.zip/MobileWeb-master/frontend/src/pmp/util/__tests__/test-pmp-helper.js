import * as pmpHelper from '../pmp-helper';

describe('getUpdatedCNValue', () => {
    const initialSelectedFilters = ["Department:Kitchen%20%26%20Dining","Category:Cutlery%20%26%20Knives"];
    it('should return selected filters as a single string separated by a +', () => {
      const initialSelectedFilters = ["Department:Kitchen%20%26%20Dining","Category:Cutlery%20%26%20Knives"];
      const expectedReturnValue = "Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining";
      expect(pmpHelper.getUpdatedCNValue(initialSelectedFilters)).toEqual(expectedReturnValue);
    });

});

describe('updateAppState', () => {
  it('should should return the correct updated state', () => {
    const paramsToUpdate = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets"},{"WS":1}];
    const currentState = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining"},{"cc":"for_thehome-TN3.0-S-CutleryKnives"},{"S":"4"}];
    const expectedUpdatedState = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets"},{"cc":"for_thehome-TN3.0-S-CutleryKnives"},{"S":"4"}, {"WS":1}];
    expect(pmpHelper.getUpdatedState(paramsToUpdate, currentState)).toEqual(expectedUpdatedState);
  });

  it('should should return the correct updated state', () => {
    const paramsToUpdate = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets"},{"S":"9"}, {"WS":"20"}];
    const currentState = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining"},{"cc":"for_thehome-TN3.0-S-CutleryKnives"},{"S":"4"}];
    const expectedUpdatedState = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets"},{"cc":"for_thehome-TN3.0-S-CutleryKnives"},{"S":"9"}, {"WS":"20"}];
    const actualUpdatedState = pmpHelper.getUpdatedState(paramsToUpdate, currentState);
    expect(actualUpdatedState).toEqual(expectedUpdatedState);
  });

});

describe('getQSFromAppState', () => {
  it('should return a valid query string generated from the backend params', () => {
    const initialAppState = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets"},{"cc":"for_thehome-TN3.0-S-CutleryKnives"},{"S":"4"}];
    const expectedQs = "?CN=Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets&cc=for_thehome-TN3.0-S-CutleryKnives&S=4";
    expect(pmpHelper.getQSFromAppState(initialAppState)).toEqual(expectedQs);
  });
});

describe('internalUpdateAppState', () => {
  const updatedParams = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets"},{"WS":1}];
  const currentState = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining"},{"cc":"for_thehome-TN3.0-S-CutleryKnives"},{"S":"4"}];
  const catalogCallback = jest.fn();
  const filtersCallback = jest.fn();
  const expectedNextQs = '?CN=Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets&cc=for_thehome-TN3.0-S-CutleryKnives&S=4&WS=1';
  const expectedNextState = [{"CN":"Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining+Product:Knife%20Sets"},{"cc":"for_thehome-TN3.0-S-CutleryKnives"},{"S":"4"},{"WS":1}];
  const expectedBackendCatalogUrl ='/service/catalog/' + expectedNextQs;
  const expectedBackendFiltersUrl ='/service/catalog/dimensions' + expectedNextQs;
  const mockCatalogData = {activeDimensions: ['a', 'b', 'c'], sorts: [1,2,3]};
  const mockFiltersData = {mockFiltersData: true};
  const expectedUrlToDataMappings = {[expectedBackendCatalogUrl]: mockCatalogData, [expectedBackendFiltersUrl]: mockFiltersData};
  const mockDispatch = {mockDispatch: true};
  const nextUri = '/nextUri';

  const fetch = jest.fn(url => {
    return {done: fetchCallback => {fetchCallback(expectedUrlToDataMappings[url])}}
  });

  it('should update both products and filters when shouldRefreshFilters = true', () => {
    const shouldRefreshFilters = true;

    pmpHelper.internalUpdateAppState(mockDispatch, updatedParams, currentState, shouldRefreshFilters, nextUri, fetch, catalogCallback, filtersCallback);
    expect(fetch).toBeCalledWith(expectedBackendCatalogUrl);
    expect(catalogCallback).toBeCalledWith(mockDispatch, mockCatalogData, nextUri, expectedNextState, expectedNextQs);
    //we passed shouldRefreshFilters, so we expect to fetch new filters
    expect(fetch).toBeCalledWith(expectedBackendFiltersUrl);
    expect(filtersCallback).toBeCalledWith(mockDispatch, mockFiltersData, mockCatalogData.activeDimensions, mockCatalogData.sorts);
  });

  it('should only update products when shouldRefreshFilters = false', () => {
    const shouldRefreshFilters = false;
    catalogCallback.mockClear();
    filtersCallback.mockClear();
    fetch.mockClear();

    pmpHelper.internalUpdateAppState(mockDispatch, updatedParams, currentState, shouldRefreshFilters, nextUri, fetch, catalogCallback, filtersCallback);
    expect(fetch).toBeCalledWith(expectedBackendCatalogUrl);
    expect(fetch).toHaveBeenCalledTimes(1);
    expect(catalogCallback).toBeCalledWith(mockDispatch, mockCatalogData, nextUri, expectedNextState, expectedNextQs);
    expect(filtersCallback).toHaveBeenCalledTimes(0);
  });
});
