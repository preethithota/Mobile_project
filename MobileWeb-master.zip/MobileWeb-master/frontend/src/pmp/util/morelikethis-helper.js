import {getCookieValue} from '../../global/utils';

export function transformRecsData(recsData){
  //console.log('product data in transformRecsData ' + JSON.stringify(product));
  const catalogData = {};
  if (!recsData) return catalogData;

  catalogData.h1Tag = recsData.displayText;
  catalogData.moreLikeThisProduct = (window.catalogData && window.catalogData.payload) ? window.catalogData.payload.products[0] : {};
  catalogData.limit = 24;

  if (recsData.payload && recsData.payload.recommendations && recsData.payload.recommendations.length > 0){
    const recommendations = recsData.payload.recommendations[0];
    catalogData.count = recommendations.products.length;
    catalogData.h1Tag = recommendations.displayText;
    catalogData.products = recommendations.products.map((product) => {
      product.rating = {avgRating: product.avgRating, count: product.ratingCount};
      product.webID = product.id;
      product.seoURL = (product.seoURL) ? product.seoURL : '/product/prd-' + product.id + '/product.jsp';

      return product;
    });
  }

  return catalogData;
}

export function getCurrentRecs(productArr, offset, limit){
  offset = (offset < 1) ? 1 : offset;
  const end = Math.min(productArr.length, offset - 1 + limit);
  let updatedProductArr = productArr.slice(offset - 1, end);
  return updatedProductArr;
}

var kohlsData = window.kohlsData || {};
var kohlsData = window.kohlsData || {};

var KOHLS = KOHLS || {};
KOHLS.MORELIKETHIS = KOHLS.MORELIKETHIS || {};
KOHLS.MORELIKETHIS.RECOMMENDATIONS = KOHLS.MORELIKETHIS.RECOMMENDATIONS || {};
KOHLS.MORELIKETHIS.RECOMMENDATIONS = {
    mcom: {
        SDKJSURL: kohlsData.recommendationsSdkUrl,
        edeWrapperURL: kohlsData.edeWrapperUrl,
        ApiKey: kohlsData.recommendationsApiKey,
        channel: (kohlsData.isTcom) ? "TCom" : "MCom",
        recomSwitch: true,
        page: {
            more_like_this: {
                placements: ["Grid"],
                limit: 36,
                pageName: "PMP",
                showRecom: true
            },
            continue_shop: {
                placements: ["Horizontal", "Horizontal1", "Horizontal2"],
                limit: 20,
                pageName: "CartAdd",
                showRecom: true
            }
        }
    }
};//end KOHLS.MORELIKETHIS.RECOMMENDATIONS


KOHLS.MORELIKETHIS.RECOMMENDATIONS.functions = {
    queryString: function(key) {
        var result = new RegExp(key + "=([^&]*)","i").exec(window.location.search);
        return result && unescape(result[1]) || ""
    },
    getCCP_values: function(productWebId) {
        if (this.queryString("from_cshop")) {
            try {
                const skBagCookie = getCookieValue('skBag');
                var products = ""
                  , minPrice = KOHLS.MR.UTILMETHOD.getLocalStorage("shippingcharge").trim()
                  , getProd = skBagCookie ? JSON.parse(skBagCookie) : [];
                getProd = getProd.reverse();
                for (var i = 0; i < getProd.length; i++) {
                    if (getProd[i]) {
                        products += getProd[i].split("|")[1] + ","
                    }
                }
                productWebId = products.substring(0, products.length - 1);
                console.log("list of products" + productWebId)
            } catch (Err) {
                console.log("exception occured while collating the product ids" + Err.message)
            }
        }
        var ccps = {
            atgId: '' || "",
            cookieId: '' || "",
            productNumbers: productWebId || "",
            minPrice: minPrice || ""
        };
        console.log("hey here are the ccps" + ccps);
        console.log(ccps);
        return ccps
    },
    getPageConfig: function(channelName) {
        var pageType = "more_like_this"
          , productWebId = this.queryString("prdId");
        if (KOHLS.MORELIKETHIS.RECOMMENDATIONS.functions.queryString("from_cshop")) {
            pageType = "continue_shop"
        } else {
            if (location.href.indexOf("/morelikethis") != -1) {
                pageType = "more_like_this"
            }
        }
        var pageConfig = KOHLS.MORELIKETHIS.RECOMMENDATIONS[KOHLS.MORELIKETHIS.RECOMMENDATIONS.channelName].page[pageType]
          , ccpPairs = KOHLS.MORELIKETHIS.RECOMMENDATIONS.functions.getCCP_values(productWebId);
        if (pageConfig) {
            pageConfig.ccps = {};
            pageConfig.ccps = ccpPairs
        }
        return pageConfig
    },
    recommendInit: function(initCallBack) {
        var sdkRecoConfig = KOHLS.MORELIKETHIS.RECOMMENDATIONS[KOHLS.MORELIKETHIS.RECOMMENDATIONS.channelName];
        if (sdkRecoConfig.recomSwitch) {
            $.getScript(sdkRecoConfig.SDKJSURL, function() {
                try {
                    var pageConfig = KOHLS.MORELIKETHIS.RECOMMENDATIONS.functions.getPageConfig();
                    if (pageConfig.showRecom) {
                        var objEdeWrapper = new window.ede.EDEWrapper(sdkRecoConfig.edeWrapperURL);
                        objEdeWrapper.setApiKey(sdkRecoConfig.ApiKey).setChannel(sdkRecoConfig.channel).setPage(pageConfig.pageName);
                        for (var index = 0; pageConfig.placements.length > index; index++) {
                            objEdeWrapper.setPlacement(pageConfig.placements[index], pageConfig.limit)
                        }
                        for (var ccp in pageConfig.ccps) {
                            objEdeWrapper.setCcp(ccp, pageConfig.ccps[ccp])
                        }
                        objEdeWrapper.getRecommendations().then(function(recommendations) {
                            KOHLS.MORELIKETHIS.RECOMMENDATIONS.rawRecommResp = recommendations;
                            var recommendationJson = JSON.parse(recommendations.getRecommendationJson());
                            var transformedData = transformRecsData(recommendationJson);
                            initCallBack(transformedData);
                            //KOHLS.MORELIKETHIS.RECOMMENDATIONS.functions.recommendRenderUI(recommendationJson)
                        }).fail(function(error) {
                            console.error("Exception occurred due to " + error.message)
                        })
                    }
                } catch (e) {
                    console.error("Exception occurred due to " + e.message)
                }
            })
        }
    }
  }//end KOHLS.MORELIKETHIS.RECOMMENDATIONS.functions



//KOHLS.MORELIKETHIS.RECOMMENDATIONS.channelName = 'channelName';
KOHLS.MORELIKETHIS.RECOMMENDATIONS.channelName = 'mcom';

export function initRecs(initCallBack){
  KOHLS.MORELIKETHIS.RECOMMENDATIONS.functions.recommendInit(initCallBack)
}
