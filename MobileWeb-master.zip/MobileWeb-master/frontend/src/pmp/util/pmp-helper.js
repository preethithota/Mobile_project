import * as actions from '../actions/actions';
import * as utils from '../../global/utils';
import * as hlHelper from '../../hookLogic/hookLogic-helper';
import { setPMPRefineOmniture } from '../../../public/lib/omniture-util';

const backendParams = ['CN', 'N', 'WS', 'limit', 'S', 'search'];
const backendBaseCatalogUrl = '/service/catalog/';
const backendBaseDimensionsUrl = '/service/catalog/dimensions';

export function getUpdatedState(paramsToUpdate, currentState){
	if (typeof paramsToUpdate.length === 'undefined'){
		console.error('Invalid argument passed to getUpdatedState(), expected array');
	}
	//var currentState = catalogStore.getAppState();
	let updatedState = [];

	//update existing params
	currentState.map(function(currentParam){
		for (var i = 0; i < paramsToUpdate.length; i++) {
			let paramToUpdate = paramsToUpdate[i];
			if (!paramToUpdate) continue;
			let paramName = Object.keys(paramToUpdate)[0];
			if (currentParam[paramName]){
				currentParam[paramName] = paramToUpdate[paramName];
				delete paramsToUpdate[i];
				break;
			}
		}
		updatedState.push(currentParam);
	});

	//add params that were not added
	for (var i = 0; i < paramsToUpdate.length; i++) {
		let paramToUpdate = paramsToUpdate[i];
		if (!paramToUpdate) continue;
		updatedState.push(paramToUpdate);
	}
	return updatedState;
};

export function updateHooklogicData(dispatch,catalogData){
	console.log('pmpHelper.updateHooklogicData called');
	//TODO: make call to Hooklogic and then call:
	//actions.updateHooklogicData(dispatch, hookLogicData)
	var callBack = function(hookLogicData) {
		actions.updateHooklogicData(dispatch, hookLogicData);
	}
	hlHelper.initHookLogic(callBack,catalogData);
}

export function getAppStateFromQueryString(queryString){
	let updatedAppState = [];

	if (queryString.length === 0){
		return updatedAppState;
	}
	queryString = queryString.slice(1, queryString.length); //remove '?'
	var queryStringArr = queryString.split('&');

	queryStringArr.map(function(paramStr){
		let paramArr = paramStr.split('=');
		let param = {};
		param[paramArr[0]] = paramArr[1];
		updatedAppState.push(param);
	});

	return updatedAppState;
};

export function getQSFromAppState(appState){
	if (appState.length === 0){
		return "";
	}
	var filterParams = (typeof filteredParamNames !== 'undefined');
	var qsArr = [];

	for (var i = 0; i < appState.length; i++) {
		var param = appState[i];
		var paramName = Object.keys(param)[0];
		var filterParam = filterParams && backendParams.indexOf(paramName) === -1;
		if (paramName && !filterParam && param[paramName]){
			qsArr.push(paramName + '=' + param[paramName]);
		}
	}
	const qs = '?' + qsArr.join('&');
	return qs;
}

export function getUpdatedCNValue(selectedFilterIds){
	return selectedFilterIds.sort().join('+');
}

export function updateAppState(dispatch, currentState, updatedParams, shouldRefreshFilters, nextUri){
	const catalogCallback = (dispatch, catalogData, nextUri, nextAppState, nextQueryString) => {
		actions.updateCatalogData(dispatch, catalogData, nextUri, nextAppState, nextQueryString);
		updateHooklogicData(dispatch,catalogData);
		//history.pushState({}, '', nextUri);
		history.pushState({}, '', nextUri + nextQueryString);
		utils.hideLoader();
		utils.scrollTop();
	};

	const filtersCallback = (!shouldRefreshFilters) ? null : (dispatch, filtersData, activeDimensions, sorts) => {
		actions.updateAvailableFilters(dispatch, filtersData, activeDimensions, sorts);
	};

	return internalUpdateAppState(dispatch, updatedParams, currentState, shouldRefreshFilters, nextUri, utils.fetch, catalogCallback, filtersCallback)
}

// This function allows functions to be injected for unit testability
export function internalUpdateAppState(dispatch, updatedParams, currentAppState, shouldRefreshFilters, nextUri, fetch, catalogCallback, filtersCallback){
	const	nextState = (updatedParams) ? getUpdatedState(updatedParams, currentAppState) : currentAppState;
	const nextQueryString = getQSFromAppState(nextState);

	let catalogResponse = fetch(backendBaseCatalogUrl + nextQueryString);
	catalogResponse.done((catalogData) => {

		if (catalogData && catalogData.redirectUrl){
			utils.hideLoader();
			const port = (location.port == "80" || location.port == "443") ? '' : ':' + location.port;
			const redirectUrl = (catalogData.redirectUrl.indexOf('http') === 0) ? catalogData.redirectUrl : location.protocol +  "//" + location.hostname + port + catalogData.redirectUrl;
			location.href = redirectUrl;
			return;
		}

		catalogCallback(dispatch, catalogData, nextUri, nextState, nextQueryString);

		if (shouldRefreshFilters){
			const filtersResponse = fetch(backendBaseDimensionsUrl + nextQueryString);
			filtersResponse.done((filtersData) => {
				window.catalogData = catalogData;
				setPMPRefineOmniture();
				filtersCallback(dispatch, filtersData, catalogData.activeDimensions, catalogData.sorts);
			});
		}
	});
}

