import intialUiState from './reducers/ui-reducer'
import PmpView from './views/pmp-view';

global.renderServer = function(dataFromJava, isTcom){
    var data = JSON.parse(dataFromJava);
    return ReactDOMServer.renderToString(
        <div><PmpView catalogData={data} serverRender={true} uiState={intialUiState} isTcom={isTcom}/></div>
    );
};
