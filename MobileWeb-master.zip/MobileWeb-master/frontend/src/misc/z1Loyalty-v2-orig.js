window.kohlsCashDisclaimer = '';
window.kohlsCashLoggedInDisclaimer = '';

function showApplyPromoModal(){
  location.href = '/checkout/shopping_cart.jsp?showApplyModal=true';
}

function callBackFnTC(disclaimerParam){
  if (kohlsCashLoggedInDisclaimer){
    kohlsCashDisclaimer = kohlsCashLoggedInDisclaimer;
  }else{
    if (typeof disclaimerParam != 'undefined' && disclaimerParam){
      kohlsCashDisclaimer = decodeURI(disclaimerParam);
    }

    if (!kohlsCashDisclaimer){
      return;
    }
  }

  var divHtml = '<div id="tcOverlay" style="position:absolute; z-index: 9999999; opacity: .3; height: 100%; width: 100%; top: 0; background-color: black;"></div>';
  divHtml += '<div id="tc-modal-container" style="position:absolute; top: 0; z-index: 99999999; opacity: 1; width:100%; height: 300px;"><div id="tc-modal" style="background-color: white; margin: 10px; padding: 1.3rem;">';
  divHtml += '<div><div id="close-tc" style="background-image: url(/images/icon_close.png); background-position: 0 0; background-repeat: no-repeat; height: 19px; width: 18px; float: right;"></div></div>';
  divHtml += '<h3 style="font-size: 16px; clear:both; font-family: Gothambold;">ADDITIONAL OFFER DETAILS</h3>';
  divHtml += '<div id="disclaimer" style="font-family: GothamBook; font-size:12px;">' + kohlsCashDisclaimer + '</div>';
  divHtml += '</div></div>';

  $('body').append(divHtml);

  $('#close-tc, #tcOverlay').on('click', function(e){
    $('#tcOverlay').remove();
    $('#tc-modal-container').remove();
  });

  //return kohlsCashDisclaimer;
}


(function(){
  //var walletDomain = 'kohlswallet03.km.sl.edst.ibm.com';
  var debug = (getCookie('z1_debug') == "true" || location.search.indexOf('z1_debug=true') > -1);
  var z1LoyaltyFeatureEnabled = true;
  var z1SoftLoggedInFeatureEnabled = true;

  var isSoftLoggedIn = (getCookie('STREAM_SOFT_IS_LOGGED_IN') == 'true');
  var isFullyLoggedIn = (getCookie('STREAM_IS_LOGGED_IN') == 'true');

  function init(){

    var totalCartItems = 0;
    debugLog('debug z1 = true');

    var bagCookie = decodeURIComponent(getCookie('skBagTotalsNew'));
    if (bagCookie){
      debugLog('bagCookiePreset');
      var bagCookieArr = bagCookie.split('|');
      if (bagCookieArr.length > 1){
        totalCartItems = bagCookieArr[1];
      }
    }

    debugLog('initalizing z1 loyalty');
    if (isFullyLoggedIn){
      debugLog('user is fully logged in');
      doLoggedInFlow(totalCartItems);
    }else if(isSoftLoggedIn){
      debugLog('user is soft logged in');
      doSoftLoggedInFlow(totalCartItems);
    }
  };

  function doSoftLoggedInFlow(totalCartItems){
    var profileId = getProfileId();
    if (profileId){
      if (!debug){
        suppressMessageForDay();//set session storage/cookie to suppress z1 for a day
      }
      initZineOne([], totalCartItems, profileId, true);
    }else{
      debugLog('profileId is not available');
    }
  }

  function doLoggedInFlow(totalCartItems){
    var walletId = getCookie('wallet_id');
    var walletToken = decodeURIComponent(getCookie('wallet_token'));

    if (!walletId || !walletToken){
      debugLog('no wallet token so aborting z1');
      return;
    }

    debugLog('get wallet id ' + walletId + ' with wallet token ' + walletToken);
    var walletData, url = 'https://' + getWalletDomain() + '/wallet/v2/wallet/id/' + walletId;
    if (!debug){
      suppressMessageForDay();//set session storage/cookie to suppress z1 for a day
    }

    $.ajax({
        url: url,
        headers: {token: walletToken},
        success: function(data){
          debugLog('wallet data - ' + JSON.stringify(data));
          var kcArr = getKcArr(data);
          debugLog('kcArr - ' + JSON.stringify(kcArr));
          if (kcArr && kcArr.length > 0){
            initZineOne(kcArr, totalCartItems, getProfileId(), false);
          }
        }
    });

  }

  function debugLog(message){
    debug && console.log(message);
  }

  function getWalletDomain(){
    walletDomains = {
      "m.kohls.com": "wallet.kohls.com",
      "mpreprod.kohlsecommerce.com": "kohlswallet02.km.sl.edst.ibm.com",
      //"mcom-qa.kohlsecommerce.com": "kohlswallet03.km.sl.edst.ibm.com"
      "mcom-qa.kohlsecommerce.com": "kohlswallet02.km.sl.edst.ibm.com"
    }

    var domain = walletDomains[location.hostname];
    if (typeof domain == 'undefined'){
      return "kohlswallet03.km.sl.edst.ibm.com";
    }else{
      return domain;
    }
  }

  function getKCMapping(subTypeCode, typeCode){

    if (typeof subTypeCode == 'undefined' || typeof typeCode == 'undefined'){
      return '';
    }

    if('loyalty' == typeCode){
      return 'y2y';
    }

    var kcTypeMappings = {
      "Kohls Cash": "kc",
      "Loyalty": "y2y"
    }

    var mappedValue = kcTypeMappings[subTypeCode];
    return ((typeof mappedValue != 'undefined') ? mappedValue : 'kc');
  }

  function getKcArr(walletData){
  	var kcArr = [];


  	walletData.currentWalletItems.map(function(item, index){
  		if ((item.typeCode === 'kohlscash' || item.typeCode === 'loyalty') && !item.deleted){
  			var startDate = new Date(item.effectiveStartDate);
  			var endDate = new Date(item.effectiveEndDate);

  			if (isDateRangeValid(startDate, endDate)){
          if (item.disclaimer){
            kohlsCashLoggedInDisclaimer = item.disclaimer;
          }

  				var kcObj = {
  					id: index,
  					amt: item.value,
            exp: endDate,
  					type: getKCMapping(item.subTypeCode, item.typeCode)
  				}
  				kcArr.push(kcObj);
  			}
  		}
  	});
  	return kcArr;
  }

  function isDateRangeValid(startDate, endDate){
  	var now = new Date();
    //var twoWeeksFromNow = new Date(now.getTime() + 1209600000);//2 weeks
    debugLog('checking valid date range for startDate: ' + startDate + ', endDate: ' + endDate);
    if (now >= startDate && now <= endDate){
      debugLog('date range is valid');
      return true;
    }

    debugLog('date is not valid');
    return false;
  }

  function getProfileId(){
    var profileId = getCookie('profileId');

    if(profileId){
      return profileId;
    }
    return getCookie('z1Profile');
  }


  function initZineOne(kcArr, totalCartItems, profileId, isSoftLoggedIn){
    $.getScript("//d2p4r375zfkzm8.cloudfront.net/html5sdk/3.0.0/z1m.js", function(){
        var z1Div = document.createElement("div");
        z1Div.setAttribute('data-zineone-widget', 'z1_content_widget');
        z1Div.setAttribute('id', 'z1_container');
        var pdpWrapperDiv = document.getElementById('id_scfContent_');
        pdpWrapperDiv.parentNode.insertBefore(z1Div, pdpWrapperDiv);

        //ZineOne.initialize("sandbox@a010a164-7ea4-4533-a390-cbdbafe33532"); // kohls sandbox
        ZineOne.initialize("apps@6f32990f-8ee4-4f0b-ad98-37ad2c12d456"); //prod account

        //var profileId = getProfileId();
        ZineOne.setCustomerId(profileId);

        pushData = {
          page: getPageName(location.pathname),
          kcArr: kcArr,
          callBackFn: "showApplyPromoModal",
          itemsInBag: (totalCartItems > 0),
          callBackFnTC : "callBackFnTC",
          isSoftLoggedIn: isSoftLoggedIn
        }

        var z1Widgets = ZineOne.getZ1Widget();
        z1Widgets.registerWidgetHandler("raw", _handleRawData);

        var configMap = {"z1.banner.offset":"50"};
        z1Widgets.setConfiguration(configMap);

        ZineOne.pushEvent("z1_loyalty", pushData);
    });
  }

  function _handleRawData(rawData, ctaData){
    debugLog('rawData is ' + JSON.stringify(rawData));
    try{
      if (typeof s == 'undefined'){
        debugLog('s is not defined');
        return;
      }
      debugLog("Received raw data:\n"+ rawData);
      var z1Response = JSON.parse(rawData);
      debugLog('z1Response.prop75 is ' + z1Response.prop75);
      if (z1Response.prop75){
        var eVar39 = (z1Response.evar39) ? z1Response.evar39 : '';
        s.tl(this,'o','ZineOne Impression',{
          linkTrackVars:'prop75,eVar39',
          prop75: z1Response.prop75,
          eVar39: eVar39
        });
      }
    }catch(error){
      console.log('Could not fire prop75');
    }
  }

  function getCookie(cookieName) {
    var name = cookieName + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
  }

  function getPageName(uri){
    if (/(^\/catalog\/(.*))|(^\/search\.jsp(.*))/.test(uri)){
      return "PMP";
    }else if (/^\/myaccount\/v2\/myinfo\.jsp(.*)/.test(uri)){
      return "MyInfo";
    }else if (/^\/product\/prd-c(.*)/.test(uri)){
      return "CDP";
    }else if (/^\/product\/prd-(.*)/.test(uri)){
      return "PDP";
    }else if (/^\/checkout\/shopping_cart\.jsp/.test(uri)){
      return "Cart";
    }else if (/(^\/$)|(^\/\?(.*))/.test(uri)){
      return "Home";
    }else{
      return "";
    }
  }

  function formatDate(date){
    return date.getFullYear() + formatMonthDay(date.getMonth() + 1) + formatMonthDay(date.getDate());
  }

  function formatMonthDay(val){
    var strVal = '' + val;
    return (strVal.length > 1) ? strVal: ('0' + strVal);
  }

  function setProfileCookie(){
    var now = new Date();
    var sixMonthsFromNow = new Date(now.getTime() + 15552000000);
    var profileId = getCookie('profileId');
    if (profileId){
      document.cookie = 'z1Profile=' + profileId + '; expires=' + sixMonthsFromNow.toUTCString() + '; path=/';
    }

  }

  function suppressMessageForDay(){
    var now = new Date();
    var oneDayFromNow = new Date(now.getTime() + 86400000);//24hours

    //TODO: change from 5 min to 24 hours before going to prod
    //var oneDayFromNow = new Date(now.getTime() + 300000);//5 minutes

    var expirationTime = oneDayFromNow.toUTCString();
    document.cookie = 'z1_s2=true; expires=' + expirationTime + '; path=/';
  }

  function isMessagingEnabled(){
    if (getCookie('z1_s2') == 'true'){
      debugLog('z1 messaging is suppressed');
      return false;
    }
    return z1LoyaltyFeatureEnabled;
  }

  function showApplyDiscountModal(){
    var i = 0;
    var applyKcInterval = setInterval(function(){
      if ($('#id_KohlsCashDiscountApply').length > 0){
        clearInterval(applyKcInterval);
        $('#id_KohlsCashDiscountApply').trigger('click');
      }

      i++;
      if (i >= 30){//15 seconds
        clearInterval(applyKcInterval);
      }
    }, 500);
  }

  setProfileCookie();

  if (location.pathname == '/checkout/shopping_cart.jsp' && location.search.indexOf('showApplyModal=true') > -1){
    debugLog('showing apply discount modal');
    showApplyDiscountModal();
  }else{
    debugLog('checking if z1 is enabled');
    if (isMessagingEnabled() || debug){
      init();
    }
  }


})();
