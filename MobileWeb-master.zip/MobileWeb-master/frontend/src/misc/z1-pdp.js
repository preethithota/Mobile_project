
import {isLoggedIn, isSoftedLoggedIn, getCookieValue} from '../global/utils';

var z1Div = document.createElement("div");
z1Div.setAttribute('data-zineone-widget', 'z1_content_widget');
z1Div.setAttribute('id', 'z1_container');
var pdpWrapperDiv = document.getElementById('skMob_pdp_ErrorContainer_id');
if(pdpWrapperDiv){
  pdpWrapperDiv.parentNode.insertBefore(z1Div, pdpWrapperDiv);
}

//var initZineOne = function(){
export function initZineOnePdp(getProfileId){

  try{
    console.log('Initializing ZineOne');
    //ZineOne.initialize("sandbox@a010a164-7ea4-4533-a390-cbdbafe33532"); // Sandbox kohls acct
    //ZineOne.initialize("apps@6f32990f-8ee4-4f0b-ad98-37ad2c12d456"); //prod account
    var apiKey = kohlsData.zineOneApiKey;
    ZineOne.initialize(apiKey); //prod account

    if (typeof pageData != 'undefined'){
      var customerId = pageData.customerDetails && pageData.customerDetails.customerID;
      console.log('Setting customerId: ' + customerId);
      //ZineOne.setCustomKey("customerId", customerId);
      var profileId = getProfileId();
      ZineOne.setCustomerId(profileId);
    }else{
      console.log('pageData is undefined');
    }

    //ZineOne.enableMessaging();
    var z1Widgets = ZineOne.getZ1Widget();

    var configMap = {
      "z1.banner.secondsToShow" : "15",
      "z1.banner.offset" : "50"
    };

    z1Widgets.setConfiguration(configMap);

    var _handleRawData = function(rawData, ctaData){
      try{
        console.log("Received raw data:\n"+ rawData);
        var z1Response = JSON.parse(rawData);
        console.log('z1Response.prop75 is ' + z1Response.prop75);
        if (z1Response.prop75 && s){
          s.tl(this,'o','ZineOne Impression',{
            linkTrackVars:'prop75',
            prop75: z1Response.prop75
          });
        }
      }catch(error){
        console.log('Could not fire prop75');
      }
    }

    z1Widgets.registerWidgetHandler('raw', _handleRawData);

    var firePushEvent = function(evtName, evtMap){
      ZineOne.pushEvent(evtName, evtMap);
      // if(!z1Session) {
      //   var z1Session = new Session().instance();
      // }
      //   z1Session.pushEvent(evtName, evtMap);
    }

    //var productId = $('meta[itemprop="productID"]').attr('content');
    let productId = '';
    try{
      productId = catalogData.payload.products[0].webID;
    }catch(err){
      console.log('Error getting product id ' + err);
    }

    if (productId){
      console.log('Calling firePushEvent with productId: ' + productId);
      firePushEvent("z1_banner",{"productId": productId});
    }else{
      console.log('No product Id set');
    }

    setTimeout(function(){
      $(document).on('click', '.skMob_ATBCheckoutBtn', function(){
        $('#z1_container').hide();
      });
    }, 3000);

  }catch(error) {
    console.log('Error initializing ZineOne');
  }

}

// $.getScript("//d2p4r375zfkzm8.cloudfront.net/html5sdk/3.0.0/z1m.js", function(){
//   initZineOne();
// });
