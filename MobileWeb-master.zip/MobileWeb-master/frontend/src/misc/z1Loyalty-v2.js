import {getCartFromStorage} from '../global/cart-helper';
import {isLoggedIn, isSoftedLoggedIn, getCookieValue} from '../global/utils';
//import {initZineOnePdp} from './z1-pdp.js';

window.kohlsCashDisclaimer = '';
window.kohlsCashLoggedInDisclaimer = '';

window.showApplyPromoModal = function(){
  location.href = '/checkout/checkout.jsp?showApplyModal=true#/shoppingBag';
}

window.callBackFnTC = function(disclaimerParam){
  if (kohlsCashLoggedInDisclaimer){
    kohlsCashDisclaimer = kohlsCashLoggedInDisclaimer;
  }else{
    if (typeof disclaimerParam != 'undefined' && disclaimerParam){
      kohlsCashDisclaimer = decodeURI(disclaimerParam);
    }
    if (!kohlsCashDisclaimer){
      return;
    }
  }

  var divHtml = '<div id="tcOverlay" style="position:absolute; z-index: 9999999; opacity: .3; height: 100%; width: 100%; top: 0; background-color: black;"></div>';
  divHtml += '<div id="tc-modal-container" style="position:absolute; top: 0; z-index: 99999999; opacity: 1; width:100%; height: 300px;"><div id="tc-modal" style="background-color: white; margin: 10px; padding: 1.3rem;">';
  divHtml += '<div><div id="close-tc" style="background-image: url(/images/icon_close.png); background-position: 0 0; background-repeat: no-repeat; height: 19px; width: 18px; float: right;"></div></div>';
  divHtml += '<h3 style="font-size: 16px; clear:both; font-family: Gothambold;">ADDITIONAL OFFER DETAILS</h3>';
  divHtml += '<div id="disclaimer" style="font-family: GothamBook; font-size:12px;">' + kohlsCashDisclaimer + '</div>';
  divHtml += '</div></div>';

  $('body').append(divHtml);

  $('#close-tc, #tcOverlay').on('click', function(e){
    $('#tcOverlay').remove();
    $('#tc-modal-container').remove();
  });
}

function getProfileId(){
  return getCookieValue('profileId');
}

(function(){
  var debug = (getCookieValue('kohls_debug') == "true" || location.search.indexOf('z1_debug=true') > -1);
  var z1LoyaltyFeatureEnabled = true;
  var z1SoftLoggedInFeatureEnabled = true;

  const isSoftLoggedIn = isSoftedLoggedIn();
  const isFullyLoggedIn = isLoggedIn();

  function init(){
    if(kohlsData.pdpEnabled){ // only true on pdp
      require(['./z1-pdp.js'], (z1Pdp) => {
        z1Pdp.initZineOnePdp(getProfileId);
      });
    }

    initZineOne();
    var totalCartItems = 0;
    debugLog('debug z1 = true');

    //var bagCookie = decodeURIComponent(getCookie('skBagTotalsNew'));
    const cart = getCartFromStorage();
    totalCartItems = (cart) ? cart.length : 0;
    debugLog('initalizing z1 loyalty');
    if (isFullyLoggedIn){
      debugLog('user is fully logged in');
      doLoggedInFlow(totalCartItems);
    }else if(isSoftLoggedIn){
      debugLog('user is soft logged in');
      doSoftLoggedInFlow(totalCartItems);
    }
  };

  function doSoftLoggedInFlow(totalCartItems){
    var profileId = getProfileId();
    if (profileId){
      if (!debug){
        suppressMessageForDay();//set session storage/cookie to suppress z1 for a day
      }
      initZineOne([], totalCartItems, profileId, true);
    }else{
      debugLog('profileId is not available');
    }
  }

  function doLoggedInFlow(totalCartItems){
    var walletId = getCookieValue('wallet_id');
    var walletToken = decodeURIComponent(getCookieValue('wallet_token'));

    if (!walletId || !walletToken){
      debugLog('no wallet token so aborting z1');
      return;
    }

    debugLog('get wallet id ' + walletId + ' with wallet token ' + walletToken);
    //var walletData, url = 'https://' + getWalletDomain() + '/wallet/v2/wallet/id/' + walletId;
    const url = getWalletDomain() + '/wallet/v2/wallet/id/' + walletId;
    if (!debug){
      suppressMessageForDay();//set session storage/cookie to suppress z1 for a day
    }

    $.ajax({
      url: url,
      headers: {token: walletToken},
      success: function(data){
        debugLog('wallet data - ' + JSON.stringify(data));
        var kcArr = getKcArr(data);
        debugLog('kcArr - ' + JSON.stringify(kcArr));
        if (kcArr && kcArr.length > 0){
          initZineOne(kcArr, totalCartItems, getProfileId(), false);
        }
      }
    });

  }

  function debugLog(message){
    debug && console.log(message);
  }

  function getWalletDomain(){
    return kohlsData.walletDomain;
  }

  function getKCMapping(subTypeCode, typeCode){

    if (typeof subTypeCode == 'undefined' || typeof typeCode == 'undefined'){
      return '';
    }

    if('loyalty' == typeCode){
      return 'y2y';
    }

    var kcTypeMappings = {
      "Kohls Cash": "kc",
      "Loyalty": "y2y"
    }

    var mappedValue = kcTypeMappings[subTypeCode];
    return ((typeof mappedValue != 'undefined') ? mappedValue : 'kc');
  }

  function getKcArr(walletData){
  	var kcArr = [];
  	walletData.currentWalletItems.map(function(item, index){
  		if ((item.typeCode === 'kohlscash' || item.typeCode === 'loyalty') && !item.deleted){
  			var startDate = new Date(item.effectiveStartDate);
  			var endDate = new Date(item.effectiveEndDate);

  			if (isDateRangeValid(startDate, endDate)){
          if (item.disclaimer){
            kohlsCashLoggedInDisclaimer = item.disclaimer;
          }

  				var kcObj = {
  					id: index,
  					amt: item.value,
            exp: endDate,
  					type: getKCMapping(item.subTypeCode, item.typeCode)
  				}
  				kcArr.push(kcObj);
  			}
  		}
  	});
  	return kcArr;
  }

  function isDateRangeValid(startDate, endDate){
  	var now = new Date();
    //var twoWeeksFromNow = new Date(now.getTime() + 1209600000);//2 weeks
    debugLog('checking valid date range for startDate: ' + startDate + ', endDate: ' + endDate);
    if (now >= startDate && now <= endDate){
      debugLog('date range is valid');
      return true;
    }

    debugLog('date is not valid');
    return false;
  }

  function initZineOne(kcArr, totalCartItems, profileId, isSoftLoggedIn){
    var z1Div = document.createElement("div");
    z1Div.setAttribute('data-zineone-widget', 'z1_content_widget');
    z1Div.setAttribute('id', 'z1_container');
    const wrapperDiv = document.getElementById('main-body');
    wrapperDiv.parentNode.insertBefore(z1Div, wrapperDiv);
    ZineOne.initialize(kohlsData.zineOneApiKey);

    ZineOne.setCustomerId(profileId);

    const pushData = {
      page: getPageName(location.pathname),
      kcArr: kcArr,
      callBackFn: "showApplyPromoModal",
      itemsInBag: (totalCartItems > 0),
      callBackFnTC : "callBackFnTC",
      isSoftLoggedIn: isSoftLoggedIn
    }

    var z1Widgets = ZineOne.getZ1Widget();
    z1Widgets.registerWidgetHandler("raw", _handleRawData);

    var configMap = {"z1.banner.offset":"50"};
    z1Widgets.setConfiguration(configMap);
    ZineOne.pushEvent("z1_loyalty", pushData);
  }

  function _handleRawData(rawData, ctaData){
    debugLog('rawData is ' + JSON.stringify(rawData));
    try{
      if (typeof s == 'undefined'){
        debugLog('s is not defined');
        return;
      }
      debugLog("Received raw data:\n"+ rawData);
      var z1Response = JSON.parse(rawData);
      debugLog('z1Response.prop75 is ' + z1Response.prop75);
      if (z1Response.prop75){
        var eVar39 = (z1Response.evar39) ? z1Response.evar39 : '';
        s.tl(this,'o','ZineOne Impression',{
          linkTrackVars:'prop75,eVar39',
          prop75: z1Response.prop75,
          eVar39: eVar39
        });
      }
    }catch(error){
      console.log('Could not fire prop75');
    }
  }

  function getPageName(uri){
    if (/(^\/catalog\/(.*))|(^\/search\.jsp(.*))/.test(uri)){
      return "PMP";
    }else if (/^\/myaccount\/v2\/myinfo\.jsp(.*)/.test(uri)){
      return "MyInfo";
    }else if (/^\/product\/prd-c(.*)/.test(uri)){
      return "CDP";
    }else if (/^\/product\/prd-(.*)/.test(uri)){
      return "PDP";
    }else if (/^\/checkout\/shopping_cart\.jsp/.test(uri)){
      return "Cart";
    }else if (/(^\/$)|(^\/\?(.*))/.test(uri)){
      return "Home";
    }else{
      return "";
    }
  }

  function formatDate(date){
    return date.getFullYear() + formatMonthDay(date.getMonth() + 1) + formatMonthDay(date.getDate());
  }

  function formatMonthDay(val){
    var strVal = '' + val;
    return (strVal.length > 1) ? strVal: ('0' + strVal);
  }

  function suppressMessageForDay(){
    var now = new Date();
    var oneDayFromNow = new Date(now.getTime() + 86400000);//24hours

    //TODO: change from 5 min to 24 hours before going to prod
    //var oneDayFromNow = new Date(now.getTime() + 300000);//5 minutes
    var expirationTime = oneDayFromNow.toUTCString();
    document.cookie = 'z1_s2=true; expires=' + expirationTime + '; path=/';
  }

  function isMessagingEnabled(){
    if (getCookieValue('z1_s2') == 'true'){
      debugLog('z1 messaging is suppressed');
      return false;
    }
    return z1LoyaltyFeatureEnabled;
  }

  function showApplyDiscountModal(){
    var i = 0;
    var applyKcInterval = setInterval(function(){
      if ($('#id_KohlsCashDiscountApply').length > 0){
        clearInterval(applyKcInterval);
        $('#id_KohlsCashDiscountApply').trigger('click');
      }
      i++;
      if (i >= 30){//15 seconds
        clearInterval(applyKcInterval);
      }
    }, 500);
  }

  $.getScript(kohlsData.zineOnePath, function(){
    if (location.pathname == '/checkout/shopping_cart.jsp' && location.search.indexOf('showApplyModal=true') > -1){
      debugLog('showing apply discount modal');
      showApplyDiscountModal();
    }else{
      debugLog('checking if z1 is enabled');
      if (isMessagingEnabled() || debug){
        init();
      }
    }
  });

})();
