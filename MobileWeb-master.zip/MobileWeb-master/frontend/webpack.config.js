const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const ManifestPlugin = require('webpack-manifest-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

const path = require('path');

// These entries will be used as the starting point to build bundle for the page.
// The path will be dervied by prepending './src/' and appending '.js'
const bundleEntries = [
  'pdp/pdp-server-main',
  'pdp/pdp-client-main',
  'pdp/pdp-deferred',
  'pmp/pmp-server-app',
  'pmp/pmp-client-app',
  'pmp/pmp-deferred',
  'pmp/morelikethis-client-app',
  'review/review-client-main',
  'header/header-server-main',
  'header/header-client-main',
  'header/css-bundle',
  'wallet/m-wallet_integration',
  'account/reset-pwd/reset-client-main',
  'checkout/checkout-hybrid-util',
  'manage/manage-client-main',
  'orderSummary/orderSummary-client-main',
  'purchaseHistory/purchaseHistory-client-main',
  'rewards/rewards-util-bridge',
  'footer/app',
  'homepage/home-page-deferred',
  'content/content-deferred',
  'checkout/checkout-deferred',
  'shopMyStore/storeLocator-client-main',
  'server/registry-proxy-adapter',
  'registryLanding/registry-client-main',
  'registryLanding/registry-css-bundle',
  'registryProxy/registry-client-main'
];

const webpackEntries = {};
bundleEntries.map(entry => webpackEntries[entry] = `./src/${entry}.js`);

let prodMode = false;
// if -p was passed as arg, prodMode = true
process.argv.map(arg => prodMode = prodMode ? true : arg === '-p');
console.log('prodMode: ' + prodMode);

const cssBundlePattern = prodMode ? 'css/[name]-rev-[contenthash].css' : 'css/[name].css';
const extractCSS = new ExtractTextPlugin(cssBundlePattern);

const publicFolder = 'public'
const distFolder = prodMode ? '/dist' : '/dev-dist';
const internalPath =  publicFolder + distFolder;

module.exports = {
  entry: webpackEntries,
  output: {
    filename: prodMode ? '[name]-bundle-rev-[chunkhash].js' : '[name]-bundle.js',
    chunkFilename: prodMode ? '[id]-bundle-rev-[chunkhash].js' : '[id]-bundle.js',
    path: path.resolve(__dirname, internalPath),
    publicPath : distFolder + '/'
  },
  externals: {
    'react': 'React',
    'react-dom': 'ReactDOM',
    'jquery': '$'
  },
  module: {
    rules: [
      {
        test: /\.(png|jpg|gif)$/,
        use: "file-loader?name=images/[name]-rev-[hash:6].[ext]"
      },
      {
        test: /\.css$/,
        use: extractCSS.extract({
          fallback: "style-loader",
          use: "css-loader"
        })
      },
      {
        test: /\.js$/,
        use: [{
          loader: 'babel-loader',
          options: {
            presets: [
              ['es2015',  'react' ]
            ]
          }
        }]
      }
    ]
  },
  plugins: [
    extractCSS,
    new ManifestPlugin(),
    new CleanWebpackPlugin([internalPath], {})
  ]
};
