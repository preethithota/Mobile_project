package com.kohls.mobile.web.service;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

import com.kohls.mobile.web.dto.MobileWebRequestContext;

public class TestRedisCacheService {
	
	@Mock
	private ConfigurationService configurationService;
	
	@InjectMocks 
	private RedisCacheService redisCacheService = new RedisCacheService();
	
	MobileWebRequestContext context;
	
	@Before
	public void init() throws Exception{
		
		MockitoAnnotations.initMocks(this);
		context = new MobileWebRequestContext(false, "", false, null, "", "");
	}
	
	@Ignore
	@Test
	public void test() throws Exception{
		
		String connectionString = "redis-sentinel://localhost:26381,localhost:26380,localhost:26379/0#mymaster";
		when(configurationService.isRedisEnabled()).thenReturn(true);
		when(configurationService.getInt("redis.timeout.seconds")).thenReturn(1);
		when(configurationService.getString("redis.connectionstring")).thenReturn(connectionString);
		
		redisCacheService.init();
		String testKey = "test-key123", testValue = "test-value123";
		redisCacheService.set(testKey, testValue, context);
		String valueFromRedis = redisCacheService.get(testKey, context);
		
		assertEquals(valueFromRedis, testValue);
	}

}
