package com.kohls.mobile.web.service;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.request.CatalogServiceRequest;

public class TestCatalogService {
	
    @Mock
    private ConfigurationService configurationService;
	
    @InjectMocks 
    private CatalogService catalogService;
	
	MobileWebRequestContext mobileWebRequestContext;

	@Before
	public void init() throws Exception{
		MockitoAnnotations.initMocks(this);
		catalogService.init();
		mobileWebRequestContext = new MobileWebRequestContext(false, "", false, null, "", "");
	}
	
	@Test
	public void testGetBackendPath() throws Exception{
		String incommingQs = "CN=Gender:Mens+Category:Outerwear+Department:Clothing&cc=mens-TN2.0-S-coatsjackets&fromMenu=true";
		String incommingUri = "CN=Gender:Mens+Category:Outerwear+Department:Clothing&cc=mens-TN2.0-S-coatsjackets&fromMenu=true";
		CatalogServiceRequest catalogServiceRequest = new CatalogServiceRequest(incommingUri, incommingQs, null, true, "24", null, null, null);
		//String expectedBackendPath = "/v1/catalog/?dimensionValueID=Gender%3AMens%2BCategory%3AOuterwear%2BDepartment%3AClothing&isSolr=true&limit=24";
		String expectedBackendPath = "/v1/catalog/?isSolr=true&limit=24&dimensionValueID=Gender%3AMens%2BCategory%3AOuterwear%2BDepartment%3AClothing";
		String actualPath = catalogService.getBackendPath(catalogServiceRequest, mobileWebRequestContext);
		System.out.println("actualPath is " + actualPath);
		assertEquals(actualPath, expectedBackendPath);
	}
//	
//	@Test
//	public void testSolrGetCNParam3() throws Exception{
//		//String testQs = "CN=Gender:Womens+Discount:10%25%20off%20or%20more";
//		String testQs = "CN=Gender:Womens+Discount:10%25%20off%20or%20more&BL=y&S=0&WS=0";
//		//String expectedString = "?dimensionValueID=Gender:Womens+Discount:10%25%20off%20or%20more";
//		String expectedString = "?dimensionValueID=Gender:Womens+Discount:10%25%20off%20or%20more";
//		String output = catalogService.getCNParam(testQs, mobileWebRequestContext);
//		System.out.println("testSolrGetCNParam1 output is " + output);
//		assertEquals(output, expectedString);
//	}

	@Test
	public void testSolrGetCNParam1() throws Exception{
		String testQs = "CN=Category:Cutlery%20%26%20Knives+Department:Kitchen%20%26%20Dining&cc=for_thehome-TN3.0-S-CutleryKnives";
		//String expectedString = "?dimensionValueID=Category%3ACutlery%20%26%20Knives%2BDepartment%3AKitchen%20%26%20Dining";
		String expectedString = "dimensionValueID=Category%3ACutlery%20%26%20Knives%2BDepartment%3AKitchen%20%26%20Dining";
		String output = catalogService.getCNParam(testQs, mobileWebRequestContext);
		//System.out.println("testSolrGetCNParam1 output is " + output);
		assertEquals(output, expectedString);
	}
	
	@Test
	public void testSolrGetCNParam2() throws Exception{
		String testQs = "CN=Category:Cutlery%20%26%20Knives";	
		//String expectedString = "?dimensionValueID=Category%3ACutlery%20%26%20Knives";
		String expectedString = "dimensionValueID=Category%3ACutlery%20%26%20Knives";
		String output = catalogService.getCNParam(testQs, mobileWebRequestContext);
		//System.out.println("testSolrGetCNParam2 output is " + output);
		assertEquals(output, expectedString);
	}
	
	@Test
	public void testEndecaGetCNParam() throws Exception{
		String testQs = "CN=4294719935+4294718226+4294719526+4294719810&S=0&WS=1";
		//String expectedString = "?dimensionValueID=4294719935%2B4294718226%2B4294719526%2B4294719810";
		String expectedString = "dimensionValueID=4294719935%2B4294718226%2B4294719526%2B4294719810";
		String output = catalogService.getCNParam(testQs, mobileWebRequestContext);
		//System.out.println("testEndecaGetCNParam output is " + output);
		assertEquals(expectedString, output);
	}
	
	@Test
	public void testEndecaGetCNParam3() throws Exception{
		String testQs = "N=3000064450";
		//String expectedString = "?dimensionValueID=3000064450";
		String expectedString = "dimensionValueID=3000064450";
		String output = catalogService.getCNParam(testQs, mobileWebRequestContext);
		assertEquals(expectedString, output);
	}
	
	@Test
	public void testEndecaGetCNParam4() throws Exception{
		String testQs = "CN=4294723349+4294715833+4294737442+4294719805+4294719810&N=4294723349+4294721600+4294715833+4294737442+4294719805+4294719810";
		//String expectedString = "?dimensionValueID=4294723349%2B4294715833%2B4294737442%2B4294719805%2B4294719810%2B4294723349%2B4294721600%2B4294715833%2B4294737442%2B4294719805%2B4294719810";
		String expectedString = "dimensionValueID=4294723349%2B4294715833%2B4294737442%2B4294719805%2B4294719810%2B4294723349%2B4294721600%2B4294715833%2B4294737442%2B4294719805%2B4294719810";
		String output = catalogService.getCNParam(testQs, mobileWebRequestContext);
		assertEquals(expectedString, output);
	}	

}
