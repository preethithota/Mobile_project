package com.kohls.mobile.web.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class TestCachePurgeService {

	CachePurgeService cachePurgeService;
	
	@Before
	public void init(){
		cachePurgeService = new CachePurgeService();
	}
	
	@Test
	public void testGetUrisToPurge() throws Exception{
		String payload = "{\"Keys\":[\"KOHLS_WCS_/home?channel=tablet&environment=stage\",\"KOHLS_WCS_/home-seo?channel=tablet&environment=stage\"]}";
		List<String> uriList = cachePurgeService.getUrisToPurge(payload);
		assertEquals(uriList.size(), 2);
		assertTrue(uriList.contains("/home?channel=tablet&environment=stage"));
		assertTrue(uriList.contains("/home-seo?channel=tablet&environment=stage"));
	}
	
}
