package com.kohls.mobile.hystrix;

import java.util.concurrent.Future;
import static org.junit.Assert.*;

import org.junit.Test;

import com.kohls.mobile.command.ReadFromCacheCommand;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;

public class TestReadFromCacheCommand {
	
	@Test
	public void testTestReadFromCacheCommand() throws Exception{
		HystrixRequestContext context = HystrixRequestContext.initializeContext();
		try{
			String url = "http://abc.com";
			ReadFromCacheCommand readFromCacheCommand1 = new ReadFromCacheCommand(url, "mcom");
			Future<String> cacheResponse1 = readFromCacheCommand1.queue();
			
//	    	try{
//	    		Thread.sleep(1000);
//	    	}catch(Exception e){
//	    		System.out.println("Error " + e.getMessage());
//	    	}
			
			ReadFromCacheCommand readFromCacheCommand2 = new ReadFromCacheCommand(url, "tcom");
			Future<String> cacheResponse2 = readFromCacheCommand2.queue();
			
			ReadFromCacheCommand readFromCacheCommand3 = new ReadFromCacheCommand("http://def.com", "tcom");
			Future<String> cacheResponse3 = readFromCacheCommand3.queue();
			
			String result1 = cacheResponse1.get();
			String result2 = cacheResponse2.get();
			//assertEquals(result, "The url is " + url);
			System.out.println("result1 is " + result1);
			System.out.println("result2 is " + result2);
			assertTrue(result1.contains(url));
		}finally{
			context.shutdown();
		}
	}

}
