package com.kohls.mobile.hystrix;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestWriteToCacheCommand {
	
	@Test
	public void testReadFromCache() throws Exception{
		
	}
}
