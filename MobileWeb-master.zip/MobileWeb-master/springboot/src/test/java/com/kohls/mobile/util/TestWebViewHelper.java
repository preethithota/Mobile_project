package com.kohls.mobile.util;

import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.kohls.mobile.web.dto.SEOMetaData;

public class TestWebViewHelper {
	
	WebViewHelper webViewHelper;

	@Before
	public void init() throws Exception{
		webViewHelper = new WebViewHelper();
	}
	
	@Test
	public void testGetSEOData(){
		String pageUri = "/somePage";
		String queryString = "?param1=value1&param2=value2";
		SEOMetaData sEOMetaData = null;
		String searchTerm = "";
		boolean isTcom = false;
		
		webViewHelper.getSEOData(pageUri, queryString, isTcom, sEOMetaData, searchTerm);
	}
	
	@Test
	public void testGetCanonicalUrl1() throws Exception{
		String expectedString = "https://www.kohls.com/search.jsp?search=skinny+jeans";
		String output = webViewHelper.getCanonicalUrl("/search.jsp", "search=skinny+jeans");
		assertEquals(output, expectedString);
	}
	
	@Test
	public void testGetCanonicalUrl2() throws Exception{
		//String testUrl = "http://whatever.com/search.jsp?search=skinny+jeans&isFromSearch=true&submit-search=mobile-regular";
		String expectedString = "https://www.kohls.com/search.jsp?search=shirts";
		String output = webViewHelper.getCanonicalUrl("/search.jsp", "search=shirts&isFromSearch=true&submit-search=mobile-regular");
		assertEquals(output, expectedString);
	}
	
	@Test
	public void testGetAssetFileName() throws Exception{
		String webpackJson = "{\"0-bundle-rev-115477f4efdf921e2497.js\":\"0-bundle-rev-115477f4efdf921e2497.js\",\"1-bundle-rev-115477f4efdf921e2497.js\":\"1-bundle-rev-115477f4efdf921e2497.js\",\"2-bundle-rev-115477f4efdf921e2497.js\":\"2-bundle-rev-115477f4efdf921e2497.js\",\"3-bundle-rev-115477f4efdf921e2497.js\":\"3-bundle-rev-115477f4efdf921e2497.js\",\"4-bundle-rev-115477f4efdf921e2497.js\":\"4-bundle-rev-115477f4efdf921e2497.js\",\"5-bundle-rev-115477f4efdf921e2497.js\":\"5-bundle-rev-115477f4efdf921e2497.js\",\"6-bundle-rev-115477f4efdf921e2497.js\":\"6-bundle-rev-115477f4efdf921e2497.js\",\"account/reset-pwd/reset-client-main.js\":\"account/reset-pwd/reset-client-main-bundle-rev-115477f4efdf921e2497.js\",\"checkout/checkout-hybrid-util.js\":\"checkout/checkout-hybrid-util-bundle-rev-115477f4efdf921e2497.js\",\"footer/app.js\":\"footer/app-bundle-rev-115477f4efdf921e2497.js\",\"header/header-client-main.js\":\"header/header-client-main-bundle-rev-115477f4efdf921e2497.js\",\"header/header-server-main.js\":\"header/header-server-main-bundle-rev-115477f4efdf921e2497.js\",\"manage/manage-client-main.js\":\"manage/manage-client-main-bundle-rev-115477f4efdf921e2497.js\",\"orderSummary/orderSummary-client-main.js\":\"orderSummary/orderSummary-client-main-bundle-rev-115477f4efdf921e2497.js\",\"pdp/pdp-client-main.js\":\"pdp/pdp-client-main-bundle-rev-115477f4efdf921e2497.js\",\"pdp/pdp-server-main.js\":\"pdp/pdp-server-main-bundle-rev-115477f4efdf921e2497.js\",\"pmp/morelikethis-client-app.js\":\"pmp/morelikethis-client-app-bundle-rev-115477f4efdf921e2497.js\",\"pmp/pmp-client-app.js\":\"pmp/pmp-client-app-bundle-rev-115477f4efdf921e2497.js\",\"pmp/pmp-server-app.js\":\"pmp/pmp-server-app-bundle-rev-115477f4efdf921e2497.js\",\"purchaseHistory/purchaseHistory-client-main.js\":\"purchaseHistory/purchaseHistory-client-main-bundle-rev-115477f4efdf921e2497.js\",\"review/review-client-main.js\":\"review/review-client-main-bundle-rev-115477f4efdf921e2497.js\",\"rewards/rewards-util-bridge.js\":\"rewards/rewards-util-bridge-bundle-rev-115477f4efdf921e2497.js\",\"wallet/m-wallet_integration.js\":\"wallet/m-wallet_integration-bundle-rev-115477f4efdf921e2497.js\"}";
		String requestedPath ="manage/manage-client-main.js";
		String expectedPath = "manage/manage-client-main-bundle-rev-115477f4efdf921e2497.js";
		Map<String, String> assetMap = webViewHelper.getAssetMap(webpackJson);
		String result = assetMap.get(requestedPath);
		assertEquals(expectedPath, result);
		
		//String bundleName = "manage/manage-client-main.js";
		//String resourceType = "js";
		//String result = webViewHelper.getAssetFileName(webpackJson, bundleName, resourceType, false);
		//assertEquals("moreLikeThisClient-bundle.js", result);
		
	}
//	
//	@Test
//	public void testGetAssetFileNameWithProdBundles() throws Exception{
//		String webpackJson = "{\"headerClient\":{\"js\":\"/dist/headerClient-bundle-rev-b4eed4feba4ecc6950a3.js\"},\"headerServer\":{\"js\":\"/dist/headerServer-bundle-rev-a439aa8a5ca58d579c10.js\"},\"manageOrderClient\":{\"js\":\"/dist/manageOrderClient-bundle-rev-ced184a1e57f8c54100e.js\"},\"monetizationClient\":{\"js\":\"/dist/monetizationClient-bundle-rev-ab052c5cdaa9b9149406.js\"},\"moreLikeThisClient\":{\"js\":\"/dist/moreLikeThisClient-bundle-rev-120551db32d79d31612c.js\"},\"pdpClient\":{\"js\":\"/dist/pdpClient-bundle-rev-36beb826790f276060e8.js\"},\"pdpServer\":{\"js\":\"/dist/pdpServer-bundle-rev-03c8054c7fe521f188f0.js\"},\"pmpClient\":{\"js\":\"/dist/pmpClient-bundle-rev-5f548edfc76a04b1e56b.js\"},\"pmpServer\":{\"js\":\"/dist/pmpServer-bundle-rev-a27c13fdf63540727b48.js\"},\"resetClient\":{\"js\":\"/dist/resetClient-bundle-rev-25b60d09cd7f6b579fde.js\"},\"reviewClient\":{\"js\":\"/dist/reviewClient-bundle-rev-205db505c7632daa75ce.js\"},\"vendor\":{\"js\":\"/dist/vendor-bundle-rev-7016f768828e304d1a66.js\"},\"walletClient\":{\"js\":\"/dist/walletClient-bundle-rev-d0cd9641fb9658e4c96c.js\"}}";
//		String bundleName = "pdpServer";
//		String resourceType = "js";
//		String result = webViewHelper.getAssetFileName(webpackJson, bundleName, resourceType, true);
//		assertEquals("pdpServer-bundle-rev-03c8054c7fe521f188f0.js", result);
//	}	
//	
	
	
//	@Test
//	public void testGetAssetFileName() throws Exception{
//		String webpackJson = "{\"headerClient\":{\"js\":\"/dist/headerClient-bundle-rev-b4eed4feba4ecc6950a3.js\"},\"headerServer\":{\"js\":\"/dist/headerServer-bundle-rev-a439aa8a5ca58d579c10.js\"},\"manageOrderClient\":{\"js\":\"/dist/manageOrderClient-bundle-rev-ced184a1e57f8c54100e.js\"},\"monetizationClient\":{\"js\":\"/dist/monetizationClient-bundle-rev-ab052c5cdaa9b9149406.js\"},\"moreLikeThisClient\":{\"js\":\"/dist/moreLikeThisClient-bundle-rev-120551db32d79d31612c.js\"},\"pdpClient\":{\"js\":\"/dist/pdpClient-bundle-rev-36beb826790f276060e8.js\"},\"pdpServer\":{\"js\":\"/dist/pdpServer-bundle-rev-03c8054c7fe521f188f0.js\"},\"pmpClient\":{\"js\":\"/dist/pmpClient-bundle-rev-5f548edfc76a04b1e56b.js\"},\"pmpServer\":{\"js\":\"/dist/pmpServer-bundle-rev-a27c13fdf63540727b48.js\"},\"resetClient\":{\"js\":\"/dist/resetClient-bundle-rev-25b60d09cd7f6b579fde.js\"},\"reviewClient\":{\"js\":\"/dist/reviewClient-bundle-rev-205db505c7632daa75ce.js\"},\"vendor\":{\"js\":\"/dist/vendor-bundle-rev-7016f768828e304d1a66.js\"},\"walletClient\":{\"js\":\"/dist/walletClient-bundle-rev-d0cd9641fb9658e4c96c.js\"}}";
//		String bundleName = "moreLikeThisClient";
//		String resourceType = "js";
//		String result = webViewHelper.getAssetFileName(webpackJson, bundleName, resourceType, false);
//		assertEquals("moreLikeThisClient-bundle.js", result);
//	}
	
//	@Test
//	public void testGetAssetFileNameWithProdBundles() throws Exception{
//		String webpackJson = "{\"headerClient\":{\"js\":\"/dist/headerClient-bundle-rev-b4eed4feba4ecc6950a3.js\"},\"headerServer\":{\"js\":\"/dist/headerServer-bundle-rev-a439aa8a5ca58d579c10.js\"},\"manageOrderClient\":{\"js\":\"/dist/manageOrderClient-bundle-rev-ced184a1e57f8c54100e.js\"},\"monetizationClient\":{\"js\":\"/dist/monetizationClient-bundle-rev-ab052c5cdaa9b9149406.js\"},\"moreLikeThisClient\":{\"js\":\"/dist/moreLikeThisClient-bundle-rev-120551db32d79d31612c.js\"},\"pdpClient\":{\"js\":\"/dist/pdpClient-bundle-rev-36beb826790f276060e8.js\"},\"pdpServer\":{\"js\":\"/dist/pdpServer-bundle-rev-03c8054c7fe521f188f0.js\"},\"pmpClient\":{\"js\":\"/dist/pmpClient-bundle-rev-5f548edfc76a04b1e56b.js\"},\"pmpServer\":{\"js\":\"/dist/pmpServer-bundle-rev-a27c13fdf63540727b48.js\"},\"resetClient\":{\"js\":\"/dist/resetClient-bundle-rev-25b60d09cd7f6b579fde.js\"},\"reviewClient\":{\"js\":\"/dist/reviewClient-bundle-rev-205db505c7632daa75ce.js\"},\"vendor\":{\"js\":\"/dist/vendor-bundle-rev-7016f768828e304d1a66.js\"},\"walletClient\":{\"js\":\"/dist/walletClient-bundle-rev-d0cd9641fb9658e4c96c.js\"}}";
//		String bundleName = "pdpServer";
//		String resourceType = "js";
//		String result = webViewHelper.getAssetFileName(webpackJson, bundleName, resourceType, true);
//		assertEquals("pdpServer-bundle-rev-03c8054c7fe521f188f0.js", result);
//	}
	
	/*
	@Test
	@Ignore //TODO: Add mocking
	public void testGetJsBundleMapsWithProdBundles() throws Exception{
		String webpackJson = "{\"headerClient\":{\"js\":\"/dist/headerClient-bundle-rev-b4eed4feba4ecc6950a3.js\"},\"headerServer\":{\"js\":\"/dist/headerServer-bundle-rev-a439aa8a5ca58d579c10.js\"}}";
		boolean useProdBundles = true;

		//TODO: need to mock configurationService to complete this call
		Map<String, String> jsBundleMap = webViewHelper.getJsBundleMap(webpackJson, useProdBundles);
		assertEquals("headerClient-bundle-rev-b4eed4feba4ecc6950a3.js", jsBundleMap.get("headerClient"));
		assertEquals("headerServer-bundle-rev-a439aa8a5ca58d579c10.js", jsBundleMap.get("headerServer"));
	}
	
	@Test
	@Ignore //TODO: Add mocking
	public void testGetJsBundleMapsWithDevBundles() throws Exception{
		String webpackJson = "{\"headerClient\":{\"js\":\"/dist/headerClient-bundle-rev-b4eed4feba4ecc6950a3.js\"},\"headerServer\":{\"js\":\"/dist/headerServer-bundle-rev-a439aa8a5ca58d579c10.js\"}}";
		boolean useProdBundles = false;
		
		//TODO: need to mock configurationService to complete this call
		Map<String, String> jsBundleMap = webViewHelper.getJsBundleMap(webpackJson, useProdBundles);
		assertEquals("headerClient-bundle.js", jsBundleMap.get("headerClient"));
		assertEquals("headerServer-bundle.js", jsBundleMap.get("headerServer"));
		
	}	
	*/
	
}
