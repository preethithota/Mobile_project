package com.kohls.mobile.util;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Ignore;
import org.junit.Test;

public class TestSecurityUtils {
	
	@Test
	public void testGetRegistyHash(){
		String expectedHash = "d80e73854f0f771be41ebedae5832c8c";
		String actualHash = SecurityUtils.getRegistyHash("Brant", "Rouse", "brant.rouse@kohls.com");
		assertEquals(expectedHash, actualHash);
	}
	
	@Test
	public void testGetRegistyHash2(){
		String expectedHash = "adc5c7de13f226b08ad4c4c8b7deff7f";
		String actualHash = SecurityUtils.getRegistyHash("joe", "BLOW", "br23456@k.com");
		assertEquals(expectedHash, actualHash);
	}
	
	@Ignore
	@Test
	public void testGetHMACString() throws Exception{
		//String message = "POST 1461869207 ae5f1fe00c5db12cdb6fd71fecd793f85acdfe2a /payment/kohlspay/v1/sessions KAS-jdfadfdfkd123552dsfdg72 session.txt";
		//String message = "POST 1461869207 ae5f1fe00c5db12cdb6fd71fecd793f85acdfe2a /payment/kohlspay/v1/sessions KAS-jdfadfdfkd123552dsfdg72";
		String message = "POST1461869207ae5f1fe00c5db12cdb6fd71fecd793f85acdfe2a/payment/kohlspay/v1/sessionsKAS-jdfadfdfkd123552dsfdg72";
		String expectedHmac = "gOkvCfCep+m+AgJAk6GKEHUvmVixObHeLAEioCzdkY4=";
		String actualHmac = SecurityUtils.getHMACString(message);
		System.out.println("actualHmac: " + actualHmac);
		assertEquals(expectedHmac, actualHmac);
		
	}
	
	@Test
	public void testGetEpoch() throws Exception{
		String str = "April 01 2017 23:11:52.454 UTC";
	    SimpleDateFormat df = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");
	    Date date = df.parse(str);
	    long expectedEpoch = 1491088312454L;
	    assertEquals(expectedEpoch, SecurityUtils.getEpoch(date));
	}
	
}
