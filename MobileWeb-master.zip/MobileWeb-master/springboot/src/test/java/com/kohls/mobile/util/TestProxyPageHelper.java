package com.kohls.mobile.util;

//import static org.junit.Assert.assertEquals;
import static org.junit.Assert.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Test;

public class TestProxyPageHelper {

	@Test
	public void testGetProcessedRegistryPage(){
		String testInputHtml ="<html>"
				+ "<head>"				
				+ "<script src='scriptToRemove1.js'></script>"
				+ "<script src='scriptToRemove2.js'></script>"
				+ "<script src='scriptToKeep.js'></script>"
				+ "</head>"				
				+ "</html>";
		
		String elementsToRemove = "script[src=scriptToRemove1.js],script[src=scriptToRemove2.js]";
		String actualHtml = ProxyPageHelper.getProcessedRegistryPage(testInputHtml, elementsToRemove);
		Document actualDoc = Jsoup.parse(actualHtml);
		assertEquals(actualDoc.select("script[src=scriptToRemove1.js]").size(), 0);
		assertEquals(actualDoc.select("script[src=scriptToRemove2.js]").size(), 0);
		assertEquals(actualDoc.select("script[src=scriptToKeep.js]").size(), 1);
		//assertEquals(expectedHtml.replaceAll("\\s+",""), actualHtml.);
	}
}
