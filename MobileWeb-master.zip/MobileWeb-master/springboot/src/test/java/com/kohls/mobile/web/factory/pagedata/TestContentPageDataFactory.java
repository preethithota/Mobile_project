package com.kohls.mobile.web.factory.pagedata;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kohls.mobile.web.factory.pagedata.ContentPageDataFactory;

public class TestContentPageDataFactory {
	ContentPageDataFactory contentPageDataFactory;
	
	@Before
	public void init(){
		contentPageDataFactory = new ContentPageDataFactory();
	}
	
	@Test
	public void testGetSeoUrl() throws Exception{
		String contentUri = "/sale-event/mensclothing.jsp";
		String expectedUri = "/sale-event/mensclothing-seo";
		String actualUri = contentPageDataFactory.getSeoUrl(contentUri);
		assertEquals(actualUri, expectedUri);
	}
	
	@Test
	public void testGetSeoUrl2() throws Exception{
		String contentUri = "/sale-event/mensclothing.jsp";
		String expectedUri = "/sale-event/mensclothing-seo";
		String actualUri = contentPageDataFactory.getSeoUrl(contentUri);
		assertEquals(actualUri, expectedUri);
	}	

}
