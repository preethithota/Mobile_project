package com.kohls.mobile.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestUtils {
	
	String paramName = "search";
	String paramValue = "newSearchTerm";

	
	@Test
	public void testReplaceQueryStringParam1() throws Exception{
		String queryString = "?a=b";
		String expectedQueryString = queryString + "&" + paramName + "=" + paramValue;
		String actualQueryString = Utils.replaceQueryStringParam(queryString, paramName, paramValue);
		assertEquals(actualQueryString, expectedQueryString);
	}
	
	@Test
	public void testReplaceQueryStringParam2() throws Exception{
		String queryString = "?a=b&search=oldSearchTerm&d=f";
		String expectedQueryString = "?a=b&search=newSearchTerm&d=f";
		String actualQueryString = Utils.replaceQueryStringParam(queryString, paramName, paramValue);
		assertEquals(actualQueryString, expectedQueryString);
	}
	
	@Test
	public void testReplaceQueryStringParam3() throws Exception{
		String queryString = "?a=b&d=f&search=oldSearchTerm";
		String expectedQueryString = "?a=b&d=f&search=newSearchTerm";
		String actualQueryString = Utils.replaceQueryStringParam(queryString, paramName, paramValue);
		assertEquals(actualQueryString, expectedQueryString);
	}
	
	@Test
	public void testReplaceQueryStringParam4() throws Exception{
		String queryString = "a=b";
		String expectedQueryString = "?a=b&" + paramName + "=" + paramValue;
		String actualQueryString = Utils.replaceQueryStringParam(queryString, paramName, paramValue);
		assertEquals(actualQueryString, expectedQueryString);
	}
	
	@Test
	public void testReplaceQueryStringParam5() throws Exception{
		String queryString = "";
		String expectedQueryString = "?&" + paramName + "=" + paramValue;
		String actualQueryString = Utils.replaceQueryStringParam(queryString, paramName, paramValue);
		assertEquals(actualQueryString, expectedQueryString);
	}		
	

}
