package com.kohls.mobile.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.service.HttpService;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandProperties;

//TODO: combine this with CatalogRequestCommand
public class ProductRequestCommand extends HystrixCommand<String>{
	
	private static final Logger logger = LogManager.getLogger(ProductRequestCommand.class.getName());
	
	private final String backendPath;
	private final MobileWebRequestContext context;
	private final HttpService httpService;


    public ProductRequestCommand(String backendPath, MobileWebRequestContext context, HttpService httpService) {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("ProductServiceRequestCommand"))
                .andCommandPropertiesDefaults(HystrixCommandProperties.Setter()
                       .withExecutionTimeoutInMilliseconds(30 * 1000)));
        
    	this.backendPath = backendPath;
    	this.context = context;
    	this.httpService = httpService;
    }
    
    @Override
    protected String run() {	
		try{
			return httpService.getFromPlatform(backendPath, context);
		}catch(Exception e){
			logger.error(Utils.getErrorMessage(context, "No data found for product request " + backendPath));
			throw new RuntimeException(e);
		}
    }
    
    @Override
    protected String getFallback() {
    	logger.warn(Utils.getErrorMessage(context, "Fallback triggered for ProductServiceRequestCommand"));
        return "{}";
    }
}
