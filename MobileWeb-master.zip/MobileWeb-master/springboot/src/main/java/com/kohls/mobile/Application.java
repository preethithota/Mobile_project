package com.kohls.mobile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.kohls.mobile.web.interceptor.MobileWebInterceptor;

@SpringBootApplication
public class Application extends WebMvcConfigurerAdapter{
	private static final Logger logger = LogManager.getLogger(Application.class.getName());
		
	@Autowired
	private MobileWebInterceptor mobileWebInterceptor;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		logger.debug("Spring application context loaded");
	}
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(mobileWebInterceptor);
	}

}