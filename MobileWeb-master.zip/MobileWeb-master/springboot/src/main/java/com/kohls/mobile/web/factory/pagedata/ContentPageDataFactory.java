package com.kohls.mobile.web.factory.pagedata;

import java.util.concurrent.Future;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.command.ContentRequestCommand;
import com.kohls.mobile.web.dto.ContentPageData;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.backend.ContentBackendData;
import com.kohls.mobile.web.service.CacheService;
import com.kohls.mobile.web.service.WCSService;

@Component
public class ContentPageDataFactory extends AbstractPageDataFactory<ContentPageData, ContentBackendData, String> {
	
	private static final Logger logger = LogManager.getLogger(ContentPageDataFactory.class.getName());
	
	@Autowired
	private WCSService wCSService;
	
	@Autowired
	private CacheService cacheService;
		
	public ContentPageData getPageData(MobileWebRequestContext context, String pageName, String contentUri){
		return super.getPageData(context, pageName, contentUri);
	}
	
	@Override
	protected ContentBackendData getBackendData(MobileWebRequestContext context, String contentUri){
		String seoUri = getSeoUrl(contentUri);
		
		Future<String> pageContentRequestFuture = null, seoContentRequestFuture = null;
		
		String pageContent = cacheService.getContent(contentUri, context);
		String sEOContent = cacheService.getContent(seoUri, context);
		
		//queue up pageContentRequestCommand and seoContentRequestCommand so both requests execute in parallel
		if (pageContent == null){
			ContentRequestCommand pageContentRequestCommand = new ContentRequestCommand(context, contentUri, wCSService);
			pageContentRequestFuture = pageContentRequestCommand.queue();
		}
		
		if (sEOContent == null){
			ContentRequestCommand seoContentRequestCommand = new ContentRequestCommand(context, seoUri, wCSService);
			seoContentRequestFuture = seoContentRequestCommand.queue();	
		}
		
		if (pageContentRequestFuture != null){
			try{
				pageContent = pageContentRequestFuture.get();
			}catch(Exception e){
				logger.error("Error getting page content for: {} :{}", contentUri, e.getMessage());
				pageContent = "";
			}		
		}
	
		if (seoContentRequestFuture != null){
			try{
				sEOContent = seoContentRequestFuture.get();
			}catch(Exception e){
				logger.error("Error getting seo content for: {} :{}", seoUri, e.getMessage());
				sEOContent = "";
			}	
		}
		
		if (pageContent != null && pageContentRequestFuture != null){
			cacheService.putContent(contentUri, pageContent, context);
		}
		
		if (sEOContent != null && seoContentRequestFuture != null){
			cacheService.putContent(seoUri, sEOContent, context);
		}
		
		ContentBackendData contentBackendData = new ContentBackendData(pageContent, sEOContent);
		return contentBackendData;
	}
	
	@Override
	protected ContentPageData buildPageData(PageData genericPageData, ContentBackendData contentBackendData, MobileWebRequestContext context){
		return new ContentPageData(genericPageData, contentBackendData.getSEOContent(), contentBackendData.getPageContent());		
	}
	
	protected String getSeoUrl(String contentUri){		
		String seoSuffix = "-seo";
		int jspIndex = contentUri.indexOf(".jsp");
	
		if (jspIndex > -1){
			contentUri = contentUri.substring(0, jspIndex);
		}
		return contentUri + seoSuffix;
	}
}
