package com.kohls.mobile.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class ProxyPageHelper {
	
	private static final Logger logger = LogManager.getLogger(ProxyPageHelper.class.getName());
	
	public static String getProcessedRegistryPage(String origHtml, String elementsToRemove){
		Document document = Jsoup.parse(origHtml);
		
		String[] elementsToRemoveArr = elementsToRemove.split(",");
		for (String elementToRemove: elementsToRemoveArr){
			document.select(elementToRemove.trim()).remove();
		}
		
		String docStr = document.toString();
		logger.debug("docStr is " + docStr);
		return docStr; 
	}
	
}
