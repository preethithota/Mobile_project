package com.kohls.mobile.web.scripting;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class RegistryScriptEngine extends BaseScriptEngine{
	
	private static final Logger logger = LogManager.getLogger(RegistryScriptEngine.class.getName());
	
	@PostConstruct
	protected void init() throws Exception{
		invocable = getInvocable("server/registry-proxy-adapter.js");
	}
	
	public String getRegistryPageHead(String inputHtml, boolean isTcom){
		try{
			Object html = invocable.invokeFunction("getRegistryPageHead", inputHtml, logger.isDebugEnabled(), isTcom);
			return String.valueOf(html);
		}catch(Exception e){
			logger.error("Error in getRegistryPageBody ", e);
		}
		return null;
	}
	
	public String getRegistryPageBody(String inputHtml, boolean isTcom) {
		try{
			Object html = invocable.invokeFunction("getRegistryPageBody", inputHtml, logger.isDebugEnabled(), isTcom);
			return String.valueOf(html);
		}catch(Exception e){
			logger.error("Error in getRegistryPageBody ", e);
		}
		return null;
	}
	
	public String getRegistryProfileData(String registryHash, String mspProfileData, boolean isTcom) {
		try{
			Object html = invocable.invokeFunction("getRegistryProfileData", registryHash, mspProfileData, logger.isDebugEnabled(), isTcom);
			return String.valueOf(html);
		}catch(Exception e){
			logger.error("Error in getRegistryProfileData ", e);
		}
		return null;
	}

}
