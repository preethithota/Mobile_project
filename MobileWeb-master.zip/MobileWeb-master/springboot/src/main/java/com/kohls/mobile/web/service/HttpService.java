package com.kohls.mobile.web.service;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.kohls.mobile.exception.PlatformException;
import com.kohls.mobile.util.Constants;
import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.OapiResponse;

@Service
public class HttpService {
	
	private static final Logger logger = LogManager.getLogger(HttpService.class.getName());
	
	@Autowired
	private ConfigurationService configurationService;
	
	public String getFromPlatform(String uri, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		return getFromPlatform(uri, null, mobileWebRequestContext);
	}
	
	public String getFromPlatform(String uri, Map<String, String> additionalHeaders, MobileWebRequestContext mobileWebRequestContext) throws Exception{		
		return requestToPlatform(uri, null, additionalHeaders, HttpMethod.GET, mobileWebRequestContext);
	}
	
	public String postToPlatform(String uri, String body, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		return postToPlatform(uri, body, null, mobileWebRequestContext);
	}
	
	public String postToPlatform(String uri, String body, Map<String, String> additionalHeaders, MobileWebRequestContext mobileWebRequestContext) throws Exception{						
		return requestToPlatform(uri, body, additionalHeaders, HttpMethod.POST, mobileWebRequestContext);
	}
	
	public String putToPlatform(String uri, String body, Map<String, String> additionalHeaders, MobileWebRequestContext mobileWebRequestContext) throws Exception{						
		return requestToPlatform(uri, body, additionalHeaders, HttpMethod.PUT, mobileWebRequestContext);
	}
	
	public String deleteFromPlatform(String uri, Map<String, String> additionalHeaders, MobileWebRequestContext mobileWebRequestContext) throws Exception{						
		return requestToPlatform(uri, null, additionalHeaders, HttpMethod.DELETE, mobileWebRequestContext);
	}
	
	public String getFromSkavaSite(MobileWebRequestContext context, String uri, String queryString, Map<String, String> additionalHeaders) throws Exception{
		String baseUrl = configurationService.getString((context.isTcom() ? "tcom" : "mcom") + ".skava.url");
		String url = baseUrl + uri;
		
		// this is necessary to ensure we're not redirecting to ourself
		queryString = ((queryString == null || "".equals(queryString)) ? "?" : "&") + Constants.PROXY_PARAM + "=true";

		HttpMethod getMethod = HttpMethod.GET;
		Request httpRequest = getRequest(getMethod, url, null, additionalHeaders, context);
		logger.info(getHttpLogMessage(url, getMethod, context));
		
		Instant t1 = Instant.now();
		String response = httpRequest.execute().handleResponse(getResponseHandler(url, getMethod, context, t1));
		long durationInMs = Duration.between(t1, Instant.now()).toMillis();
		logger.debug("Request completed to after {}ms", durationInMs);
		return response;
	}
	
	public String requestToPlatform(String uri, String body, Map<String, String> additionalHeaders, HttpMethod method, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String baseUrl = configurationService.getConfiguration().getString("msp.platform.baseurl");
		String url = baseUrl + uri;
		//TODO: remove this
//		if (uri.contains("/v1/loyalty")){
//			url = "http://localhost:8989" + uri;
//		}
		
		if (additionalHeaders != null){
			additionalHeaders.put("origin", baseUrl);
		}
		
		Request httpRequest = getRequest(method, url, body, additionalHeaders, mobileWebRequestContext);
		logger.info(getHttpLogMessage(url, method, mobileWebRequestContext));
		
		Instant t1 = Instant.now();
		String response = httpRequest.execute().handleResponse(getResponseHandler(url, method, mobileWebRequestContext, t1));
		long durationInMs = Duration.between(t1, Instant.now()).toMillis();
		logger.debug("Request completed to after {}ms", durationInMs);
		return response;
	}
	
	private ResponseHandler<String> getResponseHandler(String url, HttpMethod method, MobileWebRequestContext context, Instant t1){
		return new ResponseHandler<String>(){
			@Override
			public String handleResponse(final HttpResponse response) throws IOException{
		        StatusLine statusLine = response.getStatusLine();
		        HttpEntity entity = response.getEntity();
		        if (statusLine.getStatusCode() >= 300) {
		        	long durationInMs = Duration.between(t1, Instant.now()).toMillis();
		        	String resStr = EntityUtils.toString(entity, Constants.UTF8);
		        	String message = String.format("Error - CID: %s, url: %s, status: %s, duration:, %sms , error: %s, response: %s", context.getCorrelationId(), 
		        			url, statusLine.getStatusCode(), durationInMs, statusLine.getReasonPhrase(), resStr);
		        	logger.error(message);
		        	throw new PlatformException(message, String.valueOf(statusLine.getStatusCode()));
		        }
		        return EntityUtils.toString(entity, Constants.UTF8);
			}
		};
	}
	
	private Request getRequest(HttpMethod httpMethod, String url, String body, Map<String, String> additionalHeaders, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		Request request;
		if (httpMethod == HttpMethod.POST){
			request = Request.Post(url);
		}else if (httpMethod == HttpMethod.PUT){
			request = Request.Put(url);
		}else if (httpMethod == HttpMethod.DELETE){
			request = Request.Delete(url);
		}else{
			request = Request.Get(url);
		}
		
		if (body != null){
			request.body(new StringEntity(body));
		}
		
		if (additionalHeaders == null){
			additionalHeaders = new HashMap<String, String>();
		}
		
		if (additionalHeaders.get(Constants.COR_ID_KEY) == null){
			additionalHeaders.put(Constants.COR_ID_KEY, mobileWebRequestContext.getCorrelationId());
		}
		
		additionalHeaders.put("User-Agent", configurationService.getConfiguration().getString("platform.useragent"));
		
		Request updatedRequest = request.connectTimeout(configurationService.getConfiguration().getInt("http.connect.timeout")) //request.addHeader("Accept", "application/json")
			.socketTimeout(configurationService.getConfiguration().getInt("http.socket.timeout"));
		
		String acceptHeaderValue = Constants.APPLICATION_JSON;
		
		for (Map.Entry<String, String> entry : additionalHeaders.entrySet()) {
			if (Constants.ACCEPT.equalsIgnoreCase(entry.getKey())){
				acceptHeaderValue = entry.getValue();
				continue;
			}
			updatedRequest.addHeader(entry.getKey(), entry.getValue());
		}
		updatedRequest.addHeader(Constants.ACCEPT, acceptHeaderValue);

		if (configurationService.isProxyEnabled()){
			updatedRequest.viaProxy(new HttpHost(configurationService.getProxyHost(), configurationService.getProxyPort()));
		}
		
		return updatedRequest;
	}
	
	private String getHttpLogMessage(String url, HttpMethod method, MobileWebRequestContext mobileWebRequestContext){
		return Utils.getErrorMessage(mobileWebRequestContext, String.format("Url: %s, method: %s", url, method.toString()));
	}
	
	//TODO: everything below here should be removed
	//here
	public OapiResponse proxyOpenApiRequest(HttpMethod httpMethod, String uri, String body, Map<String, String> additionalHeaders, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String baseUrl = configurationService.getOpenApiBaseUrl().replace("http", "https");
		String url = baseUrl + uri;
		
		if (additionalHeaders.get(Constants.COR_ID_KEY) == null){
			additionalHeaders.put(Constants.COR_ID_KEY, mobileWebRequestContext.getCorrelationId());
			additionalHeaders.put(Constants.NEW_COR_ID_KEY, mobileWebRequestContext.getCorrelationId());
		}
		
		additionalHeaders.put("x-channel", mobileWebRequestContext.isTcom() ? "TCOM" : "MCOM");
		Request httpRequest = getRequest(httpMethod, url, body, additionalHeaders, mobileWebRequestContext);
		logger.info(getHttpLogMessage(url, httpMethod, mobileWebRequestContext));
		OapiResponse oapiResponse= httpRequest.execute().handleResponse(getOapiResponseHandler(url, httpMethod, mobileWebRequestContext));
//		Response response = httpRequest.execute();
//		Content content = response.returnContent();
		

		//return content.asString();
		return oapiResponse;
	}
	
	private ResponseHandler<OapiResponse> getOapiResponseHandler(String url, HttpMethod method, MobileWebRequestContext context){
		return new ResponseHandler<OapiResponse>(){
			@Override
			public OapiResponse handleResponse(final HttpResponse response) throws IOException{
		        StatusLine statusLine = response.getStatusLine();
		        HttpEntity entity = response.getEntity();
//		        if (statusLine.getStatusCode() >= 300) {
//		        	
//		        	String resStr = EntityUtils.toString(entity, Constants.UTF8);
////		        	String message = String.format("Error - CID: %s, url: %s, status: %s, duration:, %sms , error: %s, response: %s", context.getCorrelationId(), 
////		        			url, statusLine.getStatusCode(), durationInMs, statusLine.getReasonPhrase(), resStr);
//		        	logger.error("Error " + resStr);
//		        	//throw new PlatformException(message, String.valueOf(statusLine.getStatusCode()));
//		        }
		        return new OapiResponse(statusLine.getStatusCode(), EntityUtils.toString(entity, Constants.UTF8));
		        //return 
			}
		};
	}
	
	public String getOpenApiData(String uri, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		//String baseUrl = configurationService.isPocEnabled() ? configurationService.getConfiguration().getString("msp.platform.baseurl"): configurationService.getOpenApiBaseUrl();
		String baseUrl;
		if (configurationService.isPocEnabled() && (uri.indexOf("/v2/catalog/category") == 0 || uri.indexOf("/v1/catalog") == 0 || uri.indexOf("/v1/product/") == 0))  {
			baseUrl = configurationService.getConfiguration().getString("msp.platform.baseurl");
		}else{
			baseUrl = configurationService.getOpenApiBaseUrl();
		}
		
		String url = baseUrl + uri;
		Request httpRequest = Request.Get(url)
				.addHeader("X-APP-API_KEY", configurationService.getOpenApiKey())
				.addHeader(Constants.ACCEPT, Constants.APPLICATION_JSON)
				.connectTimeout(10000)
				.socketTimeout(10000);
		if (configurationService.isProxyEnabled()){	
			httpRequest.viaProxy(new HttpHost(configurationService.getProxyHost(), configurationService.getProxyPort()));
		}

		logger.debug(getHttpLogMessage(url, HttpMethod.GET, mobileWebRequestContext));
		return httpRequest.execute().returnContent().asString();
	}
	
	//TODO: this method should be removed soon
	public String getOpenApiDataWithAccessToken(String url, String accessToken, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		Request httpRequest = Request.Get(url)
				.addHeader("X-APP-API_KEY", configurationService.getOpenApiKey())
				.addHeader(Constants.ACCEPT, Constants.APPLICATION_JSON)
				.connectTimeout(10000)
				.socketTimeout(10000);
		
		if (accessToken != null){
			httpRequest.addHeader("access_token", accessToken);
		}
		
		if (configurationService.isProxyEnabled()){
			httpRequest.viaProxy(new HttpHost(configurationService.getProxyHost(), configurationService.getProxyPort()));
		}
		logger.debug(getHttpLogMessage(url, HttpMethod.GET, mobileWebRequestContext));
		return httpRequest.execute().returnContent().asString();
	}

}
