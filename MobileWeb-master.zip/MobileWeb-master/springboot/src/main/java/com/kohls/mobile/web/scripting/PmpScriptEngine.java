package com.kohls.mobile.web.scripting;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

@Service
public class PmpScriptEngine extends BaseScriptEngine{
	
	@PostConstruct
	protected void init() throws Exception{
		invocable = getInvocable("pmp/pmp-server-app.js");
	}
	
	public String invokeFunction(String catalogData, boolean isTcom) throws Exception{
		return super.invokeFunction("renderServer", catalogData, isTcom);
	}	

}
