package com.kohls.mobile.web.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kohls.mobile.util.Constants;
import com.kohls.mobile.util.SecurityUtils;
import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.ProxyPageData;
import com.kohls.mobile.web.factory.pagedata.ProxyPageFactory;
import com.kohls.mobile.web.scripting.RegistryScriptEngine;
import com.kohls.mobile.web.service.HttpService;
import com.kohls.mobile.web.dto.RegistryPageData;
import com.kohls.mobile.web.factory.pagedata.RegistryPageDataFactory;

@Controller
public class RegistryProxyController {

	private static final Logger logger = LogManager.getLogger(RegistryScriptEngine.class.getName());

	private static final String[] forwardedHeaderNames = {"content-type", Constants.ACCEPT, "access_token"};

	@Autowired
	private HttpService httpService;

	@Autowired
	private WebViewHelper webViewHelper;

	@Autowired
	private RegistryScriptEngine registryScriptEngine;

	@Autowired
	private RegistryPageDataFactory registryPageDataFactory;

	@Autowired
	private ProxyPageFactory proxyPageFactory;



	@GetMapping(value={"/gift-registry/{pageName}","/gift-registry/{pageName}.jsp"})
	public ModelAndView getContentPage(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		try{
			String url = request.getRequestURI().replace("/gift-registry/","/feature/");
			System.out.println("Registry url::"+url);
			RegistryPageData registryPageData = registryPageDataFactory.getPageData(context, "registry_landng", url);
			return new ModelAndView("global-template", "pageData", registryPageData);
		}catch(Exception e){
			logger.error("Error in getRegistryPage: ", e);
			return webViewHelper.getErrorMv(request, e);
		}
	}

	@GetMapping(value={
		"/upgrade/gift_registry/kohlsgrw_home.jsp",
		"/upgrade/giftinglisting/wishlist.jsp"
	})
	public ModelAndView fetchProxyPages(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		//construct proxy url form request url
		String _requestURI = request.getRequestURI();
		if (request.getQueryString() != null) {
		   _requestURI =  _requestURI+"?"+request.getQueryString();
		}
		String completeURI = _requestURI.toString();

		if ("true".equals(request.getParameter(Constants.PROXY_PARAM))){
			logger.error(Utils.getErrorMessage(context, "Error attempting to proxy to self"));
			response.setStatus(400);
			return new ModelAndView("error", "errorData", "Error connecting to url "+completeURI+" with param: " + Constants.PROXY_PARAM);
		}

		String proxyRequest = completeURI;
		ProxyPageData proxyPageData = proxyPageFactory.getPageData(context, "registry_proxy", proxyRequest);
		return new ModelAndView("global-template", "pageData", proxyPageData);
	}

	@RequestMapping(value={"/skavastream/xact/v5/kohls/profile/get"}, method={RequestMethod.GET})
	@ResponseBody
	public String getRegistryProfile(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("mobileWebRequestContext")
		MobileWebRequestContext context) throws Exception{

		HashMap<String, String> additionalHeaders = getAdditionalHeaders(request);
		String accessToken = webViewHelper.getCookieValue("accessToken", request.getCookies());
		if (accessToken != null){
			additionalHeaders.put("access_token", accessToken);
		}

		try{
			String responseBody = httpService.getFromPlatform("/v1/profile", additionalHeaders, context);
			ObjectMapper objectMapper = new ObjectMapper();
	    	JsonNode rootNode = objectMapper.readTree(responseBody);
	    	JsonNode payloadNode = rootNode.get("payload");
	    	JsonNode profileNode = payloadNode.get("profile");
	    	String email = profileNode.get("email").asText();

	    	JsonNode customerNameNode = profileNode.get("customerName");
	    	String firstName = customerNameNode.get("firstName").asText();
	    	String lastName = customerNameNode.get("lastName").asText();

	    	String registryHash = SecurityUtils.getRegistyHash(firstName, lastName, email);
	    	return registryScriptEngine.getRegistryProfileData(registryHash, responseBody, context.isTcom());
		}catch(Exception e){
			logger.error("Error in getRegistryProfile", e);
			response.setStatus(500);
			return "Error getting profile";
		}

	}

	private HashMap<String, String> getAdditionalHeaders(HttpServletRequest request){
		HashMap<String, String> additionalHeaders = new HashMap<String, String>();
		for (String headerName: forwardedHeaderNames){
			String headerValue = request.getHeader(headerName);
			if (headerValue != null){
				additionalHeaders.put(headerName, headerValue);
			}
		}
		return additionalHeaders;
	}

}
