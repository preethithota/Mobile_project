package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.factory.pagedata.GenericPageDataFactory;
import com.kohls.mobile.web.service.WCSService;

/**
 * Created by tkmabj6 on 3/8/17.
 */
@Controller
public class CheckoutPageController {

    @Autowired
    private GenericPageDataFactory genericPageDataFactory;

    @Autowired
    WCSService wCSService;

    @SuppressWarnings("unused")
    private static final Logger logger = LogManager.getLogger(CatalogPageController.class.getName());
    
	@GetMapping(value={"checkout/checkout.jsp", "checkout/myaccount.jsp"})
    public ModelAndView getCheckoutPage(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context) 
    		throws Exception {
    	PageData pageData = genericPageDataFactory.getPageData(context, "checkout");
        return new ModelAndView("global-template", "pageData", pageData);
    }
}