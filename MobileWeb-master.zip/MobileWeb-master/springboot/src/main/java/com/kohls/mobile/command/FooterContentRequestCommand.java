package com.kohls.mobile.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.service.WCSService;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandProperties;
import com.netflix.hystrix.HystrixCommand.Setter;

public class FooterContentRequestCommand extends HystrixCommand<String>{
	
	private static final Logger logger = LogManager.getLogger(FooterContentRequestCommand.class.getName());
	private final MobileWebRequestContext context;
	private final WCSService wCSService;
	
    public FooterContentRequestCommand(MobileWebRequestContext context, WCSService wCSService) {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("FooterContentRequestCommand"))
                .andCommandPropertiesDefaults(HystrixCommandProperties.Setter()
                       .withExecutionTimeoutInMilliseconds(30 * 1000)));
    	this.context = context;
    	this.wCSService = wCSService;
    }

    @Override
    protected String run() {
    	String footerContent;
		try{
			footerContent = wCSService.getFooterContent(context);
		}catch(Exception e){
			footerContent = "";
			logger.error(Utils.getErrorMessage(context, "Exception getting footerContent: " + e.getMessage()));
		}
		return footerContent;
    }

}
