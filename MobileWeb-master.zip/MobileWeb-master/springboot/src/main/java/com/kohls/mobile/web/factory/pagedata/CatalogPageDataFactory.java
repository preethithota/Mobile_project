package com.kohls.mobile.web.factory.pagedata;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.CatalogPageData;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.SEOData;
import com.kohls.mobile.web.dto.backend.CatalogBackendData;
import com.kohls.mobile.web.request.CatalogServiceRequest;
import com.kohls.mobile.web.scripting.PmpScriptEngine;
import com.kohls.mobile.web.service.CacheService;
import com.kohls.mobile.web.service.CatalogService;

@Component
public class CatalogPageDataFactory extends AbstractPageDataFactory<CatalogPageData, CatalogBackendData, CatalogServiceRequest> {

	private static final Logger logger = LogManager.getLogger(CatalogPageDataFactory.class.getName());
	
	@Autowired
	private CatalogService catalogService;
	
	@Autowired
	private WebViewHelper webViewHelper;
	
	@Autowired
	private PmpScriptEngine pmpScriptEngine;
	
	@Autowired
	private CacheService cacheService;
	
	public CatalogPageData getPageData(MobileWebRequestContext context, String pageName, CatalogServiceRequest catalogServiceRequest){
		return super.getPageData(context, pageName, catalogServiceRequest);
	}
		
	@Override
	protected CatalogBackendData getBackendData(MobileWebRequestContext context, CatalogServiceRequest catalogServiceRequest){
		try{			
			return catalogService.getProducts(catalogServiceRequest, context);
		}catch(Exception e){
			logger.error(Utils.getErrorMessage(context, "Error in catalogPageDataFactory.getBackendData()"), e);
			return null;
		}
	}
	
	@Override
	protected CatalogPageData buildPageData(PageData genericPageData, CatalogBackendData catalogBackendData, MobileWebRequestContext context){
		
		SEOData sEOData = webViewHelper.getSEOData(context.getRequestUri(), context.getRequestQueryString(), context.isTcom(), 
				catalogBackendData.getsEOMetaData(), catalogBackendData.getSearchTerm());
		
		String bodyContent = cacheService.getPmpPage(catalogBackendData.getBackendUri(), context);
		if (bodyContent == null){
			bodyContent = getBodyHtml(catalogBackendData.getData(), context);
			if (bodyContent != null){
				cacheService.putPmpPage(catalogBackendData.getBackendUri(), bodyContent, context);
			}
		}
		
		CatalogPageData catalogPageData = new CatalogPageData(
				genericPageData, 
				bodyContent,
				catalogBackendData.getData(),
				sEOData,
				catalogBackendData);
		
		return catalogPageData;
	}
	
	private String getBodyHtml(String catalogData, MobileWebRequestContext context) {
		try {
			return pmpScriptEngine.invokeFunction(catalogData, context.isTcom());
		} catch (Exception ex) {
			logger.error(Utils.getErrorMessage(context, "Error catalogPageDataFactory.getBodyHtml"), ex);
		}
		return "";
	}
}
