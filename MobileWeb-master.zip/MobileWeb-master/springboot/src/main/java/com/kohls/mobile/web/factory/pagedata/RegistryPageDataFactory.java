package com.kohls.mobile.web.factory.pagedata;

import java.util.concurrent.Future;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.command.RegistryRequestCommand;
import com.kohls.mobile.web.dto.RegistryPageData;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.backend.RegistryBackendData;
import com.kohls.mobile.web.service.CacheService;
import com.kohls.mobile.web.service.WCSService;

@Component
public class RegistryPageDataFactory extends AbstractPageDataFactory<RegistryPageData, RegistryBackendData, String> {
	
	private static final Logger logger = LogManager.getLogger(RegistryPageDataFactory.class.getName());
	
	@Autowired
	private WCSService wCSService;
	
	@Autowired
	private CacheService cacheService;
		
	public RegistryPageData getPageData(MobileWebRequestContext context, String pageName, String contentUri){
		return super.getPageData(context, pageName, contentUri);
	}
	
	@Override
	protected RegistryBackendData getBackendData(MobileWebRequestContext context, String contentUri){
		String seoUri = getSeoUrl(contentUri);
		
		Future<String> pageContentRequestFuture = null, seoContentRequestFuture = null;
		
		String pageContent = cacheService.getContent(contentUri, context);
		String sEOContent = cacheService.getContent(seoUri, context);
		
		//queue up pageContentRequestCommand and seoContentRequestCommand so both requests execute in parallel
		if (pageContent == null){
			RegistryRequestCommand pageContentRequestCommand = new RegistryRequestCommand(context, contentUri, wCSService);
			pageContentRequestFuture = pageContentRequestCommand.queue();
		}
		
		if (sEOContent == null){
			RegistryRequestCommand seoContentRequestCommand = new RegistryRequestCommand(context, seoUri, wCSService);
			seoContentRequestFuture = seoContentRequestCommand.queue();	
		}
		
		if (pageContentRequestFuture != null){
			try{
				pageContent = pageContentRequestFuture.get();
			}catch(Exception e){
				logger.error("Error getting page content for: {} :{}", contentUri, e.getMessage());
				pageContent = "";
			}		
		}
	
		if (seoContentRequestFuture != null){
			try{
				sEOContent = seoContentRequestFuture.get();
			}catch(Exception e){
				logger.error("Error getting seo content for: {} :{}", seoUri, e.getMessage());
				sEOContent = "";
			}	
		}
		
		if (pageContent != null && pageContentRequestFuture != null){
			cacheService.putContent(contentUri, pageContent, context);
		}
		
		if (sEOContent != null && seoContentRequestFuture != null){
			cacheService.putContent(seoUri, sEOContent, context);
		}
		
		RegistryBackendData registryBackendData = new RegistryBackendData(pageContent, sEOContent);
		return registryBackendData;
	}
	
	@Override
	protected RegistryPageData buildPageData(PageData genericPageData, RegistryBackendData registryBackendData, MobileWebRequestContext context){
		return new RegistryPageData(genericPageData, registryBackendData.getSEOContent(), registryBackendData.getPageContent());		
	}
	
	protected String getSeoUrl(String contentUri){		
		String seoSuffix = "-seo";
		int jspIndex = contentUri.indexOf(".jsp");
	
		if (jspIndex > -1){
			contentUri = contentUri.substring(0, jspIndex);
		}
		return contentUri + seoSuffix;
	}
}
