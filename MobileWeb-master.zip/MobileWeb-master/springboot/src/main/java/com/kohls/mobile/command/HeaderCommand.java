package com.kohls.mobile.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.scripting.HeaderScriptEngine;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class HeaderCommand extends HystrixCommand<String>{
	private static final Logger logger = LogManager.getLogger(HeaderCommand.class.getName());
	private final MobileWebRequestContext context;
	private HeaderScriptEngine headerScriptEngine;
	
    public HeaderCommand(MobileWebRequestContext context, HeaderScriptEngine headerScriptEngine) {
    	super(HystrixCommandGroupKey.Factory.asKey("HeaderCommand"));
    	this.context = context;
    	this.headerScriptEngine = headerScriptEngine;
    }

    @Override
    protected String run() {
    	try {
    		return headerScriptEngine.invokeFunction(context.isTcom());
    	} catch (Exception ex) {
    		logger.error(Utils.getErrorMessage(context, "Error in rendering Header javascript"), ex);
    	}
    	return "";
    }
}
