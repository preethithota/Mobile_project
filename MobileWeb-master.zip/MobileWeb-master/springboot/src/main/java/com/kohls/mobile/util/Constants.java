package com.kohls.mobile.util;

public class Constants {

	public static final String COR_ID_KEY = "Correlation-Id";
	public static final String NEW_COR_ID_KEY = "x-correlation-id";
	public static final String ACCEPT = "Accept";
	public static final String APPLICATION_JSON = "application/json";
	public static final String UTF8 = "UTF-8";
	public static final String PROXY_PARAM = "kproxy";
	
	
}
