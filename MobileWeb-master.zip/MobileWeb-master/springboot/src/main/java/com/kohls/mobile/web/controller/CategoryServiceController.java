package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.service.CategoryService;

@Controller
public class CategoryServiceController {
	
	@Autowired
	CategoryService categoryService;
	
	@GetMapping("/service/category/{dimensionId}")
	@ResponseBody
	public String getCategories(HttpServletResponse response, @PathVariable("dimensionId") String dimensionId,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		response.setContentType("application/json");
		return categoryService.getCategories(dimensionId, mobileWebRequestContext);
	}
	
	@GetMapping("/service/category")
	@ResponseBody
	public String getCategories(HttpServletResponse response, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext)
			throws Exception{
		response.setContentType("application/json");
		return categoryService.getCategories(mobileWebRequestContext);
	}
}