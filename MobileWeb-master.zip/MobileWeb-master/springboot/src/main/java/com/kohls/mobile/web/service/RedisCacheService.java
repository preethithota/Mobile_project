package com.kohls.mobile.web.service;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.lambdaworks.redis.ReadFrom;
import com.lambdaworks.redis.RedisClient;
import com.lambdaworks.redis.RedisURI;
import com.lambdaworks.redis.SetArgs;
import com.lambdaworks.redis.api.async.RedisAsyncCommands;
import com.lambdaworks.redis.api.sync.RedisCommands;
import com.lambdaworks.redis.codec.Utf8StringCodec;
import com.lambdaworks.redis.masterslave.MasterSlave;
import com.lambdaworks.redis.masterslave.StatefulRedisMasterSlaveConnection;

@Service
public class RedisCacheService {

	private static final Logger logger = LogManager.getLogger(RedisCacheService.class.getName());
	
	@Autowired
	private ConfigurationService configurationService;
	
	private final static String REDIS_KEY_PREFIX = "MCOM-";
	
	private StatefulRedisMasterSlaveConnection<String, String> connection;
	private RedisClient redisClient;
	private RedisCommands<String, String> redisReadCommands;
	private RedisAsyncCommands<String, String> redisWriteCommands;
	
	public String get(String key, MobileWebRequestContext context){
		if (redisReadCommands == null){
			logger.warn("Redis get() was called, however redisClusterCommands is null");
			return null;
		}
		String redisKey = getRedisCacheKey(key);
		
		try{
			Instant t1 = Instant.now();
			String cacheValue = redisReadCommands.get(redisKey);
			long durationInMs = Duration.between(t1, Instant.now()).toMillis();
			logger.info("Redis cache {} for {} in {} ms", (cacheValue == null) ? "miss" : "hit" , redisKey, durationInMs);
			return cacheValue;
		}catch(Exception e){
			logger.error(Utils.getErrorMessage(context, "Error getting redis value"), e);
		}
		return null;
	}
	
	public void set(String key, String value, MobileWebRequestContext context){
		long defaultExpiryInSeconds = configurationService.getLong("redis.expiration.default.seconds");
		set(key, value, context, defaultExpiryInSeconds);
	}
	
	public void set(String key, String value, MobileWebRequestContext context, long expiryInSeconds){
		if (redisWriteCommands == null){
			logger.warn("Redis set() was called, however redisClusterCommands is null");
			return;
		}
		
		String redisKey = getRedisCacheKey(key);
		
		try{
			Instant t1 = Instant.now();
			redisWriteCommands.set(redisKey, value, new SetArgs().ex(expiryInSeconds));	
			long durationInMs = Duration.between(t1, Instant.now()).toMillis();
			logger.info("Redis cache write time for {} is {} ms", redisKey, durationInMs);
		}catch(Exception e){
			logger.error(Utils.getErrorMessage(context, "Error executing RedisWriteCommand value"), e);
		}		
	}

	@PostConstruct
	protected void init() throws Exception{		
		if (!configurationService.isRedisEnabled()){
			logger.info("Redis is disabled");
			return;
		}
		
		String redisConnectionString = configurationService.getString("redis.connectionstring");
		
		if (redisConnectionString == null || redisConnectionString.equals("")){
			logger.warn("redis.enabled is true, however redis.connectionstring is empty");
			return;
		}
		
		try{
			RedisURI redisURI = RedisURI.create(redisConnectionString);
			RedisClient redisClient = RedisClient.create();
			int timeoutInSeconds = configurationService.getInt("redis.timeout.seconds");
			redisClient.setDefaultTimeout(timeoutInSeconds, TimeUnit.SECONDS);
			
			connection = MasterSlave.connect(
					redisClient,
		            new Utf8StringCodec(),
		            redisURI);

			connection.setReadFrom(ReadFrom.SLAVE);
			
			redisReadCommands = connection.sync();
			
			//writes should be asynchronous 
			redisWriteCommands = connection.async();
		}catch(Exception e){
			logger.error("Exception connecting to Redis, connection string: " + redisConnectionString, e);
		}
	}
	
	@PreDestroy
	private void destroy(){
		if (connection != null){
			try{
				connection.close();	
			}catch(Exception e){
				logger.debug("Error closing Redis connection ", e);
			}
		}
		
		if (redisClient != null){
			try{
				redisClient.shutdown();	
			}catch(Exception e){
				logger.debug("Error shutting down redisClient ", e);
			}	
		}
	}
	
	private String getRedisCacheKey(String localCacheKey){
		return REDIS_KEY_PREFIX + localCacheKey;
	}
	
}
