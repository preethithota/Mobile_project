package com.kohls.mobile.web.dto;

public class RegistryPageData extends PageData{

	private final String bodyContent;
	private final String headContent;
	
	public RegistryPageData(PageData pageData, String headContent, String bodyContent) {
		super(pageData);
		this.headContent = headContent;
		this.bodyContent = bodyContent;
	}

	public String getHeadContent() {
		return headContent;
	}
	
	public String getBodyContent(){
		return bodyContent;
	}
}
