package com.kohls.mobile.web.service;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.configuration2.ImmutableConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.ehcache.config.builders.CacheConfigurationBuilder;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.config.builders.ResourcePoolsBuilder;
import org.ehcache.config.units.MemoryUnit;
import org.ehcache.expiry.Duration;
import org.ehcache.expiry.Expirations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;

@Service
public class CacheService {
	
	private static final Logger logger = LogManager.getLogger(CacheService.class.getName());
	
	@Autowired
	private RedisCacheService redisCacheService;
	
	@Autowired
	private ConfigurationService configurationService;
	
	//private static final int MIN_OFFHEAP_CACHE_SIZE_KB = 1024;
	
	private Map<String, Cache<String, String>> localCacheMap;
	
	private CacheManager cacheManager;
	
	private static final String PAGE_CONTENT_CACHE_KEY = "pageContent";
	
	private String[] cacheRegionKeys = {"header", "bannerContent", "footerContent", PAGE_CONTENT_CACHE_KEY, "catalogData", "pmpPage", "productData", "pdpPage"};
	
	private static final String LOCAL_CACHE_HASH_KEY_SUFFIX = "Cache";
	
	//TODO: Refactor this
	public String getCatalogData(String uri, MobileWebRequestContext context){
		return get(uri, context, "catalogData");
	}
	
	public void putCatalogData(String uri, String value, MobileWebRequestContext context){
		put(uri, value, context, "catalogData");
	}
	
	public String getPmpPage(String uri, MobileWebRequestContext context){
		return get("PMP-" + uri, context, "pmpPage");
	}
	
	public void putPmpPage(String uri, String value, MobileWebRequestContext context){
		put("PMP-" + uri, value, context, "pmpPage");
	}
	
	public String getProductData(String uri, MobileWebRequestContext context){
		return get(uri, context, "productData");
	}
	
	public void putProductData(String uri, String value, MobileWebRequestContext context){
		put(uri, value, context, "productData");
	}
	
	public String getPdpPage(String uri, MobileWebRequestContext context){
		return get("PDP-" + uri, context, "pdpPage");
	}
	
	public void putPdpPage(String uri, String value, MobileWebRequestContext context){
		put("PDP-" + uri, value, context, "pdpPage");
	}
	
	public String getContent(String uri, MobileWebRequestContext context){
		return get(uri, context, PAGE_CONTENT_CACHE_KEY);
	}
	
	public void putContent(String uri, String value, MobileWebRequestContext context){
		put(uri, value, context, PAGE_CONTENT_CACHE_KEY);
	}
	
	public String get(String localCacheKey, MobileWebRequestContext context){
		return get(localCacheKey, context, localCacheKey );
	}
	
	public void put(String localCacheKey, String value, MobileWebRequestContext context){
		put(localCacheKey, value, context, localCacheKey);
	}
	
	@PostConstruct
	private void init() throws Exception{
		cacheManager = CacheManagerBuilder.newCacheManagerBuilder().build();
		cacheManager.init();
		
		Map<String, Cache<String, String>> localCacheMap = new HashMap<String, Cache<String, String>>();
		
		for (String cacheRegionKey:  cacheRegionKeys){
			String key = getLocalCacheHashKey(cacheRegionKey);
			Cache<String, String> cache = createCache(cacheManager, key);
			localCacheMap.put(key, cache);
		}
		
		this.localCacheMap = localCacheMap;
	}
	
	@PreDestroy
	private void destroy(){
		for (String cacheRegionKey : cacheRegionKeys){
			String key = getLocalCacheHashKey(cacheRegionKey);
			try{
				cacheManager.removeCache(key);
			}catch(Exception e){
				logger.error("Error removing cache for key: " + key, e);
			}
		}
		cacheManager.close();
	}
	
	private Cache<String, String> createCache(CacheManager cacheManager, String cacheName){
		String cachePrefix = cacheName + ".ehcache.";
		ImmutableConfiguration config = configurationService.getConfiguration();
		
		if (!config.getBoolean(cachePrefix + "enabled")){
			return null;
		}
		
		int onHeapKb = config.getInt(cachePrefix + "onHeapKb");
		int offHeapMb = config.getInt(cachePrefix + "offHeapMb");
		int ttlInMinutes = config.getInt(cachePrefix + "ttlInMinutes");
		
		ResourcePoolsBuilder resourcePoolsBuilder = ResourcePoolsBuilder.newResourcePoolsBuilder()
				.heap(onHeapKb, MemoryUnit.KB)
				.offheap(offHeapMb, MemoryUnit.MB);
		
		CacheConfigurationBuilder<String, String> cacheConfigurationBuilder = CacheConfigurationBuilder.newCacheConfigurationBuilder(String.class, String.class, resourcePoolsBuilder)
			    .withExpiry(Expirations.timeToLiveExpiration(Duration.of(ttlInMinutes, TimeUnit.MINUTES)));
			    
		Cache<String, String> cache = cacheManager.createCache(cacheName, cacheConfigurationBuilder);			    
		return cache;
	}

	private Cache<String, String> getLocalCache(String localCacheKey){
		return localCacheMap.get(getLocalCacheHashKey(localCacheKey));
	}
	
	private String getLocalCacheHashKey(String localCacheKey){
		return localCacheKey + LOCAL_CACHE_HASH_KEY_SUFFIX;
	}
	
	private void putInLocalCache(String localCacheKey, String value, MobileWebRequestContext context, String cacheHashKey){
		Cache<String, String> localCache = getLocalCache(cacheHashKey);
		if (localCache != null && configurationService.isEhcacheEnabled()){
			try{
				localCache.put(localCacheKey, value);
			}catch(Exception e){
				logger.error(Utils.getErrorMessage(context, "Error putting cache key: " + localCacheKey + " in ehCache "), e);
			}
		}
	}
	
	private void put(String localCacheKey, String value, MobileWebRequestContext context, String cacheHashKey){

		putInLocalCache(localCacheKey, value, context, cacheHashKey);
		
		boolean putValueInRedis = configurationService.isRedisEnabled();
		boolean redisEnabledForCacheKey = configurationService.getBoolean(getLocalCacheHashKey(cacheHashKey) + ".redis.enabled");
		
		if (putValueInRedis && redisEnabledForCacheKey){
			long redisTtlInSeconds = configurationService.getLong(getLocalCacheHashKey(cacheHashKey) + ".redis.ttlInSeconds");
			redisCacheService.set(localCacheKey, value, context, redisTtlInSeconds);
		}
	}
	
	private String get(String localCacheKey, MobileWebRequestContext context, String cacheHashKey){
		Cache<String, String> localCache = getLocalCache(cacheHashKey);
		String localCacheValue = null, remoteCacheValue = null;
		
		if (localCache != null && configurationService.isEhcacheEnabled()){
			Instant t1 = Instant.now();
			localCacheValue = localCache.get(localCacheKey);
			long durationInMs = java.time.Duration.between(t1, Instant.now()).toMillis();
			logger.info("ehCache {} for {} in {} ms", (localCacheValue == null) ? "miss" : "hit" ,localCacheKey, durationInMs);
			
			if (localCacheValue != null){
				return localCacheValue;
			}
		}
		
		boolean redisEnabledForCacheKey = configurationService.getBoolean(getLocalCacheHashKey(cacheHashKey) + ".redis.enabled");
		
		remoteCacheValue = (configurationService.isRedisEnabled() && redisEnabledForCacheKey) ? redisCacheService.get(localCacheKey, context) : null;
		// if cache value was in redis, but not in echache, we need to put the value in ehcache
		if (localCacheValue == null && remoteCacheValue != null){			
			putInLocalCache(localCacheKey, remoteCacheValue, context, cacheHashKey);
		}
		return remoteCacheValue;
	}
}
