package com.kohls.mobile.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.service.WCSService;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandProperties;

public class BannerContentRequestCommand extends HystrixCommand<String>{	
	
	private static final Logger logger = LogManager.getLogger(BannerContentRequestCommand.class.getName());
	private final MobileWebRequestContext context;
	private final WCSService wCSService;
	
    public BannerContentRequestCommand(MobileWebRequestContext context, WCSService wCSService) {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("BannerContentRequestCommand"))
                .andCommandPropertiesDefaults(HystrixCommandProperties.Setter()
                       .withExecutionTimeoutInMilliseconds(30 * 1000)));
    	
    	this.context = context;
    	this.wCSService = wCSService;
    }

    @Override
    protected String run() {
    	String bannerContent;
		try{
			bannerContent = wCSService.getBannerContent(context);
		}catch(Exception e){
			bannerContent = "";
			logger.error(Utils.getErrorMessage(context, "Exception getting banner content:" + e.getMessage()));
		}
		return bannerContent;
    }
}
