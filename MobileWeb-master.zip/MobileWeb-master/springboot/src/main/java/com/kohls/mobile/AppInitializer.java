package com.kohls.mobile;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.function.Consumer;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.web.scripting.HeaderScriptEngine;
import com.kohls.mobile.web.scripting.PdpScriptEngine;
import com.kohls.mobile.web.scripting.PmpScriptEngine;
import com.kohls.mobile.web.service.ConfigurationService;


@Component
public class AppInitializer{
	
	@Autowired
	private PmpScriptEngine pmpScriptEngine;
	
	@Autowired
	private PdpScriptEngine pdpScriptEngine;
	
	@Autowired
	private HeaderScriptEngine headerScriptEngine;
	
	@Autowired
	ConfigurationService configurationService;
	
	private static final Logger logger = LogManager.getLogger(AppInitializer.class.getName());
	
	@PostConstruct
	public void init() throws Exception{
		
		if (!configurationService.getConfiguration().getBoolean("script.initOnStartup")){
			return;
		}
			
		logger.info("Beginning Script initialization");
		logger.info("Initializing header script");
		headerScriptEngine.invokeFunction(true);
		headerScriptEngine.invokeFunction(false);
		logger.info("Completed initializing header script");
		
		//init pmp	
		logger.info("Initializing Pmp script");
		for (int i = 1; i < 12 ; i++){
			String fileName = "test-data/pmp-test-" + i + ".json";
			
			initScriptWithData(fileName, (jsonData) -> {
				try{
					pmpScriptEngine.invokeFunction(jsonData, true);
				}catch(Exception e){
					logger.error("Error in pmpScriptEngine", e);
				}
			});
		}
		logger.info("Completed initializing Pmp script");
		
		//init pdp
		logger.info("Initializing Pdp script");
		for (int i = 1; i < 6 ; i++){
			String fileName = "test-data/pdp-test-" + i + ".json";
			initScriptWithData(fileName, (jsonData) -> {
				try{
					pdpScriptEngine.invokeFunction(jsonData, true);
				}catch(Exception e){
					logger.error("Error in pdpScriptEngine", e);
				}
			});
		}
		logger.info("Completed initializing Pdp script");
	}
	
	private void initScriptWithData(String fileName, Consumer<String> scriptEngineConsumer) throws Exception{
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		try(
			InputStream inputStream = classloader.getResourceAsStream(fileName);
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
		)
		{			
	        StringBuilder out = new StringBuilder();
	        String line;
	        while ((line = reader.readLine()) != null) {
	        	out.append(line);
	        }
	        String catalogDataJson = out.toString();
	        scriptEngineConsumer.accept(catalogDataJson);
	        //logger.info("Initialized Script with " + fileName);
			
		} catch (Exception e) {
			logger.error("Error initializing app", e);
			throw e;
		}
	}

}
