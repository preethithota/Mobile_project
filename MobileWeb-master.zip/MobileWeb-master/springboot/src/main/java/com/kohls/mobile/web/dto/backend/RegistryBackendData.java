package com.kohls.mobile.web.dto.backend;

public class RegistryBackendData {
	
	private final String pageContent;
	private final String sEOContent;
	
	public RegistryBackendData(String pageContent, String sEOContent) {
		this.pageContent = pageContent;
		this.sEOContent = sEOContent;
	}

	public String getPageContent() {
		return pageContent;
	}

	public String getSEOContent() {
		return sEOContent;
	}
}
