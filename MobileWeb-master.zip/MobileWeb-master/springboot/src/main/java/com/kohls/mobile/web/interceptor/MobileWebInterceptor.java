package com.kohls.mobile.web.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.web.service.ConfigurationService;

@Component
public class MobileWebInterceptor implements HandlerInterceptor{
	
	@SuppressWarnings("unused")
	private static final Logger logger = LogManager.getLogger(MobileWebInterceptor.class.getName());
	
	@Autowired
	private ConfigurationService configurationService;
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
			throws Exception {
		String maxAgeValue = configurationService.getConfiguration().getString("cache.page.ttl.seconds");
		if (maxAgeValue != null){
			response.setHeader("Cache-Control", "max-age=" + maxAgeValue);
		}	
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
	}
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
	
		return true;
	}

}
