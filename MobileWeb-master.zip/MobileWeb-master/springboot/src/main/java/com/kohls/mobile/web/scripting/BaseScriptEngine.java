package com.kohls.mobile.web.scripting;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.time.Duration;
import java.time.Instant;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.service.ConfigurationService;

public abstract class BaseScriptEngine {
	
	private static final Logger logger = LogManager.getLogger(BaseScriptEngine.class.getName());
	
	@Autowired
	ConfigurationService configurationService;
	
	@Autowired
	WebViewHelper webViewHelper;
	
	protected Invocable invocable;
	protected String bundleName;
	
	protected Invocable getInvocable(String bundleName) throws Exception{
		this.bundleName = bundleName;
		String currentBundleName = getCurrentBundleName(bundleName); 
		ScriptEngine scriptEngine = getBaseEngine();
        scriptEngine.eval("load("+'"'+currentBundleName+'"'+");");
        invocable = (Invocable) scriptEngine;
        return invocable;
	}
	
	protected String invokeFunction(String functionName, String data, boolean isTcom) throws Exception{
		Instant t1 = Instant.now();
		Object html;
		if (data == null){
			html = invocable.invokeFunction(functionName, isTcom);
		}else{
			html = invocable.invokeFunction(functionName, data, isTcom);	
		}
		long durationInMs = Duration.between(t1, Instant.now()).toMillis();
		logger.info("Executing render of {} completed after {} ms", bundleName, durationInMs);
		return String.valueOf(html);
	}
	
	private ScriptEngine getBaseEngine() throws Exception{
		ScriptEngineManager factory = new ScriptEngineManager();
		ScriptEngine scriptEngine = factory.getEngineByName("nashorn");
		scriptEngine.eval(getReaderForLibFile("react.min.js"));
		scriptEngine.eval(getReaderForLibFile("react-dom.min.js"));
		scriptEngine.eval(getReaderForLibFile("react-dom-server.min.js"));
		scriptEngine.eval(getReaderForLibFile("server-polyfill.js"));
		return scriptEngine;
	}
	
	private String getCurrentBundleName(String bundle){
		//TODO: make this not hardcoded to false
		boolean devMode = false;
		StringBuilder sb = new StringBuilder();
		sb.append(configurationService.getFrontEndHome()); // ${MOBILEWEB_FRONTEND_HOME}
		sb.append(configurationService.getPublicPath()); // /public
		sb.append(devMode ? configurationService.getDevScriptsBundlePath() : configurationService.getProdScriptsBundlePath());// /dist
		sb.append("/" + webViewHelper.getAssetMap(devMode).get(bundle));
		String path = sb.toString();
		logger.info("Loading bundle: {}, path: {}", bundle, path);
		return path;
	}
	
	private Reader getReaderForLibFile(String path) throws Exception{
		String fullPath = configurationService.getFrontEndHome() + configurationService.getPublicPath() + "/lib/" + path;
		return getFileReader(fullPath);
	}
	
	private Reader getFileReader(String path) throws Exception {
	    File file = new File(path);
	    FileReader reader = new FileReader(file);
	    return reader;
	}
}
