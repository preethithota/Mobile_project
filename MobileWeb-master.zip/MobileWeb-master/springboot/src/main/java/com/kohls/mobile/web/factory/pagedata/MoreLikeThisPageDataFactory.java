package com.kohls.mobile.web.factory.pagedata;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.MoreLikeThisPageData;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.ProductBackendData;
import com.kohls.mobile.web.dto.SEOData;
import com.kohls.mobile.web.request.ProductServiceRequest;
import com.kohls.mobile.web.service.ProductService;

@Component
public class MoreLikeThisPageDataFactory  extends AbstractPageDataFactory<MoreLikeThisPageData, String, ProductServiceRequest>{
	private static final Logger logger = LogManager.getLogger(MoreLikeThisPageDataFactory.class.getName());
	
	@Autowired
	ProductService productService;
		
	@Autowired
	private WebViewHelper webViewHelper;
	
	public MoreLikeThisPageData getPageData(MobileWebRequestContext context, String pageName, ProductServiceRequest productServiceRequest){
		return super.getPageData(context, pageName, productServiceRequest);
	}

	@Override
	protected String getBackendData(MobileWebRequestContext context, ProductServiceRequest productServiceRequest){
		String productData;
		try{
			ProductBackendData productBackendData = productService.getProductData(productServiceRequest, context);
			return productBackendData.getData();
		}catch(Exception e){
			productData = "null";
			logger.error(Utils.getErrorMessage(context, "Error in MoreLikeThisPageData.getBackendData() for productId: "
					+ productServiceRequest.getProductId()), e);
		}
		return productData;
	}
	
	@Override
	protected MoreLikeThisPageData buildPageData(PageData genericPageData, String productData, MobileWebRequestContext context){
		SEOData sEOData = webViewHelper.getSEOData(context.getRequestUri(), context.getRequestQueryString(), context.isTcom());
		return new MoreLikeThisPageData(genericPageData, productData, sEOData);
	}
}
