package com.kohls.mobile.web.dto;

public class ProductPageData extends PageData{
	
	private final String bodyContent;
	private final String data; //This is the JSON data string from platform/oapi
	private final SEOData sEOData;
	
	public ProductPageData(PageData pageData, String bodyContent, String data, SEOData sEOData) {
		super(pageData);
		this.bodyContent = bodyContent;
		this.data = data;
		this.sEOData = sEOData;
	}
	
	public String getBodyContent() {
		return bodyContent;
	}
	public String getData() {
		return data;
	}
	
	public SEOData getSEOData() {
		return sEOData;
	}
	
	

}
