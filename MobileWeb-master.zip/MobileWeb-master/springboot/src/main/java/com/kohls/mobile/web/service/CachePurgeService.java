package com.kohls.mobile.web.service;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kohls.mobile.util.Constants;
import com.kohls.mobile.web.dto.MobileWebRequestContext;

@Service
public class CachePurgeService {
	
	@Autowired
	HttpService httpService;
	
	private static final Logger logger = LogManager.getLogger(CachePurgeService.class.getName());
	
	private static final String KEY_PREFIX = "KOHLS_WCS_";
	
	public void purgeWCSData(String requestPayload){
		List<String> uriList = getUrisToPurge(requestPayload);
		for (String uri: uriList){
			try{
				MobileWebRequestContext context = new MobileWebRequestContext(false, "MCOM-CACHE-PURGE-REQUEST", false, "", "", "");
				String purgeUri = "/v1/caching/entry?cname=content&key=" + URLEncoder.encode(uri, Constants.UTF8);
				logger.info(String.format("Sending cache DELETE request to %s", purgeUri));
				String response = httpService.deleteFromPlatform(purgeUri, null, context);
				logger.info(String.format("Response from DELETE request: %s", response));
			}catch(Exception e){
				logger.error(String.format("Error deleting from platform - uri: %s", uri), e);
			}
		}
	}
	
	protected List<String> getUrisToPurge(String requestPayload){
		logger.info("getUrisToPurge invoked with payload " + requestPayload);
		ArrayList<String> uriList = new ArrayList<String>();
		try{
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(requestPayload);
			JsonNode keysNode = rootNode.get("Keys");
		    for (final JsonNode key : keysNode) {
		    	String keyValue = key.asText();
		    	uriList.add(removePrefix(keyValue, KEY_PREFIX));
		    }		
		}catch(Exception e){
			logger.error("Error in getUrlsToPurge ", e);
		}
		
		logger.info("Cached urls to purge are " + uriList.toString());
		return uriList;
	}
	
	private String removePrefix(String data, String prefix){
		int prefixLength = prefix.length();
		if (data == null || data.length() <= prefixLength){
			return "";
		}
		return data.substring(prefixLength);
	}

}
