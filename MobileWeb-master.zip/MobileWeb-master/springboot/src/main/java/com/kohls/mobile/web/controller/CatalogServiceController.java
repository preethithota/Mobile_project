package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.backend.CatalogBackendData;
import com.kohls.mobile.web.request.CatalogServiceRequest;
import com.kohls.mobile.web.request.CatalogServiceRequestFactory;
import com.kohls.mobile.web.service.CatalogService;

@Controller
@RequestMapping("/service/catalog")
public class CatalogServiceController {
	
	@Autowired
	private CatalogService catalogService;
	
	@Autowired
	CatalogServiceRequestFactory catalogServiceRequestFactory;
	
	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	public String getProducts(HttpServletRequest request, HttpServletResponse response, 
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		CatalogServiceRequest catalogServiceRequest = catalogServiceRequestFactory.getCatalogServiceRequest(request, mobileWebRequestContext.isTcom());
		CatalogBackendData catalogData = catalogService.getProducts(catalogServiceRequest, mobileWebRequestContext);
		response.setContentType("application/json");
		String catalogJson = catalogData.getData();
		return catalogJson;
	}
	
	//TODO: This should be removed
	@RequestMapping(path = "/dimensions", method = RequestMethod.GET)
	@ResponseBody
	public String getDimensions(HttpServletRequest request, HttpServletResponse response, 
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		response.setContentType("application/json");
		CatalogServiceRequest catalogServiceRequest = catalogServiceRequestFactory.getCatalogServiceRequest(request, mobileWebRequestContext.isTcom());
		return catalogService.getDimensions(catalogServiceRequest, mobileWebRequestContext);
	}
	
}
