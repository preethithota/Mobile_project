package com.kohls.mobile.web.scripting;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

@Service
public class HeaderScriptEngine extends BaseScriptEngine{
	
	@PostConstruct
	private void init() throws Exception{
		invocable = getInvocable("header/header-server-main.js");
	}
	
	public String invokeFunction(boolean isTcom) throws Exception{
		return super.invokeFunction("renderServer", null, isTcom);
	}

}
