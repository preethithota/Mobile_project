package com.kohls.mobile.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.service.WCSService;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandProperties;

public class ContentRequestCommand extends HystrixCommand<String>{
	private static final Logger logger = LogManager.getLogger(ContentRequestCommand.class.getName());
	private final MobileWebRequestContext context;
	private final WCSService wCSService;
	private final String uri;
	
    public ContentRequestCommand(MobileWebRequestContext context, String uri, WCSService wCSService) {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("ContentRequestCommand"))
                .andCommandPropertiesDefaults(HystrixCommandProperties.Setter()
                       .withExecutionTimeoutInMilliseconds(30 * 1000)));
    	this.context = context;
    	this.wCSService = wCSService;
    	this.uri = uri;
    }

    @Override
    protected String run() {
    	String content;
		try{
			content = wCSService.getContent(uri, context);
		}catch(Exception e){
			content = "";
			logger.error(Utils.getErrorMessage(context, "Exception getting content: " + e.getMessage()));
		}
		return content;
    }

}
