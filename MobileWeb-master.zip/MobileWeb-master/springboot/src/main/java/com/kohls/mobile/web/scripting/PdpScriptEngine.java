package com.kohls.mobile.web.scripting;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

@Service
public class PdpScriptEngine extends BaseScriptEngine{
	
	@PostConstruct
	private void init() throws Exception{
		//invocable = getInvocable("pdpServer");
		invocable = getInvocable("pdp/pdp-server-main.js");
	}
	
	public String invokeFunction(String data, boolean isTcom) throws Exception{
		return super.invokeFunction("renderServerPDP", data, isTcom);
	}
}
