package com.kohls.mobile.web.dto;

import com.kohls.mobile.web.dto.backend.CatalogBackendData;

public class CatalogPageData extends PageData{
	
	private final String bodyContent;
	private final String data; //This is the JSON data string from platform/oapi
	private final SEOData sEOData;
	private final CatalogBackendData catalogBackendData;

	public CatalogPageData(PageData pageData, String bodyContent, String data, SEOData sEOData, CatalogBackendData catalogBackendData) {
		super(pageData);
		this.bodyContent = bodyContent;
		this.data = data;
		this.sEOData = sEOData;
		this.catalogBackendData = catalogBackendData;
	}
	
	public String getBodyContent() {
		return bodyContent;
	}

	public String getData() {
		return data;
	}

	public SEOData getSEOData() {
		return sEOData;
	}
	
	public CatalogBackendData getCatalogBackendData() {
		return catalogBackendData;
	}
}
