package com.kohls.mobile.web.dto;

public class SEOData {
	
	private final String canonicalUrl;
	private final String alternateUrl;
	private final SEOMetaData sEOMetaData;
	
	public SEOData(String canonicalUrl, String alternateUrl, SEOMetaData sEOMetaData) {
		this.canonicalUrl = canonicalUrl;
		this.alternateUrl = alternateUrl;
		this.sEOMetaData = sEOMetaData;
	}
	
	public SEOData(String canonicalUrl, String alternateUrl) {
		this(canonicalUrl, alternateUrl, new SEOMetaData("", "", ""));
	}

	public String getAlternateUrl() {
		return alternateUrl;
	}
	
	public String getCanonicalUrl() {
		return canonicalUrl;
	}	
	
	public SEOMetaData getSEOMetaData(){
		return sEOMetaData;
	}
	

}
