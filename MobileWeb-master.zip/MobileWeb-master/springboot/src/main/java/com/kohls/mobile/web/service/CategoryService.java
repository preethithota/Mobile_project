package com.kohls.mobile.web.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kohls.mobile.web.dto.MobileWebRequestContext;

@Service
public class CategoryService {
	
	private static final Logger logger = LogManager.getLogger(CategoryService.class.getName());
	private static final String CATEGORY_URI = "/v2/catalog/category";
	
	@Autowired
	private HttpService httpService;
		
//	@Autowired
//	private CacheService cacheService;
	
	public String getCategories(MobileWebRequestContext mobileWebRequestContext) throws Exception{
		return getCategories(null, mobileWebRequestContext);
	}

	public String getCategories(String dimensionId, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String categoryUrl = CATEGORY_URI + ((dimensionId == null) ? "" : "/" + dimensionId);
		
		logger.debug("Making request to backendPath: {}", categoryUrl);
		//String cachedResponse = cacheService.readFromCache(categoryUrl);
		
//		if (cachedResponse != null){
//			logger.debug("Response for {} found in cache", categoryUrl);
//			return cachedResponse;
//		}
		
		//String data = httpService.getOpenApiData(categoryUrl, mobileWebRequestContext);
		String data = httpService.getFromPlatform(categoryUrl, mobileWebRequestContext);
		logger.debug("data from backend is {}", data);
		//cacheService.writeToCache(categoryUrl, data);
		return data;
	}

}
