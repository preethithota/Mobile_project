package com.kohls.mobile.web.service;

import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CachePurgeController {
	
	private static final Logger logger = LogManager.getLogger(CachePurgeController.class.getName());
	
	@Autowired
	CachePurgeService cachePurgeService;
	
	@PostMapping("/mrp/transform/cachekey/clear")
	@ResponseBody
	public String purgeCache(HttpServletRequest request, HttpServletResponse response)
			throws Exception{
		String requestPaylaod = request.getParameter("customparams");
		logger.info(String.format("Received purge request to %s, payload: %s", request.getRequestURI(), requestPaylaod));
		cachePurgeService.purgeWCSData(requestPaylaod);
		response.setContentType("application/json");
		return "Purge request completed";
	}
}
