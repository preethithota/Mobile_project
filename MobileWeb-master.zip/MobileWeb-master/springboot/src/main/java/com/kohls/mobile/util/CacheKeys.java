package com.kohls.mobile.util;

public class CacheKeys {
	
	public static final String HEADER_CONTENT = "header";
	public static final String BANNER_CONTENT = "bannerContent";
	public static final String FOOTER_CONTENT = "footerContent";
}
