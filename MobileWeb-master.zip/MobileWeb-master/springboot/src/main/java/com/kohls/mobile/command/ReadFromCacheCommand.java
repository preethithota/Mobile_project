package com.kohls.mobile.command;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class ReadFromCacheCommand extends HystrixCommand<String>{
	
	private final String url;
	private final String channel;
	
    public ReadFromCacheCommand(String url, String channel) {
        super(HystrixCommandGroupKey.Factory.asKey("CacheReadGroup"));
        this.url = url;
        this.channel = channel;
    }
    
    @Override
    protected String run() {
//    	
//    	try{
//    		Thread.sleep(1000);
//    	}catch(Exception e){
//    		System.out.println("Error " + e.getMessage());
//    	}
    	System.out.println("Inside run for url " + url + " channel " + channel);
    	//int randomNumber =  (int) (Math.random() * 100) + 1;
        return "The url for channel " + channel + " is " + url;
    }
    
    @Override
    protected String getCacheKey() {
        return url;
    }
}
