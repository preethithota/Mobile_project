package com.kohls.mobile.web.dto;

public class MoreLikeThisPageData extends PageData{
	
	private final String data;
	private final SEOData sEOData;
	
	public MoreLikeThisPageData(PageData pageData, String data,  SEOData sEOData) {
		super(pageData);
		this.data = data;
		this.sEOData = sEOData;
	}
	
	public String getData(){
		return data;
	}
	
	public SEOData getSEOData(){
		return sEOData;
	}

}
