package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.ProductPageData;
import com.kohls.mobile.web.factory.pagedata.ProductPageDataFactory;
import com.kohls.mobile.web.request.ProductServiceRequest;

@Controller
public class ProductPageController {
	
	@SuppressWarnings("unused")
	private static final Logger logger = LogManager.getLogger(ProductPageController.class.getName());
	
	@Autowired
	private ProductPageDataFactory productPageDataFactory;
			
	@GetMapping("/product/prd-{productId}/{pageName}")
	public ModelAndView getProductPage(HttpServletRequest request, @PathVariable("productId") String productId,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context) {
		ProductServiceRequest productServiceRequest = new ProductServiceRequest(productId, true, true);
		ProductPageData productPageData = productPageDataFactory.getPageData(context, "pdp", productServiceRequest);
		return new ModelAndView("global-template", "pageData", productPageData);
	}	
}
