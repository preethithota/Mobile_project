package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.factory.pagedata.GenericPageDataFactory;

@Controller
public class PasswordResetController {
	
	private static final Logger logger = LogManager.getLogger(ManageOrderController.class.getName());
	
	@Autowired
	private WebViewHelper webViewHelper;
	
	@Autowired
	private GenericPageDataFactory genericPageDataFactory;
	
	@GetMapping("/myaccount/password_reset.jsp")
	public ModelAndView getPasswordResetPage(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext){
		try{			
			//PageData pageData = pageDataFactory.getPageData(mobileWebRequestContext, "password_reset", "");
			PageData pageData = genericPageDataFactory.getPageData(mobileWebRequestContext, "password_reset");
			return new ModelAndView("global-template", "pageData", pageData);			
			
		}catch (Exception ex) {
			logger.error(Utils.getErrorMessage(mobileWebRequestContext, "Error in getSearchResults"), ex);
			return webViewHelper.getErrorMv(request, ex);
		}
	}

}
