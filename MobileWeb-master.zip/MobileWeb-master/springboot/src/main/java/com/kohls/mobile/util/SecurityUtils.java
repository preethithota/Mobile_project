package com.kohls.mobile.util;

import java.security.MessageDigest;
import java.util.Date;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SecurityUtils {
	
	private static final Logger logger = LogManager.getLogger(SecurityUtils.class.getName());

	public static long getEpoch(Date date) {
		return date.getTime();
	}
	
	public static String getRegistyHash(String firstName, String lastName, String email){
		try{
			MessageDigest md = MessageDigest.getInstance("MD5");
			String strMessage = "MFalls" + firstName + lastName + email;
			byte[] bytesOfMessage = strMessage.getBytes(Constants.UTF8);
			byte[] thedigest = md.digest(bytesOfMessage);
			String strDigest = DatatypeConverter.printHexBinary(thedigest).toLowerCase();
			logger.debug("strDigest from getRegistyHash is " + strDigest);
			return strDigest;
		}catch(Exception e){
			logger.error("Error in getRegistyHash ", e);
		}
		return null;
	}

	public static String getHMACString(String message) throws Exception {
		String secret = "sX9qTR6WO0I26yqsm2iU7aN7QcVfTyu0kZc3E14Mx4CTDugUvLvZrLy6rUb1";
		//String message = "Message";

		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
		sha256_HMAC.init(secret_key);

		String hash = Base64.encodeBase64String(sha256_HMAC.doFinal(message.getBytes()));
		//System.out.println(hash);

		return hash;

	}

}
