package com.kohls.mobile.web.dto;

public class ContentPageData extends PageData{

	private final String seoContent;
	private final String bodyContent;

	public ContentPageData(PageData pageData, String seoContent, String bodyContent) {
		super(pageData);
		this.seoContent = seoContent;
		this.bodyContent = bodyContent;
	}

	public String getSeoContent() {
		return seoContent;
	}
	
	public String getBodyContent(){
		return bodyContent;
	}
}
