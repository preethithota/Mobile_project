package com.kohls.mobile.web.service;

import org.apache.http.client.utils.URIBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kohls.mobile.command.ProductRequestCommand;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.ProductBackendData;
import com.kohls.mobile.web.request.ProductServiceRequest;
import com.kohls.mobile.web.dto.SEOMetaData;


@Service
public class ProductService {
	
	private static final Logger logger = LogManager.getLogger(ProductService.class.getName());
	
	private static final String PRODUCT_URI = "/v1/product";
	
	@Autowired
	private HttpService httpService;
	
	@Autowired
	private CacheService cacheService;
	
	public ProductBackendData getProductData(ProductServiceRequest productServiceRequest, MobileWebRequestContext context) throws Exception{
		String productUri = PRODUCT_URI + "/" + productServiceRequest.getProductId();
		
		URIBuilder uRIBuilder = new URIBuilder(productUri.toString());	
		uRIBuilder.setParameter("skuDetail", Boolean.toString(productServiceRequest.isSkuDetail()));
		uRIBuilder.setParameter("invFilter", Boolean.toString(productServiceRequest.isInvFilter()));
			
		String backendPath = uRIBuilder.toString();		
		String data = cacheService.getProductData(backendPath, context);
		
		if (data == null){
			ProductRequestCommand productRequestCommand = new ProductRequestCommand(backendPath, context, httpService);
			data = productRequestCommand.execute();
			if (data != null){
				cacheService.putProductData(backendPath, data, context);
			}
		}
		
		if (logger.isDebugEnabled()){
			logger.debug("data from backend is {}", data);
		}
		
		return tranformProductData(data, backendPath);
		
		//ProductBackendData productBackendData = new ProductBackendData(data, backendPath);
		//return productBackendData;
	}
	
	private ProductBackendData tranformProductData(String inputJson, String backendPath) throws Exception{
		try{
		ObjectMapper objectMapper = new ObjectMapper();
		SEOMetaData sEOMetaData;	
    	JsonNode sourceNode = objectMapper.readTree(inputJson);
    	JsonNode payloadNode = sourceNode.get("payload");
		if(payloadNode != null){		
			JsonNode productsNode = payloadNode.get("products");    				
			JsonNode metaInfo = productsNode.get(0).get("metaInfo").get(0);			
			if (metaInfo != null){
				sEOMetaData = new SEOMetaData(
						metaInfo.get("metaTitle") == null ? "" : metaInfo.get("metaTitle").asText(),
						metaInfo.get("metaDescription") == null ? "" : metaInfo.get("metaDescription").asText(),
						metaInfo.get("metaKeywords") == null ? "" : metaInfo.get("metaKeywords").asText());
			}else{
				sEOMetaData = new SEOMetaData("", "", "");
			}
		}else{
			sEOMetaData = new SEOMetaData("", "", "");
		}
		ProductBackendData productBackendData = new ProductBackendData(inputJson, backendPath , sEOMetaData);
		return productBackendData;
		}
		catch(Exception e){
			logger.error("Transform product data"+e);
		}
		return null;
	}
	
}
