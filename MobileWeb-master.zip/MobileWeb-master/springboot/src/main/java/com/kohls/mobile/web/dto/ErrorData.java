package com.kohls.mobile.web.dto;

public class ErrorData {
	
	private final String url;
	private final String error;
	private final String correlationId;
	private final String errorCode;
	private final String hostName;
	private final String stackTraceMessage;
	
	public ErrorData(String url, String error, String correlationId, String errorCode, String hostName,
			String stackTraceMessage) {
		super();
		this.url = url;
		this.error = error;
		this.correlationId = correlationId;
		this.errorCode = errorCode;
		this.hostName = hostName;
		this.stackTraceMessage = stackTraceMessage;
	}

	public String getUrl() {
		return url;
	}

	public String getError() {
		return error;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getHostName() {
		return hostName;
	}

	public String getStackTraceMessage() {
		return stackTraceMessage;
	}

	@Override
	public String toString() {
		return "ErrorData [url=" + url + ", error=" + error + ", correlationId=" + correlationId + ", errorCode="
				+ errorCode + ", hostName=" + hostName + ", stackTraceMessage=" + stackTraceMessage + "]";
	}
	

}
