package com.kohls.mobile.web.dto;

public class SEOMetaData {
	private final String title;
	private final String description;
	private final String keywords;
	
	public SEOMetaData(String title, String description, String keywords) {
		this.title = title;
		this.description = description;
		this.keywords = keywords;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getKeywords() {
		return keywords;
	}
	
}
