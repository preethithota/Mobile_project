package com.kohls.mobile.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kohls.mobile.web.dto.ErrorData;
import com.kohls.mobile.web.dto.SEOData;
import com.kohls.mobile.web.dto.SEOMetaData;
import com.kohls.mobile.web.service.ConfigurationService;

@Service
public class WebViewHelper {
	
	@Autowired
	private ConfigurationService configurationService;
	
	private static final Logger logger = LogManager.getLogger(WebViewHelper.class.getName());
	private static final Random random = new Random();
	
	public static final String ASSET_FILE_NAME = "manifest.json";
	private static final String CANONICAL_URL_PREFIX = "https://www.kohls.com";
	private static final String MCOM_URL_PREFIX = "https://m.kohls.com";
	private static final String TCOM_URL_PREFIX = "https://mobile.kohls.com";
	
	private static Pattern searchPattern = Pattern.compile("search=([^&]+)");
	
	public String getCookieValue(String cookieName, Cookie[] cookies){
		if (cookies == null) return null;
		
		for (Cookie cookie: cookies){
			if (cookieName.equals(cookie.getName())){
				return cookie.getValue();
			}
		}
		return null;
	}
	
	
	
	public SEOData getSEOData(String pageUri, String queryString, boolean isTcom){
		return new SEOData(
			getCanonicalUrl(pageUri, queryString),
			getAlternateUrl(pageUri, queryString, isTcom));		
	}
	
	public ErrorData getErrorData(HttpServletRequest request){
		return getErrorData(request, null);
	}
	
	public ModelAndView getErrorMv(HttpServletRequest request, Exception e){
		ErrorData errorData = getErrorData(request, e);
		logger.debug("Error data being sent back is {}", errorData);
		return new ModelAndView("error", "errorData", errorData);
	}
	
	public ErrorData getErrorData(HttpServletRequest request, Exception e){
		String fullUrl = request.getRequestURL() + "?" + request.getQueryString();
		String errorCode = Integer.toString(random.nextInt(999999999));
		String correlationId = getCookieValue("correlationId", request.getCookies());
		String exceptionMsg = (e == null) ? "null" : e.getMessage();
		StringBuilder sb = new StringBuilder();
		StackTraceElement[] stackTraceElements = e.getStackTrace();
		
		String hostName = "host-not-available";
		try{
			InetAddress addr = InetAddress.getLocalHost();
			hostName = addr.getHostName();
		}catch(Exception ex){}
		
		for (StackTraceElement stackTraceElement : stackTraceElements){
			sb.append(stackTraceElement.toString() +  " <br/>");
		}
		String stackTraceMessage = sb.toString();
		
		ErrorData errorData = new ErrorData(fullUrl, exceptionMsg, correlationId, errorCode, hostName, stackTraceMessage);
		return errorData;
	}
	
	public SEOData getSEOData(String pageUri, String queryString, boolean isTcom, SEOMetaData sEOMetaData, String searchTerm){
		String defaultTitle = Utils.isStringEmpty(searchTerm) ? "" : searchTerm + " " + configurationService.getConfiguration().getString("seo.searchTitle.suffix");
		if (sEOMetaData != null){
			String title = getSeoValue(sEOMetaData.getTitle(), defaultTitle);
			String description = getSeoValue(sEOMetaData.getDescription(), configurationService.getConfiguration().getString("seo.defaultDescription"));
			String keywords = getSeoValue(sEOMetaData.getKeywords(), configurationService.getConfiguration().getString("seo.defaultValue"));
			sEOMetaData = new SEOMetaData(title, description, keywords);
		}else{
			sEOMetaData = new SEOMetaData(defaultTitle, "", "");
		}
		
		SEOData sEOData = new SEOData(
			getCanonicalUrl(pageUri, queryString),
			getAlternateUrl(pageUri, queryString, isTcom),
			sEOMetaData);
		
		return sEOData;
	}
	
	public String getFullUri(HttpServletRequest request){
		return getFullUri(request.getRequestURI(), request.getQueryString());
	}
	
	public String getFullUri(String pageUri, String queryString){
		return pageUri + ((queryString != null && queryString.length() > 0) ? "?" + queryString : "");
	}
	
	public Map<String, String> getAssetMap(boolean useDevScriptBundles){
		
		try{
			String fileContent = getAssetFileContent(useDevScriptBundles);
			return getAssetMap(fileContent);
		}catch(Exception e){
			logger.error("Error in getAssetMap {} ", e);
			return null;
		}
	}

	protected Map<String, String> getAssetMap(String webpackJson) throws Exception{
		HashMap<String, String> assetMap = new HashMap<String, String>();
    	ObjectMapper objectMapper = new ObjectMapper();
    	JsonNode topNode = objectMapper.readTree(webpackJson);
    	Iterator<Entry<String, JsonNode>> fields = topNode.fields();
    	while (fields.hasNext()){
    		Entry<String, JsonNode> field = fields.next();
    		assetMap.put(field.getKey(), field.getValue().asText());    		
    	}
    	return assetMap;
	}
	
	public String getAssetFileContent(boolean useDevAssets) throws Exception{
		StringBuilder filePathBuilder = new StringBuilder();
		filePathBuilder.append(configurationService.getFrontEndHome());// ${MOBILEWEB_FRONTEND_HOME}
		filePathBuilder.append(configurationService.getPublicPath()); //  /public
		filePathBuilder.append(useDevAssets ? configurationService.getDevScriptsBundlePath() : configurationService.getProdScriptsBundlePath());// /dist
		filePathBuilder.append("/" + ASSET_FILE_NAME);
		
	    File file = new File(filePathBuilder.toString());
		try(
			// try-with-resources block. fileReader and bufferedReader will automatically get closed
			// even if there is an exception
			FileReader fileReader =  new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
		){		
			StringBuilder sb = new StringBuilder();
			String line = null;
			while((line = bufferedReader.readLine()) != null) {
				sb.append(line);
			}	
			return sb.toString();
		}catch(Exception e){
			logger.error("Error in getAssetFileContents() {}", e.getMessage());
			throw e;
		}
	}
		
	protected String getEnvironmentFileName(String origFileName, boolean useDevScriptBundles){
    	String assetFileName = origFileName;
    	
    	//TODO: compile this regex pattern and set as a static constant
		if (useDevScriptBundles){
    		assetFileName = assetFileName.replaceFirst("-rev-[\\w]+\\.js", ".js");
    	}

    	assetFileName = assetFileName.replaceFirst("/dist/", "");
    	return assetFileName;
	}
	
	protected String getScriptsBundlePath(boolean useDevScriptBundles){
		return (useDevScriptBundles) ? configurationService.getDevScriptsBundlePath() :
				configurationService.getProdScriptsBundlePath();
	}	
	
	
	protected String getCanonicalUrl(String pageUri, String queryString){
		String seoQueryString = getSEOQueryString(queryString);
		return getSeoUrl(CANONICAL_URL_PREFIX, pageUri, seoQueryString);
	}
	
	protected String getSEOQueryString(String originQueryString){
		if (originQueryString != null && originQueryString.contains("search=")){
			//Pattern p = Pattern.compile("search=([^&]+)");
			Matcher m = searchPattern.matcher(originQueryString);
			if (m.find()) {
				return m.group();
			}
		}
		return originQueryString;
	}
	
	private String getAlternateUrl(String pageUri, String queryString, boolean isTcom){
		String seoQueryString = getSEOQueryString(queryString);
		String urlPrefix = (isTcom) ? MCOM_URL_PREFIX : TCOM_URL_PREFIX;
		return getSeoUrl(urlPrefix, pageUri, seoQueryString);
	}
	
	private String getSeoUrl(String prefixUrl, String pageUri, String queryString){
		String unsafeValue = prefixUrl + getFullUri(pageUri, queryString);
		return Encode.forHtmlAttribute(unsafeValue);
	}
	
	private String getSeoValue(String backendValue, String defaultValue){
		String unsafeValue = (Utils.isStringEmpty(backendValue) || backendValue.equalsIgnoreCase("null")) ? defaultValue : backendValue;
		return Encode.forHtmlContent(unsafeValue);
	}	

}
