package com.kohls.mobile.util;

import com.kohls.mobile.web.dto.MobileWebRequestContext;

public class Utils {
		
	public static boolean isStringEmpty(String string){
		return (string == null || string.trim().length() == 0);
	}
	
//	public static String getErrorMessage(MobileWebRequestContext mobileWebRequestContext, String message){
//		return "CID: " + mobileWebRequestContext.getCorrelationId() + "; " + message;
//	}
	
	public static String getErrorMessage(MobileWebRequestContext mobileWebRequestContext, String message){
		//return String.format("CID: %s, %s, url: %s, qs: %s", mobileWebRequestContext.getCorrelationId(), message, request.getRequestURL(), request.getQueryString());
		return message + "; " + mobileWebRequestContext.toString();
	}
	
	public static String replaceQueryStringParam(String queryString, String name, String value){
		if (queryString == null || "".equals(queryString)){
			queryString = "?";
		}
		
		if (queryString.charAt(0) != '?'){
			queryString = "?" + queryString;
		}
		
		if (queryString.indexOf(name) == -1){
			return queryString + "&" + name + "=" + value;
		}
		
		String[] splitArr = queryString.split(name);
		String firstQsPart = splitArr[0] + name +  "=" + value;
		
		String secondQsPart = splitArr[1];
		
		int ampersandIndex = secondQsPart.indexOf("&");
		if (ampersandIndex == -1){
			return firstQsPart;
		}
		
		return firstQsPart + secondQsPart.substring(ampersandIndex);

	}

}
