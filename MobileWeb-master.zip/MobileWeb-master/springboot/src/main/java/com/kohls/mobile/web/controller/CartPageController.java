package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.factory.pagedata.GenericPageDataFactory;


@Controller
public class CartPageController {
	
	private static final Logger logger = LogManager.getLogger(CartPageController.class.getName());
	
	@Autowired
	private GenericPageDataFactory genericPageDataFactory;

	
	@GetMapping("/shopping_cart1.jsp")
	public ModelAndView getCatalogPage(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext){
		try{
			
		
			PageData pageData = genericPageDataFactory.getPageData(mobileWebRequestContext, "cart");
			return new ModelAndView("cart-template", "pageData", pageData);
			//return "cart-template";
		}catch(Exception e){
			logger.error("Error calling getCatalogPage: ", e);
			
		}
		return null;

	}	
	
}
