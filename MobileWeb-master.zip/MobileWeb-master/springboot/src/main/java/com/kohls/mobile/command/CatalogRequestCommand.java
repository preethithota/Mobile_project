package com.kohls.mobile.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.service.HttpService;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandProperties;

public class CatalogRequestCommand extends HystrixCommand<String>{
	
	private static final Logger logger = LogManager.getLogger(CatalogRequestCommand.class.getName());
	
	private final String backendPath;
	private final MobileWebRequestContext context;
	private final HttpService httpService;
		
    public CatalogRequestCommand(String backendPath, MobileWebRequestContext context, HttpService httpService) {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("CatalogRequestCommand"))
                .andCommandPropertiesDefaults(HystrixCommandProperties.Setter()
                       .withExecutionTimeoutInMilliseconds(30 * 1000)));
    	
    	this.backendPath = backendPath;
    	this.context = context;
    	this.httpService = httpService;
    }

    @Override
    protected String run(){
    	try{
    		String data = httpService.getFromPlatform(backendPath, context);
    		return data;
    	}catch(Exception ex){
    		logger.error(Utils.getErrorMessage(context, "CatalogRequestCommand"), ex);
    		throw new RuntimeException(ex);
    	}
    }

    @Override
    protected String getFallback() {
    	logger.warn(Utils.getErrorMessage(context, "Fallback triggered for CatalogRequestCommand"));
        return null;
    }

}
