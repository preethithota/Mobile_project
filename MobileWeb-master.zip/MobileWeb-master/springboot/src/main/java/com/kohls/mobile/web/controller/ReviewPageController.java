package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.web.dto.GenericSeoPageData;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.factory.pagedata.GenericSEOPageDataFactory;

/**
 * Created by tkmabj6 on 2/9/17.
 */
@Controller
public class ReviewPageController {

    @Autowired
    private GenericSEOPageDataFactory genericSEOPageDataFactory;


    @SuppressWarnings("unused")
    private static final Logger logger = LogManager.getLogger(CatalogPageController.class.getName());

    @GetMapping(value={"/bvreviews/read_review.jsp", "/bvreviews/write_review.jsp"})
    public ModelAndView getReviewPage(HttpServletRequest request,
    		@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception {
    	
    	GenericSeoPageData pageData = genericSEOPageDataFactory.getPageData(mobileWebRequestContext, "review");
        return new ModelAndView("global-template", "pageData", pageData);
    }
}
