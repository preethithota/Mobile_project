package com.kohls.mobile.web.dto;

public class MobileWebRequestContext {
	
	private final boolean isTcom;
	private final String correlationId;
	private final boolean devBundleMode;
	private final String previewDate;
	private final String requestUri;
	private final String requestQueryString;

	public MobileWebRequestContext(boolean isTcom, String correlationId, boolean devBundleMode, String previewDate,
			String requestUri, String requestQueryString) {
		this.isTcom = isTcom;
		this.correlationId = correlationId;
		this.devBundleMode = devBundleMode;
		this.previewDate = previewDate;
		this.requestUri = requestUri;
		this.requestQueryString = requestQueryString;
	}

	public boolean isTcom() {
		return isTcom;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public boolean isDevBundleMode() {
		return devBundleMode;
	}

	public String getPreviewDate() {
		return previewDate;
	}

	public String getRequestUri() {
		return requestUri;
	}

	public String getRequestQueryString() {
		return requestQueryString;
	}

	@Override
	public String toString() {
		// omitting previewDate
		return "MobileWebRequestContext [isTcom=" + isTcom + ", correlationId=" + correlationId + ", devBundleMode="
				+ devBundleMode + ", requestUri=" + requestUri + ", requestQueryString=" + requestQueryString + "]";
	}
	
	
	
}
