package com.kohls.mobile.web.factory.pagedata;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.ProxyPageData;
import com.kohls.mobile.web.scripting.RegistryScriptEngine;
import com.kohls.mobile.web.service.HttpService;

@Component
public class ProxyPageFactory extends AbstractPageDataFactory<ProxyPageData, String, String>{
	
	private static final Logger logger = LogManager.getLogger(ProxyPageFactory.class.getName());
	
	@Autowired
	RegistryScriptEngine registryScriptEngine;
	
	@Autowired
	HttpService httpService;
	
	public ProxyPageData getPageData(MobileWebRequestContext context, String pageName, String proxyRequest){
		return super.getPageData(context, pageName, proxyRequest);
	}

	@Override
	protected String getBackendData(MobileWebRequestContext context, String proxyRequest){
		try{
			String proxyPageHtml = httpService.getFromSkavaSite(context, proxyRequest, "", null);
			return proxyPageHtml;			
		}catch(Exception e){
			logger.error(Utils.getErrorMessage(context, "Error in proxyPageBackendData.getBackendData()"), e);
		}
		return null;
	}
	
	@Override
	protected ProxyPageData buildPageData(PageData genericPageData, String proxyPageHtml, MobileWebRequestContext context){
		String headHtml = registryScriptEngine.getRegistryPageHead(proxyPageHtml, context.isTcom());
		String bodyHtml = registryScriptEngine.getRegistryPageBody(proxyPageHtml, context.isTcom());
		return new ProxyPageData(genericPageData, headHtml, bodyHtml);
	}

}
