package com.kohls.mobile.web.dto;

public class ProxyPageData extends PageData{
	
	private final String headContent;
	private final String bodyContent;
	
	public ProxyPageData(PageData pageData, String headContent, String bodyContent) {
		super(pageData);
		this.headContent = headContent;
		this.bodyContent = bodyContent;
	}

	public String getHeadContent() {
		return headContent;
	}

	public String getBodyContent() {
		return bodyContent;
	}

}
