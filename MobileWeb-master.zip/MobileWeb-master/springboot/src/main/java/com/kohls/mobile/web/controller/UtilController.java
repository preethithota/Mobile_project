package com.kohls.mobile.web.controller;

import java.util.Arrays;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.factory.pagedata.GenericPageDataFactory;

@Controller
public class UtilController {
	
	private static final Logger logger = LogManager.getLogger(ProductPageController.class.getName());
	public static final String[] ALLOWED_COOKIE_NAMES = {"isTcom"};
	
	@Autowired
	private GenericPageDataFactory genericPageDataFactory;

	@GetMapping("/set-cookie")
	@ResponseBody
	public String setCookie(@RequestParam("cookieName") String cookieName, @RequestParam("cookieValue") String cookieValue,
			HttpServletResponse response) {
		
		if (Arrays.asList(ALLOWED_COOKIE_NAMES).contains(cookieName)){
			response.addCookie(new Cookie(cookieName, cookieValue));
			return "Cookie successfully set";
		}else{
			logger.error("Error setting cookie {}={}", cookieName, cookieValue);
			return "Error: invalid input";
		}
	}
	
	@GetMapping("/datepicker")
	public ModelAndView getDatePickerPage(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context) {
		try{
			PageData pageData = genericPageDataFactory.getPageData(context, "datepicker");
			return new ModelAndView("global-template", "pageData", pageData);
		}catch(Exception e){
			logger.error("Error in getDatePickerPage", e);
		}
		return null;
	}
}
