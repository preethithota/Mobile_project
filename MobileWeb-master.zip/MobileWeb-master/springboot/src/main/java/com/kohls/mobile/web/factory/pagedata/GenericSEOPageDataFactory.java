package com.kohls.mobile.web.factory.pagedata;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.GenericSeoPageData;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.SEOData;

@Component
public class GenericSEOPageDataFactory extends GenericPageDataFactory{
	
	@SuppressWarnings("unused")
	private static final Logger logger = LogManager.getLogger(GenericSEOPageDataFactory.class.getName());
	
	@Autowired
	private WebViewHelper webViewHelper;
	
	@Override
	public GenericSeoPageData getPageData(MobileWebRequestContext context, String pageName){
		PageData genericPageData = super.getPageData(context, pageName, null);
		SEOData sEOData = webViewHelper.getSEOData(context.getRequestUri(), context.getRequestQueryString(), context.isTcom());
		return new GenericSeoPageData(genericPageData, sEOData);
	}
}
