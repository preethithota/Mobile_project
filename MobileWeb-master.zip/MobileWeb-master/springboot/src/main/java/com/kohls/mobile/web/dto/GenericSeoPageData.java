package com.kohls.mobile.web.dto;

/**
 * This class is used for general SEO pages which do not require any special backend data
 * 
 */
public class GenericSeoPageData extends PageData{

	private final SEOData sEOData;
	
	public GenericSeoPageData(PageData pageData, SEOData sEOData){
		super(pageData);
		this.sEOData = sEOData;
	}
	
    public SEOData getSEOData() {
        return sEOData;
    }
	
}
