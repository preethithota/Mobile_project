package com.kohls.mobile.web.dto.backend;

import com.kohls.mobile.web.dto.SEOMetaData;

public class CatalogBackendData{

	private String data;
	private final SEOMetaData sEOMetaData;
	private final String searchTerm;
	private final String redirectUri;
	private final String autoCorrectedTerm;
	private final String backendUri;
	
	public CatalogBackendData(String data, SEOMetaData sEOMetaData, String searchTerm, String redirectUri,
			String autoCorrectedTerm, String backendUri) {	
		this.data = data;
		this.sEOMetaData = sEOMetaData;
		this.searchTerm = searchTerm;
		this.redirectUri = redirectUri;
		this.autoCorrectedTerm = autoCorrectedTerm;
		this.backendUri = backendUri;
	}

	public SEOMetaData getsEOMetaData() {
		return sEOMetaData;
	}


	public String getSearchTerm() {
		return searchTerm;
	}


	public String getRedirectUri() {
		return redirectUri;
	}


	public String getAutoCorrectedTerm() {
		return autoCorrectedTerm;
	}
	
	public String getData(){
		return data;
	}
	
	public String getBackendUri(){
		return backendUri;
	}
}
