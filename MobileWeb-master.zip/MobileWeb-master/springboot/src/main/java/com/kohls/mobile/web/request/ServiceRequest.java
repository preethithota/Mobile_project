package com.kohls.mobile.web.request;

public class ServiceRequest {
	
	private final String incommingUri;
	private final String incommingQueryString;
	
	public ServiceRequest(String incommingUri, String incommingQueryString) {
		this.incommingUri = incommingUri;
		this.incommingQueryString = incommingQueryString;
	}

	public String getIncommingUri() {
		return incommingUri;
	}

	public String getIncommingQueryString() {
		return incommingQueryString;
	}

}
