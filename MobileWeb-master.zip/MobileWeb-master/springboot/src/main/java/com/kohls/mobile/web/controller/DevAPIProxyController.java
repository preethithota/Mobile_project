package com.kohls.mobile.web.controller;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kohls.mobile.util.Constants;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.OapiResponse;
import com.kohls.mobile.web.service.ConfigurationService;
import com.kohls.mobile.web.service.HttpService;

/*
 * This should be used only in dev mode
 */
@Controller
public class DevAPIProxyController {
	
	private static final Logger logger = LogManager.getLogger(DevAPIProxyController.class.getName());	
	private static final Pattern apiUriPattern = Pattern.compile("^/api");
	private static final String[] forwardedHeaderNames = {"content-type", Constants.ACCEPT, "access_token","requestid", "x-correlation-id", "x-channel"};
	
	@Autowired
	HttpService httpService;
	
	@Autowired
	private ConfigurationService configurationService;
	
	@PostMapping("/api/**")
	@ResponseBody
	public String postRequest(HttpServletRequest request, HttpServletResponse response, @RequestBody String body,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		body = URLDecoder.decode(body, "UTF-8");
		String responseBody = httpService.postToPlatform(getBackendUri(request.getRequestURI(), request.getQueryString()), body,
				getAdditionalHeaders(request), mobileWebRequestContext);
		logger.debug("response from platform: {}", responseBody);
		return responseBody;
	}
	
	
	@GetMapping("/api/**")
	@ResponseBody
	public String getRequest(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String responseBody = httpService.getFromPlatform(getBackendUri(request.getRequestURI(), request.getQueryString()),
				getAdditionalHeaders(request), mobileWebRequestContext);
		logger.debug("response from platform: {}", responseBody);
		return responseBody;
	}
	
	@PutMapping("/api/**")
	@ResponseBody
	public String putRequest(HttpServletRequest request, HttpServletResponse response, @RequestBody String body,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		body = URLDecoder.decode(body, "UTF-8");
		String responseBody = httpService.putToPlatform(getBackendUri(request.getRequestURI(), request.getQueryString()), body,
				getAdditionalHeaders(request), mobileWebRequestContext);
		logger.debug("response from platform: {}", responseBody);
		return responseBody;
	}
	
	@DeleteMapping("/api/**")
	@ResponseBody
	public String deleteRequest(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String responseBody = httpService.deleteFromPlatform(getBackendUri(request.getRequestURI(), request.getQueryString()),
				getAdditionalHeaders(request), mobileWebRequestContext);
		logger.debug("response from platform: {}", responseBody);
		return responseBody;
	}
 
	@RequestMapping(value={"/v1/profile/password"}, method={RequestMethod.PUT, RequestMethod.POST})
	@ResponseBody
	public String sendToOapi(HttpServletRequest request, HttpServletResponse response, @RequestBody String body,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		OapiResponse oapiResponse = sendRequestToOpenApi(request, body, mobileWebRequestContext);
		response.setStatus(oapiResponse.getStatus());
		return oapiResponse.getMessage();
	}
	
	@RequestMapping(value={"/v1/profile/password/validate", "/v1/profile/email"}, method={RequestMethod.GET, RequestMethod.DELETE})
	@ResponseBody
	public String getFromOapi(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext) throws Exception{
		OapiResponse oapiResponse = sendRequestToOpenApi(request, null, mobileWebRequestContext);
		response.setStatus(oapiResponse.getStatus());
		return oapiResponse.getMessage();
	}	
	
	private OapiResponse sendRequestToOpenApi(HttpServletRequest request, String body, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String uri = request.getRequestURI().replaceAll("^/api/", "/").replaceAll("^/oapi/", "/");
		if (request.getQueryString() != null) {
			uri = uri + "?" + request.getQueryString();
		}
		HttpMethod method = HttpMethod.valueOf(request.getMethod());
		HashMap<String, String> additionalHeaders = getAdditionalHeaders(request);
		additionalHeaders.put("X-APP-API_KEY", configurationService.getOpenApiKey());
		OapiResponse oapiResponse = httpService.proxyOpenApiRequest(method, uri, body, additionalHeaders, mobileWebRequestContext);
		return oapiResponse;
	}
	
	private String getBackendUri(String incomingUri, String queryString){
		return apiUriPattern.matcher(incomingUri).replaceFirst("") + ((queryString != null) ? "?" + queryString: "");
	}
	
	private HashMap<String, String> getAdditionalHeaders(HttpServletRequest request){
		HashMap<String, String> additionalHeaders = new HashMap<String, String>();		
		for (String headerName: forwardedHeaderNames){
			String headerValue = request.getHeader(headerName);
			if (headerValue != null){
				additionalHeaders.put(headerName, headerValue);
			}
		}
		return additionalHeaders;
	}	
	
}


