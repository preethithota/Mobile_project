package com.kohls.mobile.web.service;

import java.time.Instant;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kohls.mobile.util.Constants;
import com.kohls.mobile.web.dto.MobileWebRequestContext;

@Service
public class WCSService {
	
	@SuppressWarnings("unused")
	private static final Logger logger = LogManager.getLogger(WCSService.class.getName());
	
	private static final String WCS_PATH = "/v1/content";
		
	@Autowired
	private HttpService httpService;
	
	@Autowired
	ConfigurationService configurationService;
	
	public String getFooterContent(MobileWebRequestContext mobileWebRequestContext) throws Exception{
		return getContent("/footeranonymous", mobileWebRequestContext);
	}
	
	public String getHomePageSEOContent(MobileWebRequestContext mobileWebRequestContext) throws Exception{
		return getContent("/home-seo", mobileWebRequestContext);		
	}
	
	public String getBannerContent(MobileWebRequestContext mobileWebRequestContext) throws Exception{
		if (mobileWebRequestContext.isTcom()){
			return getContent("/banner", mobileWebRequestContext);
		}else{
			return "";
		}
	}
	
	public String getContent(String path, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String channelPath = (mobileWebRequestContext.isTcom()) ? "tablet" : "mcom";
		String wcsEnv = configurationService.getConfiguration().getString("wcs.environment");
		String backendPath = WCS_PATH + path + "?channel=" + channelPath + "&environment=" + wcsEnv;
		if ("stage".equals(wcsEnv)){
			if (mobileWebRequestContext.getPreviewDate() != null){
				backendPath += "&previewdate=" + mobileWebRequestContext.getPreviewDate();
			}
			backendPath += "&timeStamp=" + Instant.now().toEpochMilli();
		}

		HashMap<String, String> additionalHeaders = new HashMap<String, String>();
		additionalHeaders.put(Constants.ACCEPT, "text/html");
		return httpService.getFromPlatform(backendPath, additionalHeaders, mobileWebRequestContext);
		//return httpService.getOpenApiData(backendPath, mobileWebRequestContext);
	}
}
