package com.kohls.mobile.web.request;

public class ProductServiceRequest{
	
	private final String productId;
	private final boolean skuDetail;
	private final boolean invFilter;
	
	public ProductServiceRequest(String productId, boolean skuDetail, boolean invFilter) {
		this.productId = productId;
		this.skuDetail = skuDetail;
		this.invFilter = invFilter;
	}
	
	public String getProductId() {
		return productId;
	}
	public boolean isSkuDetail() {
		return skuDetail;
	}
	public boolean isInvFilter() {
		return invFilter;
	}

}
