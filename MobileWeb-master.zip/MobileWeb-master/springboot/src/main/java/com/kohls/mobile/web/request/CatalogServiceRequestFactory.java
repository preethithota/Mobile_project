package com.kohls.mobile.web.request;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.web.service.ConfigurationService;

@Component
public class CatalogServiceRequestFactory {
	
	@Autowired
	private ConfigurationService configurationService;
	
	public CatalogServiceRequest getCatalogServiceRequest(HttpServletRequest request, boolean isTcom){
		String offset = request.getParameter("WS");
		boolean isSolr = configurationService.getConfiguration().getBoolean("catalog.solr.enabled");
		String requestLimit = request.getParameter("limit");
		String resultCountProperty = "catalogpage.results." + ((isTcom) ? "tcom" : "mcom");
		String limit = (requestLimit != null) ? requestLimit : configurationService.getConfiguration().getString(resultCountProperty);
		String sortID = request.getParameter("S");
		String storeNum = request.getParameter("storeid");
		String keyword = request.getParameter("search");
		String incommingQueryString = request.getQueryString();
		String incommingUri = request.getRequestURI();
		
		return new CatalogServiceRequest(incommingUri, incommingQueryString, offset, isSolr, limit, sortID, storeNum, keyword);
	}

}
