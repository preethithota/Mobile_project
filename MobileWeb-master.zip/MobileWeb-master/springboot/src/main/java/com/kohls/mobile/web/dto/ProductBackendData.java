package com.kohls.mobile.web.dto;

import com.kohls.mobile.web.dto.SEOMetaData;
public class ProductBackendData {
	
	private final String data;
	private final String backendUri;
	private final SEOMetaData sEOMetaData;
	
	public ProductBackendData(String data, String backendUri , SEOMetaData sEOMetaData) {
		this.data = data;
		this.backendUri = backendUri;
		this.sEOMetaData = sEOMetaData;
	}
	
	public SEOMetaData getsEOMetaData() {
		return sEOMetaData;
	}

	public String getData() {
		return data;
	}

	public String getBackendUri() {
		return backendUri;
	}
	
}
