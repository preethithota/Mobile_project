package com.kohls.mobile.web.request;

public class CatalogServiceRequest extends ServiceRequest{
	
	private final String offset;
	private final boolean isSolr;
	private final String limit;
	private final String sortID;
	private final String storeNum;
	private final String keyword;
	
	public CatalogServiceRequest(String incommingUri, String incommingQueryString, String offset, 
			boolean isSolr, String limit, String sortID, String storeNum, String keyword) {		
		super(incommingQueryString, incommingQueryString);
		this.offset = offset;
		this.isSolr = isSolr;
		this.limit = limit;
		this.sortID = sortID;
		this.storeNum = storeNum;
		this.keyword = keyword;
	}

	public String getOffset() {
		return offset;
	}

	public boolean isSolr() {
		return isSolr;
	}

	public String getLimit() {
		return limit;
	}

	public String getSortID() {
		return sortID;
	}

	public String getStoreNum() {
		return storeNum;
	}

	public String getKeyword() {
		return keyword;
	}
}
