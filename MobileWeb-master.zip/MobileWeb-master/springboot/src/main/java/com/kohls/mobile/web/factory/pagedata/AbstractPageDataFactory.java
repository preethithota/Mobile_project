package com.kohls.mobile.web.factory.pagedata;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.command.BannerContentRequestCommand;
import com.kohls.mobile.command.FooterContentRequestCommand;
import com.kohls.mobile.command.HeaderCommand;
import com.kohls.mobile.util.CacheKeys;
import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.scripting.HeaderScriptEngine;
import com.kohls.mobile.web.service.CacheService;
import com.kohls.mobile.web.service.ConfigurationService;
import com.kohls.mobile.web.service.WCSService;

/**
 * This class is an abstract factory to construct the pages.  Pages have to be constructed in a specific way
 * in order to maximize concurrency.  This factory ensures that the requests for common header and footer data
 * are made in parallel with the request for page data
 */
@Component
public abstract class AbstractPageDataFactory<T extends PageData, D /*backend data*/, R /*service request*/ >{
	
	private static final Logger logger = LogManager.getLogger(AbstractPageDataFactory.class.getName());
	
	@Autowired
	private WCSService wCSService;
	
	@Autowired
	private HeaderScriptEngine headerScriptEngine;
	
	@Autowired
	private ConfigurationService configurationService;
	
	@Autowired
	private WebViewHelper webViewHelper;
	
	@Autowired
	private CacheService cacheService;
	
	public T getPageData(MobileWebRequestContext context, String pageName, R serviceRequest){
		PageBuilder pageBuilder = new PageBuilder(context, pageName, serviceRequest);
		return pageBuilder.build();
	}
	
	protected abstract D getBackendData(MobileWebRequestContext context, R serviceRequest);
	
	protected abstract T buildPageData(PageData genericPageData, D backendPageData, MobileWebRequestContext context);
	
	/**
	 * This private builder maintains the state of the page data object as it's being constructed.
	 */
	private class PageBuilder {

		private D backendPageData;
		private R serviceRequest;
		private MobileWebRequestContext context;
		private PageData genericPageData;
		private String pageName;
		private String headerContent;
		private String bannerContent;
		private String footerContent;
		private BannerContentRequestCommand bannerContentRequestCommand;
		private FooterContentRequestCommand footerContentRequestCommand;
		private HeaderCommand headerCommand;
		private Future<String> bannerContentFuture;
		private Future<String> footerContentFuture;
		private Future<String> headerContentFuture;
		
		public PageBuilder(MobileWebRequestContext context, String pageName, R serviceRequest){
			this.context = context;
			this.pageName = pageName;
			this.serviceRequest = serviceRequest;
		}
		
		public T build(){
			Instant t1 = Instant.now();
			PageBuilder builder = getCachedCommmonElements() //check cache
					.getFuturesForNonCachedCommonElements() // queue up common Hystrix commands
					.buildBody() // call abstract factory method setBodyData()
					.buildGenericPageData();
		
			T pageData = builder.buildPageDataFromGeneric(genericPageData, backendPageData, context);
			long durationInMs = Duration.between(t1, Instant.now()).toMillis();
			logger.info("Total page rendering time for {} is {} ms; CID: {}", pageName, durationInMs, context.getCorrelationId());
			return pageData;
		}
		
		private T buildPageDataFromGeneric(PageData genericPageData, D backendPageData, MobileWebRequestContext context){
			return buildPageData(genericPageData, backendPageData, context); //return factory buildPageData()
		}

		private PageBuilder getCachedCommmonElements(){
			
			footerContent = cacheService.get(CacheKeys.FOOTER_CONTENT, context);
			
			//footerContent = localCacheService.getFooterContentCache().get(CacheKeys.FOOTER_CONTENT);
			 
			if (context.isTcom()){
				//bannerContent = localCacheService.getBannerContentCache().get(CacheKeys.BANNER_CONTENT);
				bannerContent = cacheService.get(CacheKeys.BANNER_CONTENT, context);
			}
			
			//headerContent = localCacheService.getHeaderCache().get(CacheKeys.HEADER_CONTENT);
			headerContent = cacheService.get(CacheKeys.HEADER_CONTENT, context);
			return this;
		}
		
		// this method queues the common header data calls meaning that the command is triggered asynchronously
		private PageBuilder getFuturesForNonCachedCommonElements(){
			if (footerContent == null){
				footerContentRequestCommand = new FooterContentRequestCommand(context, wCSService);
				footerContentFuture = footerContentRequestCommand.queue();
			}
			if (context.isTcom() && bannerContent == null){
				bannerContentRequestCommand = new BannerContentRequestCommand(context, wCSService);
				bannerContentFuture = bannerContentRequestCommand.queue();
			}
			
			if (headerContent == null){
				headerCommand = new HeaderCommand(context, headerScriptEngine);
				headerContentFuture = headerCommand.queue();
			}
			return this;
		}

		private PageBuilder buildBody(){
			backendPageData = getBackendData(context, serviceRequest);
			return this;
		}
		
		private String getAndCacheContent(Future<String> future, String currentContent, String cacheKey){
			if (currentContent != null){
				return currentContent;
			}
			
			try{
				String content = future.get();
				if (content != null){
					cacheService.put(cacheKey, content, context);
				}
				return content;
			}catch(Exception e){
				logger.error(Utils.getErrorMessage(context, "Error getting content for " + cacheKey + ": " + e.getMessage()));
				return "";
			}
		}
		
		private PageBuilder buildGenericPageData(){
			boolean isDevBundleMode = context.isDevBundleMode();
			bannerContent = context.isTcom() ? getAndCacheContent(bannerContentFuture, bannerContent, CacheKeys.BANNER_CONTENT) : "";
			footerContent = getAndCacheContent(footerContentFuture, footerContent, CacheKeys.FOOTER_CONTENT);
			headerContent = getAndCacheContent(headerContentFuture, headerContent, CacheKeys.HEADER_CONTENT);
			
			Map<String, String> assetMap;
			try{
				assetMap = webViewHelper.getAssetMap(context.isDevBundleMode());
			}catch(Exception e){
				logger.error("Error in getAssetMap. Cannot load asset path list", e);
				assetMap = new HashMap<String, String>();
			}
			
			String assetPath = isDevBundleMode ? configurationService.getDevScriptsBundlePath() : configurationService.getProdScriptsBundlePath();
			
			genericPageData = new PageData(
				context.isTcom(),
				configurationService.getConfiguration(),
				pageName,
				headerContent,
				footerContent,
				bannerContent,
				assetMap,
				assetPath,
				context.isDevBundleMode());
			
			return this;
		}
	}
}
