package com.kohls.mobile.web.dto;

/**
 * Created by tkmabj6 on 3/8/17.
 */
public class CheckoutData extends PageData {
    private final SEOData seoContent;

    public CheckoutData(PageData pageData, SEOData seoContent) {
        super(pageData);
        this.seoContent = seoContent;
    }

    public SEOData getSEOData() {
        return seoContent;
    }
}