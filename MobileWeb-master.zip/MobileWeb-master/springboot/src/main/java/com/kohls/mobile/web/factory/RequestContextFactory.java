package com.kohls.mobile.web.factory;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.util.Constants;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.service.ConfigurationService;

@Component
public class RequestContextFactory {
	
	@Autowired
	private ConfigurationService configurationService;
	
	@Autowired
	WebViewHelper webViewHelper;

	public MobileWebRequestContext getMobileWebRequestContext(HttpServletRequest request){
		
		Cookie[] cookies = request.getCookies();
		String tcomHeaderName = configurationService.getConfiguration().getString("tcom.headername");
		boolean isTcom;
		if ("true".equalsIgnoreCase(request.getHeader(tcomHeaderName))){
			isTcom = true;
		}else{
			isTcom = Boolean.valueOf(webViewHelper.getCookieValue("isTcom", cookies));
		}
		
		String debugCookieStr = webViewHelper.getCookieValue("kohls_debug", cookies);
		boolean isDebugMode = Boolean.valueOf(debugCookieStr);
		
		String correlationId = webViewHelper.getCookieValue(Constants.COR_ID_KEY, cookies);
		if (correlationId == null){
			correlationId = "";
		}
		
		String previewDate = webViewHelper.getCookieValue("previewdate", cookies);
		if ("".equals(previewDate)){
			previewDate = null;
		}
		
		String dateFormatString = configurationService.getConfiguration().getString("config.correlationid.timestamp.format");
		if (correlationId.split("-").length < 4){
			correlationId += "-" + (new SimpleDateFormat(dateFormatString).format(new Date()));
		}
		
		MobileWebRequestContext mobileWebRequestContext = new MobileWebRequestContext(isTcom, correlationId, isDebugMode, 
				previewDate, request.getRequestURI(), request.getQueryString());
		
		return mobileWebRequestContext;
	}
	
}
