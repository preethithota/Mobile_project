package com.kohls.mobile.web.interceptor;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.factory.RequestContextFactory;

@ControllerAdvice
public class MobileWebControllerAdvice {
	
	@Autowired
	RequestContextFactory requestContextFactory;
	
	@ModelAttribute("mobileWebRequestContext")
    public MobileWebRequestContext getMobileWebRequestContext(HttpServletRequest request) {
		MobileWebRequestContext mobileWebRequestContext = requestContextFactory.getMobileWebRequestContext(request);
		return mobileWebRequestContext;
    }

}
