package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.factory.pagedata.GenericPageDataFactory;

@Controller
public class ErrorPageController {
	
	@Autowired
	GenericPageDataFactory genericPageDataFactory;
	
	private static final Logger logger = LogManager.getLogger(ErrorPageController.class.getName());
	
	@GetMapping("/error")
	public ModelAndView getErrorPage(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		logger.info(Utils.getErrorMessage(context, "Displaying error page"));
		PageData pageData = genericPageDataFactory.getPageData(context, "error");
		return new ModelAndView("global-template", "pageData", pageData);			
	}
}
