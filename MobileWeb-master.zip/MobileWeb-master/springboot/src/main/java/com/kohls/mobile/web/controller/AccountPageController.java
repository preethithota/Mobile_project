package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.factory.pagedata.GenericPageDataFactory;

@Controller
public class AccountPageController {
	
	private static final Logger logger = LogManager.getLogger(AccountPageController.class.getName());
	
	@Autowired
	private GenericPageDataFactory genericPageDataFactory;
	
	@Autowired
	private WebViewHelper webViewHelper;

	@GetMapping("/myaccount/v2/myinfo.jsp")
	public ModelAndView getAccountPage(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext){
		try{
			if (webViewHelper.getCookieValue("accessToken", request.getCookies()) == null){
				return new ModelAndView("redirect:/");
			};
			
			PageData pageData = genericPageDataFactory.getPageData(mobileWebRequestContext, "account");
			
			return new ModelAndView("global-template", "pageData", pageData);
		}catch (Exception ex) {
			logger.error(Utils.getErrorMessage(mobileWebRequestContext, "Error in getAccountPage"), ex);
			return webViewHelper.getErrorMv(request, ex);
		}
	}
	
}
