package com.kohls.mobile.web.factory.pagedata;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.ProductBackendData;
import com.kohls.mobile.web.dto.ProductPageData;
import com.kohls.mobile.web.dto.SEOData;
import com.kohls.mobile.web.request.ProductServiceRequest;
import com.kohls.mobile.web.scripting.PdpScriptEngine;
import com.kohls.mobile.web.service.CacheService;
import com.kohls.mobile.web.service.ProductService;

@Component
public class ProductPageDataFactory extends AbstractPageDataFactory<ProductPageData, ProductBackendData, ProductServiceRequest>{
	
	private static final Logger logger = LogManager.getLogger(ProductPageDataFactory.class.getName());
	
	@Autowired
	ProductService productService;
		
	@Autowired
	private WebViewHelper webViewHelper;
	
	@Autowired
	private PdpScriptEngine pdpScriptEngine;
	
	@Autowired
	private CacheService cacheService;
	
	public ProductPageData getPageData(MobileWebRequestContext context, String pageName, ProductServiceRequest productServiceRequest){
		return super.getPageData(context, pageName, productServiceRequest);
	}

	@Override
	protected ProductBackendData getBackendData(MobileWebRequestContext context, ProductServiceRequest productServiceRequest){
		
		try{
			return productService.getProductData(productServiceRequest, context);
		}catch(Exception e){
			logger.error(Utils.getErrorMessage(context, "Error in ProductPageDataFactory.getBackendData() for productId: "
					+ productServiceRequest.getProductId()), e);
		}
		return null;
	}
	
	@Override
	protected ProductPageData buildPageData(PageData genericPageData, ProductBackendData productBackendData, MobileWebRequestContext context){
		SEOData sEOData = webViewHelper.getSEOData(context.getRequestUri(), context.getRequestQueryString(), context.isTcom(), productBackendData.getsEOMetaData(),"");
		String bodyContent = cacheService.getPdpPage(productBackendData.getBackendUri(), context);
		if (bodyContent == null){
			bodyContent = getBodyHtml(productBackendData.getData(), context);
			if (bodyContent != null){
				cacheService.putPdpPage(productBackendData.getBackendUri(), bodyContent, context);
			}
		}
		
		return new ProductPageData(genericPageData, bodyContent, productBackendData.getData(), sEOData);
	}
	
	private String getBodyHtml(String data, MobileWebRequestContext context){
		try {
			return pdpScriptEngine.invokeFunction(data, context.isTcom());
		} catch (Exception ex) {
			logger.error(Utils.getErrorMessage(context, "Error in rendering PDP javascript"), ex);
		}
		return "";
	}
}
