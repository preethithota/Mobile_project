package com.kohls.mobile.web.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.annotation.PostConstruct;

import org.apache.http.client.utils.URIBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kohls.mobile.command.CatalogRequestCommand;
import com.kohls.mobile.util.Utils;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.SEOMetaData;
import com.kohls.mobile.web.dto.backend.CatalogBackendData;
import com.kohls.mobile.web.request.CatalogServiceRequest;

@Service
public class CatalogService {
	
	private static final Logger logger = LogManager.getLogger(CatalogService.class.getName());
	
	private static final String CATALOG_URI = "/v1/catalog/";
	
	private static final String DIMENSION_SEPARATOR = "+";
	private static final String NVP_SEPARATOR = ":";
	private static final String ENCODING = "UTF-8";
	private String encodedPlus, encodedColon;
	
	@Autowired
	private HttpService httpService;
	
	@Autowired
	private CacheService cacheService;
	
	@PostConstruct
	protected void init() throws Exception{
		encodedPlus = URLEncoder.encode(DIMENSION_SEPARATOR, ENCODING);
		encodedColon = URLEncoder.encode(NVP_SEPARATOR, ENCODING);	
	}

	public String getDimensions(CatalogServiceRequest catalogServiceRequest, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		
		String backendPath = getBackendPath(catalogServiceRequest, mobileWebRequestContext);
		String catalogData = getCatalog(backendPath, mobileWebRequestContext);
		
		ObjectMapper objectMapper = new ObjectMapper();
		
    	JsonNode sourceNode = objectMapper.readTree(catalogData);
    	JsonNode payloadNode = sourceNode.get("payload");
    	JsonNode dimensionsNode = payloadNode.get("dimensions");
    	
    	return dimensionsNode.toString();
	}
	
	public CatalogBackendData getProducts(CatalogServiceRequest catalogServiceRequest, MobileWebRequestContext mobileWebRequestContext) throws Exception{
		String backendPath = getBackendPath(catalogServiceRequest, mobileWebRequestContext);
		String catalogData = getCatalog(backendPath, mobileWebRequestContext);
		return tranformCatalogData(catalogData, catalogServiceRequest.getKeyword(), backendPath);
	}
	
	private CatalogBackendData tranformCatalogData(String inputJson, String clientEnteredSearchTerm, String backendPath) throws Exception{
		ObjectMapper objectMapper = new ObjectMapper();
		
    	JsonNode sourceNode = objectMapper.readTree(inputJson);
    	JsonNode payloadNode = sourceNode.get("payload");
    	JsonNode productsNode = payloadNode.get("products");
    	ObjectNode outputNode = objectMapper.createObjectNode();
    	
    	String autoCorrectedTerm = null;
    	if (!(null == payloadNode.get("autoCorrectedTerm")) && !payloadNode.get("autoCorrectedTerm").isNull()){
    		autoCorrectedTerm = payloadNode.get("autoCorrectedTerm").asText();
    	}
    	
    	if (productsNode.isArray() && productsNode.size() == 1){
    		JsonNode productNode = productsNode.get(0);
    		if (productNode != null && productNode.get("seoURL") != null){    			
    			String redirectUrl = productNode.get("seoURL").asText();
    			outputNode.put("redirectUrl", redirectUrl);
    			String catalogJson = outputNode.toString();
    			return new CatalogBackendData(catalogJson, null, "", redirectUrl, autoCorrectedTerm, backendPath);
    		}
    	}
    	
    	String[] fieldsToAdd = {"count", "limit", "offset"};
    	for (String field: fieldsToAdd){
    		outputNode.set(field, sourceNode.get(field));
    	}
    	
    	outputNode.set("products", productsNode);
    	outputNode.set("sorts", payloadNode.get("sorts"));
    	outputNode.set("h1Tag", payloadNode.get("h1Tag"));
    	outputNode.set("visualNavTiles", payloadNode.get("visualNavTiles"));
    	outputNode.set("activeDimensions", payloadNode.get("activeDimensions"));
    	outputNode.set("activeStores", payloadNode.get("activeStores"));
    	JsonNode searchTermNode = payloadNode.get("searchTerm");
    	String searchTerm;
    	if(searchTermNode != null && !"null".equals(searchTermNode.asText())){
    		searchTerm = searchTermNode.asText();
    	}else if(clientEnteredSearchTerm != null){
    		searchTerm = Encode.forHtmlAttribute(clientEnteredSearchTerm);
    	}else{
    		searchTerm = "";
    	}
    	outputNode.put("searchTerm", searchTerm);
    	
    	String redirectUri = null;
    	JsonNode linksNode = payloadNode.get("links");
    	if (linksNode != null && linksNode.isArray()){
    		for(JsonNode node : linksNode){
        		if (node.get("rel") != null && "redirect".equals(node.get("rel").asText())){
        			redirectUri = (node.get("uri") != null) ? node.get("uri").asText() : null;
        		}
    		}
    	}
    	
    	String catalogJson = outputNode.toString();
    	
    	JsonNode metaInfo = payloadNode.get("metaInfo");
    	SEOMetaData sEOMetaData;
    	if (metaInfo != null){
    		sEOMetaData = new SEOMetaData(
    				metaInfo.get("metaTitle") == null ? "" : metaInfo.get("metaTitle").asText(),
    				metaInfo.get("metaDescription") == null ? "" : metaInfo.get("metaDescription").asText(),
    				metaInfo.get("metaKeywords") == null ? "" : metaInfo.get("metaKeywords").asText());
    	}else{
    		sEOMetaData = new SEOMetaData("", "", "");
    	}
    	
    	CatalogBackendData catalogBackendData = new CatalogBackendData(catalogJson, sEOMetaData, searchTerm, redirectUri, autoCorrectedTerm, backendPath);
    	return catalogBackendData;
	}
	
	protected String getBackendPath(CatalogServiceRequest catalogServiceRequest, MobileWebRequestContext context) throws Exception{
		//StringBuilder backendPathBuilder = new StringBuilder(CATALOG_URI + getCNParam(catalogServiceRequest.getIncommingQueryString(), context));
		StringBuilder backendPathBuilder = new StringBuilder(CATALOG_URI);
		
		URIBuilder uRIBuilder = new URIBuilder(backendPathBuilder.toString());
		
	
		String requestOffset = catalogServiceRequest.getOffset();
		if (requestOffset != null && requestOffset.length() > 0 && !"0".equals(requestOffset.trim())){
			uRIBuilder.setParameter("offset", requestOffset);
		}
		
		//uRIBuilder.setParameter("isSolr", Boolean.toString(catalogServiceRequest.isSolr()));
		uRIBuilder.setParameter("limit", catalogServiceRequest.getLimit());
		
		String sortId = catalogServiceRequest.getSortID();
		if (sortId != null && sortId.length() > 0){
			uRIBuilder.setParameter("sortID", sortId);
		}

		String storeNum = catalogServiceRequest.getStoreNum();
        if (storeNum != null && storeNum.length() > 0){
            uRIBuilder.setParameter("storeNum", storeNum);
        }
		
        String searchParam = catalogServiceRequest.getKeyword();
		if (searchParam != null && searchParam.length() > 0){
			uRIBuilder.setParameter("keyword", searchParam);
		}
		
		String backendPath = uRIBuilder.toString();
		
		// we can't add the CN param to the uri builder like a normal param... again, because of the bastardized Solr ids
		return backendPath + ((backendPath.indexOf("?") > -1) ? "&" : "?") + getCNParam(catalogServiceRequest.getIncommingQueryString(), context);
	}
	
	private String getCatalog(String backendPath, MobileWebRequestContext context) throws Exception{
		
		String data = cacheService.getCatalogData(backendPath, context);
		
		if (data == null){
			CatalogRequestCommand catalogRequestCommand = new CatalogRequestCommand(backendPath, context, httpService);
			data = catalogRequestCommand.execute();
			if (data != null){
				cacheService.putCatalogData(backendPath, data, context);	
			}
		}

		if (logger.isDebugEnabled()){
			logger.debug("data from backend is {}", data);
		}
		
		return data;
	}
	
	protected String getCNParam(String queryString, MobileWebRequestContext mobileWebRequestContext){
		String cnParam = "";
		if(queryString !=null){
		String[] qsParams = queryString.split("&");
		String cnValue = null, nValue = "";
		
		//We have to do this vs. calling request.getParameter because of the Solr team's bastardized URL encoding
		for (String param: qsParams){
			String[] paramNameValuePair = param.split("=");
			if ("CN".equals(paramNameValuePair[0]) && paramNameValuePair.length > 1){
				cnValue = paramNameValuePair[1];
			}
		}
		
		for (String param: qsParams){
			String[] paramNameValuePair = param.split("=");
			if ("N".equals(paramNameValuePair[0]) && paramNameValuePair.length > 1){
				nValue = paramNameValuePair[1];
			}
		}
				
		if (cnValue == null){
			cnValue = nValue;
		}else{
			cnValue = ("".equals(nValue)) ? cnValue : cnValue + "+" + nValue;
		}
		
		if ("".equals(cnValue)){
			return "";
		}
		
		StringBuilder sb = new StringBuilder();
		String[] dimensions = cnValue.split("\\" + DIMENSION_SEPARATOR);
		int i = 0;
		for (String dimension: dimensions){
			String[] dimensionNVP = dimension.split(NVP_SEPARATOR);
			if (dimensionNVP.length == 2){
				if (i > 0){
					sb.append(encodedPlus);
				}
				sb.append(dimensionNVP[0] + encodedColon + dimensionNVP[1]);
				i++;
			}
		}
				
		cnParam = sb.toString();
		if (cnParam.length() == 0){
			try{
				cnParam = URLEncoder.encode(cnValue, ENCODING);
			}catch(UnsupportedEncodingException e){
				logger.error(Utils.getErrorMessage(mobileWebRequestContext, "Error encoding cnValue "), e);
				cnParam = cnValue;
			}
		}
		}

		return "dimensionValueID=" + cnParam;
	}
}
