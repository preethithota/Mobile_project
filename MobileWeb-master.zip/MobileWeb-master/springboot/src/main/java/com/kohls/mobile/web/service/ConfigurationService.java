package com.kohls.mobile.web.service;

import java.io.File;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.configuration2.ConfigurationUtils;
import org.apache.commons.configuration2.ImmutableConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class ConfigurationService {
	private static final Logger logger = LogManager.getLogger(ConfigurationService.class.getName());
	private ImmutableConfiguration configuration;

	@PostConstruct
	private void init() {
		Configurations configurations = new Configurations();

		try {
			PropertiesConfiguration appConfig = getEnvironmentConfig(configurations);
			PropertiesConfiguration configProperties = configurations.properties(new File("config.properties"));
			
			if (appConfig != null){
				appConfig.append(configProperties);
			}else{
				appConfig = configProperties;
			}

			configuration = ConfigurationUtils.unmodifiableConfiguration(appConfig);
		} catch (ConfigurationException e) {
			logger.error("Error loading configuration: {}", e.getMessage());
		}
	}
	
	private PropertiesConfiguration getEnvironmentConfig(Configurations configurations){
		try{
			//String envConfigHome = getSystemEnvVariableValue("ENVIRONMENT_CONFIG_HOME");
			String envConfigHome = getSystemEnvVariableValue("ENVIRONMENT_CONFIG_PATH");
			PropertiesConfiguration defaultConfig = configurations.properties(new File("default-environment.properties"));
			if (envConfigHome == null){
				logger.info("ENVIRONMENT_CONFIG_PATH not found, so using default-environment.properties instead");
				return defaultConfig;
			}
			String secretsConfigHome = getSystemEnvVariableValue("CREDENTIALS_PATH");
			if (secretsConfigHome == null){
				logger.info("CREDENTIALS_PATH not found, so using default-environment.properties instead");
				return defaultConfig;
			}
			
			String envFilePath = envConfigHome + "/environment.properties";
			PropertiesConfiguration localConfig = null; 
			
			int i = 0;
			int maxTries = 5;
			try{
				while (i < maxTries){
					logger.debug("Loading configuration from {}, attempt number {} ", envFilePath, i + 1);
					try{
						localConfig = configurations.properties(new File(envFilePath));
						break;
					}catch(ConfigurationException ce){
						logger.error("ConfigurationException loading env properties from path: {}, retrying {} more times, error: {}", envFilePath, (5 - (i+1)), ce.getMessage());
					}
					i++;
					TimeUnit.SECONDS.sleep(3);
				}
			}catch(InterruptedException ie){
				logger.error("InterruptedException checking config props");
			}
			if (localConfig == null){
				logger.error("Error loading environment properties");
				return null;
			}

			printConfig(localConfig, envFilePath);			
			PropertiesConfiguration secretsConfig = configurations.properties(new File(secretsConfigHome + "/secret.properties"));
			localConfig.append(secretsConfig);
			//the config from $ENVIRONMENT_CONFIG_HOME/environment.properties should take precedence over default-environment.properties			
			localConfig.append(defaultConfig);
			
			return localConfig;
		}catch (ConfigurationException e) {
			logger.error("Error in getEnvironmentConfig: {}", e.getMessage());
		}
		return null;		
	}
	
	public ImmutableConfiguration getConfiguration() {
		return configuration;
	}
	
	public String getString(String key){
		return configuration.getString(key);
	}
	
	public int getInt(String key){
		return configuration.getInt(key);
	}
	
	public long getLong(String key){
		return configuration.getLong(key);
	}
	
	public boolean getBoolean(String key){
		return configuration.getBoolean(key);
	}

	public boolean alwaysReloadScripts() {
		return configuration.getBoolean("scripts.allwaysReload");
	}

//	public boolean useProdScriptBundles() {
//		return configuration.getBoolean("scripts.useProdBundles");
//	}

	public String getProdScriptsBundlePath() {
		return configuration.getString("scripts.prodBundlePath");
	}

	public String getDevScriptsBundlePath() {
		return configuration.getString("scripts.devBundlePath");
	}

	public String getOpenApiBaseUrl() {
		return configuration.getString("openapi.baseurl");
	}

	public String getOpenApiKey() {
		return configuration.getString("openapi.apikey");
	}
	
	public String getSystemEnvVariableValue(String envVariableName){
		Map<String, String> env = System.getenv();

		String value = env.get(envVariableName);
		if (value == null){
			logger.error("Error: {} env variable not set.", envVariableName);
		}
		return value;
	}
	
	public String getFrontEndHome(){
		return getSystemEnvVariableValue("MOBILEWEB_FRONTEND_HOME");
	}
	
	public String getProxyHost(){
		String proxyHostProperty = "http.proxyHost";
		String proxyHost = System.getProperty(proxyHostProperty);
		if (proxyHost == null){
			proxyHost = configuration.getString(proxyHostProperty);
		}
		return proxyHost;
	}
	
	public boolean isProxyEnabled(){
		return getProxyHost() != null;
	}
	
	public boolean isDevMode(){
		return configuration.getBoolean("application.devmode");
	}
	
	public int getProxyPort(){
		String proxyPortProperty = "http.proxyPort";
		String proxyPort = System.getProperty(proxyPortProperty);
		if (proxyPort == null){
			proxyPort = configuration.getString(proxyPortProperty);
		}
		return Integer.parseInt(proxyPort);
	}
	
	public boolean isCacheServiceEnabled(){
		return configuration.getBoolean("cacheService.enabled");
	}
	
	public String getPublicPath(){
		return configuration.getString("scripts.internalResourceDir");
	}
	
	public boolean isRedisEnabled(){
		return configuration.getBoolean("redis.enabled");
	}
	
	public boolean isEhcacheEnabled(){
		return configuration.getBoolean("ehcache.enabled");
	}
	
	public boolean isPocEnabled(){
		return configuration.getBoolean("poc.enabled");
	}
	
	private void printConfig(PropertiesConfiguration config, String path){
		if (!logger.isDebugEnabled()){
			return;
		}
		logger.info("The following properties are configured in {}", path);
		Iterator<String> keys = config.getKeys();
		while(keys.hasNext()){
			String key = keys.next();
			logger.info("config prop: {}: {}", key, config.getString(key));
		}
	}
}
