package com.kohls.mobile.web.factory.pagedata;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.PageData;

@Component
public class GenericPageDataFactory extends AbstractPageDataFactory<PageData, String, String>{
	
	@SuppressWarnings("unused")
	private static final Logger logger = LogManager.getLogger(GenericPageDataFactory.class.getName());
	
	public PageData getPageData(MobileWebRequestContext context, String pageName){
		return super.getPageData(context, pageName, null);
	}
		
	@Override
	protected String getBackendData(MobileWebRequestContext context, String serviceRequest){
		return null;
	}
	
	@Override
	protected PageData buildPageData(PageData genericPageData, String backendPageData, MobileWebRequestContext context){
		return genericPageData;
	}
}
