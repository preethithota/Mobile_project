package com.kohls.mobile.exception;

import java.io.IOException;

public class PlatformException extends IOException{
	
	private static final long serialVersionUID = 1L;

	public PlatformException(String message, String responseStatus) {
        super(getErrorMessage(message, responseStatus));
    }

    public PlatformException(String message, String responseStatus, Throwable throwable) {
        super(getErrorMessage(message, responseStatus), throwable);
    }
    
    private static String getErrorMessage(String message, String responseStatus){
    	return String.format("ResponseStatus: %s, Message: %s", responseStatus, message);
    }
}
