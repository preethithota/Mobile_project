package com.kohls.mobile.web.request;

public class CatalogRequest{
	//TODO: implement this
	

}
