package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.util.Utils;
import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.CatalogPageData;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.dto.MoreLikeThisPageData;
import com.kohls.mobile.web.dto.PageData;
import com.kohls.mobile.web.dto.backend.CatalogBackendData;
import com.kohls.mobile.web.factory.pagedata.CatalogPageDataFactory;
import com.kohls.mobile.web.factory.pagedata.GenericPageDataFactory;
import com.kohls.mobile.web.factory.pagedata.MoreLikeThisPageDataFactory;
import com.kohls.mobile.web.request.CatalogServiceRequest;
import com.kohls.mobile.web.request.CatalogServiceRequestFactory;
import com.kohls.mobile.web.request.ProductServiceRequest;
import com.kohls.mobile.web.service.WCSService;

@Controller
public class CatalogPageController {
	
	private static final Logger logger = LogManager.getLogger(CatalogPageController.class.getName());
	
	@Autowired
	private WebViewHelper webViewHelper;
	
	@Autowired
	private CatalogPageDataFactory catalogPageDataFactory;
	
	@Autowired
	private CatalogServiceRequestFactory catalogServiceRequestFactory;
	
	@Autowired
	private MoreLikeThisPageDataFactory moreLikeThisPageDataFactory;
	
	@Autowired
	private GenericPageDataFactory genericPageDataFactory;
	
	@Autowired
	WCSService wCSService;	
	
	@GetMapping(value={"/search", "/search/{pageName}.jsp"})
	public ModelAndView getSearchResults(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		try{
 			logger.debug("recieved search page request for {}", request.getRequestURI());
 			CatalogPageData catalogPageData = getCatalogPageData(request, context);
 			CatalogBackendData catalogBackendData = catalogPageData.getCatalogBackendData();
			
			if (!Utils.isStringEmpty(catalogBackendData.getRedirectUri())){
				//String redirectProductURL = catalogBackendData.getRedirectUri().split("/prd-")[1];
				//String productId = (redirectProductURL!= null ? redirectProductURL.split("/")[0] : "");
				String searchTerm = request.getParameter("search");
				logger.debug("searchTerm:" + request.getParameter("search"));
				return new ModelAndView("redirect:" + catalogBackendData.getRedirectUri() + ((searchTerm!= null && searchTerm!= "") ? ("?search-redirect="+searchTerm) : ""));
			}
			
			if (!Utils.isStringEmpty(catalogBackendData.getAutoCorrectedTerm()) && !"null".equals(catalogBackendData.getAutoCorrectedTerm())){
				String newUri = "/search.jsp" +  Utils.replaceQueryStringParam(request.getQueryString(), "search", catalogBackendData.getAutoCorrectedTerm());
				return new ModelAndView("redirect:" + newUri);
			}			
			
			logger.debug("returning search data: {}", catalogBackendData.getData());
			//return getCatalogMV(request, catalogData, context);
			return new ModelAndView("global-template", "pageData", catalogPageData);
		}catch (Exception ex) {
			logger.error(Utils.getErrorMessage(context, "error in getSearchResults"), ex);
			//return new ModelAndView("global-template", "pageData", catalogPageData);
			PageData errorPageData = genericPageDataFactory.getPageData(context, "error");
			return new ModelAndView("global-template", "pageData", errorPageData);
			//return webViewHelper.getErrorMv(request, ex);
		}
	}

	private CatalogPageData getCatalogPageData(HttpServletRequest request, MobileWebRequestContext context) throws Exception{
		CatalogServiceRequest catalogServiceRequest = catalogServiceRequestFactory.getCatalogServiceRequest(request, context.isTcom());
		return catalogPageDataFactory.getPageData(context, "pmp", catalogServiceRequest);
	}
	
	@GetMapping(value={"/catalog/{pageName}", "/catalog.jsp"})
	public ModelAndView getCatalogPage(HttpServletRequest request, @ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		try{
			logger.debug("recieved catalog page request for {}", request.getRequestURI());
			
 			CatalogPageData catalogPageData = getCatalogPageData(request, context);
 			CatalogBackendData catalogBackendData = catalogPageData.getCatalogBackendData();
			
			if (!Utils.isStringEmpty(catalogBackendData.getRedirectUri())){
				return new ModelAndView("redirect:" + catalogBackendData.getRedirectUri());
			}
			logger.debug("returning catalogData: {}", catalogBackendData.getData());
			return new ModelAndView("global-template", "pageData", catalogPageData);
		}catch (Exception ex) {
			logger.error(Utils.getErrorMessage(context, "error in getCatalogPage"), ex);
			PageData errorPageData = genericPageDataFactory.getPageData(context, "error");
			return new ModelAndView("global-template", "pageData", errorPageData);
		}
	}
	
	@GetMapping("/morelikethis")
	public ModelAndView getMoreLikeThis(HttpServletRequest request, @RequestParam("prdId") String productId,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		logger.debug("recieved catalog page request for {}", request.getRequestURI());
		try{
			ProductServiceRequest productServiceRequest = new ProductServiceRequest(productId, true, true);
			MoreLikeThisPageData moreLikeThisPageData = moreLikeThisPageDataFactory.getPageData(context, "more-like-this", productServiceRequest);
			return new ModelAndView("global-template", "pageData", moreLikeThisPageData);
		}catch (Exception ex) {
			logger.error(Utils.getErrorMessage(context, "error in getMoreLikeThis"), ex);
			return webViewHelper.getErrorMv(request, ex);
		}
	}
	
	@GetMapping("/robots.txt")
	public ModelAndView getRobotsFile(HttpServletRequest request, HttpServletResponse response, 
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext mobileWebRequestContext){
		response.setContentType("text/plain");
		return new ModelAndView((mobileWebRequestContext.isTcom() ? "tcom" : "mcom") + "-robots");	
	}		
}