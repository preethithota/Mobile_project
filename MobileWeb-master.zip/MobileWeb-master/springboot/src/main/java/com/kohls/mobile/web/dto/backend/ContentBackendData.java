package com.kohls.mobile.web.dto.backend;

public class ContentBackendData {
	
	private final String pageContent;
	private final String sEOContent;
	
	public ContentBackendData(String pageContent, String sEOContent) {
		this.pageContent = pageContent;
		this.sEOContent = sEOContent;
	}

	public String getPageContent() {
		return pageContent;
	}

	public String getSEOContent() {
		return sEOContent;
	}
}
