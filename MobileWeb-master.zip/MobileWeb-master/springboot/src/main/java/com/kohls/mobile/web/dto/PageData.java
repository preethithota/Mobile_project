package com.kohls.mobile.web.dto;

import java.util.Map;

import org.apache.commons.configuration2.ImmutableConfiguration;

public class PageData {
	
	private final boolean tcomMode;
	private final ImmutableConfiguration configuration;
	private final String pageName;
	private final String headerContent;
	private final String footerContent;
	private final String bannerContent;
	private final Map<String, String> assetMap;
	private final String assetPath;
	private final boolean devMode;
	
	
	public PageData(boolean tcomMode, ImmutableConfiguration configuration, String pageName, String headerContent,
			String footerContent, String bannerContent, Map<String, String> assetMap, String assetPath, boolean devMode) {
		this.tcomMode = tcomMode;
		this.configuration = configuration;
		this.pageName = pageName;
		this.headerContent = headerContent;
		this.footerContent = footerContent;
		this.bannerContent = bannerContent;
		this.assetMap = assetMap;
		this.assetPath = assetPath;
		this.devMode = devMode;
	}

	// copy constructor
	public PageData(PageData pageData){
		this.tcomMode = pageData.tcomMode;
		this.configuration = pageData.configuration;
		this.pageName = pageData.pageName;
		this.headerContent = pageData.headerContent;
		this.footerContent = pageData.footerContent;
		this.bannerContent = pageData.bannerContent;
		this.assetMap = pageData.assetMap;
		this.assetPath = pageData.assetPath;
		this.devMode = pageData.devMode;
	}

	public boolean isTcomMode() {
		return tcomMode;
	}

	public String getConfigValue(String name){
		String value = configuration.getString(name);
		return value;
	}
	
	public String getAssetPath(String bundleName){
		return assetPath + "/" + assetMap.get(bundleName);
	}

	public String getPageName() {
		return pageName;
	}

	public String getFooterContent() {
		return footerContent;
	}

	public String getHeaderContent() {
		return headerContent;
	}

	public String getBannerContent() {
		return bannerContent;
	}

	public boolean isDevMode() {
		return devMode;
	}
	
}
