package com.kohls.mobile.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.mobile.util.WebViewHelper;
import com.kohls.mobile.web.dto.ContentPageData;
import com.kohls.mobile.web.dto.MobileWebRequestContext;
import com.kohls.mobile.web.factory.pagedata.ContentPageDataFactory;

@Controller
public class ContentPageController {
	
	private static final Logger logger = LogManager.getLogger(ContentPageController.class.getName());
	
	@Autowired
	private WebViewHelper webViewHelper;
	
	@Autowired
	private ContentPageDataFactory contentPageDataFactory;
	
	@GetMapping("/")
	public ModelAndView getHomePage(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		try{
			logger.debug("recieved home page request for {}", request.getRequestURI());
			ContentPageData contentPageData = contentPageDataFactory.getPageData(context, "homepage", "/home");
			return new ModelAndView("global-template", "pageData", contentPageData);
		}catch (Exception ex) {
			logger.error("Error in getHomePage: ", ex);
			return webViewHelper.getErrorMv(request, ex);
		}
	}	
	
	@GetMapping(value={"/sale-event/{pageName}", "/feature/{pageName}"})
	public ModelAndView getContentPage(HttpServletRequest request, @PathVariable("pageName") String pageName,
			@ModelAttribute("mobileWebRequestContext") MobileWebRequestContext context){
		try{				
			ContentPageData contentPageData = contentPageDataFactory.getPageData(context, "content", request.getRequestURI());
			return new ModelAndView("global-template", "pageData", contentPageData);
		}catch(Exception e){
			String redirectUri = "/search.jsp?search=" + pageName;
			return new ModelAndView("redirect:" + redirectUri);	
		}
	}
	
}
